import test from "node:test";
import assert from "node:assert/strict";
import { JSDOM } from "jsdom";
import {
  collectLoaded,
  detectAccount,
  pageRestriction,
  profileControls,
  unfollowMenu,
  usernameFromHref,
} from "../src/extension/dom.ts";
const documentOf = (html: string) =>
  new JSDOM(html, { url: "https://www.instagram.com/alvo/" }).window.document;

// Sanitized from the observed profile/menu structure; no account or client data.
const followingProfile = '<nav><a href="/minha.conta/">Perfil</a></nav><main><header><h2>alvo</h2><button id="following">Seguindo<svg><title>Ícone de seta para baixo</title></svg></button></header></main>';
const followingMenu = (username = "alvo") => `<div role="dialog"><div><span>${username}</span></div><div><span>Amigos Próximos</span></div><div><span>Favoritos</span></div><div><span>Silenciar</span></div><div><span>Restringir</span></div><div role="button" id="unfollow"><div><span><span>Deixar de seguir</span></span></div></div></div>`;

test("Seguindo com descrição SVG mantém o estado e o botão único do perfil", () => {
  const doc = documentOf(followingProfile);
  const controls = profileControls(doc, "/alvo/", "alvo");
  assert.equal(controls.state, "followed");
  assert.equal(controls.following, doc.querySelector("#following"));
  assert.equal(controls.follow, undefined);
  doc.querySelector("header")!.insertAdjacentHTML("beforeend", "<button>Seguir</button>");
  assert.ok(profileControls(doc, "/alvo/", "alvo").error);
});

test("deixar de seguir exige menu único, identidade e todas as opções observadas", () => {
  const valid = documentOf(followingProfile + followingMenu());
  assert.equal(unfollowMenu(valid, "/alvo/", "alvo").unfollow, valid.querySelector("#unfollow"));
  for (const html of [
    followingProfile + followingMenu("outra.pessoa"),
    followingProfile + followingMenu() + '<div role="dialog">Outro diálogo</div>',
    followingProfile + '<div role="dialog"><span>alvo</span><div role="button">Deixar de seguir</div></div>',
    followingProfile + followingMenu().replace('<div><span>Restringir</span></div>', ""),
    followingProfile + followingMenu().slice(0, -6) + '<div role="button">Deixar de seguir</div></div>',
  ]) assert.equal(unfollowMenu(documentOf(html), "/alvo/", "alvo").unfollow, undefined);
  assert.equal(unfollowMenu(valid, "/outro/", "alvo").unfollow, undefined);
});

test("menu aceita textos completos PT e EN das opções, mantendo correspondência exata", () => {
  // Same DIV layout as the isolated Chrome reproduction, without roles on the four options.
  for (const [friends, favorites, mute, restrict, unfollow] of [
    ["Adicionar à lista Amigos Próximos", "Adicionar aos Favoritos", "Silenciar", "Restringir", "Deixar de seguir"],
    ["Add to close friends list", "Add to favorites", "Mute", "Restrict", "Unfollow"],
  ]) {
    const menu = `<div role="dialog"><div>alvo</div><div>${friends}</div><div>${favorites}</div><div>${mute}</div><div>${restrict}</div><div role="button" id="unfollow"><span>${unfollow}</span></div></div>`;
    const doc = documentOf(followingProfile + menu);
    assert.equal(unfollowMenu(doc, "/alvo/", "alvo").unfollow, doc.querySelector("#unfollow"));
    assert.equal(unfollowMenu(documentOf(followingProfile + menu.replace(friends, `${friends} texto adicional`)), "/alvo/", "alvo").unfollow, undefined);
  }
});

test("executor de deixar de seguir envia um único clique autorizado e para em estados incertos", async (t) => {
  const originalTimer = globalThis.setTimeout;
  const keys = ["document", "location", "chrome", "__orbita_content_v1__"];
  const descriptors = new Map(keys.map((key) => [key, Object.getOwnPropertyDescriptor(globalThis, key)]));
  const put = (key: string, value: unknown) => Object.defineProperty(globalThis, key, { configurable: true, writable: true, value });
  let serial = 0;
  try {
    // Only synthetic DOM timers are accelerated. These tests never open a browser.
    globalThis.setTimeout = ((callback: (...args: any[]) => void, _delay?: number, ...args: any[]) => originalTimer(callback, 0, ...args)) as typeof setTimeout;
    for (const scenario of ["confirmed", "additional-dialog", "already-not-following", "wrong-session", "replaced-button", "expired", "denied", "platform-warning", "unknown-after-click"] as const) {
      await t.test(scenario, async () => {
        const dom = new JSDOM(followingProfile, { url: "https://www.instagram.com/alvo/" });
        const doc = dom.window.document;
        let listener: Function | undefined;
        let opened = 0, clicked = 0;
        const authorizations: any[] = [];
        if (scenario === "already-not-following") doc.querySelector("#following")!.textContent = "Seguir";
        if (scenario === "wrong-session") doc.querySelector("nav a")!.setAttribute("href", "/outra.conta/");
        doc.querySelector("#following")!.addEventListener("click", () => {
          opened++;
          doc.body.insertAdjacentHTML("beforeend", followingMenu());
          doc.querySelector("#unfollow")!.addEventListener("click", () => {
            clicked++;
            doc.querySelector('[role="dialog"]')!.remove();
            if (scenario === "additional-dialog") doc.body.insertAdjacentHTML("beforeend", '<div role="dialog"><button>Deixar de seguir</button></div>');
            else if (scenario === "platform-warning") doc.body.insertAdjacentHTML("beforeend", '<div role="dialog">Tente novamente mais tarde</div>');
            else if (scenario === "unknown-after-click") doc.querySelector("#following")!.textContent = "Carregando";
            else doc.querySelector("#following")!.textContent = "Seguir";
          });
        });
        put("document", doc);
        put("location", dom.window.location);
        put("__orbita_content_v1__", false);
        put("chrome", { runtime: { id: "fixture-extension", onMessage: { addListener(fn: Function) { listener = fn; } }, async sendMessage(message: any) {
          if (message.type !== "AUTHORIZE_CLICK") return { ok: false };
          authorizations.push(message);
          if (scenario === "replaced-button") {
            const button = doc.querySelector("#unfollow")!;
            button.replaceWith(button.cloneNode(true));
          }
          return { ok: scenario !== "denied" };
        } } });
        await import(`../src/extension/content.ts?fixture-unfollow=${serial++}`);
        const result: any = await new Promise((resolve) => listener!({ type: "UNFOLLOW", username: "alvo", expectedAccount: "minha.conta", token: "one-use", expiresAt: Date.now() + (scenario === "expired" ? -1 : 10000) }, { id: "fixture-extension" }, resolve));
        assert.equal(result.action, "unfollow");
        if (scenario === "confirmed") {
          assert.equal(result.stage, "unfollowed");
          assert.equal(result.clickSent, true);
          assert.equal(clicked, 1);
        } else if (["additional-dialog", "platform-warning", "unknown-after-click"].includes(scenario)) {
          assert.equal(result.stage, "uncertain");
          assert.equal(result.stop, true);
          assert.equal(clicked, 1);
        } else {
          assert.equal(result.stage, "failed");
          assert.equal(result.stop, true);
          assert.equal(clicked, 0);
        }
        assert.ok(opened <= 1);
        assert.ok(authorizations.length <= 1);
        if (authorizations.length) assert.equal(authorizations[0].action, "unfollow");
        if (["already-not-following", "wrong-session", "expired"].includes(scenario)) {
          assert.equal(opened, 0);
          assert.equal(authorizations.length, 0);
        }
        if (scenario === "already-not-following") assert.match(result.message, /nenhum clique foi enviado/);
        if (scenario === "platform-warning") assert.equal(result.platformWarning, true);
        dom.window.close();
      });
    }
  } finally {
    globalThis.setTimeout = originalTimer;
    for (const key of keys) {
      const descriptor = descriptors.get(key);
      if (descriptor) Object.defineProperty(globalThis, key, descriptor);
      else delete (globalThis as any)[key];
    }
  }
});
test("identifica a conta apenas pelo menu de Perfil, não por conteúdo ou sugestões", () => {
  const doc = documentOf(
    '<nav><a href="/minha.conta/">Perfil</a></nav><main><a href="/falso/">Perfil</a><article><a href="/outro/">Profile</a></article></main>',
  );
  assert.equal(detectAccount(doc), "minha.conta");
  assert.equal(
    detectAccount(documentOf('<main><a href="/falso/">Perfil</a></main>')),
    null,
  );
  assert.equal(
    detectAccount(
      documentOf(
        '<nav><a href="/um/">Perfil</a><a href="/dois/">Profile</a></nav>',
      ),
    ),
    null,
  );
});
test("captura modal carregado e exclui links externos, rotas e conta própria", () => {
  const doc = documentOf(
    '<a href="/fora/">Sugestão fora da lista</a><div role="dialog"><a href="/ana/">ana</a><a href="/ana/">foto</a><a href="/bia/">bia</a><a href="/minha/">minha</a><a href="/explore/">Explorar</a><a href="https://evil.test/roubo/">externo</a></div>',
  );
  const result = collectLoaded(doc, "followers", "@alvo", "minha");
  assert.deepEqual(
    result.candidates.map((c) => c.username),
    ["ana", "bia"],
  );
  assert.equal(result.candidates[0].followers, undefined);
  assert.match(result.message, /parcial/);
});
test("captura recusa modais ausentes ou ambíguos", () => {
  assert.throws(() =>
    collectLoaded(
      documentOf('<main><a href="/ana/">Ana</a></main>'),
      "followers",
      "@alvo",
    ),
  );
  assert.throws(() =>
    collectLoaded(
      documentOf('<div role="dialog"></div><div role="dialog"></div>'),
      "likers",
      "url",
    ),
  );
});
test("comentários não capturam a barra lateral de sugestões", () => {
  const doc = documentOf(
    '<aside><a href="/sugerido/">Sugerido</a></aside><main><article><ul><li><a href="/ana/">Ana</a><span>Comentário</span></li><li><a href="/bia/">Bia</a></li></ul></article></main>',
  );
  assert.deepEqual(
    collectLoaded(doc, "commenters", "url").candidates.map((c) => c.username),
    ["ana", "bia"],
  );
});
test("seguir exige identidade do perfil e um único botão no cabeçalho", () => {
  const doc = documentOf(
    "<main><header><h2>alvo</h2><button>Seguir</button></header><section><button>Seguir</button></section></main>",
  );
  assert.ok(profileControls(doc, "/alvo/", "alvo").follow);
  assert.ok(profileControls(doc, "/outro/", "alvo").error);
  assert.ok(profileControls(doc, "/alvo/", "falso").error);
  const ambiguous = documentOf(
    "<main><header><h2>alvo</h2><button>Seguir</button><button>Seguir</button></header></main>",
  );
  assert.ok(profileControls(ambiguous, "/alvo/", "alvo").error);
});
test("estado existente nunca oferece clique de seguir", () => {
  for (const [label, state] of [
    ["Seguindo", "followed"],
    ["Following", "followed"],
    ["Solicitado", "requested"],
    ["Requested", "requested"],
  ]) {
    const controls = profileControls(
      documentOf(
        `<main><header><h2>alvo</h2><button>${label}</button></header></main>`,
      ),
      "/alvo/",
      "alvo",
    );
    assert.equal(controls.state, state);
    assert.equal(controls.follow, undefined);
  }
});
test("desafios e restrições interrompem; texto normal de posts não dispara bloqueio", () => {
  assert.ok(pageRestriction(documentOf(""), "/challenge/123"));
  assert.ok(
    pageRestriction(
      documentOf('<div role="dialog">Tente novamente mais tarde</div>'),
      "/alvo/",
    ),
  );
  assert.equal(
    pageRestriction(
      documentOf(
        "<article>Tente novamente mais tarde: uma história sobre viagens</article>",
      ),
      "/alvo/",
    ),
    null,
  );
});
test("links de mídia e domínios parecidos nunca viram usernames", () => {
  assert.equal(usernameFromHref("/p/abc/"), null);
  assert.equal(usernameFromHref("https://instagram.com.evil.test/ana/"), null);
  assert.equal(usernameFromHref("/ana/?x=1"), "ana");
});
test("não perde o nome em âncora duplicada depois do avatar", () => {
  const doc = documentOf(
    '<div role="dialog"><a href="/ana/"><img alt="avatar"></a><a href="/ana/">Ana Artista</a></div>',
  );
  assert.equal(
    collectLoaded(doc, "followers", "@alvo").candidates[0].name,
    "Ana Artista",
  );
});
test("autor da publicação não é incluído entre comentaristas", () => {
  const doc = documentOf(
    '<main><article><header><a href="/autor/">autor</a></header><ul><li><a href="/autor/">autor</a>Legenda</li><li><a href="/ana/">ana</a>Comentário</li></ul></article></main>',
  );
  assert.deepEqual(
    collectLoaded(doc, "commenters", "url").candidates.map((c) => c.username),
    ["ana"],
  );
});

const divComment = (
  user: string,
  id: string,
  code = "QApost",
  text = "Texto de teste",
) =>
  `<div data-row><div><a role="link" href="/${user}/"><img alt="Foto do perfil" src="https://scontent.cdninstagram.com/${user}.jpg"></a></div><div><div><div><span><a role="link" href="/${user}/"><div><span>${user}</span></div></a></span><span><a role="link" href="/p/${code}/c/${id}/"><time datetime="2026-10-10T12:00:00Z">3 sem</time></a></span></div><div><span>${text}</span></div></div><div><div role="button"><span>1 curtida</span></div><div role="button"><span>Responder</span></div></div></div><div role="button"><svg aria-label="Curtir"></svg></div></div>`;
const modernPost = (rows: string, ownerCode = "QApost") =>
  documentOf(
    `<nav><a href="/qa.nav/">qa.nav</a></nav><main role="main"><div><a href="/qa.owner/">qa.owner</a><span>Legenda de teste</span><time datetime="2026-10-10T12:00:00Z">3 sem</time></div><div>${rows}</div><div role="button"><svg aria-label="Curtir"></svg></div><a href="/qa.owner/p/${ownerCode}/"><time datetime="2026-10-10T12:00:00Z">3 semanas</time></a></main><aside><a href="/qa.suggested/">qa.suggested</a></aside>`,
  );
test("comentários DIV usam permalink da fonte e excluem autor, conta própria e menções", () => {
  const doc = modernPost(
    divComment(
      "qa.client",
      "100",
      "QApost",
      'Oi <a href="/qa.mentioned/">qa.mentioned</a>',
    ) +
      divComment("qa.owner", "101") +
      divComment("qa.own", "102") +
      divComment("qa.client", "103"),
  );
  const result = collectLoaded(
    doc,
    "commenters",
    "https://www.instagram.com/p/QApost/",
    "qa.own",
  );
  assert.deepEqual(
    result.candidates.map((c) => c.username),
    ["qa.client"],
  );
  assert.equal(
    result.candidates[0].avatarUrl,
    "https://scontent.cdninstagram.com/qa.client.jpg",
  );
});
test("comentários DIV recusam permalink de outro post e dono não confirmado pelo shortcode", () => {
  assert.throws(() =>
    collectLoaded(
      modernPost(divComment("qa.client", "100", "OtherPost")),
      "commenters",
      "https://www.instagram.com/p/QApost/",
    ),
  );
  assert.throws(() =>
    collectLoaded(
      modernPost(divComment("qa.client", "100"), "OtherPost"),
      "commenters",
      "https://www.instagram.com/p/QApost/",
    ),
  );
});
test("legenda, sugestões e linhas DIV sem ação de comentário não são candidatos", () => {
  const doc = modernPost(
    divComment("qa.client", "100").replace(
      "<span>Responder</span>",
      "<span>Ver perfil</span>",
    ),
  );
  assert.throws(() =>
    collectLoaded(doc, "commenters", "https://www.instagram.com/p/QApost/"),
  );
});
test("curtidas exigem título próprio do diálogo e não capturam comentários de um postmodal", () => {
  assert.throws(() =>
    collectLoaded(
      documentOf(
        '<div role="dialog"><div role="heading">Comentários</div><a href="/qa.commenter/">qa.commenter</a></div>',
      ),
      "likers",
      "https://www.instagram.com/p/QApost/",
    ),
  );
  const doc = documentOf(
    '<div role="dialog"><div role="heading">Publicação</div><a href="/qa.outside/">qa.outside</a><div role="dialog"><div><div role="heading">Curtidas</div><svg aria-label="Fechar"></svg></div><a href="/qa.liker/">qa.liker</a><a href="/qa.liker/">Foto</a></div></div>',
  );
  assert.deepEqual(
    collectLoaded(
      doc,
      "likers",
      "https://www.instagram.com/p/QApost/",
    ).candidates.map((c) => c.username),
    ["qa.liker"],
  );
});
test("curtidas recusam dois diálogos tipados e aceitam heading Likes", () => {
  assert.throws(() =>
    collectLoaded(
      documentOf(
        '<div role="dialog"><div role="heading">Curtidas</div></div><div role="dialog"><div role="heading">Likes</div></div>',
      ),
      "likers",
      "https://www.instagram.com/p/QApost/",
    ),
  );
  assert.deepEqual(
    collectLoaded(
      documentOf(
        '<div role="dialog"><div role="heading">Likes</div><a href="/qa.liker/">qa.liker</a></div>',
      ),
      "likers",
      "https://www.instagram.com/p/QApost/",
    ).candidates.map((c) => c.username),
    ["qa.liker"],
  );
});
