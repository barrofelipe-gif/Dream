import test from "node:test";
import assert from "node:assert/strict";
import { JSDOM } from "jsdom";
import { hostedRequest, watchExtension } from "../src/transport.ts";

const scopeA = "a".repeat(32),
  scopeB = "b".repeat(32);
const storeKey = "orbita-accounts-v2";
const turn = () => new Promise<void>((resolve) => setImmediate(resolve));
type Posted = { data: any; target: string };
function environment(metaScope: string | null = scopeA) {
  const dom = new JSDOM(
    metaScope ? `<meta name="orbita-user" content="${metaScope}">` : "",
    {
      url: "https://app.bfffitnessatacado.com.br/api/growth/orbita/painel",
      pretendToBeVisual: true,
    },
  );
  const win = dom.window,
    posts: Posted[] = [];
  win.postMessage = ((data: any, target: string) =>
    posts.push({ data, target })) as typeof win.postMessage;
  const originals = new Map<string, PropertyDescriptor | undefined>();
  for (const [key, value] of Object.entries({
    window: win,
    document: win.document,
    location: win.location,
    CustomEvent: win.CustomEvent,
    chrome: undefined,
    fetch: undefined,
  })) {
    originals.set(key, Object.getOwnPropertyDescriptor(globalThis, key));
    Object.defineProperty(globalThis, key, {
      configurable: true,
      writable: true,
      value,
    });
  }
  const receive = (data: any, origin = win.location.origin) =>
    win.dispatchEvent(
      new win.MessageEvent("message", {
        source: win as unknown as Window,
        origin,
        data,
      }),
    );
  const respond = (posted: Posted, result: any) =>
    receive({
      channel: "orbita-extension-response",
      id: posted.data.id,
      result,
    });
  const changed = () =>
    receive({ channel: "orbita-extension-changed", keys: [storeKey] });
  const close = () => {
    dom.window.close();
    for (const [key, descriptor] of originals) {
      if (descriptor) Object.defineProperty(globalThis, key, descriptor);
      else Reflect.deleteProperty(globalThis, key);
    }
  };
  return { win, posts, receive, respond, changed, close };
}

test("uma mutação com timeout não é reenviada e uma resposta atrasada não inicia outra chamada", async () => {
  const env = environment();
  try {
    const request = hostedRequest(
      { type: "COMMAND", command: { type: "START" }, workspaceId: "qa" },
      5,
    );
    await assert.rejects(request, /Nenhuma ação será repetida automaticamente/);
    env.respond(env.posts[0], { ok: true });
    await turn();
    assert.equal(env.posts.length, 1);
  } finally {
    env.close();
  }
});

test("timer adiantado aguarda o deadline declarado sem reenviar a solicitação", async (t) => {
  const env = environment();
  let clock = 1_800_000_000_000,
    settled = false;
  t.mock.method(Date, "now", () => clock);
  t.mock.timers.enable({ apis: ["setTimeout"] });
  try {
    const request = hostedRequest(
      { type: "COMMAND", workspaceId: "qa", command: { type: "START" } },
      10,
    ).then(
      (result) => {
        settled = true;
        return { result };
      },
      (error: Error) => {
        settled = true;
        return { error };
      },
    );
    const sent = env.posts[0];
    assert.equal(sent.data.expiresAt, clock + 10);
    t.mock.timers.tick(10);
    await Promise.resolve();
    assert.equal(
      settled,
      false,
      "o callback não pode encerrar antes de expiresAt",
    );
    clock += 9;
    t.mock.timers.tick(10);
    await Promise.resolve();
    assert.equal(
      settled,
      false,
      "a espera restante ainda precisa respeitar o deadline",
    );
    clock += 1;
    t.mock.timers.tick(1);
    const outcome = await request;
    assert.ok("error" in outcome);
    assert.match(outcome.error.message, /não respondeu/i);
    env.respond(sent, { ok: true });
    await Promise.resolve();
    assert.equal(
      env.posts.length,
      1,
      "reagendar a espera não pode reenviar a operação",
    );
  } finally {
    t.mock.restoreAll();
    t.mock.timers.reset();
    env.close();
  }
});

test("resposta limpa o timer reagendado depois de um callback adiantado", async (t) => {
  const env = environment();
  let clock = 1_800_000_000_000;
  const callbacks: Array<() => void> = [];
  t.mock.method(Date, "now", () => clock);
  const scheduled = t.mock.method(globalThis, "setTimeout", ((
      callback: () => void,
    ) => {
      callbacks.push(callback);
      return callbacks.length;
    }) as unknown as typeof setTimeout),
    cleared = t.mock.method(globalThis, "clearTimeout", () => {});
  try {
    const request = hostedRequest({ type: "GET_STATE" }, 10);
    const observed = request.then(
      (result) => ({ result }),
      (error: Error) => ({ error }),
    );
    callbacks[0]();
    assert.equal(
      scheduled.mock.calls.length,
      2,
      "o callback adiantado agenda somente a espera restante",
    );
    const remainingTimer = scheduled.mock.calls[1].result;
    clock += 3;
    env.respond(env.posts[0], { ok: true, store: { activeId: "qa" } });
    assert.deepEqual(await observed, {
      result: { ok: true, store: { activeId: "qa" } },
    });
    assert.ok(
      cleared.mock.calls.some((call) => call.arguments[0] === remainingTimer),
      "a resposta deve cancelar o timer atual, não apenas o timer original",
    );
    callbacks[1]();
    assert.equal(scheduled.mock.calls.length, 2);
    assert.equal(env.posts.length, 1);
  } finally {
    t.mock.restoreAll();
    env.close();
  }
});

test("rajadas de invalidação usam uma leitura por vez e publicam o estado mais recente sem alterar controles", async () => {
  const env = environment(),
    seen: any[] = [];
  env.win.orbitaHostedConnected = true;
  const stop = watchExtension((changes) => seen.push(changes), storeKey);
  try {
    env.changed();
    env.changed();
    env.changed();
    assert.equal(
      env.posts.length,
      1,
      "invalidações concorrentes precisam ser agrupadas",
    );
    env.respond(env.posts[0], { ok: true, store: { activeId: "old" } });
    await turn();
    assert.equal(
      env.posts.length,
      2,
      "uma única leitura posterior deve cobrir a mudança pendente",
    );
    const latest = {
      activeId: "qa",
      accounts: [
        {
          id: "qa",
          data: {
            runtime: {
              mode: "paused",
              pendingWarning: true,
              sessionAttempts: 3,
            },
            candidates: [{ username: "fixture", stage: "approved" }],
          },
        },
      ],
    };
    env.respond(env.posts[1], { ok: true, store: latest });
    await turn();
    assert.equal(seen.length, 1);
    assert.deepEqual(seen[0][storeKey].newValue, latest);
    assert.ok(env.posts.every((p) => p.data.message.type === "GET_STATE"));
  } finally {
    stop();
    env.close();
  }
});

test("polling não acumula leituras enquanto uma leitura anterior está lenta", async (t) => {
  const env = environment(),
    seen: any[] = [];
  env.win.orbitaHostedConnected = true;
  t.mock.timers.enable({ apis: ["setInterval"] });
  const stop = watchExtension((changes) => seen.push(changes), storeKey);
  try {
    env.changed();
    t.mock.timers.tick(30000);
    assert.equal(env.posts.length, 1);
    env.respond(env.posts[0], { ok: true, store: { activeId: "qa" } });
    await turn();
    assert.equal(seen.length, 1);
    assert.equal(
      env.posts.length,
      1,
      "polls ignorados não deixam leituras extras na fila",
    );
    t.mock.timers.tick(15000);
    assert.equal(env.posts.length, 2);
    env.respond(env.posts[1], { ok: true, store: { activeId: "qa" } });
    await turn();
    stop();
    t.mock.timers.tick(30000);
    assert.equal(env.posts.length, 2);
  } finally {
    stop();
    t.mock.timers.reset();
    env.close();
  }
});

test("somente uma nova leitura válida de estado sinaliza recuperação, sem reenviar mutações", async () => {
  const env = environment();
  env.win.orbitaHostedConnected = true;
  let errors = 0,
    recovered = 0,
    updates = 0;
  env.win.addEventListener("orbita-transport-error", () => errors++);
  env.win.addEventListener("orbita-transport-recovered", () => recovered++);
  const stop = watchExtension(() => updates++, storeKey);
  try {
    env.changed();
    env.respond(env.posts[0], { ok: false, error: "Leitura indisponível" });
    await turn();
    assert.equal(errors, 1);
    assert.equal(recovered, 0);
    assert.equal(updates, 0);
    env.changed();
    env.respond(env.posts[1], { ok: true, store: { activeId: "qa" } });
    await turn();
    assert.equal(recovered, 1);
    assert.equal(updates, 1);
    env.changed();
    env.respond(env.posts[2], { ok: true, store: { activeId: "qa" } });
    await turn();
    assert.equal(recovered, 1);
    env.changed();
    stop();
    env.respond(env.posts[3], { ok: false, error: "Depois do fechamento" });
    await turn();
    assert.equal(errors, 1);
    assert.equal(recovered, 1);
    assert.ok(env.posts.every((p) => p.data.message.type === "GET_STATE"));
  } finally {
    stop();
    env.close();
  }
});

async function loadRelay(
  env: ReturnType<typeof environment>,
  runtime: (message: any) => Promise<any>,
  session: () => any,
) {
  Object.defineProperty(globalThis, "chrome", {
    configurable: true,
    value: { runtime: { sendMessage: runtime } },
  });
  Object.defineProperty(globalThis, "fetch", {
    configurable: true,
    value: async () => ({ ok: true, json: async () => session() }),
  });
  await import(
    `../src/extension/hosted-content.ts?fixture=${crypto.randomUUID()}`
  );
  const send = (id: string, message: any) =>
    env.receive({ channel: "orbita-extension-request", id, message });
  return send;
}

test("troca de usuário do app recusa a mutação antes de chegar ao worker", async () => {
  const env = environment(),
    calls: any[] = [];
  let currentScope = scopeA;
  try {
    const send = await loadRelay(
      env,
      async (message) => {
        calls.push(message);
        return { ok: true };
      },
      () => ({ ready: true, userScope: currentScope }),
    );
    send("connect", { type: "HOSTED_CONNECT" });
    await turn();
    assert.equal(calls.length, 1);
    currentScope = scopeB;
    send("mutation", {
      type: "ACCOUNT_COMMAND",
      expectedActiveId: "qa",
      command: { type: "ADD_ACCOUNT", username: "qa.denied" },
    });
    await turn();
    assert.equal(
      calls.length,
      1,
      "o worker não pode receber a mutação de um login diferente",
    );
    assert.match(
      env.posts.find((p) => p.data.id === "mutation")?.data.transportError,
      /sessão|usuário/i,
    );
  } finally {
    env.close();
  }
});

test("página sem identidade válida não estabelece conexão com o worker", async () => {
  const env = environment(null),
    calls: any[] = [];
  try {
    const send = await loadRelay(
      env,
      async (message) => {
        calls.push(message);
        return { ok: true };
      },
      () => ({ ready: true, userScope: scopeA }),
    );
    send("connect", { type: "HOSTED_CONNECT" });
    await turn();
    assert.equal(calls.length, 0);
    assert.ok(
      env.posts.find((p) => p.data.id === "connect")?.data.transportError,
    );
  } finally {
    env.close();
  }
});

test("saturação do conector responde imediatamente sem encaminhar ou repetir a solicitação excedente", async () => {
  const env = environment(),
    pending: Array<(value: any) => void> = [],
    calls: any[] = [];
  try {
    const send = await loadRelay(
      env,
      async (message) => {
        calls.push(message);
        if (message.type === "HOSTED_CONNECT") return { ok: true };
        return new Promise((resolve) => pending.push(resolve));
      },
      () => ({ ready: true, userScope: scopeA }),
    );
    send("connect", { type: "HOSTED_CONNECT" });
    await turn();
    for (let i = 0; i < 30; i++) send(`read-${i}`, { type: "GET_STATE" });
    await turn();
    send("overflow", {
      type: "COMMAND",
      workspaceId: "qa",
      command: { type: "START" },
    });
    await turn();
    assert.ok(
      env.posts.find((p) => p.data.id === "overflow")?.data.transportError,
    );
    assert.equal(calls.length, 31);
    assert.equal(calls.filter((m) => m.type === "COMMAND").length, 0);
  } finally {
    for (const resolve of pending) resolve({ ok: true });
    await turn();
    env.close();
  }
});

test("autenticação lenta não encaminha uma mutação depois do timeout do solicitante", async () => {
  const env = environment(),
    calls: any[] = [];
  let release!: (value: any) => void;
  try {
    const send = await loadRelay(
      env,
      async (message) => {
        calls.push(message);
        return { ok: true };
      },
      () => ({ ready: true, userScope: scopeA }),
    );
    send("connect", { type: "HOSTED_CONNECT" });
    await turn();
    Object.defineProperty(globalThis, "fetch", {
      configurable: true,
      value: () =>
        new Promise((resolve) => {
          release = resolve;
        }),
    });
    const request = hostedRequest(
      { type: "COMMAND", workspaceId: "qa", command: { type: "START" } },
      10,
    );
    const sent = env.posts.find(
      (p) => p.data.channel === "orbita-extension-request",
    )!;
    env.receive(sent.data);
    await assert.rejects(request, /não respondeu|prazo/i);
    release({
      ok: true,
      json: async () => ({ ready: true, userScope: scopeA }),
    });
    await turn();
    await turn();
    assert.equal(
      calls.length,
      1,
      "a autorização tardia não pode iniciar a mutação após o timeout",
    );
    assert.equal(calls[0].type, "HOSTED_CONNECT");
  } finally {
    env.close();
  }
});
