export function hostedSessionMatches(
  data: unknown,
  expectedScope: string | null | undefined,
): boolean {
  return (
    typeof expectedScope === "string" &&
    /^[a-f0-9]{32}$/.test(expectedScope) &&
    !!data &&
    typeof data === "object" &&
    (data as { ready?: unknown }).ready === true &&
    (data as { userScope?: unknown }).userScope === expectedScope
  );
}

export function supportedHostedExtension(version: unknown): boolean {
  if (typeof version !== "string" || !/^\d+\.\d+\.\d+(?:\.\d+)?$/.test(version))
    return false;
  const [major, minor] = version.split(".").map(Number);
  return major > 0 || minor >= 17;
}
