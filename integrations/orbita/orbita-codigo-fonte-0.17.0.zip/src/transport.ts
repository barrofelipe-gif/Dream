import { hostedStorageKey, trustedHostedPage } from "./core/hosted.ts";
declare global {
  interface Window {
    orbitaHostedConnected?: boolean;
  }
}
export const nativeExtension = () =>
  typeof chrome !== "undefined" &&
  !!chrome.runtime?.id &&
  location.protocol === "chrome-extension:";
export const extensionAvailable = () =>
  nativeExtension() || !!window.orbitaHostedConnected;
export function storageKey(key: string): string {
  const user = document
    .querySelector('meta[name="orbita-user"]')
    ?.getAttribute("content");
  return hostedStorageKey(key, user, trustedHostedPage(location.href));
}
export function hostedRequest(message: object, timeout = 45000): Promise<any> {
  return new Promise((resolve, reject) => {
    const id = crypto.randomUUID();
    const expiresAt = Date.now() + timeout;
    let timer: ReturnType<typeof setTimeout>,
      settled = false;
    const cleanup = () => {
      clearTimeout(timer);
      window.removeEventListener("message", listener);
    };
    const listener = (event: MessageEvent) => {
      if (
        settled ||
        event.source !== window ||
        event.origin !== location.origin ||
        event.data?.channel !== "orbita-extension-response" ||
        event.data.id !== id
      )
        return;
      settled = true;
      cleanup();
      if (event.data.transportError)
        reject(new Error(event.data.transportError));
      else resolve(event.data.result);
    };
    const expire = () => {
      if (settled) return;
      // Some platforms dispatch timers slightly early. Use the same wall-clock
      // deadline as the relay; rescheduling this wait never resends the request.
      const remaining = expiresAt - Date.now();
      if (remaining > 0) {
        timer = setTimeout(expire, remaining);
        return;
      }
      settled = true;
      cleanup();
      reject(
        new Error(
          "A extensão não respondeu. Confira a instalação e o resultado da operação antes de tentar novamente. Nenhuma ação será repetida automaticamente.",
        ),
      );
    };
    timer = setTimeout(expire, timeout);
    window.addEventListener("message", listener);
    window.postMessage(
      { channel: "orbita-extension-request", id, message, expiresAt },
      location.origin,
    );
  });
}
export function sendExtension(message: object): Promise<any> {
  if (nativeExtension()) return chrome.runtime.sendMessage(message);
  if (window.orbitaHostedConnected) return hostedRequest(message);
  return Promise.reject(
    new Error("Conecte a extensão antes de usar o Instagram."),
  );
}
export function watchExtension(
  listener: (
    changes: Record<string, chrome.storage.StorageChange>,
    area: string,
  ) => void,
  key: string,
) {
  if (nativeExtension()) {
    chrome.storage.onChanged.addListener(listener);
    return () => chrome.storage.onChanged.removeListener(listener);
  }
  let alive = true,
    reading = false,
    invalidated = false,
    stateReadFailed = false;
  const refresh = async (invalidation: boolean) => {
    if (!alive) return;
    if (reading) {
      // A mutation may have completed after the current snapshot started.
      // Poll ticks need no extra read; a real invalidation needs one fresh read.
      if (invalidation) invalidated = true;
      return;
    }
    reading = true;
    try {
      const changes: Record<string, chrome.storage.StorageChange> = {
        [key]: {},
      };
      if (key === "orbita-accounts-v2") {
        const response = await sendExtension({ type: "GET_STATE" });
        if (!response?.ok)
          throw new Error(
            response?.error || "Não foi possível atualizar as contas.",
          );
        changes[key] = { newValue: response.store };
      }
      if (alive && !invalidated) {
        listener(changes, "local");
        if (key === "orbita-accounts-v2" && stateReadFailed) {
          stateReadFailed = false;
          window.dispatchEvent(new CustomEvent("orbita-transport-recovered"));
        }
      }
    } catch (error) {
      if (alive) {
        if (key === "orbita-accounts-v2") stateReadFailed = true;
        window.dispatchEvent(
          new CustomEvent("orbita-transport-error", { detail: String(error) }),
        );
      }
    } finally {
      reading = false;
      if (invalidated && alive) {
        invalidated = false;
        void refresh(false);
      }
    }
  };
  const changed = (event: Pick<MessageEvent, "source" | "origin" | "data">) => {
    if (
      event.source === window &&
      event.origin === location.origin &&
      event.data?.channel === "orbita-extension-changed" &&
      Array.isArray(event.data.keys) &&
      event.data.keys.includes(key)
    )
      void refresh(true);
  };
  window.addEventListener("message", changed);
  // chrome.storage remains restricted to trusted extension contexts. Poll only
  // local state while visible, covering alarms and edits from the native panel.
  const poll = setInterval(() => {
    if (document.visibilityState === "visible") void refresh(false);
  }, 15000);
  const visible = () => {
    if (document.visibilityState === "visible") void refresh(false);
  };
  document.addEventListener("visibilitychange", visible);
  return () => {
    alive = false;
    clearInterval(poll);
    window.removeEventListener("message", changed);
    document.removeEventListener("visibilitychange", visible);
  };
}
