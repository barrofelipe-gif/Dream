# Órbita

Aplicativo local para organizar públicos do Instagram, revisar candidatos e executar uma fila de ações pelo navegador. Versão: **0.15.0**, com dashboard colorido, comparativo que explica as vantagens e lacunas, central de problemas, recuperação limitada de leitura, radar do setor, referências e planos de teste, alertas de desempenho, várias contas, origens dos seguidores, análise de reciprocidade, perfis protegidos, Stories e orientação por horários.

O visual usa navegação escura, cartões em roxo, azul, coral e verde, ícones por família de métricas e gráficos coloridos. As cores dos cartões identificam categorias; variações favoráveis e desfavoráveis continuam indicadas por texto, sinal e ícone, com destaque vermelho para pioras. Dados ausentes permanecem identificados, sem preencher números ou gráficos fictícios.

As fotos de perfil aparecem ao lado dos @ nas contas, listas e detalhes. Na extensão, **Conectar sessão** lê a foto da conta quando disponível no menu ou cabeçalho confirmado; **Atualizar métricas** também pode renová-la. A captura de listas aproveita a foto ligada ao mesmo @ já carregado, sem abrir cada perfil para buscar uma imagem. As telas de relações e origens reutilizam fotos conhecidas naquela conta. Cadastrar apenas um @ não garante uma foto imediata: imagem ausente, expirada ou com falha volta às iniciais. As URLs aceitas são HTTPS nas CDNs do Instagram/Meta; o app não usa serviços externos de busca de avatar. Os endereços ficam no cadastro local e nos backups, não os arquivos das imagens. CSV aceita `avatar_url`, `profile_picture_url` ou `foto_url`; a exportação inclui `avatar_url`.

## Usar dentro do app BFF

Abra **Growth → Instagram → Crescimento · Órbita** com seu login de administrador. Instale ou atualize a extensão 0.15.0 pelo download do painel, atualize a página e clique em **Conectar extensão neste navegador**. O painel usa o mesmo cadastro local da extensão, sem copiar a fila para outro armazenamento. O conector aceita apenas as duas origens HTTPS do app e a rota `/api/growth/orbita/painel`; cada operação confere novamente a sessão do app. Conectar o painel não inicia a fila nem confirma a conta do Instagram.

**Modo manual** usa armazenamento separado por usuário do app e navegador. Dados não são sincronizados entre computadores. Não há coleta nem execução sem a extensão. A seleção do @ dentro da Órbita é independente da empresa escolhida no atendimento do app. Exporte backups antes de trocar de navegador. A integração não implementa sincronização automática da API de Insights.

## Usar a extensão — sem instalar dependências

1. Descompacte `orbita-0.15.0.zip` em uma pasta permanente.
2. Abra `chrome://extensions` no Chrome ou `edge://extensions` no Edge.
3. Ative **Modo do desenvolvedor**.
4. Clique em **Carregar sem compactação** e selecione a pasta `dist`.
5. Fixe o ícone da Órbita e clique nele para abrir o painel.
6. Em **Contas**, cadastre o @perfil que você gerencia. Entre nessa conta pelo próprio Instagram e clique em **Conectar sessão** no painel. A identificação usa o link **Perfil / Profile** da navegação; se a interface não permitir confirmar a conta, a execução permanece indisponível.

A extensão não solicita senha nem lê cookies. As permissões incluem o Instagram e o conector nas rotas exatas do painel dos domínios `app.bfffitnessatacado.com.br` e `bff-painel-pendencias.vercel.app`, armazenamento local ampliado para várias listas, agendamento e injeção do próprio coletor. A extensão mantém os dados no navegador. A integração com o app BFF confere a sessão do app; não envia as listas ao servidor. As páginas do Instagram continuam fazendo suas próprias conexões normais.

Para atualizar uma instalação existente, exporte o backup de cada conta, substitua os arquivos na mesma pasta `dist` já carregada e clique em **Recarregar** na entrada existente da extensão. Uma pasta diferente pode criar outra instalação, com armazenamento separado.

## Várias contas e dashboards

- Use **Contas → Adicionar conta** e depois o seletor no alto do painel. Cada @perfil tem campanhas, público, anotações, fila, preferências, avisos, contadores e histórico próprios. O mesmo candidato pode estar salvo em contas diferentes.
- **Pessoais e profissionais no mesmo painel:** informe o tipo no cadastro ou ajuste em Contas/dashboard: pessoal, profissional comercial ou profissional criador. É uma informação manual sobre o cadastro existente no Instagram. Contas antigas ficam como tipo não informado, sem inferência pelo nome. A escolha fica separada por conta e não é uma verificação da Meta.
- Todos os tipos podem usar contadores do perfil e relatórios locais. Se sua conta pessoal disponibilizar Insights no aplicativo, você pode registrá-los/importá-los. O acesso à API oficial de conta exige um perfil profissional e permissões próprias; a sincronização automática permanece não implementada nesta versão. Informar um tipo profissional no painel não concede autorização da API. Os backups guardam o tipo; ao restaurar, uma escolha atual conhecida é preservada.
- A troca pausa a fila anterior e remove sua autorização pendente. Durante uma ação já iniciada, aguarde o resultado antes de trocar. Uma tarefa que ainda está retornando permanece vinculada ao espaço de origem.
- **Uma conta executa por vez.** Cadastrar várias contas não cria logins independentes. O Instagram usa a sessão ativa no navegador; troque a conta no próprio Instagram e verifique a sessão da conta selecionada. A extensão não troca login automaticamente e não permite executar uma fila com uma sessão diferente da conta cadastrada.
- O dashboard mostra seguidores, contas seguidas, publicações, variação entre medições, gráfico de evolução e tentativas por dia. Confirmações de “Seguindo” e solicitações enviadas são ações realizadas pela Órbita; não são seguidores recebidos nem clientes conquistados.
- **Atualizar métricas** abre o próprio perfil e lê os contadores disponíveis após conferir sessão e cabeçalho. Contagens abreviadas sem valor exato ficam desconhecidas. Use **Medição manual** para registrar valores observados, com a origem manual visível. Valores ausentes ficam em branco, sem estimativas. A variação compara medições disponíveis e não demonstra causalidade das ações.
- O histórico armazena até 730 medições por conta; os detalhes mostram as 30 mais recentes e a exportação inclui todas. Períodos de 7 e 30 dias incluem o dia atual. Cada contador exibe a data da sua última medição disponível.
- O backup é por conta. Selecione a conta correspondente para restaurar; um backup de outro perfil é rejeitado. Restaurar no espaço inicial vazio pode identificar a conta do backup, mas exige verificar novamente a sessão.

Ao atualizar da versão 0.1.x, o espaço antigo é migrado para uma conta, preservando listas, preferências e controles. A fila fica pausada e a verificação da sessão precisa ser refeita. A chave antiga permanece guardada como cópia local; exporte seus backups antes de remover a extensão.

## Problemas, recuperação e correções

Abra **Problemas e correções** no menu. Falhas retornadas pelas operações do painel/serviço, erros visíveis com `role=alert`, erros de execução do dashboard e falhas de renderização são registrados localmente. Resultados incertos ou malsucedidos da fila e avisos da plataforma também recebem registro, mantendo os controles já existentes. A captura não é um monitor de todos os erros internos ou de toda a página do Instagram: cobre os pontos instrumentados da Órbita e as falhas que chegam a eles.

Os registros ficam na chave separada `orbita-problems-v1`; o cadastro das contas continua em `orbita-accounts-v2`. Assim o diagnóstico pode ser consultado mesmo quando a leitura do cadastro falhar. Um problema mostra mensagem resumida, categoria, conta/espaço, operação, primeira/última ocorrência e histórico. Cada conta vê seus registros e os do painel geral, sem misturar problemas das demais contas. Falhas iguais na mesma operação/categoria/conta são agrupadas, com contagem acumulada. Uma nova ocorrência reabre o grupo, preservando os eventos recentes de investigação e resolução.

- **Recuperação conservadora:** somente `GET_STATE`, a leitura inicial do estado do painel, pode ser repetida automaticamente uma vez, após 250 ms, se houver falha de transporte reconhecida. Uma resposta explícita de erro do serviço, formato inválido ou problema de armazenamento não dispara repetição. Sucesso da segunda leitura marca **Recuperado · observar**, sem declarar a causa corrigida. Falhar novamente encerra as tentativas e preserva a mensagem real. Falha no diagnóstico não deve transformar a leitura bem-sucedida em erro nem esconder o erro original.
- **Ações e mutações:** seguir, solicitações, mensagens, início da fila, importações, gravações e leitura de páginas do Instagram não entram nesse mecanismo. Resultados incertos exigem conferir o próprio perfil. Resolver um registro não altera avisos, tentativas consumidas, fila, autorização ou sessão. Não há tentativa de ultrapassar login ou bloqueio.
- **Acompanhamento:** use **Acompanhar problema** para anotar investigação, registrar a correção e como foi conferida. **Resolvido pelo usuário** é uma declaração manual; a central não comprova sozinha que um defeito foi eliminado. **Registrar problema** permite descrever uma falha que não foi capturada automaticamente. **Reabrir painel** apenas recarrega a interface e não reaplica uma ação no Instagram.
- **Falha de interface:** um limite de erro do React apresenta diagnóstico e opção de reabrir o painel, em vez de depender de uma tela vazia. Se o defeito persistir após recarregar, o código ainda precisa de correção.
- **Privacidade:** não copiamos os arquivos importados, listas, campos de formulário ou objetos inteiros de comandos para o diagnóstico. Mensagens e notas são resumidas a 600 caracteres; links, JWTs e campos reconhecidos de credenciais são omitidos. Erros de interpretação JSON usam uma mensagem genérica para não expor trechos do arquivo. Isso não é uma garantia de reconhecer qualquer segredo sem rótulo: revise o JSON antes de compartilhar.
- **Retenção e falha do registro:** até 1.000 grupos no armazenamento local compartilhado, priorizando descarte dos resolvidos mais antigos; se necessário, os demais mais antigos podem sair. O painel informa os totais descartados, inclusive os ainda abertos. Cada grupo mantém até 12 eventos recentes e sua contagem de ocorrências. Se a persistência do diagnóstico falhar, os novos registros ficam somente na memória da sessão, com aviso para exportar antes de fechar. Nenhum cadastro corrompido é zerado como tentativa de reparo.

**Exportar diagnóstico** gera JSON da conta selecionada e do painel geral, incluindo a indicação dos registros que só existem na sessão. Se o histórico persistente estiver ilegível, o botão indica diagnóstico disponível e o JSON informa `persistentHistoryReadable=false`; o arquivo não representa o histórico completo que não pôde ser lido. O diagnóstico é separado do backup da conta; exporte-o pela central para levar o histórico. Atualizações na mesma instalação preservam a chave local. Não há telemetria, envio automático para desenvolvedores, acesso automático ao código-fonte ou instalação de correções pela extensão.

No desenvolvimento, [AGENTS.md](AGENTS.md) determina o registro de defeitos em [docs/REGISTRO-DE-PROBLEMAS.md](docs/REGISTRO-DE-PROBLEMAS.md), com reprodução, correção e validação verdadeira antes de concluir. O histórico de código complementa os registros da aplicação; receber um diagnóstico não equivale a corrigir o defeito.

## Radar do setor: referências, oportunidades e testes

Abra **Radar do setor** no menu de cada conta. Em **Identificar meu setor**, a extensão pode abrir seu perfil, conferir a sessão e trazer o texto do cabeçalho carregado. Você também pode informar a bio manualmente. Palavras como fitness, biquíni, atacado e varejo produzem uma sugestão simples, que precisa da sua confirmação. Não há análise visual do vídeo ou inferência confiável de setor só pelo @nome. Configure setor, modelo de venda e público por conta; fitness no atacado e biquínis no varejo não compartilham bases automaticamente.

- **Referências:** adicione um link de perfil, post, Reel, anúncio específico da Biblioteca da Meta ou página pública. Na extensão, **Ler página** consulta um único link do Instagram e traz texto carregado e contagens exatas reconhecidas para revisão. O autor da publicação e o padrão precisam ser conferidos manualmente. A página pode não permitir leitura; a função não ultrapassa login, verificação, conteúdo privado ou estrutura desconhecida. Contagens abreviadas/ambíguas ficam ausentes; não há estimativa de visualizações privadas, salvamentos ou vendas. Capturar a referência não executa follow, DM ou publicação.
- **Recorte:** mostra observações dos últimos 30/90 dias ou histórico, do setor e modelo configurados, incluindo referências que atendem ambos os modelos. Modelo desconhecido continua visível para revisão, sem entrar como modelo confirmado na comparação de padrões ou nos destaques. Configurar o próprio modelo como desconhecido desabilita os destaques até contextualizar o negócio. Fontes pagas e orgânicas são identificadas; desconhecido não vira orgânico. A ordem por visualizações mostra totais observados, sem afirmar que conteúdos de idades diferentes tiveram desempenho equivalente.
- **Destaque na amostra:** exige Reel de perfil identificado e pelo menos 5 outros Reels do mesmo autor, setor, modelo de venda, distribuição conhecida e janela declarada. Publicações e observações precisam estar no recorte. Uma referência é sinalizada com pelo menos 2× a mediana dos outros conteúdos; base zero não gera razão. Datas de publicação e observação devem diferir da janela em até 30 minutos. São controles do produto, não prova de viralização, causa de crescimento ou ranking de todo o Instagram. Não misturamos anúncios e conteúdo orgânico para essa conta.
- **Comparar comigo:** cruza os padrões classificados nas referências com palavras de título, tema e abertura dos conteúdos de um único relatório próprio selecionado. Não soma revisões nem mistura contas. A correspondência é uma sugestão textual, não análise audiovisual. “Nenhum encontrado” significa ausência naquele recorte, não que você nunca publicou esse padrão.
- **Adaptar para mim:** gera um roteiro revisável por regras do setor, padrão e público, com hipótese, chamada para ação, métrica e janela de teste. Use sua gravação, identidade e informações reais. O recurso não copia o vídeo, não prevê vendas e não publica. Salve a ideia, marque em teste e vincule o link da sua publicação.
- **Medição própria:** o plano encontra esse link nos Insights salvos da mesma conta e usa a revisão mais recente encontrada. Só sinaliza janela compatível quando o relatório tem cobertura conhecida, valores do período e a mesma janela em horas. Métrica ausente não vira zero; marcar o teste como medido não cria resultados nem comprova autoria. A tela mostra o valor próprio e seu contexto, sem chamar diferença entre contas de efeito causal.
- **Pesquisa inicial:** fontes públicas consultadas em 03/11/2026 sobre comunicação de fitness e moda praia para lojistas, além de um anúncio de fitness encontrado pela busca da Biblioteca da Meta. As hipóteses são nossas inferências, não resultados comprovados dessas marcas. O Instagram impediu a consulta pública direta de alguns perfis; não há números de Reels inventados. A busca da Meta via ferramenta conectada usada durante o desenvolvimento não é uma integração automática do aplicativo.

Botões de pesquisa abrem buscas externas para revisar novas fontes; não rodam um monitor automático de tendências. A leitura de página funciona apenas na extensão instalada, usa a sessão local e requer a fila pausada. A API oficial de descoberta de outras contas profissionais depende de autorização e disponibilidade e não está integrada. Referência técnica: [coleção da Meta para Instagram](https://www.postman.com/meta/instagram/documentation/6yqw8pt/instagram-api).

Importação JSON no modelo Órbita, até 2 MB e 500 referências por lote/conta: `{ "account": "seu.perfil", "references": [...] }`. Baixe o modelo na tela. Links idênticos são atualizados, preservando identificador, arquivamento e vínculo dos testes; duplicatas no mesmo lote e erros invalidam o lote todo. Até 200 testes por conta. Exportar referências não exporta os testes; o **backup da conta** guarda o radar completo, setor, referências e testes. Restauração preserva versões mais recentes, incluindo arquivamento, e remapeia vínculos quando o mesmo link já tem outro identificador local.

## Alertas de desempenho e recuperação

No dashboard da conta, **Onde melhorar agora** organiza os pontos de atenção do relatório selecionado. Vermelho significa diferença desfavorável em pelo menos uma base disponível; o quadro informa o valor, a referência, o que testar e como medir o próximo ciclo. Um indicador pode melhorar frente à última semana e continuar abaixo da própria média histórica. Indicadores favoráveis ficam em uma área verde. Nos cartões de Resumo e Todas as métricas, **Ver plano de melhoria** leva à explicação do destaque vermelho.

A base histórica usa até seis períodos anteriores, de mesma duração, conta e cobertura, sem sobreposição e dentro dos 180 dias anteriores. Exige pelo menos três valores disponíveis por indicador. Para totais, usa a média dos períodos; para engajamento, soma as interações e divide pela soma do alcance. Não agrega médias de tempo assistido nem taxas de pulos sem denominadores conhecidos. Ausências não são zero. Revisões do mesmo intervalo não entram duas vezes.

**Informar referência do setor** cadastra uma referência manual de engajamento, com fonte HTTPS, datas, cobertura, amostra e o setor/modelo definido no Radar. A fórmula aceita é interações ÷ alcance × 100 no agregado da conta. Não são equivalentes taxas por seguidores, visualizações ou por publicação. O mínimo operacional é de cinco contas; isso não garante representatividade. Setor, modelo, cobertura e duração precisam coincidir; fontes posteriores ao relatório ou mais de 180 dias anteriores ficam suspensas. O painel usa a referência declarada, sem verificar a fonte automaticamente ou tratá-la como média de todo o mercado. Nenhum percentual genérico foi aplicado aos seus perfis.

As referências pertencem à conta, persistem no cadastro local e no backup; salvar ou remover uma referência não altera a fila, avisos ou tentativas. **Exportar diagnóstico** inclui todos os pontos de atenção, indicadores favoráveis, bases, métodos e fontes mesmo quando a tela mostra só os primeiros cartões. Veja [os critérios e as fontes consultadas](docs/REFERENCIAS-DE-DESEMPENHO.md).

O detalhamento **O que precisa de atenção**, dentro de **Ver detalhes da comparação com o período anterior**, preserva os alertas originais. Eles incluem quedas e aumentos desfavoráveis: perdas de seguidores e pulos maiores contam como piora; reduções contam como melhora. Quantidade publicada e navegação bruta de Stories ficam como contexto.

Cada cartão mostra os valores anterior e atual, variação percentual quando a base é positiva, diferença absoluta e, em taxas, **pontos percentuais**. Base zero permite diferença absoluta, sem percentual inventado. Abra **O que verificar e testar** para um roteiro específico e a referência anterior a acompanhar. **Ver publicações do período** e **Abrir Aprendizados** levam aos dados do relatório selecionado; use o seletor de relatório para consultar os conteúdos do período anterior.

Qualquer variação desfavorável, mesmo pequena, gera um sinal observacional; não há limiar de significância estatística ou garantia de recuperação. O painel distingue, quando os dados permitem, queda de alcance de queda nas interações por alcance. Informa mudanças na quantidade publicada somente se o campo estiver presente nos dois relatórios. Não conclui causa, bloqueio ou mudança de algoritmo a partir das métricas.

Os alertas exigem **períodos de calendário encerrados**, imediatamente consecutivos, de mesma duração e conta, com cobertura conhecida e igual e `contentWindow=period`. Relatório com o dia atual, cobertura desconhecida ou acumulados de vida inteira recebe uma orientação para completar a base, sem falso alerta. A versão mais recente do relatório anterior é usada, sem somar revisões. Confirme também na origem que os dados estão completos e têm definições equivalentes; o calendário sozinho não verifica isso. Campos ausentes não são zero e ficam listados como sem dados comparáveis. A razão de interações por alcance pode superar 100%, porque não representa pessoas únicas.

Os alertas são calculados localmente ao abrir o dashboard, usando os relatórios já salvos por conta. Não há notificação externa, coleta em tempo real ou integração automática da Meta nesta versão. Registre ou importe o próximo período com a mesma duração e cobertura para acompanhar se o teste melhorou o resultado.

## Origens dos seguidores: orgânico, anúncio e prospecção

Abra **Origens dos seguidores**. A página usa as medições de seguidores da conta selecionada e separa três sinais:

- **Origem informada:** sua classificação individual como orgânico, anúncio, prospecção ou desconhecido, com nome da fonte e evidência: classificação manual, pessoa informou ou registro de atendimento/rastreamento. Essas escolhas não são verificadas automaticamente pela Meta. Salvar atualiza a classificação do @perfil; escolher desconhecido remove a atribuição anterior sem apagar as associações observadas.
- **Associação observada com a prospecção:** cruza os seguidores do recorte com as origens salvas dos candidatos. Exemplo: um perfil aparece na base “Dalu Fitness” e na lista de seguidores. Mostra campanha, alvo, data de captura/importação e se essa data foi anterior ao intervalo ou dentro dele. Estar na base não prova por que a pessoa seguiu. Fontes registradas depois da medição final são excluídas; quem já constava na base de seguidores não é contado como novo. Todas as fontes são preservadas, sem escolher uma causa única por coincidência.
- **Total agregado de canal:** contagem que você copia de um relatório de anúncio ou orgânico, quando disponível, com período, nome da campanha/conteúdo e regra/janela consultada. Não identifica nomes, não é distribuída entre os seguidores e não é somada automaticamente a outros recortes. Relatórios de Insights já salvos com cobertura orgânica/paga e `follows` também ficam disponíveis para consulta, sem somar versões ou períodos.

O recorte automático escolhe novos @perfis entre duas medições completas, quando disponíveis; caso contrário, mostra os observados na lista selecionada. Listas parciais não geram um total inventado de novos seguidores. A identificação é por username, sujeita a troca de nomes; o intervalo não fornece a hora exata do follow. Classificações manuais atuais são aplicadas ao recorte, sem fingir reconstruir o conhecimento disponível naquela data.

**Desconhecido não é orgânico.** Não calculamos orgânico como total menos anúncios ou scraper. Uma pessoa pode aparecer em mais de uma base e também ter sido exposta a conteúdo/anúncio. A contagem de associações por fonte pode se sobrepor; não deve ser somada como aquisição exclusiva. Uma ação “Seguindo” ou uma solicitação enviada pela Órbita é um registro de saída, não prova de origem de seguidores recebidos. Eventos de outra conta e posteriores à medição são ignorados.

Use **Informar origem** por perfil ou **Importar origens** no modelo CSV/JSON, até 5 MB e 20.000 classificações por lote. CSV: `account,username,channel,source_label,evidence,campaign_id,note`. Campos de canal: `organic`, `paid`, `prospecting`, `unknown`; evidência: `manual`, `self_report`, `tracking`. Os dois últimos campos são opcionais; campanhas de prospecção vinculadas precisam pertencer à conta. No JSON, use `{ "account": "seu.perfil", "assignments": [...] }`, com `sourceLabel` e `campaignId`. Importação rejeita contas misturadas, usernames repetidos e linhas incompatíveis antes de salvar o lote. Um CSV nativo de anúncios só com totais não é aceito como lista de pessoas.

Limites locais por conta: até 20.000 registros de classificação e 120 resultados agregados. A revisão mostra 50 perfis por página, com busca e filtros por canal/fonte. A exportação da análise inclui todo o filtro, contexto das medições, classificações e associações. Tudo entra no backup da conta. Na restauração, classificações atuais mais recentes, inclusive a opção desconhecida, prevalecem; resultados idênticos não se duplicam. Não descartamos histórico silenciosamente ao atingir limites.

A integração oficial de Insights e Ads permanece não implementada. Esta versão não possui um mecanismo validado para identificar automaticamente qual anúncio trouxe cada @perfil. Os contratos consultados de [Insights do Instagram](https://github.com/facebook/facebook-python-business-sdk/blob/main/facebook_business/adobjects/instagraminsightsresult.py) e [Ads Insights](https://github.com/facebook/facebook-python-business-sdk/blob/main/facebook_business/adobjects/adsinsights.py) servem de referência para métricas e recortes, sem garantir disponibilidade de uma métrica em toda conta. Os registros de anúncios desta versão são manuais.

## Seguidores, reciprocidade e perfis protegidos

Abra **Seguidores e seguidos** no menu. Funciona com contas pessoais ou profissionais, usando listas que você informa ou importa localmente. Não há monitoramento em tempo real, leitura automática dessas relações nem unfollow automático.

- **Não seguem de volta:** perfis presentes nos seguidos e ausentes nos seguidores da mesma medição. Só calculamos quando a lista de seguidores é declarada completa. Com seguidos parciais, o resultado cobre apenas os perfis informados, sem afirmar que representa todos os seguidos.
- **Saíram da lista:** compara a medição selecionada com uma anterior completa de seguidores. As duas listas de seguidores precisam ser completas; uma coleta parcial não serve para inferir perdas. A primeira medição inicia o histórico, sem inventar quem deixou de seguir antes dela. Troca de username, desativação, bloqueio ou remoção podem produzir a mesma diferença; não identificamos o motivo nem a hora exata. Saídas com retorno entre duas medições não são detectadas.
- **Mútuos:** @perfis presentes nas duas listas informadas. Uma presença observada não exige concluir nada sobre quem ficou fora de listas parciais.
- **Protegidos:** marque amigos, família, perfis importantes, clientes/contatos ou outro motivo, com uma anotação. Ficam ocultos por padrão nas revisões de reciprocidade e saídas, mas continuam disponíveis na aba Protegidos ou ao desmarcar o filtro. Proteger não muda as relações observadas nem executa ações no Instagram. Você pode editar ou remover a proteção.

Use **Importar medição**. É preciso informar seguidores, seguidos, a data/hora do levantamento, a completude de cada lista e confirmar que ambas pertencem à conta selecionada e ao mesmo levantamento. A data de início de um follow encontrada em um arquivo não é usada como data da medição. Os formatos aceitos são:

- **JSON de conexões do Instagram:** estruturas conhecidas de `followers_1.json`, `followers_2.json` etc. e `following.json`, incluindo entradas antigas com `string_list_data.value` e entradas de seguidos com username em `title`. Inclua todas as partes do mesmo download. A ferramenta verifica conflitos entre nome e link e não descarta registros inválidos silenciosamente. Alterações no formato da Meta podem exigir adaptação.
- **TXT/texto:** um @perfil ou link completo por linha, sem cabeçalho. **Arquivo CSV:** uma coluna com cabeçalho obrigatório `username`. A primeira pessoa em um texto não é descartada por se chamar `perfil` ou `username`. Links `_u/username` são reconhecidos. Uma lista realmente vazia precisa ser declarada explicitamente como `[]` em JSON.
- **JSON exportado pela Órbita:** o dono é conferido contra a conta selecionada. Em arquivos nativos sem identificação da conta, a confirmação do dono e do levantamento é uma declaração sua, não uma verificação da Meta.

Na [Central de Contas, a Meta oferece o download de informações](https://about.fb.com/news/2023/10/manage-your-information-across-apps/). Escolha somente as conexões da sua conta em JSON e todo o período disponível; descompacte antes. Os nomes das telas podem variar. A Órbita não recebe ZIP/HTML nem precisa do arquivo inteiro com mensagens, fotos ou dados de login. Arquivos são processados localmente, sem envio a um servidor.

Limites locais: 20.000 perfis por lista, até 50 arquivos em uma importação, 5 MB por arquivo e 20 MB no lote; histórico de até 24 medições e 200.000 entradas por conta; até 5.000 registros de proteção, incluindo remoções guardadas para preservar escolhas no backup. Não removemos histórico silenciosamente ao atingir limites. Exporte uma medição/backup antes de remover registros antigos. A tela pagina de 50 em 50 perfis; a exportação CSV da revisão inclui todo o filtro, com motivo e anotação das proteções.

Listas e proteções ficam isoladas por conta e entram no backup existente. Restaurar combina medições sem duplicar; dados diferentes para o mesmo instante são rejeitados, preservando o estado anterior. Escolhas de proteção mais recentes, inclusive remoções, prevalecem sobre backups antigos. Remover uma medição não remove perfis protegidos. A correspondência usa username, sem rastreamento por ID numérico.

## Aprendizados: o que repetir nas publicações

A aba **Aprendizados** é a entrada principal dos Insights. Ela compara resultados por publicação e ajuda a escolher hipóteses para o próximo teste de conteúdo.

- **Seguidores atribuídos por publicação:** campo `follows` do conteúdo, quando disponível na origem. Não é distribuído a partir do crescimento total da conta nem das ações de seguir da Órbita. Ausência fica desconhecida; zero só vale quando informado.
- **Interações por alcance:** `total_interactions / reach × 100`, por publicação. Pode superar 100% porque uma pessoa pode interagir mais de uma vez. Não substituímos o total ausente pela soma parcial de curtidas/comentários.
- **Eficiência em seguidores:** `follows / reach × 1.000`. O ranking pode ser ordenado por seguidores totais ou por eficiência, engajamento, salvamentos e compartilhamentos por alcance. Um conteúdo com mais alcance pode ganhar em volume e perder em eficiência.
- **Comparações por formato, tema, abertura e chamada para ação:** usam medianas por publicação. Os rótulos de tema, abertura e CTA são informados pelo usuário, sem classificação automática ou inferência a partir da legenda. Rótulos vazios ficam fora do contraste daquela dimensão.
- **Hipóteses para testar:** exigem cobertura declarada (orgânico, pago ou ambos), mesma janela informada das primeiras horas e pelo menos 3 publicações no grupo e 3 com outros valores conhecidos. Esses mínimos são controles do produto, não significância estatística. As hipóteses não demonstram causa nem garantem crescimento; podem se sobrepor. Filtre um formato para comparar temas e chamadas com menos diferenças entre publicações.
- **Janela comparável:** informe `publishedAt` com hora e fuso e `observationHours` (ex.: 48 para as primeiras 48h). A janela deve já estar concluída no momento do registro e até a data final do relatório, interpretada no mesmo deslocamento de fuso da publicação. Entram nas hipóteses apenas publicações com data dentro do período do relatório. O automático escolhe a janela com mais medições nesse recorte; não escolhe a janela que dá o melhor resultado.
- **Vida inteira:** é uma leitura exploratória, sem hipóteses automáticas. Para usar primeiras horas, registre o recorte realmente medido em relatório `contentWindow=period`; não divida resultados acumulados pelo número de dias. O limite local é de 1 a 8.760 horas por janela informada, sem relação com limites oficiais da plataforma.
- **Registrar publicação:** permite começar com uma publicação mesmo sem totais da conta. Informe título, formato, métricas e, para aprender com padrões, tema, abertura, CTA e janela. A edição grava uma versão manual do relatório; a original é preservada. Um link canônico igual conserva a identidade da publicação, sem contar o mesmo post duas vezes.
- **Exportar análise:** inclui objetivo, formato selecionado, janela, cobertura, recorte do relatório, ranking e todos os grupos calculados. A lista de grupos na tela mostra até 50; esse limite não altera os cálculos.

Metadados opcionais no JSON de cada conteúdo: `publishedAt`, `observationHours`, `theme`, `hook`, `cta`. No CSV: `published_at`, `observation_hours`, `theme`, `hook`, `cta`, repetidos de forma consistente nas linhas da mesma publicação. Exemplo: `2026-10-10T12:00:00-03:00`, `48`, `Dicas`, `Lista`, `Seguir`. Tempo de observação não é tempo assistido: o primeiro define a janela de comparação; o segundo é uma métrica do vídeo.

A análise funciona com os dados locais registrados/importados. A sincronização oficial com a Meta continua não implementada nesta versão.

## Instagram Insights

### Stories, horários e roteiro de testes

Na aba **Aprendizados**, selecione **Story** em Formato para análise. O objetivo muda para interações por alcance, e você pode escolher respostas ou respostas à caixinha por mil alcançadas. Registre mídia (foto/vídeo) e figurinha (sem figurinha, caixinha, enquete, quiz, controle deslizante, link ou outra) separadamente: uma foto pode ter caixinha. Valores antigos não classificados continuam desconhecidos. No JSON, use `storyMedia` e `storySticker`; no CSV, `story_media` e `story_sticker`. Esses campos só são aceitos em conteúdos `story`.

**O que fazer agora** converte os dados do relatório selecionado em um roteiro: escolher uma mudança no conteúdo, testar o horário em outro ciclo, medir na mesma janela e continuar a revisão de candidatos em Campanhas. A orientação não publica nem agenda automaticamente.

Os horários são calculados em faixas de 2 horas no fuso IANA escolhido. Só há uma faixa candidata quando o formato está filtrado, há cobertura e janela conhecidas, pelo menos 3 publicações no grupo e 3 fora dele, em pelo menos 2 datas de cada lado, e a mediana do grupo supera o contraste. Dias da semana são analisados separadamente; o painel não combina um dia vencedor com uma faixa vencedora como se tivesse medido essa combinação. Observações de uma única data, vida inteira, janelas misturadas e empates não produzem uma indicação. Os mínimos são controles do produto, não comprovação estatística. Posição na sequência, tema, promoção e público podem influenciar os resultados.

Sem histórico, as faixas 12h–14h e 18h–20h aparecem apenas como exemplos de início de teste, explicitamente sem evidência de que sejam os melhores horários da conta. A recomendação personalizada depende de medições reais; não usamos um horário genérico como se fosse um resultado da sua conta. A exportação da análise guarda fuso, faixa, amostras e base da orientação.

`question_answers` é um campo local de contagem manual da caixinha. Não representa uma métrica garantida da API, não equivale a `replies` nem a `sticker_taps` e não é somado a eles para inventar interações. As métricas efetivamente disponíveis dependem da origem consultada.

### Comparativo do mercado

Abra **Comparativo** no menu para ver quem leva vantagem, por quê e sob quais condições. A consulta a fontes oficiais em 03/11/2026 cobre Órbita, AutoInsta (autoinsta.online), Nikau, Metricool e Later. São 12 critérios: 3 vantagens condicionais do nosso modelo de projeto, 6 pontos em que ferramentas do mercado estão à frente, 1 recurso compartilhado e 2 conclusões ainda sem comprovação. Esses números organizam critérios; não são uma nota geral de qualidade. Use os filtros ou a visão **Por ferramenta** para conferir as diferenças e as prioridades que ainda não implementamos.

Nossas vantagens estão em adaptar o código ao negócio, manter a base principal local e entregar este aplicativo sem uma assinatura própria. Isso não demonstra maior segurança, menor custo total, exclusividade funcional ou mais crescimento. AutoInsta também usa execução local e o Metricool tem plano gratuito. Metricool e Later estão à frente em métricas conectadas e publicação; Metricool já coleta dados públicos de concorrentes e Later oferece tendências de hashtags por setor. AutoInsta e Nikau anunciam mais modalidades de automação. O quadro descreve os limites de cada comparação.

A implementação da Órbita foi conferida no código; os concorrentes foram avaliados por documentação pública, sem assinatura ou teste de resultados. Perforgram e Scalehot continuam sem avaliação atual, o que não indica inferioridade. Origem automática de cada seguidor, mais clientes, maior engajamento e menos bloqueios não foram demonstrados. O JSON exportado, versão 2, inclui todos os critérios, vereditos, condições, fontes e prioridades, independentemente do filtro selecionado.

O dashboard agora inclui **Resumo, Conteúdo, Público e Todas as métricas**. Os contadores públicos, os Insights da conta e as ações da Órbita têm origens e períodos próprios.

**A sincronização automática oficial dos Insights ainda não está implementada nesta versão.** Conectar a sessão do navegador confirma a conta e permite ler os contadores do perfil; isso não concede autorização da API. A integração oficial exige um aplicativo da Meta, fluxo de autorização e permissões adequadas para cada conta profissional. Métricas, formatos e histórico disponíveis dependem da Meta e da conta. Não prometemos acesso a todas as métricas existentes no aplicativo. Referência: [Instagram API, coleção da Meta](https://www.postman.com/meta/instagram/collection/6yqw8pt/instagram-api).

Funciona agora:

- **Registrar Insights:** transcreva os números consultados na sua conta. O painel identifica esses dados como manuais. O formulário oferece 31 campos principais: visualizações, alcance, contas com engajamento, interações, curtidas, comentários, salvamentos, compartilhamentos, respostas, republicações, seguidores recebidos e perdidos, visitas e links do perfil, atividade, publicação de conteúdos, tempo assistido, pulos dos Reels, visualizações cruzadas, navegação e ações nos Stories, figurinhas, pico de Live e impressões históricas.
- **Importar Insights:** CSV ou JSON **no modelo Órbita**, com prévia antes de salvar. Relatórios nativos da Meta precisam ser adaptados às colunas e unidades descritas; não há promessa de aceitar qualquer exportação nativa. O arquivo sempre deve identificar a conta, o período e os valores observados. Dados de outra conta são rejeitados e uma importação em lote com erro não salva relatórios pela metade.
- **Conteúdo:** compare Posts, Carrosséis, Reels, Stories e Lives por visualizações, alcance, interações, salvamentos, compartilhamentos e tempo médio assistido. Abra um conteúdo para ver todas as métricas informadas. `contentWindow=period` identifica valores do período; `lifetime` identifica dados de vida inteira medidos até a data final. Não misture esses recortes.
- **Público:** o JSON aceita cidade, país, idade, gênero, horários, dias e seguidores/não seguidores, para público seguidor, alcançado ou engajado. Cada recorte declara contagem ou percentual; grupos podem ser parciais. Não há identificação de quem visitou o perfil.
- **Comparação:** exige relatório do intervalo imediatamente anterior, com mesma duração, mesmo recorte de conteúdo (período ou vida inteira) e cobertura declarada igual (`organic`, `paid` ou `combined`). `unknown` desabilita a comparação. Bases zero e campos ausentes ficam sem variação percentual. Alcance de vários posts, médias e picos não são somados para inventar um total da conta.
- **Cálculos:** saldo de seguidores = novos seguidores menos perdas, somente com os dois dados presentes. A razão de interações por alcance usa os valores do mesmo relatório e pode superar 100%, pois uma pessoa pode interagir mais de uma vez. Isso não é uma porcentagem de pessoas únicas.
- **Histórico:** até 120 relatórios por conta, até 500 conteúdos e 30 recortes de público por relatório. Até 120 métricas por recorte. Exportação JSON preserva o relatório completo; o backup da conta inclui todos. É possível remover um relatório depois de conferir a seleção, sem afetar a fila ou outras contas. Reimportações idênticas não duplicam registros. A restauração combina os históricos, preserva identificadores e datas originais dos relatórios e mantém versões com valores ou observações diferentes separadas, sem somá-las. Medições do perfil continuam limitadas às 730 mais recentes.

Baixe um modelo pelo dashboard. Limites: até 5 MB por arquivo e 30.000 linhas por CSV. Datas usam `AAAA-MM-DD` e cada relatório cobre até 366 dias, sem datas futuras. Valores ausentes permanecem desconhecidos; zero só aparece quando informado. Tempo assistido usa **segundos**; converta milissegundos antes de importar. Percentuais usam 0 a 100. Métricas adicionais em snake_case são preservadas como inteiros, sem unidade inferida.

Exemplo de estrutura JSON **com números fictícios**, a adaptar aos dados reais da sua conta:

```json
{
  "version": 1,
  "reports": [
    {
      "account": "seu.perfil",
      "start": "2026-10-01",
      "end": "2026-10-07",
      "coverage": "organic",
      "contentWindow": "period",
      "note": "Exemplo fictício; substitua pelos dados observados.",
      "metrics": { "views": 1000, "reach": 500, "total_interactions": 40 },
      "content": [
        {
          "id": "conteudo-1",
          "kind": "reel",
          "title": "Meu Reel",
          "metrics": { "views": 300, "avg_watch_time_seconds": 8.5 }
        }
      ],
      "audience": [
        {
          "audience": "followers",
          "dimension": "country",
          "unit": "percent",
          "values": [{ "label": "Brasil", "value": 70 }]
        }
      ]
    }
  ]
}
```

CSV: `account,start,end,coverage,content_window,scope,content_id,title,url,metric,value`. Use uma linha por métrica; scope aceita `account`, `post`, `carousel`, `reel`, `story` ou `live`. Repita `content_id` nas métricas do mesmo conteúdo. Números não usam separador de milhar; decimais usam ponto. O JSON é o formato para recortes de público. Exportações de relatórios podem ser importadas pelo mesmo caminho.

Os nomes do catálogo são o formato local da Órbita; não são uma lista de permissões ou de endpoints disponíveis em todas as versões da API. Referências de campos e formatos consultadas: [Insights no SDK da Meta](https://github.com/facebook/facebook-python-business-sdk/blob/main/facebook_business/adobjects/instagraminsightsresult.py), [conta](https://github.com/facebook/facebook-python-business-sdk/blob/main/facebook_business/adobjects/iguser.py) e [conteúdo](https://github.com/facebook/facebook-python-business-sdk/blob/main/facebook_business/adobjects/igmedia.py). Não copiamos a implementação desses arquivos nem adicionamos o SDK como dependência.

## Ritmo e cuidados

A tela **Ritmo e cuidados** traz um começo guiado escolhido pelo produto: **1 fonte de referência, revisão de 5 candidatos, até 5 tentativas por dia e intervalo de 15 minutos**. O lote padrão tem no máximo 5 tentativas. Esses números não são limites aprovados pelo Instagram nem uma faixa de risco comprovada. Mesmo volumes pequenos podem sofrer restrições.

- Perfis salvos são uma lista local. Salvar ou importar pessoas não faz sua conta ganhar seguidores. Consultar listas, rolar páginas e seguir pessoas são atividades distintas.
- Mais fontes podem exigir mais consultas, mas não aumentam o teto diário. Uma fila grande aguarda os próximos lotes e o saldo disponível.
- Ao encerrar um lote, a fila pausa. Cada novo lote exige sua declaração de revisão da conta e dos candidatos. Não há crescimento automático do teto nem retomada automática para executar o restante de uma lista.
- O painel avisa quando o ritmo configurado supera o piloto, quando o teto está próximo e quando a fila ultrapassa o saldo diário.
- Ações realizadas pelo celular ou por outras ferramentas não são medidas pela Órbita. O contador local não representa toda a atividade da conta.
- Se houver bloqueio, pedido de verificação, erros repetidos ou resultado incerto, interrompa. Siga as instruções do Instagram; não insista por outro bot ou dispositivo. Não há espera fixa que prove liberação da conta.
- **Minha conta mostrou um aviso** marca uma pendência e suspende novas coletas e execução. Avisos detectados pelo adaptador também podem marcar a pendência. Só desmarque em Preferências após conferir a resolução no Instagram. Desmarcar é uma declaração manual, não uma verificação automática de segurança.
- Aplicar o começo guiado pausa a fila e preserva avisos, exclusões e contadores. Restaurar um backup antigo também preserva avisos atuais, o maior contador diário disponível e a última tentativa. Pausar, reiniciar ou restaurar não encurta o intervalo que ainda resta.
- Se a conta for nova, pouco utilizada ou recém-restrita, prefira organizar e revisar os perfis e fazer interações manuais.

As preferências anteriores são preservadas ao atualizar da 0.1.0; um lote padrão de 5 é acrescentado e a fila fica pausada para revisão. Use **Aplicar começo guiado** para substituir os valores antigos pelo piloto.

Referências consultadas: [Meta: limites e coleta automatizada](https://about.fb.com/news/2021/05/scraping-by-the-numbers/) e [Meta: identificação de possíveis atividades de spam](https://about.fb.com/br/news/2023/12/protegendo-os-criadores-de-interacoes-indesejadas-por-meio-de-novas-ferramentas-proativas-de-seguranca/). Esses textos descrevem mecanismos de proteção; não certificam os números de nosso piloto como seguros.

## Primeiro fluxo

1. Crie uma campanha: seguidores ou seguidos de um perfil; comentários ou curtidas de uma publicação; hashtag; localização; lista importada.
2. Clique em **Coletar**. Na página do Instagram, abra a lista correspondente e clique em **Capturar carregados**. Role para carregar mais perfis; use **Capturar enquanto eu rolo** para salvar os novos itens. A coleta é parcial e não garante toda a lista.
3. Em hashtags e locais, abra uma publicação **a partir da fonte da campanha**, na mesma aba. A leitura captura autores dos posts abertos, não identifica usuários pelas miniaturas. Apenas publicações vinculadas pelo clique naquela fonte são aceitas.
4. Em **Seu público**, revise os perfis, use os filtros e selecione **Aprovar**. Depois selecione os aprovados e **Adicionar à fila**.
5. Ajuste teto de tentativas, intervalo e janela de horários em **Preferências**. Esses valores são controles locais escolhidos pelo usuário; não são limites seguros publicados pelo Instagram.
6. Abra **Fila de ações**, confira a conta e clique em **Iniciar fila**. A primeira verificação acontece em cerca de 30 segundos. O navegador e o computador precisam permanecer em execução.

A fila usa uma aba própria e confere a conta, o endereço, o cabeçalho e o botão antes de clicar. O estado “Seguindo” ou “Solicitado” precisa permanecer na interface por várias leituras para ser registrado. Um resultado incerto ou desafio interrompe a fila sem repetição automática. Uma ação já autorizada e enviada pode terminar após a pausa. O início fica bloqueado até a ação em andamento terminar.

Perfis incertos, não realizados ou excluídos podem voltar à revisão pelos detalhes do perfil, após conferência manual. Isso não os aprova nem os coloca automaticamente na fila.

## Importar e exportar

Aceita um @perfil ou URL de perfil por linha, TXT e CSV de até 5 MB / 10.000 registros por importação. Colunas aceitas:

```csv
username,name,bio,followers,following,posts,is_private,id
perfil.exemplo,Nome do perfil,Biografia,1200,500,80,false,123456789
```

`id` é opcional. Contagens devem ser inteiros sem separadores ou abreviações. Privacidade aceita `true/false`, `1/0`, `sim/não`; campo vazio permanece desconhecido. Campos desconhecidos não passam em filtros que dependem deles.

A captura de listas normalmente traz apenas o username; nome, bio e contagens não são inventados. A deduplicação utiliza ID quando fornecido e username normalizado no restante. A identificação somente por username não acompanha automaticamente trocas de nome no Instagram. As origens de cada perfil ficam preservadas.

Exporte CSV do público, JSON do histórico ou backup da conta selecionada. O backup contém listas, anotações e medições; guarde-o de forma privada. Restaurar substitui os dados de campanhas e público da conta, combina as medições sem duplicar registros iguais, preserva avisos e contadores de tentativas e não restaura sessão nem ações executáveis. As outras contas permanecem intactas. Desinstalar a extensão remove os dados locais do navegador: exporte antes.

## Prévia e desenvolvimento

Node.js 24.14 ou superior. A prévia e a extensão têm armazenamentos separados. A prévia permite criar campanhas, importar, revisar e exportar; conexão e execução exigem a extensão.

```powershell
npm ci
npm run dev
npm test
npm run build
```

`dist/` contém a extensão completa. A compilação inclui a interface React e os scripts MV3 independentes. Os ícones são assets locais. Não há código remoto na extensão.

## Validação e limites desta versão

- Testes de domínio e DOM verificam deduplicação, filtros de dados desconhecidos, CSV, exclusões, janela de horários, teto diário independente do histórico, recuperação e ausência de cliques ambíguos.
- A interface foi exercitada no navegador com criação de campanha, importação, filtros, aprovação, persistência e layouts de desktop e celular.
- O painel e o service worker foram carregados em um perfil de teste do Chrome. A coleta e o fluxo de seguir foram exercitados com páginas simuladas, sem usar a conta do usuário.
- **O layout atual do Instagram em uma sessão autenticada real ainda precisa de validação.** Mudanças na interface, idioma e paginação podem impedir a coleta ou execução. O sistema prefere interromper a tentar um botão ambíguo.
- Várias contas cadastradas e separadas; uma sessão do Instagram e uma execução por vez neste navegador. Publicação, mensagens, Stories e unfollow não fazem parte desta versão.
- A integração usa DOM, não uma API oficial de follow/unfollow. Não há acesso a conteúdo privado, solução de CAPTCHA ou mecanismos para contornar restrições. Não há garantia de crescimento nem de ausência de bloqueios.

## Código

- `src/core/`: modelo, regras, CSV e validação.
- `src/extension/`: fila MV3, mensagens e adaptador DOM.
- `src/ui/`: painel e componentes.
- `tests/`: cenários de regressão e entradas fictícias.

Referências estudadas: [InstaPy](https://github.com/InstaPy/InstaPy), [GramAddict](https://github.com/GramAddict/bot), [instagrapi](https://github.com/subzeroid/instagrapi) e [autoinsta](https://github.com/Brannydonowt/autoinsta). A implementação é própria; esses projetos não são dependências e não há vínculo com os fornecedores comerciais mencionados na pesquisa.
