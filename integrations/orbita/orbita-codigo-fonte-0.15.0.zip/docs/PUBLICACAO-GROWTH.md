# Publicação no Growth · 0.15.0

Destino autorizado pelo usuário em 03/11/2026: app BFF, Growth → Instagram → Crescimento · Órbita. Projeto existente Vercel `bff-painel-pendencias`, equipe `felipe-461d`, repositório `barrofelipe-gif/Dream`. Integração preparada em worktree isolado a partir do commit publicado `09d7a6eea085c827ca66b8680f0f80e594f36a9d`, preservando alterações de Telegram não publicadas em outro checkout.

O painel e seu download são protegidos pelo login de administrador do app. O modo manual usa armazenamento por usuário/navegador; o modo conectado usa diretamente o cadastro local da extensão. Não há nova tabela, variável de ambiente, armazenamento de senha ou envio de listas ao servidor. O teste real no Instagram continua dependendo da instalação e sessão do usuário; nenhuma ação de seguir foi executada nesta validação.

## Segunda opinião e decisões

O Claude Code recebeu seis arquivos de implementação, sem credenciais, por meio do script local autorizado. A resposta foi lida. Foram incorporados: tratamento do redirecionamento de login e respostas inválidas, recusa de escopo ausente no modo hospedado, tratamento de falha na abertura, avisos de invalidação sem `oldValue/newValue` e maior restrição ao contexto nativo.

Divergências verificadas: o import de `main.tsx` está incluído no bundle único do esbuild, sem chunk externo; os arquivos privados têm inclusão explícita no tracing do Next, confirmada no manifesto compilado. Não foi adicionada abertura genérica de caminhos para contornar a allowlist. O manifest não tem `externally_connectable`; o worker confere remetente/rota e as validações de conta/sessão já existentes. Não duplicamos cookies ou tokens do login do app na extensão. A hipótese de expor a extensão diretamente com uma alteração futura no manifest não foi tratada como falha presente.

O teste encontrou que os eventos de storage não chegam ao content script, porque o cadastro está em `TRUSTED_CONTEXTS`. A proteção foi mantida. A interface recebe avisos após mensagens confirmadas e consulta somente o estado local para atualizar; uma leitura periódica visível cobre alterações do painel nativo e alarmes. Isso não repete mutações nem acessa o Instagram.

## Evidências locais

- Suíte da Órbita: `output/test-v0150.log`.
- Compilação TypeScript/Vite/esbuild: `output/build-v0150.log`.
- Extensão instalada em Chrome descartável, dentro de iframe com CSP: `output/hosting/native-connect-verified.log`.
- Gravação e atualização ao vivo da medição; recusa de sessão 403 sem criar conta: `output/hosting/native-write-verified.log`.
- Preservação de aviso, três tentativas e modo pausado; bloqueio por redirecionamento para login: `output/hosting/final-qa.log`.
- Isolamento de dois usuários no modo manual, sem chave global e tela de 390 px: `output/hosting/final-qa.log`.

As evidências de navegador usam uma conta fictícia, HTML de integração e sessão do app simulada. Não equivalem à validação de coleta/execução em contas reais. Os dados fictícios não estão incluídos nos pacotes de produção.
