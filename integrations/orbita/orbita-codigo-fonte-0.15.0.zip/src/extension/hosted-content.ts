import { allowedHostedMessage, trustedHostedPage } from "../core/hosted.ts";

if (trustedHostedPage(location.href)) {
  let connected = false,
    pending = 0;
  const session = async () => {
    const response = await fetch("/api/growth/orbita/session", {
      credentials: "same-origin",
      cache: "no-store",
      redirect: "error",
    });
    if (!response.ok)
      throw new Error(
        "Entre novamente no app com um usuário administrador para conectar a extensão.",
      );
    const data = await response.json();
    if (data?.ready !== true)
      throw new Error("A sessão do app não está disponível.");
  };
  window.addEventListener("message", async (event) => {
    const request = event.data;
    if (
      event.source !== window ||
      event.origin !== location.origin ||
      request?.channel !== "orbita-extension-request" ||
      typeof request.id !== "string" ||
      request.id.length > 80 ||
      pending >= 30
    )
      return;
    if (
      request.message?.type !== "HOSTED_CONNECT" &&
      (!connected || !allowedHostedMessage(request.message))
    )
      return;
    pending++;
    try {
      await session();
      let result;
      if (request.message.type === "HOSTED_CONNECT") {
        // Only establishes transport. Never starts a queue or changes an account.
        result = await chrome.runtime.sendMessage({ type: "HOSTED_CONNECT" });
        connected = result?.ok === true;
      } else result = await chrome.runtime.sendMessage(request.message);
      window.postMessage(
        { channel: "orbita-extension-response", id: request.id, result },
        location.origin,
      );
      if (
        result?.ok &&
        [
          "COMMAND",
          "ACCOUNT_COMMAND",
          "REPORT_PROBLEM",
          "UPDATE_PROBLEM",
          "RECOVER_PROBLEM",
        ].includes(request.message.type)
      ) {
        const keys = request.message.type.endsWith("PROBLEM")
          ? ["orbita-problems-v1"]
          : ["orbita-accounts-v2", "orbita-problems-v1"];
        window.postMessage(
          { channel: "orbita-extension-changed", keys },
          location.origin,
        );
      }
    } catch (error) {
      window.postMessage(
        {
          channel: "orbita-extension-response",
          id: request.id,
          transportError:
            error instanceof Error ? error.message : "Conexão indisponível.",
        },
        location.origin,
      );
    } finally {
      pending--;
    }
  });
}
