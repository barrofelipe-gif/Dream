import { hostedStorageKey, trustedHostedPage } from "./core/hosted.ts";
declare global {
  interface Window {
    orbitaHostedConnected?: boolean;
  }
}
export const nativeExtension = () =>
  typeof chrome !== "undefined" &&
  !!chrome.runtime?.id &&
  location.protocol === "chrome-extension:";
export const extensionAvailable = () =>
  nativeExtension() || !!window.orbitaHostedConnected;
export function storageKey(key: string): string {
  const user = document
    .querySelector('meta[name="orbita-user"]')
    ?.getAttribute("content");
  return hostedStorageKey(key, user, trustedHostedPage(location.href));
}
export function hostedRequest(message: object, timeout = 45000): Promise<any> {
  return new Promise((resolve, reject) => {
    const id = crypto.randomUUID();
    const listener = (event: MessageEvent) => {
      if (
        event.source !== window ||
        event.origin !== location.origin ||
        event.data?.channel !== "orbita-extension-response" ||
        event.data.id !== id
      )
        return;
      clearTimeout(timer);
      window.removeEventListener("message", listener);
      if (event.data.transportError)
        reject(new Error(event.data.transportError));
      else resolve(event.data.result);
    };
    const timer = setTimeout(() => {
      window.removeEventListener("message", listener);
      reject(
        new Error(
          "A extensão não respondeu. Confira a instalação e o resultado da operação antes de tentar novamente. Nenhuma ação será repetida automaticamente.",
        ),
      );
    }, timeout);
    window.addEventListener("message", listener);
    window.postMessage(
      { channel: "orbita-extension-request", id, message },
      location.origin,
    );
  });
}
export function sendExtension(message: object): Promise<any> {
  if (nativeExtension()) return chrome.runtime.sendMessage(message);
  if (window.orbitaHostedConnected) return hostedRequest(message);
  return Promise.reject(
    new Error("Conecte a extensão antes de usar o Instagram."),
  );
}
export function watchExtension(
  listener: (
    changes: Record<string, chrome.storage.StorageChange>,
    area: string,
  ) => void,
  key: string,
) {
  if (nativeExtension()) {
    chrome.storage.onChanged.addListener(listener);
    return () => chrome.storage.onChanged.removeListener(listener);
  }
  let revision = 0,
    alive = true;
  const changed = async (event: Pick<MessageEvent, "source" | "origin" | "data">) => {
    if (
      event.source === window &&
      event.origin === location.origin &&
      event.data?.channel === "orbita-extension-changed" &&
      event.data.keys?.includes(key)
    ) {
      const current = ++revision;
      try {
        const changes: Record<string, chrome.storage.StorageChange> = {
          [key]: {},
        };
        if (key === "orbita-accounts-v2") {
          const response = await sendExtension({ type: "GET_STATE" });
          if (!response?.ok)
            throw new Error(
              response?.error || "Não foi possível atualizar as contas.",
            );
          changes[key] = { newValue: response.store };
        }
        if (alive && current === revision) listener(changes, "local");
      } catch (error) {
        if (alive)
          window.dispatchEvent(
            new CustomEvent("orbita-transport-error", {
              detail: String(error),
            }),
          );
      }
    }
  };
  window.addEventListener("message", changed);
  // chrome.storage remains restricted to trusted extension contexts. Poll only
  // local state while visible, covering alarms and edits from the native panel.
  const poll = setInterval(() => {
    if (document.visibilityState === "visible")
      void changed({
        source: window,
        origin: location.origin,
        data: { channel: "orbita-extension-changed", keys: [key] },
      });
  }, 15000);
  return () => {
    alive = false;
    clearInterval(poll);
    window.removeEventListener("message", changed);
  };
}
