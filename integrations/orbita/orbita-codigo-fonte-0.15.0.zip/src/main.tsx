import React from "react";
import { createRoot } from "react-dom/client";
import App from "./ui/App.tsx";
import { ProblemBoundary } from "./ui/ProblemBoundary.tsx";
import { installProblemListeners } from "./problems-client.ts";
import "./ui/styles.css";
import "./ui/safety.css";
import "./ui/accounts.css";
import "./ui/insights.css";
import "./ui/performance.css";
import "./ui/market.css";
import "./ui/problems.css";
import "./ui/comparison.css";
import "./ui/growth.css";
import "./ui/guidance.css";
import "./ui/relationships.css";
import "./ui/acquisition.css";
import "./ui/color-theme.css";
import "./ui/improvement.css";
installProblemListeners();
createRoot(document.getElementById("root")!).render(
  <React.StrictMode>
    <ProblemBoundary>
      <App />
    </ProblemBoundary>
  </React.StrictMode>,
);
