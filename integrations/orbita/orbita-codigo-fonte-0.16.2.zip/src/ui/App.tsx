import { useMemo, useRef, useState } from "react";
import type { FormEvent } from "react";
import {
  Activity,
  Archive,
  ArrowDownToLine,
  ArrowRight,
  ArrowUpRight,
  Ban,
  Bug,
  Check,
  CheckCheck,
  ChevronDown,
  ChevronRight,
  CircleHelp,
  Clock3,
  Download,
  ExternalLink,
  FileText,
  FolderOpen,
  Camera as Instagram,
  LayoutDashboard,
  Link2,
  ListOrdered,
  LoaderCircle,
  Menu,
  Pause,
  Play,
  Plus,
  Search,
  Settings2,
  ShieldCheck,
  SlidersHorizontal,
  Sparkles,
  Target,
  Upload,
  UsersRound,
  X,
} from "lucide-react";
import {
  dispatch,
  dispatchAccount,
  isExtension,
  useAccountStore,
} from "../bridge.ts";
import { workspace as getWorkspace, accountBackup } from "../core/accounts.ts";
import {
  AccountSelector,
  AccountsPage,
  AccountSession,
  AccountDashboard,
  AddAccountModal,
  SnapshotModal,
} from "./Accounts.tsx";
import type { RunAccount } from "./Accounts.tsx";
import { attemptsToday, matchesFilters, sourceUrl } from "../core/domain.ts";
import { safetyAssessment, sessionLimit } from "../core/safety.ts";
import {
  SafetyPage,
  SafetyOverview,
  SafetyNotices,
  DraftPaceNotice,
} from "./Safety.tsx";
import { download, exportCsv, parseCandidates } from "../core/io.ts";
import { ComparisonPage } from "./Comparison.tsx";
import { RelationshipsPage } from "./Relationships.tsx";
import { AcquisitionPage } from "./Acquisition.tsx";
import { MarketPage } from "./Market.tsx";
import { ProblemsPage } from "./Problems.tsx";
import { useProblems, useVisibleProblemCapture } from "../problems-client.ts";
import { scopedProblems } from "../core/problems.ts";
import type {
  AppState,
  AccountStore,
  AccountWorkspace,
  Campaign,
  Candidate,
  Command,
  Filters,
  Settings,
  SourceKind,
  SpecialCommand,
  Stage,
} from "../core/types.ts";
import { SOURCE_LABELS, STAGE_LABELS } from "../core/types.ts";
import {
  Avatar,
  ProfilePhotosProvider,
  Badge,
  date,
  Empty,
  External,
  Field,
  FormButtons,
  Hint,
  Modal,
  number,
  SourceBadge,
  SourceIcon,
  SourceSelector,
  Toast,
} from "./components.tsx";

type Page =
  | "overview"
  | "campaigns"
  | "audience"
  | "queue"
  | "activity"
  | "settings"
  | "accounts"
  | "safety"
  | "help"
  | "comparison"
  | "relationships"
  | "acquisition"
  | "market"
  | "problems";
const titles: Record<Page, string> = {
  overview: "Visão geral",
  campaigns: "Campanhas",
  audience: "Seu público",
  queue: "Fila de ações",
  activity: "Atividade",
  settings: "Preferências",
  accounts: "Contas do Instagram",
  safety: "Ritmo e cuidados",
  help: "Instalação e ajuda",
  comparison: "Comparativo",
  relationships: "Seguidores e seguidos",
  acquisition: "Origens dos seguidores",
  market: "Radar do setor",
  problems: "Problemas e correções",
};
const emptyFilters = (): Filters => ({
  query: "",
  campaignId: "",
  stage: "",
  minFollowers: "",
  maxFollowers: "",
  bio: "",
  publicOnly: false,
  requireKnown: false,
});
const menus = [
  { page: "overview", icon: LayoutDashboard },
  { page: "accounts", icon: Instagram },
  { page: "relationships", icon: UsersRound },
  { page: "acquisition", icon: Link2 },
  { page: "market", icon: Sparkles },
  { page: "problems", icon: Bug },
  { page: "campaigns", icon: Target },
  { page: "audience", icon: UsersRound },
  { page: "queue", icon: ListOrdered },
  { page: "safety", icon: ShieldCheck },
  { page: "activity", icon: Activity },
  { page: "comparison", icon: FileText },
] as const;
type Run = (
  command: Command | SpecialCommand,
  success?: string,
) => Promise<boolean>;

export default function App() {
  const [store, ready, loadError] = useAccountStore();
  if (!ready)
    return (
      <div className="loading-screen">
        <img src="./orbita.svg" alt="" />
        <LoaderCircle className="spin" />
        Abrindo suas contas…
      </div>
    );
  const account = getWorkspace(store);
  return (
    <WorkspaceView
      key={account.id}
      store={store}
      account={account}
      loadError={loadError}
    />
  );
}
function WorkspaceView({
  store,
  account,
  loadError,
}: {
  store: AccountStore;
  account: AccountWorkspace;
  loadError: string | null;
}) {
  const state = account.data;
  const ready = true;
  const [page, setPage] = useState<Page>("overview");
  const problemSnapshot = useProblems();
  useVisibleProblemCapture(account.id, page);
  const pendingProblems = scopedProblems(
    problemSnapshot.store,
    account.id,
  ).filter((p) => p.status !== "resolved").length;
  const [modal, setModal] = useState<"campaign" | "import" | "start" | null>(
    null,
  );
  const [importCampaign, setImportCampaign] = useState("");
  const [toast, setToast] = useState<{
    message: string;
    error?: boolean;
  } | null>(null);
  const [filters, setFilters] = useState<Filters>(emptyFilters);
  const [selected, setSelected] = useState<Set<string>>(new Set());
  const [detail, setDetail] = useState<string | null>(null);
  const [sidebar, setSidebar] = useState(false);
  const [busy, setBusy] = useState(false);
  const [reviewedStart, setReviewedStart] = useState(false);
  const [accountModal, setAccountModal] = useState<"add" | "snapshot" | null>(
    null,
  );
  const toastTimer = useRef<ReturnType<typeof setTimeout> | undefined>(
    undefined,
  );
  const flash = (message: string, error = false) => {
    if (toastTimer.current) clearTimeout(toastTimer.current);
    setToast({ message, error });
    toastTimer.current = setTimeout(() => setToast(null), error ? 11000 : 5000);
  };
  const run: Run = async (command, success) => {
    setBusy(true);
    try {
      const notice = await dispatch(command, account.id);
      if (notice || success) flash(notice || success!);
      return true;
    } catch (error) {
      flash(
        error instanceof Error ? error.message : "Não foi possível concluir.",
        true,
      );
      return false;
    } finally {
      setBusy(false);
    }
  };
  const runAccount: RunAccount = async (command, success) => {
    setBusy(true);
    try {
      await dispatchAccount(command, account.id);
      if (success) flash(success);
      return true;
    } catch (error) {
      flash(
        error instanceof Error
          ? error.message
          : "Não foi possível atualizar a conta.",
        true,
      );
      return false;
    } finally {
      setBusy(false);
    }
  };
  const navigate = (next: Page) => {
    setPage(next);
    setSidebar(false);
    setSelected(new Set());
  };
  const activeCampaigns = state.campaigns.filter((c) => !c.archived);
  const queue = state.candidates.filter((c) =>
    ["queued", "attempting"].includes(c.stage),
  );
  const candidates = useMemo(
    () => state.candidates.filter((c) => matchesFilters(c, filters)),
    [state.candidates, filters],
  );
  const selectedCandidate = state.candidates.find((c) => c.id === detail);
  const reviewed = state.candidates.filter(
    (c) => c.stage === "approved",
  ).length;
  const confirmed = state.candidates.filter(
    (c) => c.stage === "followed",
  ).length;
  const demo = state.candidates.some((c) =>
    c.sources.some((s) => s.url.startsWith("demo:")),
  );
  const safety = safetyAssessment(state, attemptsToday(state));
  const openImport = (campaignId = "") => {
    setImportCampaign(campaignId);
    setModal("import");
  };
  const chooseCampaign = (id: string) => {
    setFilters({ ...emptyFilters(), campaignId: id });
    navigate("audience");
  };
  const stop = () =>
    void run(
      { type: "PAUSE" },
      "Pausa solicitada. Uma ação já enviada pode terminar.",
    );
  if (!ready)
    return (
      <div className="loading-screen">
        <img src="./orbita.svg" alt="" />
        <LoaderCircle className="spin" /> Abrindo seu espaço…
      </div>
    );
  return (
    <ProfilePhotosProvider account={account}>
      <div className="app-shell">
        <aside className={`sidebar ${sidebar ? "open" : ""}`}>
          <a
            href="#"
            className="brand"
            onClick={(event) => {
              event.preventDefault();
              navigate("overview");
            }}
          >
            <img src="./orbita.svg" alt="" />
            <span>
              órbita<span className="brand-dot">.</span>
            </span>
          </a>
          <div className="workspace">
            {account.username ? (
              <Avatar
                username={account.username}
                name={account.label}
                src={account.avatarUrl || ""}
              />
            ) : (
              <span className="workspace-icon">O</span>
            )}
            <div>
              <strong>{account.label}</strong>
              <span>
                {account.username
                  ? `@${account.username}`
                  : "Conta ainda não vinculada"}
              </span>
            </div>
            <ShieldCheck size={15} />
          </div>
          <p className="nav-caption">SEU CENTRO DE CONEXÕES</p>
          <nav aria-label="Navegação principal">
            {menus.map(({ page: item, icon: Icon }) => (
              <button
                key={item}
                data-page={item}
                className={`nav-item ${page === item ? "active" : ""}`}
                onClick={() => navigate(item)}
              >
                <Icon size={19} />
                <span>{titles[item]}</span>
                {item === "queue" && queue.length > 0 ? (
                  <b>{queue.length}</b>
                ) : null}
                {item === "audience" && state.candidates.length ? (
                  <small>{state.candidates.length}</small>
                ) : null}
              </button>
            ))}
          </nav>
          <div className="sidebar-bottom">
            <div className="private-card">
              <span className="private-symbol">
                <ShieldCheck size={19} />
              </span>
              <strong>Seu público. Seus dados.</strong>
              <p>Armazenamento local, sem enviar sua lista para servidores.</p>
              <button onClick={() => navigate("help")}>
                Conhecer a Órbita <ArrowUpRight size={14} />
              </button>
            </div>
            <button
              className={`nav-item ${page === "settings" ? "active" : ""}`}
              onClick={() => navigate("settings")}
            >
              <Settings2 size={19} />
              <span>Preferências</span>
            </button>
            <button
              className={`nav-item ${page === "help" ? "active" : ""}`}
              onClick={() => navigate("help")}
            >
              <CircleHelp size={19} />
              <span>Instalação e ajuda</span>
              <span className="version">v0.16.2</span>
            </button>
            <div className="sidebar-footer">
              <div className="status-dot" />
              {isExtension ? "Extensão local" : "Prévia local"}
              <span>ÓRBITA</span>
            </div>
          </div>
        </aside>
        <div className="main-shell">
          <header className="topbar">
            <div className="breadcrumb">
              <button
                className="mobile-menu icon-button"
                aria-label="Abrir navegação"
                onClick={() => setSidebar(!sidebar)}
              >
                <Menu size={20} />
              </button>
              <span>
                {account.username ? `@${account.username}` : "Meu espaço"}
              </span>
              <ChevronRight size={14} />
              <strong>{titles[page]}</strong>
            </div>
            <div className="topbar-right">
              <span className="local-badge">
                <span />
                {isExtension
                  ? "Dados neste navegador"
                  : "Prévia · sem execução real"}
              </span>
              <AccountSelector
                store={store}
                run={runAccount}
                onManage={() => navigate("accounts")}
              />
              <button
                className="account-button"
                disabled={busy}
                onClick={() =>
                  void run(
                    { type: "CONNECT" },
                    "Sessão do Instagram identificada.",
                  )
                }
              >
                <Instagram size={16} />
                {account.verifiedAt ? "Verificar sessão" : "Conectar sessão"}
                <ChevronDown size={13} />
              </button>
            </div>
          </header>
          <main>
            {loadError ? <div className="notice error">{loadError}</div> : null}
            {demo ? (
              <div className="notice demo">
                <Sparkles size={16} />
                Você está explorando dados fictícios de demonstração. Esses
                perfis não podem ser executados na fila.
              </div>
            ) : null}
            <div className="page-heading">
              <div>
                <div className="eyebrow">
                  {page === "overview"
                    ? "CRESÇA COM INTENÇÃO"
                    : "MEU ESPAÇO / " + titles[page].toUpperCase()}
                </div>
                <h1>
                  {page === "overview"
                    ? account.username
                      ? `Dashboard · @${account.username}`
                      : "Boas conexões começam aqui"
                    : titles[page]}
                  {page === "overview" ? (
                    <span className="heading-dot">.</span>
                  ) : null}
                </h1>
                <p>
                  {
                    {
                      overview:
                        "Encontre o público certo. Organize cada oportunidade. Acompanhe cada ação.",
                      campaigns:
                        "Dê uma direção para cada fonte de novos perfis.",
                      audience:
                        "Pessoas, contexto e critérios. Tudo em um só lugar.",
                      queue:
                        "Uma ação por vez, com revisão e resultado registrado.",
                      activity: "Um registro do que aconteceu no seu espaço.",
                      settings:
                        "Defina o ritmo, os horários e as suas exclusões.",
                      accounts:
                        "Várias contas. Cada uma com seus dados e resultados.",
                      safety:
                        "Um começo gradual, controles claros e sinais para interromper.",
                      help: "Instale a extensão e organize suas contas no mesmo painel.",
                      comparison:
                        "Confira o que já funciona, o que o mercado oferece e o que ainda falta.",
                      relationships:
                        "Reciprocidade, mudanças entre listas e perfis que você quer manter.",
                      acquisition:
                        "Origens informadas, fontes de prospecção e limites da atribuição.",
                      market:
                        "Referências do seu setor e testes para evoluir com a sua marca.",
                      problems:
                        "Falhas registradas, acompanhamento e histórico de correções.",
                    }[page]
                  }
                </p>
              </div>
              <div className="heading-actions">
                {page === "overview" || page === "campaigns" ? (
                  <>
                    <button
                      className="button secondary"
                      onClick={() => openImport()}
                    >
                      <Upload size={16} />
                      Importar lista
                    </button>
                    <button
                      className="button primary"
                      onClick={() => setModal("campaign")}
                    >
                      <Plus size={18} />
                      Nova campanha
                    </button>
                  </>
                ) : page === "audience" ? (
                  <>
                    <button
                      className="button secondary"
                      onClick={() =>
                        download(
                          "orbita-publico.csv",
                          exportCsv(candidates),
                          "text/csv;charset=utf-8",
                        )
                      }
                    >
                      <Download size={16} />
                      Exportar
                    </button>
                    <button
                      className="button primary"
                      onClick={() => openImport()}
                    >
                      <Upload size={16} />
                      Importar perfis
                    </button>
                  </>
                ) : page === "queue" ? (
                  <button
                    className={`button ${state.runtime.mode === "running" ? "secondary" : "primary"}`}
                    disabled={busy || !queue.length}
                    onClick={() =>
                      state.runtime.mode === "running"
                        ? stop()
                        : (setReviewedStart(false), setModal("start"))
                    }
                  >
                    {state.runtime.mode === "running" ? (
                      <Pause size={17} />
                    ) : (
                      <Play size={17} />
                    )}
                    {state.runtime.mode === "running"
                      ? "Pausar execução"
                      : "Iniciar fila"}
                  </button>
                ) : null}
              </div>
            </div>
            {page === "overview" && pendingProblems ? (
              <div className="problems-overview">
                <Bug size={19} />
                <p>
                  <strong>
                    {pendingProblems}{" "}
                    {pendingProblems === 1
                      ? "problema em acompanhamento"
                      : "problemas em acompanhamento"}
                  </strong>
                  <br />
                  Veja os registros e o próximo passo para cada caso.
                </p>
                <button
                  className="text-link"
                  onClick={() => navigate("problems")}
                >
                  Abrir central →
                </button>
              </div>
            ) : null}
            {page === "accounts" ? (
              <AccountsPage
                store={store}
                run={runAccount}
                busy={busy}
                onAdd={() => setAccountModal("add")}
                onOpen={() => navigate("overview")}
              />
            ) : null}
            {page === "overview" ? (
              <>
                <AccountSession
                  store={store}
                  account={account}
                  run={run}
                  busy={busy}
                />
                <AccountDashboard
                  account={account}
                  run={run}
                  runAccount={runAccount}
                  busy={busy}
                  onManual={() => setAccountModal("snapshot")}
                  onMarket={() => navigate("market")}
                />
              </>
            ) : null}
            {state.runtime.mode === "running" && page !== "queue" ? (
              <div className="notice running-notice">
                <Activity size={17} />
                <span>Fila em execução · @{state.runtime.account}</span>
                <button className="button secondary small" onClick={stop}>
                  <Pause size={14} />
                  Pausar agora
                </button>
              </div>
            ) : null}
            {page === "overview" ? (
              <SafetyOverview state={state} onOpen={() => navigate("safety")} />
            ) : null}
            {state.settings.hasPendingWarning && page !== "safety" ? (
              <div className="safety-notice stop" role="alert">
                <ShieldCheck size={19} />
                <div>
                  <strong>Aviso pendente na conta</strong>
                  <p>
                    Coleta e execução estão suspensas. Confira o Instagram antes
                    de liberar nas Preferências.
                  </p>
                </div>
                <button
                  className="text-link"
                  onClick={() => navigate("safety")}
                >
                  Ver orientação <ArrowRight size={14} />
                </button>
              </div>
            ) : null}
            {page === "overview" ? (
              <>
                {!account.username ? (
                  <section className="hero">
                    <div className="hero-copy">
                      <div className="hero-kicker">
                        <span />
                        MENOS ACASO. MAIS DIREÇÃO.
                      </div>
                      <h2>
                        Transforme públicos
                        <br />
                        em próximas conexões.
                      </h2>
                      <p>
                        Reúna perfis de diferentes fontes, escolha quem faz
                        <br className="desktop-break" /> sentido e mantenha o
                        controle de cada passo.
                      </p>
                      <button
                        className="hero-button"
                        onClick={() => setModal("campaign")}
                      >
                        Criar minha campanha <ArrowRight size={17} />
                      </button>
                      <div className="hero-footnote">
                        <ShieldCheck size={13} />
                        Revisão antes da ação. Dados salvos localmente.
                      </div>
                    </div>
                    <OrbitGraphic />
                  </section>
                ) : null}
                <section className="stats-grid" aria-label="Resumo do espaço">
                  <Stat
                    label="Perfis no seu radar"
                    value={state.candidates.length}
                    icon={<UsersRound size={19} />}
                    foot="Pessoas únicas entre todas as fontes"
                    color="green"
                  />
                  <Stat
                    label="Campanhas"
                    value={activeCampaigns.length}
                    icon={<Target size={19} />}
                    foot="Fontes organizadas por objetivo"
                    color="blue"
                  />
                  <Stat
                    label="Prontos para conectar"
                    value={reviewed}
                    icon={<CheckCheck size={19} />}
                    foot="Revisados e aprovados por você"
                    color="amber"
                  />
                  <Stat
                    label="Conexões confirmadas"
                    value={confirmed}
                    icon={<Link2 size={19} />}
                    foot="Estado Seguindo lido no Instagram"
                    color="violet"
                  />
                </section>
                <div className="overview-grid">
                  <section className="panel campaigns-panel">
                    <div className="panel-heading">
                      <div>
                        <h2>
                          Suas campanhas{" "}
                          <span className="count-pill">
                            {activeCampaigns.length}
                          </span>
                        </h2>
                        <p>Cada fonte tem seu lugar.</p>
                      </div>
                      <button
                        className="text-link"
                        onClick={() => navigate("campaigns")}
                      >
                        Ver todas <ArrowUpRight size={15} />
                      </button>
                    </div>
                    {activeCampaigns.length ? (
                      <div className="campaign-list">
                        {activeCampaigns.slice(0, 4).map((c) => (
                          <CampaignRow
                            key={c.id}
                            campaign={c}
                            state={state}
                            onClick={() => chooseCampaign(c.id)}
                          />
                        ))}
                      </div>
                    ) : (
                      <Empty
                        icon={<Target size={26} />}
                        title="Seu próximo público começa com uma fonte"
                        text="Escolha um perfil de referência, uma publicação ou importe sua primeira lista."
                        action={
                          <button
                            className="text-link"
                            onClick={() => setModal("campaign")}
                          >
                            Criar primeira campanha <ArrowRight size={15} />
                          </button>
                        }
                      />
                    )}
                  </section>
                  <section className="panel journey">
                    <div className="panel-heading">
                      <div>
                        <h2>Seu próximo passo</h2>
                        <p>Do primeiro perfil à conexão.</p>
                      </div>
                      <span className="step-counter">
                        {Number(!!activeCampaigns.length) +
                          Number(!!state.candidates.length) +
                          Number(!!reviewed)}
                        /3
                      </span>
                    </div>
                    <Step
                      index={1}
                      done={!!activeCampaigns.length}
                      title="Escolha uma fonte"
                      text="Um público que tenha a ver com você."
                      onClick={() => setModal("campaign")}
                    />
                    <Step
                      index={2}
                      done={!!state.candidates.length}
                      title="Traga os perfis"
                      text="Capture uma lista ou importe um arquivo."
                      onClick={() => openImport()}
                    />
                    <Step
                      index={3}
                      done={!!reviewed}
                      title="Revise e aprove"
                      text="Você decide quem entra na sua fila."
                      onClick={() => navigate("audience")}
                    />
                    <div className="journey-note">
                      <span>✦</span> Uma boa conexão começa com contexto.
                    </div>
                  </section>
                </div>
                <section className="sources-strip">
                  <div>
                    <span className="eyebrow">VÁ ALÉM DE UMA LISTA</span>
                    <h3>
                      Diferentes caminhos.
                      <br />
                      Um público mais relevante.
                    </h3>
                  </div>
                  {(
                    [
                      "followers",
                      "commenters",
                      "likers",
                      "hashtag",
                    ] as SourceKind[]
                  ).map((kind) => (
                    <button key={kind} onClick={() => setModal("campaign")}>
                      <span className={`source-symbol ${kind}`}>
                        <SourceIcon kind={kind} />
                      </span>
                      <strong>
                        {
                          {
                            followers: "Perfis de referência",
                            commenters: "Quem comenta",
                            likers: "Quem curte",
                            hashtag: "Interesses em comum",
                          }[
                            kind as
                              "followers" | "commenters" | "likers" | "hashtag"
                          ]
                        }
                      </strong>
                      <span>
                        {kind === "followers"
                          ? "Seguidores e seguidos"
                          : kind === "commenters"
                            ? "Conversas relevantes"
                            : kind === "likers"
                              ? "Interesse em publicações"
                              : "Hashtags e localização"}
                      </span>
                    </button>
                  ))}
                </section>
                {!state.candidates.length ? (
                  <div className="demo-link">
                    <span>Quer conhecer o fluxo antes de começar?</span>
                    <button
                      className="text-link"
                      disabled={busy || !!state.campaigns.length}
                      onClick={() =>
                        void run(
                          { type: "DEMO" },
                          "Demonstração carregada com dados fictícios.",
                        )
                      }
                    >
                      Explorar demonstração <ArrowUpRight size={14} />
                    </button>
                  </div>
                ) : null}
              </>
            ) : null}
            {page === "campaigns" ? (
              <>
                <div className="section-summary">
                  <span>
                    <b>{activeCampaigns.length}</b> campanhas ativas
                  </span>
                  <span>
                    <b>{state.candidates.length}</b> perfis únicos no espaço
                  </span>
                  <span>
                    <ShieldCheck size={15} />
                    Fontes preservadas por perfil
                  </span>
                </div>
                {activeCampaigns.length ? (
                  <div className="campaign-grid">
                    {activeCampaigns.map((c) => {
                      const members = state.candidates.filter((p) =>
                        p.sources.some((s) => s.campaignId === c.id),
                      );
                      return (
                        <section className="panel campaign-card" key={c.id}>
                          <div className="campaign-card-top">
                            <span className={`source-symbol ${c.kind}`}>
                              <SourceIcon kind={c.kind} size={23} />
                            </span>
                            <button
                              className="icon-button"
                              aria-label={`Arquivar ${c.name}`}
                              onClick={() =>
                                void run(
                                  { type: "ARCHIVE_CAMPAIGN", id: c.id },
                                  "Campanha arquivada.",
                                )
                              }
                            >
                              <Archive size={17} />
                            </button>
                          </div>
                          <span className="tiny-label">
                            {SOURCE_LABELS[c.kind]}
                          </span>
                          <h2>{c.name}</h2>
                          <p className="campaign-target">
                            {c.target || "Importação de arquivo ou texto"}
                          </p>
                          <div className="campaign-card-numbers">
                            <div>
                              <strong>{number(members.length)}</strong>
                              <span>perfis únicos</span>
                            </div>
                            <div>
                              <strong>
                                {number(
                                  members.filter((p) => p.stage === "approved")
                                    .length,
                                )}
                              </strong>
                              <span>aprovados</span>
                            </div>
                            <div>
                              <strong>
                                {number(
                                  members.filter((p) => p.stage === "followed")
                                    .length,
                                )}
                              </strong>
                              <span>confirmados</span>
                            </div>
                          </div>
                          <div className="campaign-card-actions">
                            <button
                              className="button secondary"
                              onClick={() => chooseCampaign(c.id)}
                            >
                              Ver público
                              <ArrowRight size={15} />
                            </button>
                            <button
                              className="button primary"
                              disabled={busy}
                              onClick={() =>
                                c.kind === "import"
                                  ? openImport(c.id)
                                  : void run(
                                      { type: "OPEN_SOURCE", id: c.id },
                                      "Fonte aberta no Instagram. Use o coletor na página.",
                                    )
                              }
                            >
                              <Plus size={16} />
                              {c.kind === "import" ? "Importar" : "Coletar"}
                            </button>
                          </div>
                        </section>
                      );
                    })}
                  </div>
                ) : (
                  <section className="panel">
                    <Empty
                      icon={<Target />}
                      title="Dê um objetivo à sua primeira campanha"
                      text="Comece pelos seguidores de um perfil ou pelos comentários de uma publicação."
                      action={
                        <button
                          className="button primary"
                          onClick={() => setModal("campaign")}
                        >
                          <Plus size={16} />
                          Criar campanha
                        </button>
                      }
                    />
                  </section>
                )}
                <Hint>
                  A coleta lê conteúdo carregado na interface do Instagram e
                  pode ser parcial. Hashtags e locais permitem capturar autores
                  ao abrir as publicações encontradas.
                </Hint>
              </>
            ) : null}
            {page === "audience" ? (
              <Audience
                state={state}
                candidates={candidates}
                filters={filters}
                setFilters={setFilters}
                selected={selected}
                setSelected={setSelected}
                onDetail={setDetail}
                run={run}
                busy={busy}
                onImport={() => openImport()}
              />
            ) : null}
            {page === "queue" ? (
              <>
                <SafetyNotices state={state} />
                <div className={`execution-banner ${state.runtime.mode}`}>
                  <span className="execution-icon">
                    {state.runtime.mode === "running" ? (
                      <Activity />
                    ) : (
                      <Pause />
                    )}
                  </span>
                  <div>
                    <strong>
                      {state.runtime.mode === "running"
                        ? "Fila em execução"
                        : "Execução pausada"}
                    </strong>
                    <p>{state.runtime.pauseReason}</p>
                    {state.runtime.nextRun ? (
                      <small>
                        Próxima verificação:{" "}
                        {new Date(state.runtime.nextRun).toLocaleTimeString(
                          "pt-BR",
                        )}
                      </small>
                    ) : null}
                  </div>
                  <span className="badge">
                    {attemptsToday(state)} / {state.settings.dailyLimit}{" "}
                    tentativas hoje
                  </span>
                </div>
                <div className="queue-settings">
                  <span>
                    <Clock3 size={16} />
                    Intervalo de {state.settings.intervalMinutes} min
                  </span>
                  <span>
                    Lotes de até {sessionLimit(state.settings)} tentativas
                  </span>
                  <span>
                    {state.settings.startHour}–{state.settings.endHour} ·
                    horário deste computador
                  </span>
                  <button
                    className="text-link"
                    onClick={() => navigate("settings")}
                  >
                    Ajustar preferências <ArrowUpRight size={14} />
                  </button>
                </div>
                <section className="panel">
                  <div className="panel-heading">
                    <div>
                      <h2>
                        Próximas ações{" "}
                        <span className="count-pill">{queue.length}</span>
                      </h2>
                      <p>Apenas perfis aprovados entram nesta lista.</p>
                    </div>
                    <span className="subtle-label">
                      Conta:{" "}
                      {state.runtime.account
                        ? `@${state.runtime.account}`
                        : "não conectada"}
                    </span>
                  </div>
                  {queue.length ? (
                    <div className="table-scroll">
                      <table>
                        <thead>
                          <tr>
                            <th>ORDEM</th>
                            <th>PERFIL</th>
                            <th>AÇÃO</th>
                            <th>ESTADO</th>
                            <th />
                          </tr>
                        </thead>
                        <tbody>
                          {queue.map((c, i) => (
                            <tr key={c.id}>
                              <td className="row-number">
                                {String(i + 1).padStart(2, "0")}
                              </td>
                              <td>
                                <button
                                  className="profile-cell"
                                  onClick={() => setDetail(c.id)}
                                >
                                  <Avatar username={c.username} name={c.name} />
                                  <span>
                                    <strong>@{c.username}</strong>
                                    <small>
                                      {c.name || "Nome não coletado"}
                                    </small>
                                  </span>
                                </button>
                              </td>
                              <td>Seguir perfil</td>
                              <td>
                                <Badge stage={c.stage} />
                              </td>
                              <td>
                                <button
                                  className="icon-button"
                                  disabled={busy || c.stage === "attempting"}
                                  aria-label={`Retirar ${c.username} da fila`}
                                  onClick={() =>
                                    void run(
                                      {
                                        type: "REMOVE_FROM_QUEUE",
                                        ids: [c.id],
                                      },
                                      "Perfil retirado da fila.",
                                    )
                                  }
                                >
                                  <X size={16} />
                                </button>
                              </td>
                            </tr>
                          ))}
                        </tbody>
                      </table>
                    </div>
                  ) : (
                    <Empty
                      icon={<ListOrdered size={28} />}
                      title="Uma fila com intenção"
                      text="Revise os perfis, aprove os que fazem sentido e adicione-os à fila."
                      action={
                        <button
                          className="button secondary"
                          onClick={() => navigate("audience")}
                        >
                          Revisar meu público <ArrowRight size={16} />
                        </button>
                      }
                    />
                  )}
                </section>
                <Hint>
                  “Solicitado” é diferente de “Seguindo”. Se um resultado não
                  puder ser confirmado, a fila para e o perfil fica para
                  revisão, sem repetir a ação automaticamente.
                </Hint>
              </>
            ) : null}
            {page === "activity" ? (
              <section className="panel">
                <div className="panel-heading">
                  <div>
                    <h2>Histórico do espaço</h2>
                    <p>
                      Tentativas e resultados são registrados separadamente.
                    </p>
                  </div>
                  <button
                    className="button secondary small"
                    onClick={() =>
                      download(
                        "orbita-historico.json",
                        JSON.stringify(state.audit, null, 2),
                        "application/json",
                      )
                    }
                  >
                    <Download size={15} />
                    Exportar
                  </button>
                </div>
                {state.audit.length ? (
                  <div className="activity-list">
                    {state.audit.slice(0, 200).map((a) => (
                      <div key={a.id} className="activity-row">
                        <span className={`activity-icon ${a.kind}`}>
                          {a.kind === "followed" ? (
                            <Link2 size={17} />
                          ) : a.kind === "attempt" ? (
                            <ArrowUpRight size={17} />
                          ) : a.kind === "pause" ? (
                            <Pause size={17} />
                          ) : (
                            <Activity size={17} />
                          )}
                        </span>
                        <div>
                          <strong>
                            {a.username
                              ? `@${a.username}`
                              : a.kind === "import"
                                ? "Perfis importados"
                                : a.kind === "campaign"
                                  ? "Campanha atualizada"
                                  : a.kind === "pause"
                                    ? "Execução pausada"
                                    : "Atualização do espaço"}
                          </strong>
                          <p>{a.message}</p>
                          {a.account ? (
                            <small>Conta: @{a.account}</small>
                          ) : null}
                        </div>
                        <time>{date(a.at)}</time>
                      </div>
                    ))}
                  </div>
                ) : (
                  <Empty
                    icon={<Activity />}
                    title="Sua história começa na primeira ação"
                    text="Crie uma campanha ou importe uma lista para começar o registro."
                  />
                )}
              </section>
            ) : null}
            {page === "settings" ? (
              <SettingsPage
                key={
                  state.audit.find((a) =>
                    ["restore", "settings", "warning"].includes(a.kind),
                  )?.id || "settings"
                }
                state={state}
                account={account}
                run={run}
                busy={busy}
                flash={flash}
              />
            ) : null}
            {page === "help" ? <HelpPage /> : null}
            {page === "comparison" ? <ComparisonPage /> : null}
            {page === "problems" ? (
              <ProblemsPage account={account} snapshot={problemSnapshot} />
            ) : null}
            {page === "market" ? (
              <MarketPage
                key={account.id}
                account={account}
                run={runAccount}
                busy={busy}
              />
            ) : null}
            {page === "acquisition" ? (
              <AcquisitionPage
                key={account.id}
                account={account}
                run={runAccount}
                busy={busy}
                onRelationships={() => navigate("relationships")}
              />
            ) : null}
            {page === "relationships" ? (
              <RelationshipsPage
                key={account.id}
                account={account}
                run={runAccount}
                busy={busy}
              />
            ) : null}
            {page === "safety" ? (
              <SafetyPage
                state={state}
                run={run}
                busy={busy}
                onSettings={() => navigate("settings")}
              />
            ) : null}
            <footer className="page-footer">
              <span>Órbita · conexões com direção</span>
              <span>
                <ShieldCheck size={12} />
                Local por princípio. Você no controle.
              </span>
            </footer>
          </main>
        </div>
        {toast ? (
          <Toast
            message={toast.message}
            error={toast.error === true}
            onClose={() => setToast(null)}
          />
        ) : null}
        {modal === "campaign" ? (
          <CampaignModal
            run={run}
            busy={busy}
            onClose={() => setModal(null)}
            onCreated={() => {
              setModal(null);
              navigate("campaigns");
            }}
          />
        ) : null}
        {modal === "import" ? (
          <ImportModal
            campaigns={activeCampaigns}
            initialCampaign={importCampaign}
            run={run}
            busy={busy}
            onClose={() => setModal(null)}
            onImported={() => {
              setModal(null);
              navigate("audience");
            }}
          />
        ) : null}
        {modal === "start" ? (
          <Modal
            title="Iniciar a fila revisada"
            subtitle="Confira a conta e os controles antes de executar."
            onClose={() => setModal(null)}
          >
            <div className="start-summary">
              <div>
                <span>CONTA DE EXECUÇÃO</span>
                <strong>
                  {state.runtime.account
                    ? `@${state.runtime.account}`
                    : "Conecte a conta primeiro"}
                </strong>
              </div>
              <div>
                <span>PERFIS NA FILA</span>
                <strong>{queue.length}</strong>
              </div>
              <div>
                <span>INTERVALO</span>
                <strong>{state.settings.intervalMinutes} min</strong>
              </div>
              <div>
                <span>TETO DIÁRIO DE TENTATIVAS</span>
                <strong>{state.settings.dailyLimit}</strong>
              </div>
              <div>
                <span>NESTE PRÓXIMO LOTE, NO MÁXIMO</span>
                <strong>{safety.nextBatch} tentativas</strong>
              </div>
              <div>
                <span>JÁ REGISTRADAS HOJE</span>
                <strong>{safety.dailyUsed} tentativas</strong>
              </div>
            </div>
            <SafetyNotices state={state} />
            <Hint>
              A execução abre uma aba do Instagram e envia ações reais. Os
              controles configurados não garantem ausência de restrições. Você
              pode pausar pelo painel.
            </Hint>
            <label className="check-label start-review">
              <input
                type="checkbox"
                checked={reviewedStart}
                onChange={(e) => setReviewedStart(e.target.checked)}
              />
              Revisei os candidatos e conferi a conta no Instagram antes deste
              lote.
            </label>
            <div className="modal-actions">
              <button
                className="button secondary"
                onClick={() => setModal(null)}
              >
                Voltar
              </button>
              <button
                className="button primary"
                disabled={
                  busy ||
                  !isExtension ||
                  !reviewedStart ||
                  !!state.settings.hasPendingWarning ||
                  !safety.nextBatch
                }
                onClick={async () => {
                  if (
                    await run(
                      { type: "START", reviewed: reviewedStart },
                      "Fila iniciada. Acompanhe os resultados no painel.",
                    )
                  )
                    setModal(null);
                }}
              >
                <Play size={16} />
                Iniciar lote de até {safety.nextBatch}
              </button>
            </div>
          </Modal>
        ) : null}
        {selectedCandidate ? (
          <CandidateModal
            key={selectedCandidate.id}
            candidate={selectedCandidate}
            state={state}
            run={run}
            onClose={() => setDetail(null)}
          />
        ) : null}
        {accountModal === "add" ? (
          <AddAccountModal
            run={runAccount}
            busy={busy}
            onClose={() => setAccountModal(null)}
          />
        ) : null}
        {accountModal === "snapshot" ? (
          <SnapshotModal
            account={account}
            run={runAccount}
            busy={busy}
            onClose={() => setAccountModal(null)}
          />
        ) : null}
      </div>
    </ProfilePhotosProvider>
  );
}

function OrbitGraphic() {
  return (
    <div className="orbit-art" aria-hidden="true">
      <div className="orbit-orbit o1" />
      <div className="orbit-orbit o2" />
      <div className="orbit-orbit o3" />
      <div className="art-cross c1">+</div>
      <div className="art-cross c2">+</div>
      <div className="orbit-core">
        <img src="./orbita.svg" alt="" />
      </div>
      <div className="floating-profile fp1">
        <span className="mini-avatar">A</span>
        <span>
          <i />
          <i />
        </span>
        <span className="mini-check">
          <Check size={12} />
        </span>
      </div>
      <div className="floating-profile fp2">
        <span className="mini-avatar coral">M</span>
        <span>
          <i />
          <i />
        </span>
        <span className="mini-check">
          <Check size={12} />
        </span>
      </div>
      <div className="floating-icon fi1">
        <UsersRound size={19} />
      </div>
      <div className="floating-icon fi2">
        <Target size={20} />
      </div>
      <div className="orbit-label">
        <span />
        Pessoas certas. Novas possibilidades.
      </div>
    </div>
  );
}
function Stat({
  label,
  value,
  icon,
  foot,
  color,
}: {
  label: string;
  value: number;
  icon: React.ReactNode;
  foot: string;
  color: string;
}) {
  return (
    <div className={`stat-card stat-${color}`}>
      <div>
        <span>{label}</span>
        <span className={`stat-icon ${color}`}>{icon}</span>
      </div>
      <strong>{number(value)}</strong>
      <small>{foot}</small>
    </div>
  );
}
function Step({
  index,
  done,
  title,
  text,
  onClick,
}: {
  index: number;
  done: boolean;
  title: string;
  text: string;
  onClick: () => void;
}) {
  return (
    <button className={`journey-step ${done ? "done" : ""}`} onClick={onClick}>
      <span className="step-number">
        {done ? <Check size={15} /> : `0${index}`}
      </span>
      <span>
        <strong>{title}</strong>
        <small>{text}</small>
      </span>
      <ChevronRight size={15} />
    </button>
  );
}
function CampaignRow({
  campaign,
  state,
  onClick,
}: {
  campaign: Campaign;
  state: AppState;
  onClick: () => void;
}) {
  const count = state.candidates.filter((c) =>
    c.sources.some((s) => s.campaignId === campaign.id),
  ).length;
  return (
    <button className="campaign-row" onClick={onClick}>
      <span className={`source-symbol ${campaign.kind}`}>
        <SourceIcon kind={campaign.kind} />
      </span>
      <span>
        <strong>{campaign.name}</strong>
        <small>{SOURCE_LABELS[campaign.kind]}</small>
      </span>
      <b>
        {number(count)} <small>perfis</small>
      </b>
      <ArrowUpRight size={17} />
    </button>
  );
}

function CampaignModal({
  run,
  busy,
  onClose,
  onCreated,
}: {
  run: Run;
  busy: boolean;
  onClose: () => void;
  onCreated: () => void;
}) {
  const [kind, setKind] = useState<SourceKind>("followers");
  const [name, setName] = useState("");
  const [target, setTarget] = useState("");
  const placeholders: Record<SourceKind, string> = {
    followers: "@perfil_de_referencia",
    following: "@perfil_de_referencia",
    commenters: "https://www.instagram.com/p/.../",
    likers: "https://www.instagram.com/p/.../",
    hashtag: "#designbrasileiro",
    location: "https://www.instagram.com/explore/locations/.../",
    import: "Ex.: lista de contatos do meu evento",
  };
  return (
    <Modal
      title="Uma nova direção"
      subtitle="Escolha a fonte e dê um nome para sua campanha."
      onClose={onClose}
      wide
    >
      <form
        onSubmit={(event) => {
          event.preventDefault();
          void run(
            { type: "CREATE_CAMPAIGN", name, kind, target },
            "Campanha criada.",
          ).then((ok) => {
            if (ok) onCreated();
          });
        }}
      >
        <Field label="Nome da campanha">
          <input
            autoFocus
            required
            maxLength={100}
            placeholder="Ex.: Criadores de São Paulo"
            value={name}
            onChange={(e) => setName(e.target.value)}
          />
        </Field>
        <div className="field">
          <span>De onde vêm os perfis?</span>
          <SourceSelector
            kind={kind}
            onChange={(next) => {
              setKind(next);
              setTarget("");
            }}
          />
        </div>
        <Field
          label={
            kind === "import"
              ? "Descrição da lista (opcional)"
              : kind === "followers" || kind === "following"
                ? "Perfil de referência"
                : kind === "hashtag"
                  ? "Hashtag"
                  : "Link da fonte"
          }
          hint={
            kind === "import"
              ? "Você poderá importar um CSV ou colar os @perfis depois."
              : "A fonte será aberta na sua sessão local do Instagram."
          }
        >
          <input
            required={kind !== "import"}
            placeholder={placeholders[kind]}
            value={target}
            onChange={(e) => setTarget(e.target.value)}
          />
        </Field>
        <FormButtons onCancel={onClose} label="Criar campanha" busy={busy} />
      </form>
    </Modal>
  );
}
function ImportModal({
  campaigns,
  initialCampaign,
  run,
  busy,
  onClose,
  onImported,
}: {
  campaigns: Campaign[];
  initialCampaign: string;
  run: Run;
  busy: boolean;
  onClose: () => void;
  onImported: () => void;
}) {
  const [campaignId, setCampaignId] = useState(
    initialCampaign || campaigns[0]?.id || "",
  );
  const [text, setText] = useState("");
  const [parseError, setParseError] = useState("");
  const parsed = useMemo(() => {
    try {
      return parseCandidates(text);
    } catch (error) {
      return { candidates: [], invalid: 0, error: String(error) };
    }
  }, [text]);
  async function handle(event: FormEvent) {
    event.preventDefault();
    setParseError("");
    if ("error" in parsed) {
      setParseError(parsed.error || "Arquivo inválido.");
      return;
    }
    if (!parsed.candidates.length) {
      setParseError("Adicione ao menos um @perfil válido.");
      return;
    }
    if (
      await run(
        { type: "IMPORT", campaignId, candidates: parsed.candidates },
        `${parsed.candidates.length} registros processados. Perfis repetidos foram mesclados.`,
      )
    )
      onImported();
  }
  return (
    <Modal
      title="Traga seu público"
      subtitle="Importe um CSV ou cole uma lista de perfis. Repetidos são mesclados."
      onClose={onClose}
      wide
    >
      <form onSubmit={(event) => void handle(event)}>
        <Field label="Campanha de destino">
          <select
            required
            value={campaignId}
            onChange={(e) => setCampaignId(e.target.value)}
          >
            <option value="" disabled>
              Selecione uma campanha
            </option>
            {campaigns.map((c) => (
              <option key={c.id} value={c.id}>
                {c.name}
              </option>
            ))}
          </select>
        </Field>
        {!campaigns.length ? (
          <div className="notice">
            Crie uma campanha antes de importar sua primeira lista.
          </div>
        ) : null}
        <label className="file-drop">
          <Upload size={22} />
          <strong>Escolher arquivo CSV ou TXT</strong>
          <span>Até 5 MB · até 10.000 perfis por importação</span>
          <input
            type="file"
            accept=".csv,.txt,text/csv,text/plain"
            onChange={(event) => {
              const file = event.target.files?.[0];
              if (file) {
                if (file.size > 5_000_000) {
                  setParseError("O arquivo deve ter até 5 MB.");
                  return;
                }
                void file
                  .text()
                  .then(setText)
                  .catch(() =>
                    setParseError("Não foi possível ler o arquivo."),
                  );
              }
            }}
          />
        </label>
        <Field
          label="Ou cole seus perfis"
          hint="Um @perfil por linha. CSV: username, name, bio, followers, following, posts, is_private, id. Contagens em números inteiros, sem abreviação."
        >
          <textarea
            rows={6}
            placeholder={"@primeiro.perfil\n@segundo.perfil\n@terceiro.perfil"}
            value={text}
            onChange={(e) => setText(e.target.value)}
          />
        </Field>
        <div className="import-count">
          <Check size={15} />
          {parsed.candidates.length} registros válidos
          {parsed.invalid ? (
            <span>· {parsed.invalid} inválidos serão ignorados</span>
          ) : null}
        </div>
        {parseError || ("error" in parsed && parsed.error) ? (
          <div className="notice error" role="alert">
            {parseError || ("error" in parsed ? parsed.error : "")}
          </div>
        ) : null}
        <FormButtons
          onCancel={onClose}
          label="Importar perfis"
          busy={busy}
          disabled={!campaignId || !parsed.candidates.length}
        />
      </form>
    </Modal>
  );
}

function Audience({
  state,
  candidates,
  filters,
  setFilters,
  selected,
  setSelected,
  onDetail,
  run,
  busy,
  onImport,
}: {
  state: AppState;
  candidates: Candidate[];
  filters: Filters;
  setFilters: (f: Filters) => void;
  selected: Set<string>;
  setSelected: (s: Set<string>) => void;
  onDetail: (id: string) => void;
  run: Run;
  busy: boolean;
  onImport: () => void;
}) {
  const [advanced, setAdvanced] = useState(false);
  const [page, setPage] = useState(0);
  const pages = Math.max(1, Math.ceil(candidates.length / 25));
  const currentPage = Math.min(page, pages - 1);
  const visible = candidates.slice(currentPage * 25, currentPage * 25 + 25);
  const change = (patch: Partial<Filters>) => {
    setFilters({ ...filters, ...patch });
    setPage(0);
    setSelected(new Set());
  };
  const toggle = (id: string) => {
    const next = new Set(selected);
    if (next.has(id)) next.delete(id);
    else next.add(id);
    setSelected(next);
  };
  const batch = async (type: "APPROVE" | "QUEUE" | "EXCLUDE") => {
    if (
      await run(
        { type, ids: [...selected] },
        type === "APPROVE"
          ? "Perfis elegíveis aprovados."
          : type === "QUEUE"
            ? "Perfis aprovados adicionados à fila."
            : "Perfis excluídos das próximas ações.",
      )
    )
      setSelected(new Set());
  };
  return (
    <section className="panel audience-panel">
      <div className="audience-toolbar">
        <label className="search-input">
          <Search size={17} />
          <input
            aria-label="Buscar perfis"
            placeholder="Buscar por perfil, nome ou bio…"
            value={filters.query}
            onChange={(e) => change({ query: e.target.value })}
          />
        </label>
        <select
          aria-label="Filtrar por campanha"
          value={filters.campaignId}
          onChange={(e) => change({ campaignId: e.target.value })}
        >
          <option value="">Todas as campanhas</option>
          {state.campaigns.map((c) => (
            <option key={c.id} value={c.id}>
              {c.name}
              {c.archived ? " (arquivada)" : ""}
            </option>
          ))}
        </select>
        <select
          aria-label="Filtrar por estado"
          value={filters.stage}
          onChange={(e) => change({ stage: e.target.value })}
        >
          <option value="">Todos os estados</option>
          {(Object.keys(STAGE_LABELS) as Stage[]).map((s) => (
            <option key={s} value={s}>
              {STAGE_LABELS[s]}
            </option>
          ))}
        </select>
        <button
          className={`button secondary ${advanced ? "pressed" : ""}`}
          onClick={() => setAdvanced(!advanced)}
        >
          <SlidersHorizontal size={16} />
          Filtros
        </button>
      </div>
      {advanced ? (
        <div className="advanced-filters">
          <Field label="Mín. seguidores">
            <input
              type="number"
              min="0"
              placeholder="Sem mínimo"
              value={filters.minFollowers}
              onChange={(e) => change({ minFollowers: e.target.value })}
            />
          </Field>
          <Field label="Máx. seguidores">
            <input
              type="number"
              min="0"
              placeholder="Sem máximo"
              value={filters.maxFollowers}
              onChange={(e) => change({ maxFollowers: e.target.value })}
            />
          </Field>
          <Field label="Palavra na bio">
            <input
              placeholder="Ex.: arquitetura"
              value={filters.bio}
              onChange={(e) => change({ bio: e.target.value })}
            />
          </Field>
          <label className="check-label">
            <input
              type="checkbox"
              checked={filters.publicOnly}
              onChange={(e) => change({ publicOnly: e.target.checked })}
            />
            Somente públicos confirmados
          </label>
          <button
            className="text-link"
            onClick={() => {
              setFilters(emptyFilters());
              setSelected(new Set());
            }}
          >
            Limpar filtros
          </button>
          <p>
            Campos desconhecidos não passam por filtros que exigem essa
            informação. A captura de listas geralmente traz apenas o @perfil.
          </p>
        </div>
      ) : null}
      <div className="audience-summary">
        <span>
          <strong>{number(candidates.length)}</strong> perfis encontrados{" "}
          <span className="muted">· {state.candidates.length} no espaço</span>
        </span>
        {selected.size ? (
          <div className="batch-actions">
            <b>{selected.size} selecionados</b>
            <button disabled={busy} onClick={() => void batch("APPROVE")}>
              <CheckCheck size={15} />
              Aprovar
            </button>
            <button disabled={busy} onClick={() => void batch("QUEUE")}>
              <ListOrdered size={15} />
              Adicionar à fila
            </button>
            <button disabled={busy} onClick={() => void batch("EXCLUDE")}>
              <Ban size={15} />
              Excluir
            </button>
          </div>
        ) : (
          <span className="subtle-label">
            Selecione os perfis para revisar e aprovar
          </span>
        )}
      </div>
      {visible.length ? (
        <>
          <div className="table-scroll">
            <table>
              <thead>
                <tr>
                  <th className="check-cell">
                    <input
                      type="checkbox"
                      aria-label="Selecionar perfis desta página"
                      checked={
                        visible.length > 0 &&
                        visible.every((c) => selected.has(c.id))
                      }
                      onChange={(e) => {
                        const next = new Set(selected);
                        for (const c of visible)
                          if (e.target.checked) next.add(c.id);
                          else next.delete(c.id);
                        setSelected(next);
                      }}
                    />
                  </th>
                  <th>PERFIL</th>
                  <th>SEGUIDORES</th>
                  <th>ORIGEM</th>
                  <th>ESTADO</th>
                  <th />
                </tr>
              </thead>
              <tbody>
                {visible.map((c) => (
                  <tr
                    key={c.id}
                    className={selected.has(c.id) ? "selected-row" : ""}
                  >
                    <td className="check-cell">
                      <input
                        type="checkbox"
                        aria-label={`Selecionar ${c.username}`}
                        checked={selected.has(c.id)}
                        onChange={() => toggle(c.id)}
                      />
                    </td>
                    <td>
                      <button
                        className="profile-cell"
                        onClick={() => onDetail(c.id)}
                      >
                        <Avatar username={c.username} name={c.name} />
                        <span>
                          <strong>@{c.username}</strong>
                          <small>{c.name || "Nome não coletado"}</small>
                        </span>
                      </button>
                    </td>
                    <td>
                      <span className="follower-number">
                        {number(c.followers)}
                      </span>
                      <small className="cell-subtext">
                        {c.isPrivate === true
                          ? "Privado"
                          : c.isPrivate === false
                            ? "Público"
                            : "Privacidade desconhecida"}
                      </small>
                    </td>
                    <td>
                      <SourceBadge
                        campaign={state.campaigns.find(
                          (p) => p.id === c.sources[0]?.campaignId,
                        )}
                      />
                      {c.sources.length > 1 ? (
                        <small className="cell-subtext">
                          +{c.sources.length - 1} outras origens
                        </small>
                      ) : null}
                    </td>
                    <td>
                      <Badge stage={c.stage} />
                    </td>
                    <td>
                      <button
                        className="icon-button"
                        aria-label={`Ver detalhes de ${c.username}`}
                        onClick={() => onDetail(c.id)}
                      >
                        <ArrowUpRight size={17} />
                      </button>
                    </td>
                  </tr>
                ))}
              </tbody>
            </table>
          </div>
          <div className="pagination">
            <span>
              {currentPage * 25 + 1}–
              {Math.min((currentPage + 1) * 25, candidates.length)} de{" "}
              {candidates.length} perfis
            </span>
            <div>
              <button
                className="button secondary small"
                disabled={!currentPage}
                onClick={() => setPage(currentPage - 1)}
              >
                Anterior
              </button>
              <span>
                {currentPage + 1} / {pages}
              </span>
              <button
                className="button secondary small"
                disabled={currentPage + 1 >= pages}
                onClick={() => setPage(currentPage + 1)}
              >
                Próxima
              </button>
            </div>
          </div>
        </>
      ) : (
        <Empty
          icon={<UsersRound size={28} />}
          title={
            state.candidates.length
              ? "Nenhum perfil com esses critérios"
              : "Seu público vai ganhar forma aqui"
          }
          text={
            state.candidates.length
              ? "Ajuste os filtros. Informações desconhecidas não são tratadas como confirmadas."
              : "Capture perfis de uma campanha ou importe uma lista para começar a revisão."
          }
          action={
            <button
              className="button secondary"
              onClick={
                state.candidates.length
                  ? () => {
                      setFilters(emptyFilters());
                      setSelected(new Set());
                    }
                  : onImport
              }
            >
              {state.candidates.length
                ? "Limpar filtros"
                : "Importar minha lista"}
              <ArrowRight size={15} />
            </button>
          }
        />
      )}
    </section>
  );
}
function CandidateModal({
  candidate: c,
  state,
  run,
  onClose,
}: {
  candidate: Candidate;
  state: AppState;
  run: Run;
  onClose: () => void;
}) {
  const [note, setNote] = useState(c.note);
  const [rechecked, setRechecked] = useState(false);
  const fictitious = c.sources.some((s) => s.url.startsWith("demo:"));
  return (
    <Modal title="Contexto do perfil" onClose={onClose}>
      <div className="profile-detail">
        <Avatar username={c.username} name={c.name} large />
        <div>
          <h2>@{c.username}</h2>
          <p>{c.name || "Nome não coletado"}</p>
          <Badge stage={c.stage} />
        </div>
        {!fictitious ? (
          <a
            className="icon-button"
            aria-label="Abrir perfil no Instagram"
            href={`https://www.instagram.com/${c.username}/`}
            target="_blank"
            rel="noreferrer"
          >
            <ArrowUpRight />
          </a>
        ) : null}
      </div>
      {c.bio ? (
        <p className="profile-bio">{c.bio}</p>
      ) : (
        <p className="muted">Biografia não coletada.</p>
      )}
      <div className="profile-counts">
        <div>
          <strong>{number(c.followers)}</strong>
          <span>seguidores</span>
        </div>
        <div>
          <strong>{number(c.following)}</strong>
          <span>seguindo</span>
        </div>
        <div>
          <strong>{number(c.posts)}</strong>
          <span>publicações</span>
        </div>
      </div>
      {c.lastResult ? <div className="notice">{c.lastResult}</div> : null}
      <div className="detail-sources">
        <h3>De onde veio este perfil</h3>
        {c.sources.map((s, i) => (
          <div key={`${s.campaignId}-${i}`}>
            <SourceBadge
              campaign={state.campaigns.find((p) => p.id === s.campaignId)}
            />
            <small>{date(s.at)}</small>
            {s.url.startsWith("https://www.instagram.com/") ? (
              <External href={s.url}>Ver fonte</External>
            ) : null}
          </div>
        ))}
      </div>
      <Field label="Suas anotações">
        <textarea
          rows={3}
          value={note}
          maxLength={2000}
          onChange={(e) => setNote(e.target.value)}
          placeholder="O que torna este perfil relevante?"
        />
      </Field>
      {["uncertain", "failed", "excluded"].includes(c.stage) ? (
        <label className="check-label">
          <input
            type="checkbox"
            checked={rechecked}
            onChange={(e) => setRechecked(e.target.checked)}
          />
          Conferi o estado deste perfil no Instagram e quero revisá-lo
          novamente.
        </label>
      ) : null}
      <div className="modal-actions">
        {["uncertain", "failed", "excluded"].includes(c.stage) ? (
          <button
            className="button secondary"
            disabled={!rechecked}
            onClick={() =>
              void run(
                { type: "RETURN_TO_REVIEW", id: c.id },
                "Perfil devolvido à revisão e retirado da lista de exclusão.",
              )
            }
          >
            Devolver à revisão
          </button>
        ) : null}
        <button
          className="button secondary"
          onClick={() =>
            void run({ type: "NOTE", id: c.id, note }, "Anotação salva.")
          }
        >
          Salvar anotação
        </button>
        {c.stage === "new" ? (
          <button
            className="button primary"
            onClick={() =>
              void run({ type: "APPROVE", ids: [c.id] }, "Perfil aprovado.")
            }
          >
            <CheckCheck size={16} />
            Aprovar perfil
          </button>
        ) : c.stage === "approved" && !fictitious ? (
          <button
            className="button primary"
            onClick={() =>
              void run(
                { type: "QUEUE", ids: [c.id] },
                "Perfil adicionado à fila.",
              )
            }
          >
            <Plus size={16} />
            Adicionar à fila
          </button>
        ) : null}
      </div>
    </Modal>
  );
}

function SettingsPage({
  state,
  account,
  run,
  busy,
  flash,
}: {
  state: AppState;
  account: AccountWorkspace;
  run: Run;
  busy: boolean;
  flash: (message: string, error?: boolean) => void;
}) {
  const [settings, setSettings] = useState<Settings>(state.settings);
  const [exclusions, setExclusions] = useState(
    state.settings.exclusions.join("\n"),
  );
  const [restore, setRestore] = useState<unknown>(null);
  const [restoreName, setRestoreName] = useState("");
  return (
    <>
      <div className="settings-grid">
        <form
          className="panel settings-panel"
          onSubmit={(event) => {
            event.preventDefault();
            void run(
              {
                type: "SETTINGS",
                settings: {
                  ...settings,
                  exclusions: exclusions.split(/[\s,;]+/).filter(Boolean),
                },
              },
              "Preferências salvas.",
            );
          }}
        >
          <div className="settings-title">
            <Clock3 size={20} />
            <div>
              <h2>Ritmo e horários</h2>
              <p>Controles de execução definidos por você.</p>
            </div>
          </div>
          <button
            type="button"
            className="button secondary full starter-settings-button"
            disabled={busy}
            onClick={() =>
              void run(
                { type: "APPLY_STARTER" },
                "Começo guiado aplicado; fila pausada e contadores preservados.",
              )
            }
          >
            <ShieldCheck size={16} />
            Usar começo guiado: 5/dia · lote de 5 · 15 min
          </button>
          <div className="form-grid">
            <Field label="Teto diário de tentativas">
              <input
                type="number"
                min="1"
                max="500"
                step="1"
                value={settings.dailyLimit}
                onChange={(e) =>
                  setSettings({
                    ...settings,
                    dailyLimit: Number(e.target.value),
                  })
                }
              />
            </Field>
            <Field label="Intervalo entre perfis (min)">
              <input
                type="number"
                min="1"
                max="1440"
                value={settings.intervalMinutes}
                onChange={(e) =>
                  setSettings({
                    ...settings,
                    intervalMinutes: Number(e.target.value),
                  })
                }
              />
            </Field>
            <Field
              label="Máximo de tentativas por lote"
              hint="A fila pausa ao concluir esse lote; só continua se você iniciar outro, dentro do teto diário."
            >
              <input
                type="number"
                min="1"
                max="500"
                step="1"
                required
                value={sessionLimit(settings)}
                onChange={(e) =>
                  setSettings({
                    ...settings,
                    sessionLimit: Number(e.target.value),
                  })
                }
              />
            </Field>
            <Field label="Início da janela">
              <input
                type="time"
                required
                value={settings.startHour}
                onChange={(e) =>
                  setSettings({ ...settings, startHour: e.target.value })
                }
              />
            </Field>
            <Field label="Fim da janela">
              <input
                type="time"
                required
                value={settings.endHour}
                onChange={(e) =>
                  setSettings({ ...settings, endHour: e.target.value })
                }
              />
            </Field>
          </div>
          <DraftPaceNotice settings={settings} />
          <div className="pending-warning-control">
            <label className="check-label">
              <input
                type="checkbox"
                checked={!!settings.hasPendingWarning}
                onChange={(e) =>
                  setSettings({
                    ...settings,
                    hasPendingWarning: e.target.checked,
                  })
                }
              />
              Há um aviso ou pedido de verificação pendente na minha conta
            </label>
            <p>
              Marcar e salvar suspende coleta e execução. Desmarque somente
              depois de conferir que o aviso foi resolvido no Instagram. Isso
              não comprova que a conta ficará livre de restrições.
            </p>
          </div>
          <Hint>
            Os valores são controles do aplicativo, não limites seguros
            publicados pelo Instagram. Vale o horário local deste computador.
          </Hint>
          <div className="settings-title separator">
            <Ban size={20} />
            <div>
              <h2>Lista de exclusão</h2>
              <p>Estes perfis não entram nas próximas ações.</p>
            </div>
          </div>
          <Field label="Um @perfil por linha">
            <textarea
              rows={5}
              placeholder={"@perfil_protegido\n@nao_interagir"}
              value={exclusions}
              onChange={(e) => setExclusions(e.target.value)}
            />
          </Field>
          <button className="button primary" disabled={busy}>
            <Check size={16} />
            Salvar preferências
          </button>
        </form>
        <div className="settings-side">
          <section className="panel settings-panel">
            <div className="settings-title">
              <ShieldCheck size={20} />
              <div>
                <h2>Um espaço local</h2>
                <p>Sem uma conta adicional na Órbita.</p>
              </div>
            </div>
            <p className="body-copy">
              Campanhas, listas e histórico ficam neste navegador. A extensão
              usa a sessão já aberta do Instagram e não solicita sua senha.
            </p>
            <div className="connection-detail">
              <Instagram size={22} />
              <div>
                <strong>
                  {state.runtime.account
                    ? `@${state.runtime.account}`
                    : "Nenhuma conta identificada"}
                </strong>
                <small>
                  {isExtension
                    ? "Dados separados por conta · uma execução por vez"
                    : "Instale a extensão para conectar"}
                </small>
              </div>
            </div>
            <button
              className="button secondary"
              disabled={busy}
              onClick={() =>
                void run({ type: "CONNECT" }, "Sessão identificada.")
              }
            >
              <Link2 size={16} />
              Identificar sessão
            </button>
          </section>
          <section className="panel settings-panel">
            <div className="settings-title">
              <FolderOpen size={20} />
              <div>
                <h2>Backup do espaço</h2>
                <p>Leve seus dados com você.</p>
              </div>
            </div>
            <p className="body-copy">
              O backup contém suas listas e anotações. Guarde-o em um lugar de
              confiança. A restauração substitui o espaço atual e não retoma
              ações.
            </p>
            <button
              className="button secondary full"
              onClick={() =>
                download(
                  `orbita-${account.username || "conta"}-backup.json`,
                  JSON.stringify(accountBackup(account), null, 2),
                  "application/json",
                )
              }
            >
              <Download size={16} />
              Exportar backup JSON
            </button>
            <label className="button secondary full restore-button">
              <Upload size={16} />
              Selecionar backup para restaurar
              <input
                type="file"
                accept=".json,application/json"
                onChange={(e) => {
                  const file = e.target.files?.[0];
                  if (!file) return;
                  if (file.size > 15_000_000) {
                    flash("O backup deve ter até 15 MB.", true);
                    return;
                  }
                  void file.text().then((text) => {
                    try {
                      setRestore(JSON.parse(text));
                      setRestoreName(file.name);
                    } catch {
                      flash("Arquivo JSON inválido.", true);
                    }
                  });
                }}
              />
            </label>
          </section>
        </div>
      </div>
      {restore ? (
        <Modal
          title="Restaurar este backup?"
          subtitle={restoreName}
          onClose={() => setRestore(null)}
        >
          <p className="body-copy">
            As campanhas, os perfis e as preferências atuais serão substituídos.
            Exporte um backup antes se quiser preservá-los. A conexão e a fila
            em execução não são restauradas.
          </p>
          <div className="modal-actions">
            <button
              className="button secondary"
              onClick={() => setRestore(null)}
            >
              Cancelar
            </button>
            <button
              className="button primary"
              disabled={busy}
              onClick={async () => {
                if (
                  await run(
                    { type: "RESTORE", data: restore },
                    "Backup restaurado. Preferências importadas e execução pausada.",
                  )
                )
                  setRestore(null);
              }}
            >
              Substituir e restaurar
            </button>
          </div>
        </Modal>
      ) : null}
    </>
  );
}
function HelpPage() {
  return (
    <div className="help-grid">
      <section className="panel help-panel">
        <span className="source-symbol followers">
          <FolderOpen size={24} />
        </span>
        <h2>Instale uma vez. Use no seu navegador.</h2>
        <p>
          A versão local é uma extensão para Chrome ou Edge. O painel aberto
          fora da extensão permite organizar listas, mas não se conecta ao
          Instagram.
        </p>
        <ol className="installation-steps">
          <li>
            <b>Abra a página de extensões</b>
            <span>
              Chrome: <code>chrome://extensions</code>
              <br />
              Edge: <code>edge://extensions</code>
            </span>
          </li>
          <li>
            <b>Ative o Modo do desenvolvedor</b>
            <span>O controle fica no alto da página de extensões.</span>
          </li>
          <li>
            <b>Clique em “Carregar sem compactação”</b>
            <span>
              Selecione a pasta <code>orbita\dist</code> fornecida com o
              projeto. Descompacte o ZIP antes, se estiver usando o pacote.
            </span>
          </li>
          <li>
            <b>Abra a Órbita pelo ícone da extensão</b>
            <span>
              Em Contas, cadastre o @perfil. Entre nessa conta pelo Instagram e
              clique em “Conectar sessão”. O menu Perfil precisa permitir
              identificar a conta.
            </span>
          </li>
        </ol>
        <Hint>
          Os dados da prévia e os da extensão são separados. Exporte e restaure
          um backup para transferir suas campanhas.
        </Hint>
        <Hint>
          Cadastre outras contas em Contas e use o seletor no alto do painel.
          Cada conta tem dashboard, campanhas, público, fila e preferências
          próprios. A troca pausa a fila. O Instagram mantém uma sessão ativa
          neste navegador: troque a conta no próprio Instagram e verifique aqui
          antes de executar.
        </Hint>
      </section>
      <div>
        <section className="panel help-panel">
          <h2>Seu primeiro fluxo</h2>
          <div className="help-flow">
            <span>01</span>
            <p>
              <b>Campanha</b>Escolha seguidores, seguidos, comentários,
              curtidas, hashtags, localização ou importação.
            </p>
          </div>
          <div className="help-flow">
            <span>02</span>
            <p>
              <b>Coleta</b>Abra a fonte. Na página do Instagram, abra a lista e
              use “Capturar carregados”. Role para trazer mais perfis.
            </p>
          </div>
          <div className="help-flow">
            <span>03</span>
            <p>
              <b>Revisão</b>Filtre os candidatos, consulte as origens e aprove
              sua seleção. Só depois adicione os aprovados à fila.
            </p>
          </div>
          <div className="help-flow">
            <span>04</span>
            <p>
              <b>Execução</b>Confira a conta e inicie a fila. O navegador
              precisa permanecer aberto. A Órbita para em desafios e resultados
              incertos.
            </p>
          </div>
        </section>
        <section className="panel help-panel limitations">
          <h2>O que esta versão confirma</h2>
          <p>
            A coleta e a execução usam a interface visível do Instagram e podem
            precisar de ajustes quando ela mudar. A integração real ainda
            precisa ser validada na sua sessão.
          </p>
          <p>
            O resultado de seguir é confirmado pela leitura do botão “Seguindo”
            ou “Solicitado”. Isso não prova que a pessoa passou a seguir você de
            volta.
          </p>
          <p>
            Não há leitura de conteúdo privado, solução de CAPTCHA, promessa de
            crescimento ou garantia contra restrições. Recursos de publicação,
            mensagens e Stories ficam fora desta primeira versão.
          </p>
          <External href="https://github.com/InstaPy/InstaPy">
            Referência: InstaPy
          </External>
          <External href="https://github.com/GramAddict/bot">
            Referência: GramAddict
          </External>
          <External href="https://github.com/subzeroid/instagrapi">
            Referência: instagrapi
          </External>
        </section>
      </div>
    </div>
  );
}
