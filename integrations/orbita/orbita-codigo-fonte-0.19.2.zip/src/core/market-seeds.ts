import type {
  AccountWorkspace,
  MarketBook,
  MarketProfile,
  MarketReference,
} from "./types.ts";

// Fontes da pesquisa já registrada em 03/11/2026. Nenhuma consulta nova é presumida.
export const MARKET_RESEARCH = [
  {
    sector: "fitness",
    creator: "Paula Fashion Fitness",
    url: "https://paulafashion.com.br/",
    pattern: "backstage" as const,
    title: "Fábrica e comunicação para lojistas",
    note: "O site apresenta fabricação própria, grade comercial e foco em lojistas. Hipótese: mostrar produção e orientar a montagem de pedidos. Não foi possível medir Reels ou provar desempenho.",
  },
  {
    sector: "fitness",
    creator: "Jeniffer moda fitness",
    url: "https://www.facebook.com/ads/library/?id=1250101639757350",
    pattern: "faq" as const,
    title: "Anúncio de produto e entrega",
    note: "Anúncio em vídeo encontrado na Biblioteca da Meta, com chamada para o site e entrega nacional. Modelo de atacado não confirmado. Anúncio ativo não prova venda, alcance no Instagram ou viralização.",
  },
  {
    sector: "beachwear",
    creator: "Biquinell",
    url: "https://www.biquinell.com.br/atacado/",
    pattern: "faq" as const,
    title: "Como comprar e montar um mix no atacado",
    note: "A página de atacado explica pedido e variedade de modelos, cores e tamanhos. Hipótese: responder dúvidas de lojistas em conteúdo próprio. Não há métricas públicas verificadas de Reels nesta consulta.",
  },
  {
    sector: "beachwear",
    creator: "La Coquille",
    url: "https://www.lacoquille.com.br/pagina/atacado.html",
    pattern: "mix" as const,
    title: "Grade, reposição e catálogo para revenda",
    note: "A página apresenta variedade, reposição e consulta de grade por atendimento. Hipótese: demonstrar combinações e tirar dúvidas sobre compra. Isso não comprova uma tendência de engajamento.",
  },
];

export const MARKET_RESEARCH_AT = "2026-11-03T14:20:00.000Z";

/** Contexto informado pelo usuário; não é uma inferência de bio nem verificação da conta. */
export function knownBusinessProfile(
  username: string | undefined,
): MarketProfile | undefined {
  if (username === "bfffitness_atacado")
    return {
      sector: "fitness",
      model: "wholesale",
      audience:
        "Lojistas e revendedores de moda fitness · contexto informado por você.",
      bio: "",
      updatedAt: MARKET_RESEARCH_AT,
    };
  if (username === "moranga_biquinis")
    return {
      sector: "beachwear",
      model: "unknown",
      audience:
        "Biquínis e moda praia · contexto informado por você. Confirme seu público e modelo de venda.",
      bio: "",
      updatedAt: MARKET_RESEARCH_AT,
    };
}
export function researchReference(
  row: (typeof MARKET_RESEARCH)[number],
): Omit<MarketReference, "id" | "source" | "archived" | "updatedAt"> {
  const ad = row.url.includes("facebook.com");
  return {
    ...row,
    model: ad ? "unknown" : "wholesale",
    kind: ad ? "ad" : "article",
    distribution: ad ? "paid" : "unknown",
    observedAt: MARKET_RESEARCH_AT,
    metrics: {},
    hook: "",
    cta: "",
    note: `Pesquisa consultada em 03/11/2026; não atualizada automaticamente. ${row.note}`,
  };
}
/** Prepara somente contexto já informado e fontes existentes, sem qualquer métrica nova. */
export function prepareKnownMarket(account: AccountWorkspace): void {
  const known = knownBusinessProfile(account.username);
  if (!known || !account.username) return;
  const book: MarketBook = (account.market ||= {
    version: 1,
    account: account.username,
    references: [],
    experiments: [],
  });
  if (book.account !== account.username)
    throw new Error("O radar precisa pertencer à conta selecionada.");
  book.profile ||= known;
  // Nunca substitui referências, medições, arquivamentos ou contexto escolhido pela pessoa.
  if (book.references.length || book.experiments.length) return;
  book.references = MARKET_RESEARCH.filter(
    (r) => r.sector === book.profile!.sector,
  ).map((r, i) => ({
    ...researchReference(r),
    id: `research-initial-${account.username}-${i}`,
    source: "manual",
    archived: false,
    updatedAt: MARKET_RESEARCH_AT,
  }));
}
