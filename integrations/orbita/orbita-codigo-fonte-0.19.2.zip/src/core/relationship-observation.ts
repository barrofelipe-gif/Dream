import type { AccountWorkspace, Candidate } from "./types.ts";

export interface CandidateRelationshipReading {
  account: string;
  username: string;
  at: string;
  status: "following" | "requested" | "not_following";
}
const canonical = (value: unknown): value is string =>
  typeof value === "string" && /^[a-z0-9._]{1,30}$/.test(value);
function timestamp(value: unknown): number | undefined {
  if (
    typeof value !== "string" ||
    !/^\d{4}-\d{2}-\d{2}T\d{2}:\d{2}(?::\d{2}(?:\.\d{1,3})?)?(?:Z|[+-]\d{2}:\d{2})$/.test(
      value,
    ) ||
    !Number.isFinite(Date.parse(value)) ||
    Number(value.slice(11, 13)) > 23 ||
    Number(value.slice(14, 16)) > 59 ||
    Number(value.slice(17, 19) || 0) > 59 ||
    new Date(value.slice(0, 10)).toISOString().slice(0, 10) !==
      value.slice(0, 10)
  )
    return undefined;
  return Date.parse(value);
}
/** An observed relationship is historical data, never a proof that this app sent a click. */
export function validateCandidateRelationshipObservation(
  candidate: Candidate,
  owner?: string,
  restored = false,
  now = new Date(),
): void {
  const value = candidate.relationshipObserved;
  if (value === undefined) return;
  const at = timestamp(value?.at);
  if (
    !value ||
    typeof value !== "object" ||
    Array.isArray(value) ||
    !canonical(value.account) ||
    (owner !== undefined && value.account !== owner) ||
    !["following", "requested", "not_following"].includes(value.status) ||
    !["instagram", "restored"].includes(value.source) ||
    at === undefined ||
    at > now.getTime() + 60000
  )
    throw new Error(
      "A observação do vínculo está inválida ou pertence a outra conta.",
    );
  candidate.relationshipObserved = {
    account: value.account,
    status: value.status,
    at: new Date(at).toISOString(),
    source: restored ? "restored" : value.source,
  };
}

/** Called only after the worker has independently checked the session and read the target page. */
export function applyCandidateRelationshipObservation(
  account: AccountWorkspace,
  id: string,
  reading: CandidateRelationshipReading,
  now = new Date(),
): void {
  const owner = account.username;
  const candidate = account.data.candidates.find((c) => c.id === id);
  if (
    !canonical(owner) ||
    account.data.runtime.account !== owner ||
    reading.account !== owner
  )
    throw new Error(
      "A conferência precisa pertencer à conta selecionada e à sessão conectada.",
    );
  if (
    account.data.runtime.mode !== "paused" ||
    account.data.candidates.some((c) => c.stage === "attempting")
  )
    throw new Error(
      "Pause a fila e aguarde a ação atual antes de conferir o resultado.",
    );
  if (
    !candidate ||
    candidate.stage !== "uncertain" ||
    (candidate.queuedAction || "follow") !== "follow" ||
    candidate.queueAccount !== owner ||
    !canonical(candidate.username) ||
    candidate.username === owner ||
    reading.username !== candidate.username ||
    candidate.sources.some((s) => s.url.startsWith("demo:"))
  )
    throw new Error(
      "Somente um resultado de seguir incerto desta conta pode ser conferido, sem repetir a ação.",
    );
  const at = timestamp(reading.at);
  if (
    at === undefined ||
    !Number.isFinite(now.getTime()) ||
    at > now.getTime() + 1000 ||
    now.getTime() - at > 120000
  )
    throw new Error(
      "A observação precisa ser uma leitura recente e válida do perfil selecionado.",
    );
  const previousAt = timestamp(candidate.relationshipObserved?.at);
  if (previousAt !== undefined && previousAt > at)
    throw new Error(
      "Há uma observação mais recente deste perfil. Confira os dados atuais antes de continuar.",
    );
  // Validate before mutating anything, including the audit journal.
  const checked: Candidate = {
    ...candidate,
    relationshipObserved: {
      account: reading.account,
      at: reading.at,
      status: reading.status,
      source: "instagram",
    },
  };
  validateCandidateRelationshipObservation(checked, owner, false, now);
  const observation = checked.relationshipObserved!;
  candidate.relationshipObserved = observation;
  if (observation.status === "following") candidate.stage = "followed";
  else if (observation.status === "requested") candidate.stage = "requested";
  candidate.updatedAt = now.toISOString();
  const label =
    observation.status === "following"
      ? "Seguindo"
      : observation.status === "requested"
        ? "Solicitado"
        : "Seguir";
  account.data.audit = [
    {
      id: crypto.randomUUID(),
      at: now.toISOString(),
      kind: "relationship_verified",
      username: candidate.username,
      account: owner,
      message: `Conferência sem clique: Instagram exibiu ${label}. A observação não comprova a ação original nem habilita deixar de seguir.`,
    },
    ...account.data.audit,
  ].slice(0, 3000);
}
