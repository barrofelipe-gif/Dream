import { normalizeUsername, sourceUrl } from "./domain.ts";
import type { Campaign, Candidate } from "./types.ts";

export const PROFILE_SOURCES = ["followers", "commenters", "likers"] as const;
export function profileSource(value: string): string {
  let text = value.trim();
  if (/^https?:\/\//i.test(text)) {
    const url = new URL(text);
    if (url.protocol !== "https:" || !["instagram.com", "www.instagram.com"].includes(url.hostname) || url.port || url.username || url.password || !/^\/[a-z0-9._]{1,30}\/?$/i.test(url.pathname))
      throw new Error("Informe o @perfil ou o link do perfil no Instagram.");
    text = url.pathname.split("/").filter(Boolean)[0];
  }
  const profile = normalizeUsername(text);
  if (!profile) throw new Error("Informe um @perfil válido para a campanha.");
  return profile;
}
export function profileCampaignPlan(name: string, profileValue: string, postValue: string) {
  const title = name.trim();
  if (!title || title.length > 100) throw new Error("Dê um nome de até 100 caracteres para a campanha.");
  const profile = profileSource(profileValue);
  let url: URL;
  try { url = new URL(postValue.trim()); } catch { throw new Error("Cole o link de uma publicação ou Reel desse perfil para preparar comentários e curtidas."); }
  if (url.protocol !== "https:" || !["instagram.com", "www.instagram.com"].includes(url.hostname) || url.port || url.username || url.password)
    throw new Error("Use um link https de publicação do Instagram.");
  const match = url.pathname.match(/^\/(?:(?<owner>[a-z0-9._]{1,30})\/)?(?<kind>p|reel)\/(?<code>[\w-]+)\/?$/i);
  if (!match?.groups || (match.groups.owner && match.groups.owner.toLowerCase() !== profile))
    throw new Error("Use o link de uma publicação ou Reel do perfil informado.");
  const postUrl = sourceUrl("commenters", `https://www.instagram.com/${match.groups.kind.toLowerCase()}/${match.groups.code}/`);
  return { name: title, profile, postUrl, sources: PROFILE_SOURCES.map((kind) => ({ kind, target: kind === "followers" ? `@${profile}` : postUrl })) };
}
export function checkedCampaignGroup(value: unknown, campaign: Pick<Campaign, "kind" | "target">): NonNullable<Campaign["group"]> | undefined {
  if (value === undefined) return;
  if (!value || typeof value !== "object") throw new Error("Grupo de campanha inválido.");
  const group = value as NonNullable<Campaign["group"]>;
  if (typeof group.id !== "string" || !/^[\w-]{1,100}$/.test(group.id) || typeof group.name !== "string" || typeof group.profile !== "string" || typeof group.postUrl !== "string") throw new Error("Grupo de campanha inválido.");
  const plan = profileCampaignPlan(group.name, group.profile, group.postUrl);
  const source = plan.sources.find((s) => s.kind === campaign.kind);
  if (!source || plan.profile !== group.profile || plan.postUrl !== group.postUrl || plan.name !== group.name || sourceUrl(campaign.kind, campaign.target) !== sourceUrl(source.kind, source.target))
    throw new Error("A fonte não corresponde ao perfil e à publicação da campanha agrupada.");
  return { id: group.id, name: plan.name, profile: plan.profile, postUrl: plan.postUrl };
}
export function groupedCampaigns(campaigns: Campaign[]) {
  const groups = new Map<string, { id: string; name: string; profile?: string; postUrl?: string; sources: Campaign[] }>();
  for (const campaign of campaigns.filter((c) => !c.archived)) {
    const group = checkedCampaignGroup(campaign.group, campaign);
    const key = group ? `group:${group.id}` : `source:${campaign.id}`;
    if (!groups.has(key)) groups.set(key, { id: key, name: group?.name || campaign.name, profile: group?.profile, postUrl: group?.postUrl, sources: [] });
    const current = groups.get(key)!;
    if (group && (current.profile !== group.profile || current.postUrl !== group.postUrl || current.name !== group.name)) throw new Error("As fontes da campanha agrupada estão divergentes.");
    current.sources.push(campaign);
  }
  return [...groups.values()].map((group) => ({ ...group, sources: group.profile ? [...group.sources].sort((a, b) => PROFILE_SOURCES.indexOf(a.kind as typeof PROFILE_SOURCES[number]) - PROFILE_SOURCES.indexOf(b.kind as typeof PROFILE_SOURCES[number])) : group.sources }));
}
export function campaignMembers(candidates: Candidate[], sources: Campaign[]) {
  const ids = new Set(sources.map((source) => source.id));
  return candidates.filter((candidate) => candidate.sources.some((source) => ids.has(source.campaignId)));
}
