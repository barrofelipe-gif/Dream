import type {
  AccountWorkspace,
  Candidate,
  Settings,
  SourceKind,
} from "./types.ts";
import { validateCandidateRelationshipObservation } from "./relationship-observation.ts";

const DAY = 86_400_000;
export type Reciprocity = {
  status: "yes" | "no" | "unknown";
  measuredAt?: string;
  snapshotId?: string;
  followersComplete?: boolean;
  source?: "manual" | "file";
};
export interface ProspectingRow {
  cycleId: string;
  candidateId: string;
  username: string;
  stage: Candidate["stage"];
  queuedAction?: Candidate["queuedAction"];
  confirmedFollowAt?: string;
  confirmedFollowAccount?: string;
  confirmedFollowSource?: Candidate["confirmedFollowSource"];
  ageDays?: number;
  dueAt?: string;
  ready: boolean;
  canQueue: boolean;
  status:
    "waiting" | "ready" | "queued" | "attempting" | "unfollowed" | "blocked";
  reasons: string[];
  codes: string[];
  protected: boolean;
  protectionReason?: string;
  excluded: boolean;
  sources: {
    campaignId: string;
    name?: string;
    kind?: SourceKind;
    target?: string;
    url: string;
    at: string;
    archived?: boolean;
  }[];
  reciprocity: Reciprocity;
}
const canonical = (value: unknown): value is string =>
  typeof value === "string" && /^[a-z0-9._]{1,30}$/.test(value);
function instant(value: unknown): number | undefined {
  if (
    typeof value !== "string" ||
    !/^\d{4}-\d{2}-\d{2}T\d{2}:\d{2}(?::\d{2}(?:\.\d{1,3})?)?(?:Z|[+-]\d{2}:\d{2})$/.test(
      value,
    ) ||
    !Number.isFinite(Date.parse(value)) ||
    Number(value.slice(11, 13)) > 23 ||
    Number(value.slice(14, 16)) > 59 ||
    Number(value.slice(17, 19) || 0) > 59 ||
    new Date(value.slice(0, 10)).toISOString().slice(0, 10) !==
      value.slice(0, 10)
  )
    return undefined;
  return Date.parse(value);
}
export function validateProspectingSettings(settings: Settings): void {
  if (!settings || typeof settings !== "object")
    throw new Error("Preferências da revisão inválidas.");
  if (
    settings.reviewAfterDays !== undefined &&
    (!Number.isSafeInteger(settings.reviewAfterDays) ||
      settings.reviewAfterDays < 1 ||
      settings.reviewAfterDays > 365)
  )
    throw new Error("O prazo de revisão deve ser um inteiro de 1 a 365 dias.");
  if (
    settings.reviewPolicy !== undefined &&
    !["preserve_followers", "review_all"].includes(settings.reviewPolicy)
  )
    throw new Error(
      "Escolha preservar seguidores ou revisar todos para a revisão da prospecção.",
    );
}
/** Storage reload preserves native proofs. Only an explicit restore demotes them. */
export function validateProspectingCandidate(
  candidate: Candidate,
  owner?: string,
  restored = false,
  now = new Date(),
): void {
  validateCandidateRelationshipObservation(candidate, owner, restored, now);
  if (
    candidate.queuedAction !== undefined &&
    !["follow", "unfollow"].includes(candidate.queuedAction)
  )
    throw new Error("Há uma ação de fila inválida no cadastro.");
  const proof = [
    candidate.confirmedFollowAt,
    candidate.confirmedFollowAccount,
    candidate.confirmedFollowSource,
  ];
  if (proof.some((v) => v !== undefined)) {
    const at = instant(candidate.confirmedFollowAt);
    if (
      at === undefined ||
      at > now.getTime() + 60000 ||
      !canonical(candidate.confirmedFollowAccount) ||
      !["orbita", "restored"].includes(candidate.confirmedFollowSource || "") ||
      (owner && candidate.confirmedFollowAccount !== owner)
    )
      throw new Error(
        "A confirmação de seguir está inválida ou pertence a outra conta.",
      );
    if (restored) candidate.confirmedFollowSource = "restored";
  }
  if (
    ["queued", "attempting"].includes(candidate.stage) &&
    candidate.queuedAction === undefined
  )
    candidate.queuedAction = "follow";
}
function relationship(
  account: AccountWorkspace,
  candidate: Candidate,
  due: number | undefined,
  now: number,
): Reciprocity {
  const latest = (account.relationships?.snapshots || [])
    .filter(
      (s) =>
        s.account === account.username &&
        instant(s.at) !== undefined &&
        Date.parse(s.at) <= now,
    )
    .sort((a, b) => Date.parse(b.at) - Date.parse(a.at))[0];
  if (!latest) return { status: "unknown" };
  const base = {
    measuredAt: latest.at,
    snapshotId: latest.id,
    followersComplete: latest.followersComplete,
    source: latest.source,
  };
  // A partial list proves presence, never absence. Do not fall back to an older
  // complete list when a newer partial observation has replaced it.
  if (latest.followers.includes(candidate.username))
    return { ...base, status: "yes" };
  if (
    latest.followersComplete &&
    due !== undefined &&
    Date.parse(latest.at) >= due
  )
    return { ...base, status: "no" };
  return { ...base, status: "unknown" };
}
function reviewRow(
  account: AccountWorkspace,
  candidate: Candidate,
  now: Date,
): ProspectingRow {
  const clock = now.getTime(),
    at = instant(candidate.confirmedFollowAt),
    days = account.data.settings.reviewAfterDays;
  const configured =
    Number.isSafeInteger(days) &&
    days !== undefined &&
    days >= 1 &&
    days <= 365;
  const validProof =
    at !== undefined &&
    at <= clock &&
    canonical(account.username) &&
    candidate.confirmedFollowAccount === account.username &&
    candidate.confirmedFollowSource === "orbita" &&
    (!candidate.relationshipObserved ||
      (instant(candidate.relationshipObserved.at) !== undefined &&
        instant(candidate.relationshipObserved.at)! < at!));
  const due = validProof && configured ? at! + days! * DAY : undefined;
  const ready =
    candidate.stage !== "unfollowed" &&
    due !== undefined &&
    Number.isFinite(clock) &&
    clock >= due;
  const protection = account.relationships?.protections.find(
    (p) => p.enabled && p.username === candidate.username,
  );
  const excluded =
    candidate.stage === "excluded" ||
    account.data.settings.exclusions.includes(candidate.username);
  const reciprocity = relationship(account, candidate, due, clock),
    codes: string[] = [],
    reasons: string[] = [];
  const block = (code: string, message: string) => {
    codes.push(code);
    reasons.push(message);
  };
  if (!Number.isFinite(clock))
    block("invalid_clock", "Não foi possível conferir a data da revisão.");
  if (
    !canonical(account.username) ||
    account.data.runtime.account !== account.username
  )
    block(
      "account_mismatch",
      "Confira a conta selecionada antes de montar a revisão.",
    );
  if (!canonical(candidate.username))
    block(
      "invalid_candidate",
      "O perfil selecionado está inválido e precisa de conferência.",
    );
  if (candidate.username === account.username)
    block("own_account", "A própria conta não pode entrar na fila.");
  if (!validProof)
    block(
      candidate.confirmedFollowSource === "restored"
        ? "restored_proof"
        : "unconfirmed_follow",
      candidate.confirmedFollowSource === "restored"
        ? "Histórico restaurado: a confirmação não habilita uma ação automática de deixar de seguir."
        : "Sem confirmação de seguir registrada pela Órbita para esta conta.",
    );
  if (!configured)
    block(
      "review_disabled",
      "Escolha o prazo de revisão antes de montar esta fila.",
    );
  else if (due !== undefined && clock < due)
    block("not_due", "O prazo escolhido ainda não terminou.");
  if (
    !["preserve_followers", "review_all"].includes(
      account.data.settings.reviewPolicy || "",
    )
  )
    block(
      "policy_missing",
      "Escolha a política de reciprocidade antes de montar esta fila.",
    );
  if (excluded) block("excluded", "Este perfil está na lista de exclusão.");
  if (protection)
    block("protected", "Este perfil está protegido e fica fora da fila.");
  if (candidate.sources.some((s) => s.url.startsWith("demo:")))
    block("demo", "Perfis de demonstração não podem entrar na fila real.");
  if (!["followed", "queued", "attempting"].includes(candidate.stage))
    block(
      "stage_ineligible",
      candidate.stage === "requested"
        ? "Solicitação pendente não é uma confirmação de seguir."
        : "O estado atual deste perfil exige conferência antes de uma nova ação.",
    );
  if (
    ["queued", "attempting"].includes(candidate.stage) &&
    (candidate.queuedAction !== "unfollow" ||
      candidate.queueAccount !== account.username)
  )
    block(
      "queue_mismatch",
      "A ação ou a conta da fila não corresponde a esta revisão.",
    );
  if (account.data.settings.reviewPolicy === "preserve_followers") {
    if (reciprocity.status === "yes")
      block(
        "follows_back",
        "Este perfil consta como seguidor na medição disponível.",
      );
    else if (reciprocity.status === "unknown")
      block(
        "reciprocity_unknown",
        "A reciprocidade está desconhecida. É necessária uma lista completa medida após o prazo para comprovar ausência.",
      );
  }
  let status: ProspectingRow["status"] = "blocked";
  if (candidate.stage === "unfollowed") status = "unfollowed";
  else if (
    candidate.stage === "queued" &&
    candidate.queuedAction === "unfollow"
  )
    status = "queued";
  else if (
    candidate.stage === "attempting" &&
    candidate.queuedAction === "unfollow"
  )
    status = "attempting";
  else if (!codes.length) status = "ready";
  else if (
    validProof &&
    configured &&
    !ready &&
    codes.every((c) => ["not_due", "reciprocity_unknown"].includes(c))
  )
    status = "waiting";
  return {
    cycleId: `${account.id}:${candidate.id}:${candidate.confirmedFollowAt || "unconfirmed"}`,
    candidateId: candidate.id,
    username: candidate.username,
    stage: candidate.stage,
    queuedAction: candidate.queuedAction,
    confirmedFollowAt:
      at !== undefined ? new Date(at).toISOString() : undefined,
    confirmedFollowAccount: candidate.confirmedFollowAccount,
    confirmedFollowSource: candidate.confirmedFollowSource,
    ageDays:
      at !== undefined && at <= clock
        ? Math.floor((clock - at) / DAY)
        : undefined,
    dueAt: due !== undefined ? new Date(due).toISOString() : undefined,
    ready,
    canQueue: candidate.stage === "followed" && !codes.length,
    status,
    reasons,
    codes,
    protected: !!protection,
    protectionReason: protection?.reason,
    excluded,
    sources: candidate.sources.map((s) => {
      const c = account.data.campaigns.find((c) => c.id === s.campaignId);
      return {
        campaignId: s.campaignId,
        name: c?.name,
        kind: c?.kind,
        target: c?.target,
        url: s.url,
        at: s.at,
        archived: c?.archived,
      };
    }),
    reciprocity,
  };
}
/** Recheck this immediately before execution and before AUTHORIZE_CLICK.
 * The worker separately enforces exact stage, session, token, budgets and pause.
 */
export function unfollowEligibility(
  account: AccountWorkspace,
  candidate: Candidate,
  now = new Date(),
) {
  const row = reviewRow(account, candidate, now);
  return {
    eligible: row.codes.length === 0,
    reasons: row.reasons,
    codes: row.codes,
  };
}
export function prospectingReview(account: AccountWorkspace, now = new Date()) {
  const rows = account.data.candidates
    .filter(
      (c) =>
        c.confirmedFollowAt !== undefined ||
        c.confirmedFollowAccount !== undefined ||
        c.confirmedFollowSource !== undefined ||
        [
          "followed",
          "requested",
          "already",
          "queued",
          "attempting",
          "unfollowed",
        ].includes(c.stage),
    )
    .map((c) => reviewRow(account, c, now));
  return {
    accountId: account.id,
    account: account.username,
    reviewAfterDays: account.data.settings.reviewAfterDays,
    reviewPolicy: account.data.settings.reviewPolicy,
    rows,
    counts: {
      total: rows.length,
      ready: rows.filter((r) => r.ready).length,
      canQueue: rows.filter((r) => r.canQueue).length,
      protected: rows.filter((r) => r.protected).length,
      excluded: rows.filter((r) => r.excluded).length,
      unknown: rows.filter((r) => r.reciprocity.status === "unknown").length,
    },
  };
}
