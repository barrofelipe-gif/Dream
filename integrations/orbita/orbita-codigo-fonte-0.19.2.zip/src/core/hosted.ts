// The app connector is available only on these exact origins and this route.
export const HOSTED_PATH = "/api/growth/orbita/painel";
export const HOSTED_ORIGINS = [
  "https://app.bfffitnessatacado.com.br",
  "https://bff-painel-pendencias.vercel.app",
];
export function trustedHostedPage(raw: string | undefined): boolean {
  try {
    const url = new URL(raw || "");
    return HOSTED_ORIGINS.includes(url.origin) && url.pathname === HOSTED_PATH;
  } catch {
    return false;
  }
}
export const HOSTED_MESSAGES = new Set([
  "GET_STATE",
  "COMMAND",
  "ACCOUNT_COMMAND",
  "READ_MARKET_PAGE",
  "READ_OWN_RELATIONSHIPS",
  "GET_PROBLEMS",
  "REPORT_PROBLEM",
  "UPDATE_PROBLEM",
  "RECOVER_PROBLEM",
]);
export function allowedHostedMessage(value: unknown): boolean {
  return (
    !!value &&
    typeof value === "object" &&
    HOSTED_MESSAGES.has((value as { type: string }).type)
  );
}

export function hostedStorageKey(
  key: string,
  user: string | null | undefined,
  hosted: boolean,
): string {
  if (!hosted) return key;
  if (!user || !/^[a-f0-9]{32}$/.test(user))
    throw new Error(
      "Não foi possível identificar seu usuário no app. Entre novamente antes de abrir os dados locais.",
    );
  return `${key}:app:${user}`;
}
