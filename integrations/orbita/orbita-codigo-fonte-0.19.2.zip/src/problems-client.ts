import {
  extensionAvailable,
  sendExtension,
  watchExtension,
  storageKey,
} from "./transport.ts";
import { useEffect, useState } from "react";
import {
  APP_SCOPE,
  emptyProblems,
  problemScope,
  problemText,
  PROBLEMS_KEY,
  recordProblem,
  recoverProblem,
  updateProblem,
  validateProblems,
} from "./core/problems.ts";
import type {
  ProblemInput,
  ProblemSource,
  ProblemStatus,
  ProblemStore,
} from "./core/problems.ts";

const native = extensionAvailable;
let scope = APP_SCOPE,
  operation = "UI_ALERT",
  memory = emptyProblems(),
  storageError = "";
let readFailureActive = false;
const seen = new WeakMap<Error, string | undefined>(),
  recent = new Map<string, number>();
const emit = () => window.dispatchEvent(new Event("orbita-problems-change"));
export function setProblemContext(nextScope: string, page: string) {
  scope = problemScope(nextScope);
  operation = `UI_${page.toUpperCase()}`;
}
export function responseError(message: string, problemId?: string): Error {
  const error = new Error(message) as Error & { problemId?: string };
  error.name = "OrbitaResponseError";
  error.problemId = problemId;
  return error;
}
const localRead = () => {
  const raw = localStorage.getItem(storageKey(PROBLEMS_KEY));
  return validateProblems(raw ? JSON.parse(raw) : undefined);
};
const localSave = (store: ProblemStore) => {
  localStorage.setItem(storageKey(PROBLEMS_KEY), JSON.stringify(store));
  emit();
};
export async function reportProblem(
  error: unknown,
  options: {
    scope?: string;
    operation?: string;
    source?: ProblemSource;
    category?: ProblemInput["category"];
  } = {},
): Promise<string | undefined> {
  try {
    const message = problemText(error),
      source = options.source || "dashboard",
      recorded = (error as { problemId?: string })?.problemId;
    if (recorded) {
      recent.set(message, Date.now());
      return recorded;
    }
    if (error instanceof Error && seen.has(error)) return seen.get(error);
    if (source === "visible" && Date.now() - (recent.get(message) || 0) < 5000)
      return undefined;
    if (source !== "visible") {
      recent.delete(message);
      recent.set(message, Date.now());
      if (recent.size > 100) recent.delete(recent.keys().next().value!);
    }
    const input: ProblemInput = {
      scope: options.scope || scope,
      operation: options.operation || operation,
      source,
      message,
      category: options.category,
    };
    let id: string | undefined;
    try {
      if (native()) {
        const result = await sendExtension({
          type: "REPORT_PROBLEM",
          input,
        });
        if (!result?.ok || !result.id)
          throw Error(result?.error || "O registro persistente não respondeu.");
        id = result.id;
      } else {
        const result = recordProblem(localRead(), input);
        localSave(result.store);
        id = result.id;
      }
    } catch (cause) {
      const result = recordProblem(memory, input);
      memory = result.store;
      id = result.id;
      memory = recordProblem(memory, {
        scope: APP_SCOPE,
        operation: "DIAGNOSTICS_WRITE",
        source: "runtime",
        category: "storage",
        message: `Falha ao salvar o diagnóstico: ${problemText(cause)}`,
      }).store;
      storageError =
        "O registro persistente falhou. Os novos registros estão somente nesta sessão; exporte o diagnóstico antes de fechar o painel.";
      emit();
    }
    if (error instanceof Error) seen.set(error, id);
    return id;
  } catch {
    return undefined;
  }
}
export async function tracked<T>(
  scope: string,
  operation: string,
  work: () => Promise<T>,
): Promise<T> {
  try {
    return await work();
  } catch (error) {
    await reportProblem(error, { scope, operation });
    throw error;
  }
}
export async function markReadRecovered(id: string) {
  try {
    if (memory.entries.some((p) => p.id === id)) {
      memory = recoverProblem(memory, APP_SCOPE, id);
      emit();
      return;
    }
    if (native()) {
      const result = await sendExtension({
        type: "RECOVER_PROBLEM",
        scope: APP_SCOPE,
        id,
      });
      if (!result?.ok) throw Error("Recuperação não registrada.");
    } else localSave(recoverProblem(localRead(), APP_SCOPE, id));
  } catch (cause) {
    memory = recordProblem(memory, {
      scope: APP_SCOPE,
      operation: "DIAGNOSTICS_RECOVERY",
      source: "runtime",
      category: "storage",
      message: `A recuperação da leitura não pôde ser registrada: ${problemText(cause)}`,
    }).store;
    storageError =
      "A recuperação não pôde ser persistida. Exporte o diagnóstico desta sessão.";
    emit();
  }
}
async function snapshot() {
  let persisted: ProblemStore;
  let persistedReadable = true;
  try {
    if (native()) {
      const r = await sendExtension({ type: "GET_PROBLEMS" });
      if (!r?.ok) throw Error(r?.error || "Registro indisponível.");
      persisted = validateProblems(r.store);
    } else persisted = localRead();
    readFailureActive = false;
  } catch (cause) {
    persisted = emptyProblems();
    persistedReadable = false;
    storageError =
      "O histórico persistente não pôde ser lido. Os dados existentes foram preservados; exporte os registros disponíveis desta sessão.";
    if (!readFailureActive)
      memory = recordProblem(memory, {
        scope: APP_SCOPE,
        operation: "DIAGNOSTICS_STORAGE",
        source: "runtime",
        category: "storage",
        message: `Não foi possível ler o registro persistente de problemas: ${problemText(cause)}. Os dados existentes não foram alterados.`,
      }).store;
    readFailureActive = true;
  }
  storageError = !persistedReadable
    ? "O histórico persistente não pôde ser lido. A exportação contém apenas os registros disponíveis desta sessão; os dados existentes no armazenamento não foram alterados."
    : memory.entries.length
      ? `Há ${memory.entries.length} registros somente nesta sessão. Exporte o diagnóstico antes de fechar o painel; esses registros ainda não foram salvos no histórico persistente.`
      : "";
  return {
    store: { ...persisted, entries: [...persisted.entries, ...memory.entries] },
    storageError,
    sessionIds: memory.entries.map((e) => e.id),
    persistedReadable,
  };
}
export function useProblems() {
  const [state, setState] = useState<{
    store: ProblemStore;
    storageError: string;
    sessionIds: string[];
    persistedReadable: boolean;
  }>({
    store: emptyProblems(),
    storageError: "",
    sessionIds: [],
    persistedReadable: false,
  });
  useEffect(() => {
    let alive = true,
      revision = 0;
    const refresh = () => {
      const token = ++revision;
      void snapshot().then((value) => {
        if (alive && token === revision) setState(value);
      });
    };
    const changed = (
      changes: Record<string, chrome.storage.StorageChange>,
      area: string,
    ) => {
      if (area === "local" && changes[PROBLEMS_KEY]) refresh();
    };
    refresh();
    window.addEventListener("orbita-problems-change", refresh);
    window.addEventListener("storage", refresh);
    const unwatch = native() ? watchExtension(changed, PROBLEMS_KEY) : () => {};
    return () => {
      alive = false;
      window.removeEventListener("orbita-problems-change", refresh);
      window.removeEventListener("storage", refresh);
      unwatch();
    };
  }, []);
  return state;
}
export async function changeProblem(
  scope: string,
  id: string,
  status: ProblemStatus,
  note: string,
) {
  if (memory.entries.some((e) => e.id === id)) {
    memory = updateProblem(memory, scope, id, status, note);
    emit();
    return;
  }
  if (native()) {
    const r = await sendExtension({
      type: "UPDATE_PROBLEM",
      scope,
      id,
      status,
      note,
    });
    if (!r?.ok)
      throw Error(r?.error || "Não foi possível atualizar o problema.");
  } else localSave(updateProblem(localRead(), scope, id, status, note));
}
export function installProblemListeners() {
  const runtime = (event: ErrorEvent) => {
    void reportProblem(event.error || event.message, {
      source: "runtime",
      operation: "UI_RUNTIME",
      scope: APP_SCOPE,
      category: "interface",
    });
  };
  const rejected = (event: PromiseRejectionEvent) => {
    void reportProblem(event.reason, {
      source: "runtime",
      operation: "UNHANDLED_REJECTION",
      scope: APP_SCOPE,
    });
  };
  window.addEventListener("error", runtime);
  window.addEventListener("unhandledrejection", rejected);
}
export function visibleProblemAlerts(root: ParentNode): Element[] {
  return [...root.querySelectorAll('[role="alert"]')].filter(
    (element) => !element.closest('[data-problem-capture="skip"]'),
  );
}
export function useVisibleProblemCapture(accountId: string, page: string) {
  useEffect(() => {
    setProblemContext(accountId, page);
    const root = document.getElementById("root");
    if (!root) return;
    const observed = new WeakMap<Element, string>();
    const scan = () => {
      for (const element of visibleProblemAlerts(root)) {
        const text = element.textContent?.trim();
        if (!text || observed.get(element) === text) continue;
        observed.set(element, text);
        void reportProblem(text, {
          scope: accountId,
          operation: `UI_${page.toUpperCase()}`,
          source: "visible",
        });
      }
    };
    const observer = new MutationObserver(scan);
    observer.observe(root, {
      childList: true,
      subtree: true,
      characterData: true,
    });
    scan();
    return () => observer.disconnect();
  }, [accountId, page]);
}
