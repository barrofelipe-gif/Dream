import {
  ACCOUNT_STORE_KEY,
  migrateStore,
  workspace,
} from "../core/accounts.ts";
import {
  STORAGE_KEY,
  recoverInterrupted,
  validateSettings,
} from "../core/domain.ts";
import type { AccountStore } from "../core/types.ts";
import { pauseContinuous } from "../core/continuous.ts";
import { continuousAlarmName, continuousWakeAt } from "./continuous-schedule.ts";

let transaction: Promise<unknown> = Promise.resolve();
export const alarmName = (id: string) => `orbita-queue:${id}`;
export async function readStore(): Promise<AccountStore> {
  const saved = await chrome.storage.local.get([
    ACCOUNT_STORE_KEY,
    STORAGE_KEY,
  ]);
  return migrateStore(saved[ACCOUNT_STORE_KEY], saved[STORAGE_KEY]);
}
export async function settledStore() {
  await transaction;
}
export function editStore(
  fn: (store: AccountStore) => AccountStore | void,
): Promise<AccountStore> {
  const next = transaction.then(async () => {
    const store = await readStore();
    const result = fn(store) || store;
    await chrome.storage.local.set({ [ACCOUNT_STORE_KEY]: result });
    return result;
  });
  transaction = next.catch(() => {});
  return next;
}
export const storeReady = (async () => {
  await chrome.storage.local.setAccessLevel({
    accessLevel: "TRUSTED_CONTEXTS",
  });
  const store = await readStore();
  for (const account of store.accounts) {
    const actionInterrupted = account.data.candidates.some((c) => c.stage === "attempting");
    if (actionInterrupted)
      account.data = recoverInterrupted(account.data);
    if (account.data.settings.sessionLimit === undefined) {
      account.data.settings = validateSettings(account.data.settings);
      account.data = recoverInterrupted(account.data);
    }
    account.data.runtime.account = account.username;
    if (
      account.id !== store.activeId &&
      account.data.runtime.mode === "running"
    )
      account.data = recoverInterrupted(account.data);
    if (account.data.continuous?.mode === "running") {
      if (account.id !== store.activeId || actionInterrupted || account.data.settings.hasPendingWarning || account.data.candidates.some((c) => c.stage === "uncertain"))
        account.data = pauseContinuous(account.data, "A rotina precisa de conferência da conta ou de uma ação interrompida.");
      else {
        // An interrupted DOM scan cannot have clicked Follow or imported from
        // the page. Its obsolete runId is revoked; a new scheduled scan may run.
        for (const campaign of account.data.campaigns) if (campaign.continuous?.status === "checking") {
          campaign.continuous.status = "ready";
          delete campaign.continuous.runId;
          campaign.continuous.nextCheckAt = new Date().toISOString();
          campaign.continuous.reason = "Consulta de leitura interrompida. Uma nova consulta será programada.";
        }
      }
    }
    await chrome.alarms.clear(continuousAlarmName(account.id));
  }
  await chrome.storage.local.set({ [ACCOUNT_STORE_KEY]: store });
  await chrome.alarms.clear("orbita-queue");
  const active = workspace(store);
  if (
    active.data.runtime.mode === "running" && active.data.continuous?.mode !== "running" &&
    !(await chrome.alarms.get(alarmName(active.id)))
  )
    await chrome.alarms.create(alarmName(active.id), {
      when: Math.max(Date.now() + 1000, active.data.runtime.nextRun || 0),
    });
  const next = continuousWakeAt(active);
  if (next !== undefined) await chrome.alarms.create(continuousAlarmName(active.id), { when: next });
})();
