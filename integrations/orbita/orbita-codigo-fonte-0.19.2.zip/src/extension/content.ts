import {
  collectLoaded,
  detectAccount,
  pageRestriction,
  profileControls,
  unfollowMenu,
  readOwnProfileMetrics,
  readOwnRelationships,
  sessionProfilePhoto,
} from "./dom.ts";
import type { FollowResult } from "./dom.ts";
import type { Campaign } from "../core/types.ts";
import { SOURCE_LABELS } from "../core/types.ts";
import { sourceUrl } from "../core/domain.ts";
import { readMarketPage } from "./market-dom.ts";
import { withDeadline } from "./page-channel.ts";
import { hasPageDraft, stepContinuousSource } from "./continuous-dom.ts";

const marker = "__orbita_content_v1__";
const globalState = globalThis as typeof globalThis & { [marker]?: boolean };
if (!globalState[marker]) {
  globalState[marker] = true;
  let host: HTMLElement | null = null;
  let observer: MutationObserver | undefined;
  let captureGeneration = 0;
  let collectingGeneration: number | undefined;
  let captureAgainGeneration: number | undefined;
  let captureBlocked = false;
  let savedTotal: number | undefined;
  let sent = new Map<string, string>();
  const captureIdentity = (candidate: { name?: string; avatarUrl?: string }) =>
    JSON.stringify([candidate.name || "", candidate.avatarUrl || ""]);
  let activeCampaign: Campaign | undefined;
  let actionInFlight = false;
  let scheduled: ReturnType<typeof setTimeout> | undefined;
  const wait = (ms: number) =>
    new Promise((resolve) => setTimeout(resolve, ms));

  function stopWatching() {
    observer?.disconnect();
    observer = undefined;
    if (scheduled) clearTimeout(scheduled);
    scheduled = undefined;
    captureAgainGeneration = undefined;
    const watch = host?.shadowRoot?.querySelector<HTMLInputElement>("#watch");
    if (watch) watch.checked = false;
  }

  function scheduleCapture(shadow: ShadowRoot) {
    if (!scheduled) scheduled = setTimeout(() => {
      scheduled = undefined;
      void capture(shadow);
    }, 1500);
  }

  async function capture(shadow: ShadowRoot): Promise<void> {
    const status = shadow.querySelector("#status")!;
    if (!activeCampaign || captureBlocked) return;
    if (collectingGeneration === captureGeneration) {
      if (shadow.querySelector<HTMLInputElement>("#watch")?.checked) captureAgainGeneration = captureGeneration;
      return;
    }
    const campaign = activeCampaign;
    const generation = captureGeneration;
    const sessionSent = sent;
    const restricted = pageRestriction(document, location.pathname);
    if (restricted) {
      status.textContent = restricted;
      stopWatching();
      void chrome.runtime
        .sendMessage({ type: "PLATFORM_WARNING", message: restricted })
        .catch(() => {});
      return;
    }
    let saveSent = false;
    const button = shadow.querySelector<HTMLButtonElement>("#capture")!;
    try {
      const result = collectLoaded(
        document,
        campaign.kind,
        campaign.target,
        detectAccount(document) || undefined,
        campaign.group?.profile,
      );
      const progress = shadow.querySelector("#progress")!;
      progress.textContent = `${result.candidates.length} carregados agora · ${savedTotal === undefined ? `${sessionSent.size} salvos neste coletor` : `${savedTotal} únicos salvos nesta fonte`}`;
      const fresh = result.candidates.filter(
        (c) => sessionSent.get(c.username) !== captureIdentity(c),
      );
      if (!fresh.length) {
        status.textContent = "Nenhum perfil novo neste trecho. Role dentro da lista do Instagram para carregar mais; o total não está limitado a 11.";
        return;
      }
      collectingGeneration = generation;
      button.disabled = true;
      status.textContent = "Salvando os perfis carregados…";
      saveSent = true;
      const response = await withDeadline(() => chrome.runtime.sendMessage({
        type: "CAPTURE",
        campaignId: campaign.id,
        candidates: fresh,
        url: location.href,
        sourceProfile: campaign.group?.profile,
      }), Date.now() + 5000, "salvamento da captura");
      if (!response?.ok)
        throw new Error(response?.error || "A captura não foi salva.");
      if (generation !== captureGeneration || activeCampaign?.id !== campaign.id) return;
      fresh.forEach((c) => sessionSent.set(c.username, captureIdentity(c)));
      if (Number.isSafeInteger(response.total) && response.total >= 0) savedTotal = response.total;
      progress.textContent = `${result.candidates.length} carregados agora · ${savedTotal === undefined ? `${sessionSent.size} salvos neste coletor` : `${savedTotal} únicos salvos nesta fonte`}`;
      status.textContent = `${fresh.length} perfis novos ou atualizados salvos neste trecho. Role para carregar mais; a captura pode ser parcial.`;
    } catch (error) {
      if (generation === captureGeneration) {
        stopWatching();
        // A rejected or expired delivery may already have saved data. Require
        // an explicit review/reopen rather than resending an import on scroll.
        captureBlocked = saveSent;
        if (saveSent) {
          const detail = error instanceof Error ? ` ${error.message}` : "";
          status.textContent = `O salvamento não foi confirmado. Confira o painel e reabra esta fonte antes de capturar novamente.${detail}`;
          shadow.querySelector<HTMLInputElement>("#watch")!.disabled = true;
        } else status.textContent = error instanceof Error ? error.message : "Falha ao capturar.";
      }
    } finally {
      if (collectingGeneration === generation) collectingGeneration = undefined;
      if (generation === captureGeneration) {
        button.disabled = captureBlocked;
        if (captureAgainGeneration === generation) {
          captureAgainGeneration = undefined;
          if (!captureBlocked && shadow.querySelector<HTMLInputElement>("#watch")?.checked) scheduleCapture(shadow);
        }
      }
    }
  }
  function stopCollector() {
    stopWatching();
    host?.remove();
    activeCampaign = undefined;
    captureGeneration++;
  }
  function showCollector(campaign: Campaign, savedCount?: number): void {
    stopCollector();
    activeCampaign = campaign;
    captureBlocked = false;
    sent = new Map();
    savedTotal = Number.isSafeInteger(savedCount) && savedCount! >= 0 ? savedCount : undefined;
    host = document.createElement("div");
    host.id = "orbita-collector";
    document.body.append(host);
    const shadow = host.attachShadow({ mode: "open" });
    shadow.innerHTML = `<style>:host{all:initial}.box{position:fixed;right:16px;bottom:24px;box-sizing:border-box;width:min(376px,calc(100vw - 32px));z-index:2147483647;background:#fff;color:#173d36;padding:22px;border-radius:20px;box-shadow:0 12px 70px #0004;font:14px/1.5 system-ui;border:1px solid #d8e0d5}h3{font-size:19px;margin:0 0 5px}p{margin:8px 0;color:#52655e}button{font:600 13px system-ui;padding:11px 14px;border:0;border-radius:10px;cursor:pointer;background:#d8f576;color:#173d36}button.secondary{background:#edf2e9}.actions{display:flex;gap:8px;margin:16px 0 12px}.close{float:right;background:transparent;padding:0 4px;font-size:20px}.meta{font-size:11px;color:#6c7d73}label{display:flex;align-items:center;gap:6px;margin-top:12px}</style><section class="box"><button class="close" aria-label="Fechar coletor">×</button><div class="meta">ÓRBITA · COLETA ACOMPANHADA</div><h3></h3><p id="status">Abra a lista correspondente. A captura lê apenas o conteúdo carregado, sem acessar perfis privados.</p><div class="actions"><button id="capture">Capturar carregados</button><button id="dashboard" class="secondary">Ver painel ↗</button></div><label><input id="watch" type="checkbox"> Capturar enquanto eu rolo</label><p class="meta">A coleta pode ser parcial. Uma captura não segue ninguém.</p></section>`;
    const progress = document.createElement("p");
    progress.id = "progress";
    progress.className = "meta";
    progress.setAttribute("aria-live", "polite");
    progress.textContent = savedTotal === undefined ? "Aguardando a primeira captura deste coletor." : `${savedTotal} perfis únicos já salvos nesta fonte.`;
    shadow.querySelector("#status")!.after(progress);
    shadow.querySelector("h3")!.textContent = `${campaign.name} · ${SOURCE_LABELS[campaign.kind]}`;
    shadow.querySelector("#status")!.textContent = campaign.kind === "followers" || campaign.kind === "following"
      ? "Abra a lista de seguidores ou seguidos e role dentro dela. Capturar salva todos os perfis carregados; não há teto de 11."
      : campaign.kind === "likers" ? "Abra a lista Curtidas da publicação e role dentro dela para carregar mais perfis. Capture os carregados ou ative a captura enquanto rola."
      : "Abra ou expanda os comentários e capture os perfis carregados. Novos trechos são somados sem duplicar as pessoas.";
    shadow.querySelector(".close")!.addEventListener("click", stopCollector);
    shadow
      .querySelector("#capture")!
      .addEventListener("click", () => void capture(shadow));
    shadow
      .querySelector("#dashboard")!
      .addEventListener(
        "click",
        () => void chrome.runtime.sendMessage({ type: "OPEN_DASHBOARD" }),
      );
    shadow.querySelector("#watch")!.addEventListener("change", (event) => {
      if (captureBlocked || !(event.target as HTMLInputElement).checked) {
        stopWatching();
        return;
      }
      void capture(shadow);
      observer = new MutationObserver(() => scheduleCapture(shadow));
      observer.observe(document.body, {
        childList: true,
        subtree: true,
        attributes: true,
        attributeFilter: ["src", "srcset"],
      });
    });
  }
  async function follow(
    username: string,
    expectedAccount: string,
    token: string,
    expiresAt: number,
  ): Promise<FollowResult> {
    if (!Number.isFinite(expiresAt) || Date.now() >= expiresAt)
      return { stage: "failed", message: "A autorização expirou. Nenhum clique foi enviado.", stop: true };
    const restricted = pageRestriction(document, location.pathname);
    if (restricted)
      return {
        stage: "failed",
        message: restricted,
        stop: true,
        platformWarning: true,
      };
    if (detectAccount(document) !== expectedAccount)
      return {
        stage: "failed",
        message:
          "A conta da sessão não pôde ser confirmada ou foi trocada. Nenhum clique foi enviado.",
        stop: true,
      };
    const controls = profileControls(document, location.pathname, username);
    if (controls.error)
      return { stage: "failed", message: controls.error, stop: true };
    if (controls.state)
      return {
        stage: "already",
        message:
          controls.state === "requested"
            ? "Já havia uma solicitação pendente."
            : "O perfil já estava sendo seguido.",
      };
    const authorization = await chrome.runtime.sendMessage({
      type: "AUTHORIZE_CLICK",
      action: "follow",
      username,
      expectedAccount,
      token,
    });
    if (!authorization?.ok)
      return {
        stage: "failed",
        message:
          "A execução foi pausada ou perdeu a autorização. Nenhum clique foi enviado.",
        stop: true,
      };
    // Recheck the DOM after the asynchronous authorization to avoid clicking a replaced control.
    if (
      pageRestriction(document, location.pathname) ||
      detectAccount(document) !== expectedAccount || Date.now() >= expiresAt
    )
      return {
        stage: "failed",
        message: "A sessão mudou antes do clique.",
        stop: true,
      };
    const current = profileControls(document, location.pathname, username);
    if (!current.follow || current.follow !== controls.follow)
      return {
        stage: "failed",
        message:
          "O botão mudou durante a verificação. Nenhum clique foi enviado.",
        stop: true,
      };
    current.follow.click();
    let lastState = "",
      stable = 0;
    for (let i = 0; i < 20; i++) {
      await wait(300);
      const blocked = pageRestriction(document, location.pathname);
      if (blocked)
        return {
          stage: "uncertain",
          message: blocked,
          stop: true,
          platformWarning: true,
          clickSent: true,
        };
      if (detectAccount(document) !== expectedAccount)
        return { stage: "uncertain", message: "A conta da sessão mudou após o clique. Confira o perfil antes de continuar.", stop: true, clickSent: true };
      const result = profileControls(document, location.pathname, username);
      if (result.state) {
        stable = result.state === lastState ? stable + 1 : 1;
        lastState = result.state;
        if (stable >= 4)
          return {
            stage: result.state,
            clickSent: true,
            message:
              result.state === "requested"
                ? "Solicitação confirmada pelo botão do Instagram."
                : "Estado Seguindo confirmado pelo botão do Instagram.",
          };
      } else {
        stable = 0;
        lastState = "";
      }
    }
    return {
      stage: "uncertain",
      message:
        "Clique enviado, mas o resultado não foi confirmado. Confira no Instagram; não haverá repetição automática.",
      stop: true,
      clickSent: true,
    };
  }
  async function unfollow(
    username: string,
    expectedAccount: string,
    token: string,
    expiresAt: number,
  ): Promise<FollowResult> {
    const fail = (message: string, platformWarning = false): FollowResult =>
      ({ stage: "failed", message, stop: true, ...(platformWarning ? { platformWarning: true } : {}) });
    const uncertain = (message: string, platformWarning = false): FollowResult =>
      ({ stage: "uncertain", message, stop: true, clickSent: true, ...(platformWarning ? { platformWarning: true } : {}) });
    const sessionChanged = () => detectAccount(document) !== expectedAccount;
    const expired = () => !Number.isFinite(expiresAt) || Date.now() >= expiresAt;
    const restricted = pageRestriction(document, location.pathname);
    if (restricted) return fail(restricted, true);
    if (sessionChanged() || expired()) return fail("A sessão mudou ou a autorização expirou. Nenhum clique foi enviado.");
    const controls = profileControls(document, location.pathname, username);
    if (controls.error) return fail(controls.error);
    if (controls.follow) return fail("O perfil já não estava sendo seguido; nenhum clique foi enviado. Confira o histórico antes de continuar.");
    if (!controls.following) return fail("O estado Seguindo não foi confirmado. Nenhum clique foi enviado.");
    if (document.querySelector('[role="dialog"]')) return fail("Há um diálogo aberto. Feche-o e confira o perfil; nenhum clique foi enviado.");
    // Opening this verified menu only reads options. The final mutation needs its own token.
    controls.following.click();
    let menu: ReturnType<typeof unfollowMenu> = {};
    for (let i = 0; i < 8; i++) {
      await wait(200);
      const blocked = pageRestriction(document, location.pathname);
      if (blocked) return fail(blocked, true);
      if (sessionChanged() || expired()) return fail("A sessão mudou ou a autorização expirou ao abrir o menu. Nenhum clique de deixar de seguir foi enviado.");
      menu = unfollowMenu(document, location.pathname, username);
      if (menu.unfollow) break;
    }
    if (!menu.unfollow || !menu.dialog) return fail(menu.error || "O menu de Seguindo não foi confirmado. Nenhum clique de deixar de seguir foi enviado.");
    const authorization = await chrome.runtime.sendMessage({ type: "AUTHORIZE_CLICK", action: "unfollow", username, expectedAccount, token });
    if (!authorization?.ok) return fail("A execução foi pausada ou perdeu a autorização. Nenhum clique de deixar de seguir foi enviado.");
    const beforeClickRestriction = pageRestriction(document, location.pathname);
    if (beforeClickRestriction) return fail(beforeClickRestriction, true);
    if (sessionChanged() || expired()) return fail("A sessão mudou ou a autorização expirou antes do clique. Nenhum clique de deixar de seguir foi enviado.");
    const current = unfollowMenu(document, location.pathname, username);
    if (current.dialog !== menu.dialog || current.unfollow !== menu.unfollow)
      return fail("O menu mudou durante a autorização. Nenhum clique de deixar de seguir foi enviado.");
    current.unfollow!.click();
    let stable = 0;
    for (let i = 0; i < 20; i++) {
      await wait(300);
      const blocked = pageRestriction(document, location.pathname);
      if (blocked) return uncertain(blocked, true);
      if (sessionChanged()) return uncertain("A conta da sessão mudou após o clique. Confira o perfil antes de continuar.");
      const dialogs = [...document.querySelectorAll('[role="dialog"]')];
      if (dialogs.some((dialog) => dialog !== menu.dialog) || (dialogs.length && !unfollowMenu(document, location.pathname, username).unfollow))
        return uncertain("O Instagram abriu uma confirmação adicional ou um diálogo desconhecido. Nenhum segundo clique foi enviado; confira o perfil.");
      const result = profileControls(document, location.pathname, username);
      if (result.error) return uncertain("O perfil mudou após o clique e o resultado não pôde ser confirmado. Confira no Instagram.");
      stable = result.follow && !dialogs.length ? stable + 1 : 0;
      if (stable >= 4)
        return { stage: "unfollowed", message: "Estado Seguir confirmado após o clique de deixar de seguir da Órbita.", clickSent: true };
    }
    return uncertain("Clique de deixar de seguir enviado, mas o resultado não foi confirmado. Confira no Instagram; não haverá repetição automática.");
  }
  async function observeRelationship(username: string, expectedAccount: string) {
    let previous = "", stable = 0;
    for (let i = 0; i < 12; i++) {
      const restricted = pageRestriction(document, location.pathname);
      if (restricted) throw new Error(restricted);
      if (detectAccount(document) !== expectedAccount) throw new Error("A conta da sessão mudou. Nenhuma conferência foi registrada.");
      const controls = profileControls(document, location.pathname, username);
      if (controls.error) throw new Error(controls.error);
      const status = controls.state === "followed" ? "following" : controls.state === "requested" ? "requested" : controls.follow ? "not_following" : "";
      if (!status) throw new Error("O estado atual do perfil não pôde ser reconhecido.");
      stable = status === previous ? stable + 1 : 1;
      previous = status;
      if (stable >= 4) return { account: expectedAccount, username, at: new Date().toISOString(), status };
      await wait(300);
    }
    throw new Error("O estado do perfil não ficou estável. Nenhuma conferência foi registrada.");
  }
  chrome.runtime.onMessage.addListener((message, sender, respond) => {
    if (sender.id !== chrome.runtime.id) return false;
    if (message.type === "STATUS") {
      respond({
        account: detectAccount(document),
        avatarUrl: sessionProfilePhoto(document, location.pathname),
        restricted: pageRestriction(document, location.pathname),
        url: location.href,
        hasDraft: hasPageDraft(document),
      });
      return false;
    }
    if (message.type === "STEP_CONTINUOUS_SOURCE") {
      if (actionInFlight) respond({ ok: false, error: "Aguarde a ação em andamento antes de avançar a coleta." });
      else respond(stepContinuousSource(document, location.href, { campaign: message.campaign, expectedAccount: message.expectedAccount, runId: message.runId }));
      return false;
    }
    if (message.type === "COLLECTOR") {
      showCollector(message.campaign, message.savedCount);
      respond({ ok: true });
      return false;
    }
    if (message.type === "CLOSE_COLLECTOR") {
      stopCollector();
      respond({ ok: true });
      return false;
    }
    if (message.type === "MARKET_PAGE") {
      try {
        respond({
          ok: true,
          data: readMarketPage(document, location.href, message.expectedOwn),
        });
      } catch (error) {
        respond({
          ok: false,
          error:
            error instanceof Error
              ? error.message
              : "Não foi possível ler a página.",
        });
      }
      return false;
    }
    if (message.type === "PROFILE_METRICS") {
      try {
        respond({
          ok: true,
          ...readOwnProfileMetrics(
            document,
            location.pathname,
            message.expectedAccount,
          ),
        });
      } catch (error) {
        respond({
          ok: false,
          error:
            error instanceof Error
              ? error.message
              : "Não foi possível ler as métricas.",
        });
      }
      return false;
    }
    if (message.type === "OWN_RELATIONSHIPS") {
      try {
        respond({ ok: true, data: readOwnRelationships(document, location.pathname, message.expectedAccount, message.kind) });
      } catch (error) {
        respond({ ok: false, error: error instanceof Error ? error.message : "Não foi possível ler esta lista." });
      }
      return false;
    }
    if (message.type === "PROFILE_RELATIONSHIP_STATE") {
      if (actionInFlight) {
        respond({ ok: false, error: "Aguarde a verificação em andamento antes de conferir o estado do perfil." });
        return false;
      }
      void observeRelationship(message.username, message.expectedAccount)
        .then((data) => respond({ ok: true, data }))
        .catch((error) => respond({ ok: false, error: error instanceof Error ? error.message : "Não foi possível conferir o estado do perfil." }));
      return true;
    }
    if (message.type === "FOLLOW" || message.type === "UNFOLLOW") {
      const action = message.type === "UNFOLLOW" ? "unfollow" : "follow";
      if (actionInFlight) {
        respond({ action, stage: "failed", message: "Já há uma verificação em andamento neste documento. Nenhum novo clique foi enviado.", stop: true });
        return false;
      }
      actionInFlight = true;
      const execute = action === "unfollow" ? unfollow : follow;
      void execute(message.username, message.expectedAccount, message.token, message.expiresAt)
        .then((result) => respond({ ...result, action }))
        .catch(() =>
          respond({
            action,
            stage: "uncertain",
            message: "A comunicação foi interrompida. Verifique o perfil.",
            stop: true,
          }),
        ).finally(() => { actionInFlight = false; });
      return true;
    }
    return false;
  });
  document.addEventListener(
    "click",
    (event) => {
      if (
        !activeCampaign ||
        !["hashtag", "location"].includes(activeCampaign.kind)
      )
        return;
      const expected = new URL(
        sourceUrl(activeCampaign.kind, activeCampaign.target),
      );
      if (!location.pathname.startsWith(expected.pathname)) return;
      const anchor = (event.target as Element)?.closest<HTMLAnchorElement>(
        "a[href]",
      );
      if (
        !anchor ||
        !/^\/(p|reel)\/[\w-]+\/?$/.test(new URL(anchor.href).pathname)
      )
        return;
      void chrome.runtime
        .sendMessage({
          type: "COLLECTOR_MEDIA",
          campaignId: activeCampaign.id,
          url: anchor.href,
        })
        .catch(() => {});
    },
    true,
  );
  void chrome.runtime
    .sendMessage({ type: "GET_COLLECTOR" })
    .then((result) => {
      if (result?.ok && result.campaign) showCollector(result.campaign, result.savedCount);
    })
    .catch(() => {});
}
