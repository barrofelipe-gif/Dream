export class PageDeadlineError extends Error {
  readonly phase: string;
  constructor(phase: string) {
    super(`Tempo esgotado: ${phase}.`);
    this.name = "PageDeadlineError";
    this.phase = phase;
  }
}

/** Bounds the wait, not the underlying Chrome operation. Never invokes it twice. */
export function withDeadline<T>(operation: () => Promise<T>, deadline: number, phase: string): Promise<T> {
  return new Promise<T>((resolve, reject) => {
    let finished = false;
    let timer: ReturnType<typeof setTimeout> | undefined;
    const finish = (callback: () => void) => {
      if (finished) return;
      finished = true;
      if (timer !== undefined) clearTimeout(timer);
      callback();
    };
    const expired = () => !Number.isFinite(deadline) || Date.now() >= deadline;
    const timeout = () => {
      if (finished) return;
      if (!expired()) { timer = setTimeout(timeout, Math.max(1, deadline - Date.now())); return; }
      finish(() => reject(new PageDeadlineError(phase)));
    };
    if (expired()) { timeout(); return; }
    timer = setTimeout(timeout, Math.max(1, deadline - Date.now()));
    try {
      Promise.resolve(operation()).then(
        (value) => expired() ? timeout() : finish(() => resolve(value)),
        (error) => expired() ? timeout() : finish(() => reject(error)),
      );
    } catch (error) {
      if (expired()) timeout(); else finish(() => reject(error));
    }
  });
}

export type PageReadMessage = { type: string; [key: string]: unknown };
export type PageReadBudget = { injectionUsed: boolean };
export interface PageReadChannel {
  sendMessage(tabId: number, message: PageReadMessage): Promise<unknown>;
  inject(tabId: number): Promise<unknown>;
}
const PAGE_READS = new Set(["STATUS", "PROFILE_METRICS", "MARKET_PAGE", "PROFILE_RELATIONSHIP_STATE", "OWN_RELATIONSHIPS", "COLLECTOR", "CLOSE_COLLECTOR", "STEP_CONTINUOUS_SOURCE"]);
const missingReceiver = (error: unknown) => /^(?:could not establish connection\.\s*)?receiving end does not exist\.?$/i.test(error instanceof Error ? error.message.trim() : typeof error === "string" ? error.trim() : "");

/** The sole recovery is one injection after an unequivocally missing receiver.
 * Every delivery and the injection share one absolute deadline.
 */
export async function readPageMessage<T = any>(channel: PageReadChannel, tabId: number, message: PageReadMessage, deadline = Date.now() + 4000, phase = `aguardando ${message.type}`, budget: PageReadBudget = { injectionUsed: false }): Promise<T> {
  if (!PAGE_READS.has(message.type)) throw new Error("O canal de leitura não aceita essa operação.");
  try {
    return await withDeadline(() => channel.sendMessage(tabId, message), deadline, phase) as T;
  } catch (error) {
    if (!missingReceiver(error) || budget.injectionUsed || Date.now() >= deadline) throw error;
    budget.injectionUsed = true;
    await withDeadline(() => channel.inject(tabId), deadline, `${phase}: injetando conector`);
    return await withDeadline(() => channel.sendMessage(tabId, message), deadline, phase) as T;
  }
}
