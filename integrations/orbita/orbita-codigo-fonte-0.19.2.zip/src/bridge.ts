import {
  extensionAvailable,
  sendExtension,
  watchExtension,
  storageKey,
} from "./transport.ts";
import { useEffect, useState } from "react";
import { verifyHostedActor } from "./hosted-access.ts";
import type {
  AccountCommand,
  AccountStore,
  Command,
  SpecialCommand,
  MarketPageReading,
  OwnRelationshipReading,
} from "./core/types.ts";
import { STORAGE_KEY } from "./core/domain.ts";
import {
  markReadRecovered,
  reportProblem,
  responseError,
  tracked,
} from "./problems-client.ts";
import { recoverStateRead } from "./core/recovery.ts";
import { APP_SCOPE } from "./core/problems.ts";
import {
  ACCOUNT_STORE_KEY,
  accountCommand,
  applyScopedCommand,
  initialStore,
  migrateStore,
} from "./core/accounts.ts";

export const isExtension = extensionAvailable();
export async function readOwnRelationships(workspaceId: string, kind: "followers" | "following"): Promise<OwnRelationshipReading> {
  return tracked(workspaceId, "READ_OWN_RELATIONSHIPS", async () => {
    if (!isExtension) throw new Error("A leitura das próprias listas precisa da extensão conectada.");
    const result = await sendExtension({ type: "READ_OWN_RELATIONSHIPS", workspaceId, kind });
    if (!result?.ok) throw responseError(result?.error || "Não foi possível ler os perfis carregados.", result?.problemId);
    return result.data;
  });
}
export async function readMarketPage(
  workspaceId: string,
  own: boolean,
  url = "",
): Promise<MarketPageReading> {
  return tracked(workspaceId, "READ_MARKET_PAGE", async () => {
    if (!isExtension)
      throw new Error(
        "A leitura da página funciona na extensão instalada. Na prévia, informe a bio ou registre uma referência manualmente.",
      );
    const result = await sendExtension({
      type: "READ_MARKET_PAGE",
      workspaceId,
      own,
      url,
    });
    if (!result?.ok)
      throw responseError(
        result?.error || "Não foi possível ler a página.",
        result?.problemId,
      );
    return result.data;
  });
}
const localRead = (): AccountStore => {
  const raw = localStorage.getItem(storageKey(ACCOUNT_STORE_KEY));
  if (raw) return migrateStore(JSON.parse(raw));
  const legacy = localStorage.getItem(storageKey(STORAGE_KEY));
  const store = migrateStore(
    undefined,
    legacy ? JSON.parse(legacy) : undefined,
  );
  localStorage.setItem(storageKey(ACCOUNT_STORE_KEY), JSON.stringify(store));
  return store;
};
function saveLocal(store: AccountStore) {
  localStorage.setItem(storageKey(ACCOUNT_STORE_KEY), JSON.stringify(store));
  window.dispatchEvent(new Event("orbita-change"));
}
export async function dispatch(
  command: Command | SpecialCommand,
  workspaceId: string,
): Promise<string | undefined> {
  return tracked(workspaceId, `COMMAND_${command.type}`, async () => {
    if (isExtension) {
      const response = await sendExtension({
        type: "COMMAND",
        command,
        workspaceId,
      });
      if (!response?.ok)
        throw responseError(
          response?.error || "Não foi possível concluir a operação.",
          response?.problemId,
        );
      return response.notice;
    }
    if (
      ["CONNECT", "OPEN_SOURCE", "OPEN_OWN_RELATIONSHIPS", "VERIFY_CANDIDATE_RESULT", "START", "REFRESH_METRICS"].includes(
        command.type,
      )
    )
      throw new Error(
        "Esta ação funciona na extensão instalada no Chrome/Edge. Abra “Instalação” para ver os passos.",
      );
    await verifyHostedActor();
    saveLocal(applyScopedCommand(localRead(), workspaceId, command as Command));
  });
}
export async function dispatchAccount(
  command: AccountCommand,
  expectedActiveId: string,
): Promise<void> {
  return tracked(expectedActiveId, `ACCOUNT_${command.type}`, async () => {
    if (isExtension) {
      const response = await sendExtension({
        type: "ACCOUNT_COMMAND",
        command,
        expectedActiveId,
      });
      if (!response?.ok)
        throw responseError(
          response?.error || "Não foi possível atualizar as contas.",
          response?.problemId,
        );
    } else {
      await verifyHostedActor();
      const store = localRead();
      if (store.activeId !== expectedActiveId)
        throw new Error(
          "A conta selecionada mudou. Aguarde a atualização do painel.",
        );
      saveLocal(accountCommand(store, command));
    }
  });
}
export function useAccountStore(): [AccountStore, boolean, string | null] {
  const [store, setStore] = useState<AccountStore>(initialStore);
  const [ready, setReady] = useState(false);
  const [error, setError] = useState<string | null>(null);
  useEffect(() => {
    if (isExtension) {
      let alive = true;
      const listener = (
        changes: Record<string, chrome.storage.StorageChange>,
        area: string,
      ) => {
        if (area === "local" && changes[ACCOUNT_STORE_KEY]?.newValue)
          setStore(changes[ACCOUNT_STORE_KEY].newValue as AccountStore);
      };
      const unwatch = watchExtension(listener, ACCOUNT_STORE_KEY);
      void recoverStateRead(
        "GET_STATE",
        async () => {
          const response = await sendExtension({
            type: "GET_STATE",
          });
          if (!response?.ok)
            throw responseError(
              response?.error || "Falha ao carregar as contas.",
              response?.problemId,
            );
          return response;
        },
        {
          report: (error) =>
            reportProblem(error, { scope: APP_SCOPE, operation: "LOAD_STATE" }),
          recovered: markReadRecovered,
        },
      )
        .then((response) => {
          if (!alive) return;
          if (!response?.ok)
            throw responseError(
              response?.error || "Falha ao carregar as contas.",
              response?.problemId,
            );
          setStore(response.store);
          setReady(true);
        })
        .catch((err) => {
          if (alive) {
            setError(String(err));
            setReady(true);
          }
        });
      return () => {
        alive = false;
        unwatch();
      };
    }
    const update = () => {
      try {
        setStore(localRead());
      } catch (err) {
        void reportProblem(err, {
          scope: APP_SCOPE,
          operation: "LOAD_STATE",
          category: "storage",
        });
        setError(String(err));
      }
      setReady(true);
    };
    update();
    window.addEventListener("orbita-change", update);
    window.addEventListener("storage", update);
    return () => {
      window.removeEventListener("orbita-change", update);
      window.removeEventListener("storage", update);
    };
  }, []);
  return [store, ready, error];
}
