import {
  AlertTriangle,
  ArrowRight,
  Check,
  CircleHelp,
  Pause,
  ShieldCheck,
  Sprout,
  ExternalLink,
} from "lucide-react";
import { attemptsToday } from "../core/domain.ts";
import { safetyAssessment, sessionLimit, STARTER } from "../core/safety.ts";
import type {
  AppState,
  Command,
  Settings,
  SpecialCommand,
} from "../core/types.ts";

type Run = (
  command: Command | SpecialCommand,
  success?: string,
) => Promise<boolean>;
export function SafetyNotices({ state }: { state: AppState }) {
  const { notices } = safetyAssessment(state, attemptsToday(state));
  return (
    <div className="safety-notices" aria-label="Alertas de ritmo">
      {notices.map((notice) => (
        <div
          key={notice.id}
          className={`safety-notice ${notice.severity}`}
          role={notice.severity === "stop" ? "alert" : undefined}
          data-problem-capture={notice.id === "daily" ? "skip" : undefined}
        >
          <AlertTriangle size={18} />
          <div>
            <strong>{notice.title}</strong>
            <p>{notice.text}</p>
          </div>
        </div>
      ))}
    </div>
  );
}
export function SafetyOverview({
  state,
  onOpen,
}: {
  state: AppState;
  onOpen: () => void;
}) {
  const used = attemptsToday(state),
    a = safetyAssessment(state, used);
  return (
    <section
      className={`safety-overview ${state.settings.hasPendingWarning ? "attention" : ""}`}
    >
      <span className="safety-overview-icon">
        <Sprout size={22} />
      </span>
      <div>
        <strong>{a.label}</strong>
        <p>
          {state.settings.hasPendingWarning
            ? "Confira o aviso na conta antes de liberar novas ações."
            : `${used} de ${state.settings.dailyLimit} tentativas hoje · lotes de até ${a.sessionLimit} · intervalo de ${state.settings.intervalMinutes} min`}
        </p>
        <small>
          Organizar listas não segue ninguém. Os controles não garantem ausência
          de bloqueios.
        </small>
      </div>
      <button className="button secondary" onClick={onOpen}>
        Ritmo e cuidados <ArrowRight size={15} />
      </button>
    </section>
  );
}
export function DraftPaceNotice({ settings }: { settings: Settings }) {
  const expanded =
    settings.dailyLimit > STARTER.dailyLimit ||
    sessionLimit(settings) > STARTER.sessionLimit ||
    settings.intervalMinutes < STARTER.intervalMinutes;
  return (
    <div className={`draft-pace ${expanded ? "attention" : ""}`}>
      <AlertTriangle size={17} />
      <p>
        {expanded
          ? "Você está permitindo mais volume ou menos intervalo que o começo guiado. Não trate essa mudança como segura: reveja também ações feitas no celular e em outras ferramentas."
          : "Começo guiado: até 5 tentativas por dia, lotes de 5 e intervalo de 15 minutos. É um piloto pequeno escolhido pelo aplicativo, não um limite aprovado pelo Instagram."}
      </p>
    </div>
  );
}
export function SafetyPage({
  state,
  run,
  busy,
  onSettings,
}: {
  state: AppState;
  run: Run;
  busy: boolean;
  onSettings: () => void;
}) {
  const used = attemptsToday(state),
    a = safetyAssessment(state, used);
  return (
    <>
      <section className="safety-intro panel">
        <div>
          <span className="eyebrow">DIREÇÃO ANTES DE VOLUME</span>
          <h2>Comece pequeno. Observe. Decida o próximo passo.</h2>
          <p>
            A Órbita limita a exposição ao volume e interrompe diante de avisos.
            Ela não conhece todos os sinais usados pelo Instagram e não calcula
            uma probabilidade de bloqueio.
          </p>
        </div>
        <span className="safety-intro-icon">
          <ShieldCheck size={33} />
        </span>
      </section>
      <SafetyNotices state={state} />
      <div className="safety-metrics">
        <div>
          <span>Perfis salvos</span>
          <strong>{state.candidates.length}</strong>
          <small>Lista local; não são novos seguidores.</small>
        </div>
        <div>
          <span>Tentativas de hoje</span>
          <strong>
            {used}
            <em> / {state.settings.dailyLimit}</em>
          </strong>
          <small>Apenas ações registradas pela Órbita.</small>
          <progress
            aria-label="Tentativas de hoje"
            max={state.settings.dailyLimit}
            value={Math.min(used, state.settings.dailyLimit)}
          />
        </div>
        <div>
          <span>Lote atual / último lote</span>
          <strong>
            {a.sessionUsed}
            <em> / {a.sessionLimit}</em>
          </strong>
          <small>A fila pausa quando o lote termina.</small>
        </div>
        <div>
          <span>Próximo lote pode ter</span>
          <strong>
            {a.nextBatch}
            <em> tentativas</em>
          </strong>
          <small>Respeitando fila, lote e saldo diário.</small>
        </div>
      </div>
      <div className="safety-layout">
        <section className="panel safety-plan">
          <div className="panel-heading">
            <div>
              <h2>
                <Sprout size={20} /> Começo guiado
              </h2>
              <p>Uma direção prática, sem aumento automático de volume.</p>
            </div>
          </div>
          <ol>
            <li>
              <span>01</span>
              <div>
                <strong>Escolha 1 perfil de referência</strong>
                <p>
                  Comece com um público do seu nicho. Muitas fontes podem
                  aumentar consultas e rolagens; elas não devem virar uma ordem
                  para seguir todo mundo.
                </p>
              </div>
            </li>
            <li>
              <span>02</span>
              <div>
                <strong>Revise 5 candidatos</strong>
                <p>
                  Confira contexto e interesse real. Salvar 500 perfis não
                  autoriza 500 ações: coleta, revisão e execução continuam
                  separadas.
                </p>
              </div>
            </li>
            <li>
              <span>03</span>
              <div>
                <strong>
                  Até 5 tentativas no dia, com 15 min entre perfis
                </strong>
                <p>
                  É a configuração inicial da Órbita. Uma tentativa pode
                  terminar sem clique, por exemplo quando você já segue a conta.
                  Mesmo esse volume pode sofrer restrições.
                </p>
              </div>
            </li>
            <li>
              <span>04</span>
              <div>
                <strong>Confira a conta antes de continuar</strong>
                <p>
                  Avalie os resultados do lote e os avisos do Instagram. Não
                  aumentamos o teto com o passar dos dias. Mude o ritmo somente
                  por decisão sua, sem presumir que ausência de aviso significa
                  segurança.
                </p>
              </div>
            </li>
          </ol>
          <div className="safety-plan-actions">
            <button
              className="button primary"
              disabled={busy}
              onClick={() =>
                void run(
                  { type: "APPLY_STARTER" },
                  "Começo guiado aplicado. Contadores e avisos foram preservados; a fila está pausada.",
                )
              }
            >
              <Check size={16} />
              Aplicar começo guiado
            </button>
            <button className="text-link" onClick={onSettings}>
              Ver meus controles <ArrowRight size={15} />
            </button>
          </div>
        </section>
        <div className="safety-side">
          <section className="panel safety-card">
            <h2>
              <AlertTriangle size={19} /> Quando interromper
            </h2>
            <ul>
              <li>
                “Ação bloqueada”, “tente novamente mais tarde”, login ou pedido
                de verificação.
              </li>
              <li>
                Botão que não muda de estado, erros repetidos ou resultado que
                não pôde ser confirmado.
              </li>
              <li>
                Conta nova, pouco utilizada ou que acabou de receber restrições:
                prefira organizar e revisar, com ações manuais.
              </li>
            </ul>
            <p>
              Se o aviso persistir, siga as instruções do Instagram. Não insista
              e não continue por outro bot ou dispositivo. Não existe um prazo
              fixo que prove a recuperação da conta.
            </p>
            <button
              className="button secondary full"
              disabled={busy}
              onClick={() =>
                void run(
                  { type: "REPORT_WARNING" },
                  "Aviso registrado. Coleta e execução ficam suspensas até sua conferência nas Preferências.",
                )
              }
            >
              <Pause size={16} />
              Minha conta mostrou um aviso
            </button>
          </section>
          <section className="panel safety-card">
            <h2>
              <CircleHelp size={19} /> O que o contador não vê
            </h2>
            <p>
              Follows, curtidas, comentários e mensagens feitos pelo celular ou
              por outras ferramentas não entram neste contador. Também não
              medimos todas as consultas de rede geradas pelo Instagram ao rolar
              páginas.
            </p>
            <p>
              Uma conta salva não é um cliente nem um seguidor conquistado.
              Priorize relevância e contatos voluntários; evite mensagens
              repetidas ou insistentes.
            </p>
          </section>
        </div>
      </div>
      <details className="panel safety-references">
        <summary>Por que não prometemos um número “seguro”?</summary>
        <p>
          A Meta descreve limites de consultas e mecanismos para interromper
          coleta não autorizada e identificar possível spam. Esses textos não
          fornecem um número universal de cliques que garanta ausência de
          bloqueio. Nossas sugestões são controles do produto, sem validação
          como uma faixa segura do Instagram.
        </p>
        <a
          href="https://about.fb.com/news/2021/05/scraping-by-the-numbers/"
          target="_blank"
          rel="noreferrer"
        >
          Meta: limites e combate à coleta automatizada{" "}
          <ExternalLink size={13} />
        </a>
        <a
          href="https://about.fb.com/br/news/2023/12/protegendo-os-criadores-de-interacoes-indesejadas-por-meio-de-novas-ferramentas-proativas-de-seguranca/"
          target="_blank"
          rel="noreferrer"
        >
          Meta: identificação de possíveis atividades de spam{" "}
          <ExternalLink size={13} />
        </a>
      </details>
    </>
  );
}
