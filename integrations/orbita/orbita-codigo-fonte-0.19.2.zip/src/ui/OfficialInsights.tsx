import { useEffect, useRef, useState } from "react";
import { CloudDownload, LoaderCircle } from "lucide-react";
import { trustedHostedPage } from "../core/hosted.ts";
import { localDay } from "../core/insights.ts";
import { hostedSessionMatches } from "../core/hosted-session.ts";
import {
  officialChoices,
  officialInsightResult,
  officialRange,
} from "../core/official-insights.ts";
import type {
  OfficialAccountChoice,
  OfficialInsightResult,
} from "../core/official-insights.ts";
import type {
  AccountCommand,
  AccountWorkspace,
  InsightReport,
} from "../core/types.ts";
import { verifyHostedActor } from "../hosted-access.ts";
import { Field, Modal } from "./components.tsx";

export const appMetricsAvailable = () =>
  typeof location !== "undefined" && trustedHostedPage(location.href);
const closedWeek = () => {
  const end = new Date();
  end.setDate(end.getDate() - 1);
  const start = new Date(end);
  start.setDate(start.getDate() - 6);
  return { start: localDay(start), end: localDay(end) };
};
export function OfficialInsights({
  account,
  run,
  busy,
  onSaved,
}: {
  account: AccountWorkspace;
  run: (command: AccountCommand, success?: string) => Promise<boolean>;
  busy: boolean;
  onSaved: (report: InsightReport) => void;
}) {
  const [open, setOpen] = useState(false);
  const [dates, setDates] = useState(closedWeek);
  const [loading, setLoading] = useState(false);
  const [error, setError] = useState("");
  const [choices, setChoices] = useState<OfficialAccountChoice[]>([]);
  const [choice, setChoice] = useState("");
  const [result, setResult] = useState<OfficialInsightResult | null>(null);
  const controller = useRef<AbortController | null>(null);
  const alive = useRef(true);
  const saving = useRef(false);
  const opened = useRef(false);
  const [savingNow, setSavingNow] = useState(false);
  useEffect(() => {
    alive.current = true;
    return () => {
      alive.current = false;
      controller.current?.abort();
    };
  }, []);
  if (!appMetricsAvailable()) return null;
  const load = async () => {
    if (!account.username || loading || busy || savingNow || controller.current)
      return;
    setError("");
    setResult(null);
    try {
      officialRange(dates.start, dates.end);
    } catch (cause) {
      setError(String(cause instanceof Error ? cause.message : cause));
      return;
    }
    const abort = new AbortController();
    controller.current = abort;
    setLoading(true);
    const timer = setTimeout(() => abort.abort(), 20000);
    try {
      const query = new URLSearchParams({
        username: account.username,
        start: dates.start,
        end: dates.end,
      });
      if (choice) query.set("accountId", choice);
      const response = await fetch(`/api/growth/orbita/insights?${query}`, {
        cache: "no-store",
        redirect: "manual",
        credentials: "same-origin",
        signal: abort.signal,
      });
      if (
        response.type === "opaqueredirect" ||
        response.status === 401 ||
        response.status === 403
      )
        throw new Error(
          "Entre novamente no app com um usuário administrador para consultar métricas.",
        );
      if (!response.headers.get("content-type")?.includes("application/json"))
        throw new Error(
          "O app não retornou métricas válidas. Reabra o painel e tente consultar novamente.",
        );
      const text = await response.text();
      if (text.length > 5_000_000)
        throw new Error(
          "A resposta do app é grande demais. Consulte um período menor.",
        );
      let payload;
      try {
        payload = JSON.parse(text);
      } catch {
        throw new Error("A resposta de métricas do app não pôde ser lida.");
      }
      if (!alive.current || abort.signal.aborted) return;
      const userScope = document
        .querySelector('meta[name="orbita-user"]')
        ?.getAttribute("content");
      if (
        !hostedSessionMatches(
          { ready: true, userScope: payload?.userScope },
          userScope,
        )
      )
        throw new Error(
          "O usuário do app mudou. Reabra a Órbita antes de consultar métricas.",
        );
      const available = officialChoices(payload.accounts, account.username);
      if (available.length) setChoices(available);
      if (!response.ok)
        throw new Error(
          typeof payload.error === "string"
            ? payload.error.slice(0, 700)
            : "Não foi possível consultar a coleta desta conta.",
        );
      setResult(
        officialInsightResult(
          payload,
          account.username,
          dates.start,
          dates.end,
          userScope,
        ),
      );
    } catch (cause) {
      if (alive.current)
        setError(
          abort.signal.aborted
            ? "A consulta foi interrompida ou excedeu o tempo disponível. Nenhum relatório foi importado."
            : cause instanceof Error
              ? cause.message
              : "Não foi possível consultar as métricas do app.",
        );
    } finally {
      clearTimeout(timer);
      if (alive.current) setLoading(false);
      if (controller.current === abort) controller.current = null;
    }
  };
  const save = async () => {
    if (!result?.reports.length || loading || busy || saving.current) return;
    saving.current = true;
    setSavingNow(true);
    const check = new AbortController();
    controller.current = check;
    try {
      await verifyHostedActor(check.signal);
      if (!alive.current || !opened.current || check.signal.aborted) return;
      const saved = await run(
        { type: "IMPORT_INSIGHTS", data: result.reports },
        "Métricas da coleta do app importadas nesta conta.",
      );
      if (saved && alive.current) {
        onSaved(
          result.reports.find((r) => r.contentWindow === "period") ||
            result.reports[0],
        );
        setOpen(false);
        setResult(null);
      }
    } catch (cause) {
      if (alive.current && opened.current)
        setError(
          cause instanceof Error
            ? cause.message
            : "Não foi possível conferir o acesso antes de importar.",
        );
    } finally {
      saving.current = false;
      if (controller.current === check) controller.current = null;
      if (alive.current) setSavingNow(false);
    }
  };
  return (
    <>
      <button
        className="button secondary"
        disabled={!account.username || busy}
        onClick={() => {
          opened.current = true;
          setOpen(true);
          setError("");
        }}
      >
        <CloudDownload size={15} />
        Trazer métricas do app
      </button>
      {open ? (
        <Modal
          title={`Métricas do app · @${account.username}`}
          subtitle="Consulte a coleta oficial já salva no app e confira antes de importar."
          onClose={() => {
            opened.current = false;
            controller.current?.abort();
            setOpen(false);
          }}
        >
          <div className="official-insights">
            <p>
              Esta leitura usa os dados já coletados em{" "}
              <strong>Growth → Instagram → Métricas</strong>. Não faz uma nova
              coleta da Meta nem altera campanhas, público ou fila.
            </p>
            <p>
              Para atualizar capas de publicações já importadas, consulte o
              mesmo período e importe novamente. Quando só a miniatura mudar, o
              relatório existente mantém a identidade, a data e as métricas.
              Imagens ausentes ou expiradas aparecem com aviso.
            </p>
            <div className="official-date-grid">
              <Field label="Data inicial">
                <input
                  type="date"
                  value={dates.start}
                  max={dates.end}
                  onChange={(e) => {
                    setDates({ ...dates, start: e.target.value });
                    setResult(null);
                  }}
                  disabled={loading || busy || savingNow}
                />
              </Field>
              <Field label="Data final">
                <input
                  type="date"
                  value={dates.end}
                  max={localDay(new Date(Date.now() - 86400000))}
                  onChange={(e) => {
                    setDates({ ...dates, end: e.target.value });
                    setResult(null);
                  }}
                  disabled={loading || busy || savingNow}
                />
              </Field>
            </div>
            {choices.length ? (
              <Field label="Conta de métricas vinculada">
                <select
                  value={choice}
                  onChange={(e) => {
                    setChoice(e.target.value);
                    setResult(null);
                  }}
                  disabled={loading || busy || savingNow}
                >
                  <option value="">Selecione uma conta</option>
                  {choices.map((c) => (
                    <option key={c.id} value={c.id}>
                      @{c.username} · {c.loja}
                    </option>
                  ))}
                </select>
              </Field>
            ) : null}
            <button
              className="button secondary"
              disabled={
                loading || busy || savingNow || (choices.length > 0 && !choice)
              }
              onClick={() => void load()}
            >
              {loading ? (
                <LoaderCircle size={15} className="spin" />
              ) : (
                <CloudDownload size={15} />
              )}{" "}
              {loading ? "Consultando coleta…" : "Consultar coleta do app"}
            </button>
            {error ? (
              <p role="alert" className="official-error">
                {error}
              </p>
            ) : null}
            {result ? (
              <div className="official-result" role="status">
                <strong>
                  {result.reports.length
                    ? `${result.reports.length} relatório(s) disponíveis`
                    : "Nenhum relatório com métricas disponíveis neste período"}
                </strong>
                <p>
                  {result.source.daysAvailable} de {result.source.daysExpected}{" "}
                  dias com coleta · {result.source.contentAvailable} publicações
                  com dados.
                </p>
                <p>
                  {result.reports.reduce(
                    (total, report) =>
                      total +
                      report.content.filter((content) => content.thumbnailUrl)
                        .length,
                    0,
                  )}{" "}
                  publicações com miniatura disponível na coleta.
                </p>
                <p>
                  Última coleta:{" "}
                  {result.source.lastCollectedAt
                    ? new Date(result.source.lastCollectedAt).toLocaleString(
                        "pt-BR",
                      )
                    : "não disponível"}
                  .
                </p>
                {result.warnings.length ? (
                  <ul>
                    {result.warnings.map((w, i) => (
                      <li key={i}>{w}</li>
                    ))}
                  </ul>
                ) : null}
                <p>
                  Valores ausentes continuam sem valor. Conteúdo acumulado de
                  vida inteira e métricas do período permanecem separados.
                </p>
              </div>
            ) : null}
            <a
              className="text-link"
              href="/areas/growth/papeis/instagram#metricas"
              target="_blank"
              rel="noreferrer"
            >
              Ver conexões e coleta nas Métricas do app ↗
            </a>
            <div className="modal-actions">
              <button
                className="button secondary"
                onClick={() => {
                  opened.current = false;
                  controller.current?.abort();
                  setOpen(false);
                }}
              >
                Fechar
              </button>
              <button
                className="button primary"
                disabled={
                  !result?.reports.length || loading || busy || savingNow
                }
                onClick={() => void save()}
              >
                {savingNow ? "Importando…" : "Importar relatórios nesta conta"}
              </button>
            </div>
          </div>
        </Modal>
      ) : null}
    </>
  );
}
