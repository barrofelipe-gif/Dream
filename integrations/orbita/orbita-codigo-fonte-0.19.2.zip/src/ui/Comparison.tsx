import { useState } from "react";
import { ArrowUpRight, Check, Download, GitCompareArrows } from "lucide-react";
import { download } from "../core/io.ts";
import {
  COMPARISON_CRITERIA,
  COMPARISON_DATE,
  COMPARISON_PRIORITIES,
  COMPARISON_PROVIDERS,
  COMPARISON_SOURCES,
  VERDICTS,
} from "../core/comparison.ts";
import type { ComparisonVerdict } from "../core/comparison.ts";

function Sources({
  ids,
}: {
  ids: readonly (keyof typeof COMPARISON_SOURCES)[];
}) {
  return (
    <div className="comparison-row-sources">
      {ids.map((id) => (
        <a
          key={id}
          href={COMPARISON_SOURCES[id].url}
          target="_blank"
          rel="noreferrer"
        >
          {COMPARISON_SOURCES[id].label} ↗
        </a>
      ))}
    </div>
  );
}
export function ComparisonPage() {
  const [view, setView] = useState<"criteria" | "providers">("criteria");
  const [filter, setFilter] = useState<ComparisonVerdict | "all">("all");
  const rows = COMPARISON_CRITERIA.filter(
    (row) => filter === "all" || row.verdict === filter,
  );
  const choose = (next: ComparisonVerdict) => {
    setView("criteria");
    setFilter(next);
    requestAnimationFrame(() =>
      document
        .getElementById("comparison-detail")
        ?.scrollIntoView({ block: "start", behavior: "smooth" }),
    );
  };
  return (
    <section
      className="comparison-page"
      aria-label="Comparativo de ferramentas"
    >
      <div className="comparison-verdict-heading">
        <div>
          <span className="eyebrow">COMPARAÇÃO COM VEREDITO</span>
          <h2>Onde ganhamos. Onde precisamos alcançar.</h2>
          <p>
            Vantagens do nosso projeto, capacidades em que os concorrentes estão
            à frente e o que ainda não tem comparação comprovada.
          </p>
        </div>
        <button
          className="button secondary"
          onClick={() =>
            download(
              "orbita-comparativo.json",
              JSON.stringify(
                {
                  version: 2,
                  orbitaVersion: "0.19.2",
                  checkedAt: COMPARISON_DATE,
                  method:
                    "Código local e documentação oficial consultada. Vantagens da Órbita são condicionais ao modelo de projeto. Fornecedores não testados com assinatura. Sem comparação de resultados reais.",
                  verdictDefinitions: VERDICTS,
                  criteria: COMPARISON_CRITERIA,
                  providers: COMPARISON_PROVIDERS,
                  priorities: COMPARISON_PRIORITIES,
                  sources: COMPARISON_SOURCES,
                  limitations: [
                    "Não avaliado não é empate nem ausência do recurso.",
                    "Perforgram e Scalehot não receberam avaliação funcional atual.",
                    "AutoInsta identifica especificamente autoinsta.online.",
                    "Recursos dependem de plano, conta e conexão.",
                  ],
                },
                null,
                2,
              ),
              "application/json",
            )
          }
        >
          <Download size={16} />
          Exportar quadro
        </button>
      </div>
      <div className="comparison-position">
        <span>LEITURA DIRETA DO QUADRO</span>
        <h3>
          Temos mais controle sobre o nosso projeto. Eles já automatizam mais
          partes da operação.
        </h3>
        <p>
          A Órbita leva vantagem para{" "}
          <strong>
            personalizar esta entrega, manter sua base local e evitar uma
            mensalidade própria do app
          </strong>
          . Metricool, Later e os produtos de automação já oferecem recursos
          operacionais que ainda nos faltam.{" "}
          <strong>Isso não comprova quem faz crescer mais.</strong>
        </p>
      </div>
      <div className="comparison-summary-grid">
        <article className="comparison-summary-card">
          <span>Nossa vantagem neste uso</span>
          <h3>Controle e adaptação ao seu negócio</h3>
          <ul>
            <li>Código do projeto disponível para mudar regras e telas.</li>
            <li>Base local, se essa for a sua prioridade.</li>
            <li>Sem assinatura própria desta entrega local.</li>
          </ul>
          <p>
            São vantagens deste modelo de projeto. Há custo de manutenção, e o
            Metricool também tem plano gratuito: não comparamos o custo total.
          </p>
          <button className="text-link" onClick={() => choose("orbita")}>
            Ver vantagens e condições <ArrowUpRight size={13} />
          </button>
        </article>
        <article className="comparison-summary-card market">
          <span>Eles estão à frente</span>
          <h3>Integração e execução da rotina</h3>
          <ul>
            <li>Metricool / Later: análise conectada.</li>
            <li>Metricool: concorrentes; Later: hashtags do setor.</li>
            <li>Calendário, publicação, mais interações e inbox.</li>
          </ul>
          <p>
            Nossa dependência de dados manuais e funções ainda não implementadas
            é uma desvantagem concreta hoje.
          </p>
          <button className="text-link" onClick={() => choose("market")}>
            Ver o que falta alcançar <ArrowUpRight size={13} />
          </button>
        </article>
        <article className="comparison-summary-card unverified">
          <span>Sem conclusão comprovada</span>
          <h3>Resultados e eficácia</h3>
          <ul>
            <li>Mais seguidores ou clientes recebidos.</li>
            <li>Maior engajamento e vendas.</li>
            <li>Menor taxa de bloqueios.</li>
          </ul>
          <p>
            Não fizemos um teste real equivalente entre os produtos. “Não
            avaliado” não deve aparecer como empate.
          </p>
          <button className="text-link" onClick={() => choose("unverified")}>
            Ver limites da comparação <ArrowUpRight size={13} />
          </button>
        </article>
      </div>
      <div id="comparison-detail" className="comparison-toolbar">
        <div
          className="insight-tabs"
          role="group"
          aria-label="Visão do comparativo"
        >
          <button
            aria-pressed={view === "criteria"}
            className={view === "criteria" ? "selected" : ""}
            onClick={() => setView("criteria")}
          >
            <GitCompareArrows size={13} /> Por critério
          </button>
          <button
            aria-pressed={view === "providers"}
            className={view === "providers" ? "selected" : ""}
            onClick={() => setView("providers")}
          >
            Por ferramenta
          </button>
        </div>
        <span className="comparison-source-note">
          Consulta: 03/11/2026 · Órbita 0.19.2
        </span>
      </div>
      <p className="comparison-method">
        <strong>Como ler:</strong> “Eles estão à frente” compara uma capacidade
        documentada com o que existe no nosso código hoje. As vantagens de
        projeto são nossa avaliação para este uso. Não fizemos login nos
        concorrentes nem medimos seus resultados. Plano e disponibilidade podem
        mudar.
      </p>
      {view === "criteria" ? (
        <>
          <div
            className="comparison-filters"
            role="group"
            aria-label="Filtrar vereditos"
          >
            <button
              aria-pressed={filter === "all"}
              onClick={() => setFilter("all")}
            >
              Todos
            </button>
            {(Object.entries(VERDICTS) as [ComparisonVerdict, string][]).map(
              ([key, label]) => (
                <button
                  key={key}
                  aria-pressed={filter === key}
                  onClick={() => setFilter(key)}
                >
                  {label}
                </button>
              ),
            )}
          </div>
          <table
            role="table"
            className="comparison-decision-table"
            aria-label="Quem leva vantagem por critério"
          >
            <thead role="rowgroup">
              <tr role="row">
                <th scope="col">CRITÉRIO</th>
                <th scope="col">QUEM LEVA VANTAGEM</th>
                <th scope="col">COMO ESTAMOS HOJE</th>
                <th scope="col">POR QUÊ / O QUE FALTA</th>
              </tr>
            </thead>
            <tbody role="rowgroup">
              {rows.map((row) => (
                <tr
                  role="row"
                  key={row.id}
                  className={`comparison-row-${row.verdict}`}
                >
                  <td>
                    <span className="comparison-cell-label" aria-hidden>
                      Critério
                    </span>
                    <strong>{row.title}</strong>
                    <small>{row.scope}</small>
                  </td>
                  <td>
                    <span className="comparison-cell-label" aria-hidden>
                      Quem leva vantagem
                    </span>
                    <span className={`comparison-badge ${row.verdict}`}>
                      {VERDICTS[row.verdict]}
                    </span>
                    <strong>{row.leader}</strong>
                  </td>
                  <td>
                    <span className="comparison-cell-label" aria-hidden>
                      Como estamos hoje
                    </span>
                    {row.ours}
                  </td>
                  <td>
                    <span className="comparison-cell-label" aria-hidden>
                      Por quê / o que falta
                    </span>
                    {row.reason}
                    <details>
                      <summary>Condições e evidência</summary>
                      <p>{row.limit}</p>
                      <p>Base do veredito: {row.evidence}.</p>
                      {row.sources.length ? (
                        <Sources ids={row.sources} />
                      ) : (
                        <p>
                          Base local: comportamento e código entregue da Órbita.
                          Não usamos ausência de documentação de terceiros como
                          prova de ausência de função.
                        </p>
                      )}
                    </details>
                  </td>
                </tr>
              ))}
            </tbody>
          </table>
        </>
      ) : (
        <div className="comparison-provider-grid">
          {COMPARISON_PROVIDERS.map((provider) => (
            <article className="comparison-provider" key={provider.name}>
              <span>{provider.group}</span>
              <h3>{provider.name}</h3>
              <h4>Onde está à nossa frente</h4>
              <p>{provider.ahead}</p>
              <h4 className="ours">Nosso diferencial implementado</h4>
              <p>{provider.ours}</p>
              <p className="comparison-provider-limit">{provider.caution}</p>
              <Sources ids={provider.sources} />
            </article>
          ))}
        </div>
      )}
      <section
        className="comparison-roadmap"
        aria-label="Prioridades para alcançar o mercado"
      >
        <h3>O que precisamos fazer para alcançar e superar</h3>
        <p>
          Esta é a ordem de trabalho sugerida a partir das lacunas. Os itens
          abaixo ainda não são funções prontas.
        </p>
        <div className="comparison-roadmap-grid">
          {COMPARISON_PRIORITIES.map((item) => (
            <article key={item.title}>
              <span>{item.priority}</span>
              <h4>{item.title}</h4>
              <p>{item.why}</p>
            </article>
          ))}
        </div>
      </section>
      <section className="comparison-evidence">
        <h3>O que já é nosso diferencial, sem inventar exclusividade</h3>
        <ul>
          <li>
            <Check size={12} /> Roteiros de teste por setor, com referência,
            hipótese e medição própria vinculadas.
          </li>
          <li>
            <Check size={12} /> Origens informadas separadas de associações com
            bases de prospecção e de resultados agregados.
          </li>
          <li>
            <Check size={12} /> Central de problemas com histórico, reabertura e
            diagnóstico local exportável.
          </li>
        </ul>
        <p className="comparison-method">
          Esses recursos existem no nosso código. Ainda não há base suficiente
          para afirmar que nenhum concorrente faça algo semelhante ou que eles
          produzam resultados inferiores.
        </p>
        <details>
          <summary>Fontes oficiais e limites da pesquisa</summary>
          <ul className="comparison-sources">
            {Object.entries(COMPARISON_SOURCES).map(([id, source]) => (
              <li key={id}>
                <a href={source.url} target="_blank" rel="noreferrer">
                  {source.label} ↗
                </a>
              </li>
            ))}
          </ul>
          <p className="comparison-source-note">
            AutoInsta refere-se a autoinsta.online. Perforgram e Scalehot ficam
            sem avaliação funcional atual. Não os tratamos como inferiores por
            falta de evidência. Promessas de crescimento e de segurança não
            foram tratadas como garantias verificadas.
          </p>
        </details>
      </section>
    </section>
  );
}
