import { useState } from "react";
import { OfficialInsights, appMetricsAvailable } from "./OfficialInsights.tsx";
import {
  BarChart3,
  Download,
  FileUp,
  Eye,
  Heart,
  Info,
  Layers,
  Minus,
  MousePointerClick,
  Play,
  Plus,
  Radio,
  Search,
  TrendingDown,
  TrendingUp,
  Trash2,
  UsersRound,
} from "lucide-react";
import {
  INSIGHT_GROUPS,
  INSIGHT_METRICS,
  CONTENT_LABELS,
  COVERAGE_LABELS,
  insightSummary,
  insightTemplate,
  localDay,
  metricSpec,
  parseInsightFile,
  validateInsightReport,
  reportFamily,
} from "../core/insights.ts";
import type { InsightMetric, MetricGroup } from "../core/insights.ts";
import type {
  AccountCommand,
  AccountWorkspace,
  InsightAudience,
  InsightContent,
  InsightReport,
} from "../core/types.ts";
import { download } from "../core/io.ts";
import { accountTypeGuide } from "../core/account-types.ts";
import { GrowthPanel, ContentEntry } from "./Growth.tsx";
import { PerformanceAlerts } from "./Performance.tsx";
import { ImprovementCenter } from "./Improvement.tsx";
import { improvementReview } from "../core/improvement.ts";
import { performanceTone } from "../core/performance.ts";
import { contentPerformance } from "../core/growth.ts";
import { ContentCover } from "./ContentCover.tsx";
import { Empty, External, Field, Modal } from "./components.tsx";

type Run = (command: AccountCommand, success?: string) => Promise<boolean>;
const range = (r: Pick<InsightReport, "start" | "end">) =>
  `${r.start.split("-").reverse().join("/")} – ${r.end.split("-").reverse().join("/")}`;
const source = (r: InsightReport) =>
  r.source === "manual" ? "Registro manual" : "Dados importados";
const decimal = (n: number) =>
  n !== 0 && Math.abs(n) < 0.01
    ? `${n < 0 ? "−" : ""}<0,01`
    : new Intl.NumberFormat("pt-BR", { maximumFractionDigits: 2 }).format(n);
function format(value: number | undefined, key: string): string {
  if (value === undefined) return "—";
  const unit = metricSpec(key)?.unit;
  return unit === "percent"
    ? `${decimal(value)}%`
    : unit === "seconds"
      ? `${decimal(value)} s`
      : decimal(value);
}
const todayRange = () => {
  const start = new Date();
  start.setDate(start.getDate() - 6);
  return { start: localDay(start), end: localDay() };
};
const SUMMARY = [
  "views",
  "reach",
  "accounts_engaged",
  "total_interactions",
  "follows",
  "unfollows",
  "profile_visits",
  "profile_links_taps",
];
const METRIC_ICONS = {
  visibility: Eye,
  engagement: Heart,
  growth: UsersRound,
  profile: MousePointerClick,
  video: Play,
  stories: Layers,
  live: Radio,
} as const;
export function InsightsDashboard({
  account,
  run,
  busy,
  onMarket,
}: {
  account: AccountWorkspace;
  run: Run;
  busy: boolean;
  onMarket: () => void;
}) {
  const [selected, setSelected] = useState("");
  const [family, setFamily] = useState<string | null>(null);
  const [tab, setTab] = useState<
    "growth" | "overview" | "content" | "audience" | "all"
  >("growth");
  const [modal, setModal] = useState<
    "manual" | "import" | "connection" | "remove" | "content" | null
  >(null);
  const [content, setContent] = useState<InsightContent | null>(null);
  const [editing, setEditing] = useState<InsightContent | undefined>();
  const [search, setSearch] = useState("");
  const reports = account.insights || [];
  const report =
    (family
      ? reports.findLast((r) => reportFamily(r) === family)
      : reports.find((r) => r.id === selected)) || reports.at(-1);
  const summary = report ? insightSummary(report, reports) : undefined;
  const improvement = report ? improvementReview(account, report) : undefined;
  const attentionKeys = new Set(improvement?.priorities.map((m) => m.key));
  const comparisonEnabled = !improvement?.blocked;
  const known = Object.keys(report?.metrics || {}).length;
  const type = accountTypeGuide(account.accountType);
  const openSection = (next: "growth" | "content") => {
    setTab(next);
    requestAnimationFrame(() =>
      document
        .querySelector(
          next === "content"
            ? ".insights-dashboard .insight-content"
            : ".insights-dashboard .growth-panel, .insights-dashboard .growth-empty",
        )
        ?.scrollIntoView({ block: "start", behavior: "smooth" }),
    );
  };
  const recordContent = (c?: InsightContent) => {
    if (!account.username) return;
    setEditing(c);
    setModal("content");
  };
  return (
    <section className="insights-dashboard" aria-label="Insights do Instagram">
      <div className="insights-title">
        <div>
          <span className="eyebrow">INSTAGRAM INSIGHTS</span>
          <h2>Crescimento e engajamento</h2>
          <p>
            Entenda o desempenho das publicações e o que merece um novo teste.
            Cada relatório mantém o período e a origem.
          </p>
        </div>
        <div className="metrics-actions">
          <OfficialInsights
            account={account}
            run={run}
            busy={busy}
            onSaved={(report) => {
              setSelected("");
              setFamily(reportFamily(report));
            }}
          />
          <button
            className="button secondary"
            disabled={!account.username || busy}
            onClick={() => setModal("import")}
          >
            <FileUp size={15} />
            Importar Insights
          </button>
          <button
            className="button primary"
            disabled={!account.username || busy}
            onClick={() => setModal("manual")}
          >
            <Plus size={15} />
            Registrar Insights
          </button>
        </div>
      </div>
      <div className="insights-connection">
        <Info size={17} />
        <p>
          <strong>
            {appMetricsAvailable()
              ? "Consulte as métricas já coletadas pelo app."
              : "Insights por importação ou registro manual."}
          </strong>{" "}
          {appMetricsAvailable()
            ? "Use “Trazer métricas do app” para consultar a coleta oficial disponível e conferir os relatórios antes de importar. Esta consulta não atualiza a Meta em tempo real."
            : "A extensão lê os contadores do perfil. Para consultar a coleta oficial disponível no app, abra a Órbita pela área de Growth."}{" "}
          Métricas ausentes continuam sem valor. A disponibilidade depende da
          conta e das permissões de leitura.
          <span className="insight-type-guidance">
            {type.label} · tipo informado. {type.guidance}
          </span>
        </p>
        <button className="text-link" onClick={() => setModal("connection")}>
          Sobre a conexão <span aria-hidden>↗</span>
        </button>
      </div>
      <div className="insights-toolbar">
        <div
          className="insight-tabs"
          role="group"
          aria-label="Seções dos Insights"
        >
          {(
            [
              ["growth", "Aprendizados"],
              ["overview", "Resumo"],
              ["content", "Conteúdo"],
              ["audience", "Público"],
              ["all", "Todas as métricas"],
            ] as const
          ).map(([key, label]) => (
            <button
              className={tab === key ? "selected" : ""}
              key={key}
              aria-pressed={tab === key}
              onClick={() => setTab(key)}
            >
              {label}
            </button>
          ))}
        </div>
        {reports.length ? (
          <div className="insight-report-picker">
            <select
              aria-label="Relatório de Insights"
              value={report?.id || ""}
              onChange={(e) => {
                setFamily(null);
                setSelected(e.target.value);
              }}
            >
              {[...reports].reverse().map((r) => (
                <option value={r.id} key={r.id}>
                  {range(r)} ·{" "}
                  {r.contentWindow === "lifetime" ? "Acumulado" : "Período"} ·{" "}
                  {COVERAGE_LABELS[r.coverage]} · {source(r)} ·{" "}
                  {new Date(r.recordedAt).toLocaleString("pt-BR")}
                </option>
              ))}
            </select>
            <button
              className="icon-button"
              aria-label="Exportar relatório de Insights selecionado"
              onClick={() =>
                download(
                  `orbita-${account.username}-insights-${report!.end}.json`,
                  JSON.stringify({ version: 1, reports: [report] }, null, 2),
                  "application/json",
                )
              }
            >
              <Download size={17} />
            </button>
            <button
              className="icon-button"
              aria-label="Remover relatório de Insights selecionado"
              disabled={busy}
              onClick={() => setModal("remove")}
            >
              <Trash2 size={16} />
            </button>
          </div>
        ) : (
          <span className="insight-coverage">Sem relatório nesta conta</span>
        )}
      </div>
      {report ? (
        <div className="insight-provenance">
          <span>{range(report)}</span>
          <span>{COVERAGE_LABELS[report.coverage]}</span>
          <span>
            {source(report)} · registrado em{" "}
            {new Date(report.recordedAt).toLocaleString("pt-BR")}
          </span>
          <span>
            {known} métricas da conta · {report.content.length} conteúdos ·{" "}
            {report.audience.length} recortes de público
          </span>
          {report.note ? <p>{report.note}</p> : null}
        </div>
      ) : null}
      {report && improvement ? (
        <ImprovementCenter
          account={account}
          report={report}
          review={improvement}
          run={run}
          busy={busy}
          onExplore={() => openSection("growth")}
          onContent={() => openSection("content")}
          onMarket={onMarket}
        />
      ) : null}
      {report ? (
        <details className="improvement-previous-details">
          <summary>Ver detalhes da comparação com o período anterior</summary>
          <PerformanceAlerts
            report={report}
            reports={reports}
            onExplore={() => openSection("growth")}
            onContent={() => openSection("content")}
          />
        </details>
      ) : null}
      {tab === "growth" ? (
        <GrowthPanel
          key={report ? reportFamily(report) : account.id}
          report={report}
          onRecord={recordContent}
          onOpen={setContent}
          canRecord={!!account.username}
        />
      ) : null}
      {tab === "overview" ? (
        <>
          <div className="insight-kpis">
            {SUMMARY.map((key) => (
              <MetricCard
                key={key}
                spec={metricSpec(key)!}
                value={report?.metrics[key]}
                change={comparisonEnabled ? summary?.change(key) : undefined}
                attention={attentionKeys.has(key)}
              />
            ))}
          </div>
          <div className="insight-derived">
            <div>
              <TrendingUp size={18} />
              <span>
                Saldo de seguidores recebidos
                <strong>
                  {summary?.net === undefined
                    ? "—"
                    : `${summary.net > 0 ? "+" : ""}${decimal(summary.net)}`}
                </strong>
                <small>
                  Novos seguidores − perdas. Exige os dois dados do mesmo
                  relatório.
                </small>
              </span>
            </div>
            <div>
              <BarChart3 size={18} />
              <span>
                Interações / alcance · cálculo
                <strong>
                  {summary?.rate === undefined
                    ? "—"
                    : `${decimal(summary.rate)}%`}
                </strong>
                <small>
                  Interações ÷ contas alcançadas × 100. Pode superar 100%; uma
                  pessoa pode interagir várias vezes.
                </small>
              </span>
            </div>
          </div>
          <p className="insights-note">
            {summary?.previous
              ? `Variações comparam o período anterior completo: ${range(summary.previous)}. Base zero fica sem comparação percentual.`
              : "A comparação exige período anterior contíguo, mesma duração e a mesma cobertura declarada (orgânico, pago ou ambos). Cobertura desconhecida e períodos sobrepostos não geram comparação."}{" "}
            Seguidores recebidos, alcance e interações não são inferidos a
            partir da fila da Órbita.
          </p>
        </>
      ) : null}
      {tab === "content" ? (
        <ContentTable
          content={report?.content || []}
          onOpen={setContent}
          window={report?.contentWindow || "period"}
          onRecord={recordContent}
          canRecord={!!account.username}
        />
      ) : null}
      {tab === "audience" ? (
        <div className="insight-audience-grid">
          {report?.audience.length ? (
            report.audience.map((row) => (
              <AudienceCard
                row={row}
                key={`${row.audience}|${row.dimension}`}
              />
            ))
          ) : (
            <Empty
              icon={<UsersRound size={25} />}
              title="O público precisa de dados da própria conta"
              text="Importe recortes agregados de cidade, país, idade, gênero ou horários. A disponibilidade depende do que o Instagram libera. Ausência de dado não significa público zero."
            />
          )}
          <p className="insights-note">
            Distribuições são agregadas e podem representar apenas os grupos
            disponibilizados na origem. Não revelam quem visitou o perfil. Não
            somamos públicos alcançados de diferentes posts, pois podem ser as
            mesmas pessoas.
          </p>
        </div>
      ) : null}
      {tab === "all" ? (
        <>
          <label className="insight-search">
            <Search size={16} />
            <input
              aria-label="Buscar métrica de Insights"
              placeholder="Buscar alcance, salvamentos, Stories…"
              value={search}
              onChange={(e) => setSearch(e.target.value)}
            />
          </label>
          {(Object.keys(INSIGHT_GROUPS) as MetricGroup[]).map((group) => {
            const specs = INSIGHT_METRICS.filter(
              (m) =>
                m.group === group &&
                `${m.label} ${m.key}`
                  .toLocaleLowerCase("pt-BR")
                  .includes(search.toLocaleLowerCase("pt-BR")),
            );
            return specs.length ? (
              <div className="insight-metric-group" key={group}>
                <h3>{INSIGHT_GROUPS[group]}</h3>
                <div className="insight-kpis">
                  {specs.map((spec) => (
                    <MetricCard
                      key={spec.key}
                      spec={spec}
                      value={report?.metrics[spec.key]}
                      attention={attentionKeys.has(spec.key)}
                      change={
                        !comparisonEnabled
                          ? undefined
                          : spec.unit === "percent"
                            ? summary?.difference(spec.key)
                            : summary?.change(spec.key)
                      }
                    />
                  ))}
                </div>
              </div>
            ) : null;
          })}
          {report &&
          Object.keys(report.metrics).some((key) => !metricSpec(key)) ? (
            <div className="insight-metric-group">
              <h3>Outras métricas do arquivo</h3>
              <p className="insights-note">
                Identificadores preservados como informados no arquivo; não
                indicam suporte automático da API.
              </p>
              <div className="insight-kpis">
                {Object.entries(report.metrics)
                  .filter(
                    ([key]) =>
                      !metricSpec(key) && key.includes(search.toLowerCase()),
                  )
                  .map(([key, value]) => (
                    <MetricCard
                      key={key}
                      spec={{
                        key,
                        label: key,
                        unit: "count",
                        group: "visibility",
                        help: "Métrica adicional do arquivo importado. Confira sua definição na origem.",
                      }}
                      value={value}
                    />
                  ))}
              </div>
            </div>
          ) : null}
          <p className="insights-note">
            O catálogo organiza os campos suportados pelo relatório local. Nem
            todos existem para cada conta, formato ou versão da API. Impressões
            ficam identificadas como histórico; tempo assistido é informado em
            segundos. Um traço significa “sem dado”, nunca zero estimado.
          </p>
        </>
      ) : null}
      {!report ? (
        <div className="insights-get-started">
          <FileUp size={20} />
          <div>
            <strong>Traga os Insights que sua conta disponibiliza</strong>
            <p>
              Importe um CSV/JSON no modelo Órbita ou registre uma leitura
              manual. Contas e períodos são validados antes de salvar.
            </p>
          </div>
          <button
            className="text-link"
            disabled={!account.username}
            onClick={() =>
              download(
                `orbita-${account.username}-modelo-insights.csv`,
                insightTemplate(
                  account.username!,
                  todayRange().start,
                  todayRange().end,
                ),
                "text/csv;charset=utf-8",
              )
            }
          >
            Baixar modelo CSV <Download size={14} />
          </button>
        </div>
      ) : null}
      {modal === "manual" ? (
        <ManualInsights
          account={account}
          run={run}
          busy={busy}
          onSaved={(r) => {
            setSelected("");
            setFamily(reportFamily(r));
          }}
          onClose={() => setModal(null)}
        />
      ) : null}
      {modal === "import" ? (
        <ImportInsights
          account={account}
          run={run}
          busy={busy}
          onSaved={(r) => {
            setSelected("");
            setFamily(reportFamily(r));
          }}
          onClose={() => setModal(null)}
        />
      ) : null}
      {modal === "connection" ? (
        <Modal
          title="Conexão oficial dos Insights"
          subtitle="A sessão do navegador e a autorização de Insights são conexões diferentes."
          onClose={() => setModal(null)}
        >
          <div className="insight-connection-help">
            <p>
              Para sincronizar automaticamente é necessário configurar um
              aplicativo da Meta, o fluxo de autorização e as permissões de
              leitura para cada conta profissional gerenciada. A disponibilidade
              varia por métrica e formato.
            </p>
            <p>
              No app BFF, o botão “Trazer métricas do app” consulta os dados
              oficiais já coletados na área de Métricas. Você confere a data e a
              cobertura antes de importar. Não é uma nova coleta da Meta; dados
              acumulados de publicações permanecem separados dos totais do
              período. Nenhum token ou senha é solicitado por este painel.
            </p>
            <p>
              O catálogo inclui conta, conteúdo, Reels, Stories, Lives e
              público. Dados não autorizados ou indisponíveis continuam sem
              valor, com a origem explícita.
            </p>
            <External href="https://www.postman.com/meta/instagram/collection/6yqw8pt/instagram-api">
              Documentação da Meta · Instagram API
            </External>
          </div>
        </Modal>
      ) : null}
      {modal === "remove" && report ? (
        <Modal
          title="Remover este relatório?"
          subtitle={`@${account.username} · ${range(report)} · ${source(report)}`}
          onClose={() => setModal(null)}
        >
          <div className="insight-connection-help">
            <p>
              Somente este relatório de Insights será removido. As campanhas, a
              fila, as medições do perfil e as outras contas são preservadas.
              Exporte o relatório se quiser guardá-lo.
            </p>
            <button
              className="button secondary"
              onClick={() =>
                download(
                  `orbita-${account.username}-insights-${report.end}.json`,
                  JSON.stringify({ version: 1, reports: [report] }, null, 2),
                  "application/json",
                )
              }
            >
              <Download size={15} />
              Exportar relatório
            </button>
          </div>
          <div className="modal-actions">
            <button className="button secondary" onClick={() => setModal(null)}>
              Cancelar
            </button>
            <button
              className="button primary"
              disabled={busy}
              onClick={async () => {
                if (
                  await run(
                    { type: "REMOVE_INSIGHT_REPORT", id: report.id },
                    "Relatório removido desta conta.",
                  )
                ) {
                  setSelected("");
                  setFamily(null);
                  setModal(null);
                }
              }}
            >
              Remover relatório
            </button>
          </div>
        </Modal>
      ) : null}
      {modal === "content" && account.username ? (
        <ContentEntry
          account={account.username}
          report={report}
          content={editing}
          run={run}
          busy={busy}
          onSaved={(r) => {
            setSelected("");
            setFamily(reportFamily(r));
          }}
          onClose={() => setModal(null)}
        />
      ) : null}
      {content ? (
        <Modal
          title={content.title}
          subtitle={`${CONTENT_LABELS[content.kind]} · ${report?.contentWindow === "lifetime" ? "Vida inteira, medido até " + report.end : report ? range(report) : ""}`}
          onClose={() => setContent(null)}
          wide
        >
          <ContentCover content={content} large />
          <div className="insight-kpis">
            {Object.entries(content.metrics).map(([key, value]) => (
              <MetricCard
                key={key}
                value={value}
                spec={
                  key === "follows"
                    ? {
                        ...metricSpec(key)!,
                        label: "Seguidores atribuídos à publicação",
                      }
                    : metricSpec(key) || {
                        key,
                        label: key,
                        unit: "count",
                        group: "visibility",
                        help: "Métrica adicional informada no arquivo.",
                      }
                }
              />
            ))}
          </div>
          <button
            className="button secondary"
            onClick={() => {
              const item = content;
              setContent(null);
              recordContent(item);
            }}
          >
            Editar medição da publicação
          </button>
          {content.url ? (
            <External href={content.url}>Abrir conteúdo no Instagram</External>
          ) : null}
        </Modal>
      ) : null}
    </section>
  );
}
function MetricCard({
  spec,
  value,
  change,
  attention = false,
}: {
  spec: InsightMetric;
  value?: number;
  change?: number;
  attention?: boolean;
}) {
  const Icon = METRIC_ICONS[spec.group];
  return (
    <div
      className={`insight-kpi metric-${spec.group} ${value === undefined ? "unavailable" : ""} ${attention ? "attention" : ""}`}
    >
      <span title={spec.help}>
        <span className="metric-symbol" aria-hidden="true">
          <Icon size={17} />
        </span>
        {spec.label} <Info size={12} />
      </span>
      <strong>{format(value, spec.key)}</strong>
      {attention ? (
        <button
          className="metric-attention-link"
          aria-label={`Ver plano de melhoria para ${spec.label}`}
          onClick={() =>
            document
              .getElementById("improvement-center")
              ?.scrollIntoView({ block: "start", behavior: "smooth" })
          }
        >
          Ver plano de melhoria ↑
        </button>
      ) : null}
      {change !== undefined ? (
        <small className={performanceTone(spec.key, change)}>
          {change > 0 ? (
            <TrendingUp size={13} aria-hidden="true" />
          ) : change < 0 ? (
            <TrendingDown size={13} aria-hidden="true" />
          ) : (
            <Minus size={13} aria-hidden="true" />
          )}
          {change > 0 ? "+" : ""}
          {decimal(change)}
          {spec.unit === "percent" ? " p.p." : "%"} frente ao período anterior
        </small>
      ) : (
        <small>
          {value === undefined
            ? "Sem dado neste relatório"
            : "Valor informado na origem"}
        </small>
      )}
    </div>
  );
}
function ContentTable({
  content,
  onOpen,
  window,
  onRecord,
  canRecord,
}: {
  content: InsightContent[];
  onOpen: (c: InsightContent) => void;
  window: InsightReport["contentWindow"];
  onRecord: (c?: InsightContent) => void;
  canRecord: boolean;
}) {
  const [kind, setKind] = useState("all"),
    [sort, setSort] = useState("views");
  const rows = content
    .filter((c) => kind === "all" || c.kind === kind)
    .sort((a, b) => (b.metrics[sort] ?? -1) - (a.metrics[sort] ?? -1));
  return (
    <div className="insight-content">
      <div className="insight-content-filters">
        <select
          aria-label="Formato do conteúdo"
          value={kind}
          onChange={(e) => setKind(e.target.value)}
        >
          <option value="all">Todos os formatos</option>
          {Object.entries(CONTENT_LABELS).map(([key, label]) => (
            <option key={key} value={key}>
              {label}
            </option>
          ))}
        </select>
        <select
          aria-label="Ordenar conteúdo por métrica"
          value={sort}
          onChange={(e) => setSort(e.target.value)}
        >
          {[
            "follows",
            "views",
            "reach",
            "total_interactions",
            "saves",
            "shares",
          ].map((key) => (
            <option key={key} value={key}>
              {key === "follows"
                ? "Seguidores atribuídos"
                : metricSpec(key)!.label}
            </option>
          ))}
        </select>
        <span>
          {rows.length} conteúdos ·{" "}
          {window === "lifetime"
            ? "vida inteira até a data final"
            : "período do relatório"}
        </span>
        <button
          className="button secondary"
          disabled={!canRecord}
          onClick={() => onRecord()}
        >
          <Plus size={15} />
          Registrar publicação
        </button>
      </div>
      {rows.length ? (
        <div className="table-scroll">
          <table>
            <thead>
              <tr>
                <th>CONTEÚDO</th>
                <th>FORMATO</th>
                {[
                  "follows",
                  "views",
                  "reach",
                  "total_interactions",
                  "saves",
                  "shares",
                  "avg_watch_time_seconds",
                ].map((key) => (
                  <th key={key}>
                    {key === "follows"
                      ? "SEGUIDORES ATRIBUÍDOS"
                      : metricSpec(key)!.label.toUpperCase()}
                  </th>
                ))}
                <th>INTERAÇÕES / ALCANCE</th>
                <th />
              </tr>
            </thead>
            <tbody>
              {rows.map((row) => (
                <tr key={row.id}>
                  <td>
                    <button
                      className="text-link publication-link"
                      onClick={() => onOpen(row)}
                    >
                      <ContentCover content={row} />
                      <span>
                        <span className="publication-title">{row.title}</span>
                      </span>
                    </button>
                  </td>
                  <td>{CONTENT_LABELS[row.kind]}</td>
                  {[
                    "follows",
                    "views",
                    "reach",
                    "total_interactions",
                    "saves",
                    "shares",
                    "avg_watch_time_seconds",
                  ].map((key) => (
                    <td key={key}>{format(row.metrics[key], key)}</td>
                  ))}
                  <td>
                    {contentPerformance(row).engagementRate === undefined
                      ? "—"
                      : `${decimal(contentPerformance(row).engagementRate!)}%`}
                  </td>
                  <td>
                    <button
                      className="text-link"
                      aria-label={`Editar medição de ${row.title}`}
                      onClick={() => onRecord(row)}
                    >
                      Editar
                    </button>
                  </td>
                </tr>
              ))}
            </tbody>
          </table>
        </div>
      ) : (
        <Empty
          icon={<BarChart3 size={25} />}
          title="Compare seus conteúdos quando houver medições"
          text="Use o CSV para registrar Posts, Carrosséis, Reels, Stories e Lives, ou importe um JSON com detalhes de conteúdo. A Órbita não estima desempenho a partir de curtidas públicas."
        />
      )}
      <p className="insights-note">
        As métricas de cada conteúdo precisam corresponder ao recorte informado
        no relatório. Dados de vida inteira devem ficar em relatório
        identificado como tal. Não somamos alcance, médias ou picos para criar
        totais da conta. Seguidores atribuídos só aparecem quando informados
        para a publicação; não são estimados pelo crescimento da conta.
      </p>
    </div>
  );
}
const DIMENSIONS: Record<InsightAudience["dimension"], string> = {
  country: "Países",
  city: "Cidades",
  age: "Faixas etárias",
  gender: "Gênero",
  hour: "Horários de atividade",
  day: "Dias de atividade",
  follower_status: "Seguidores e não seguidores",
};
const AUDIENCES: Record<InsightAudience["audience"], string> = {
  followers: "Seguidores",
  reached: "Contas alcançadas",
  engaged: "Contas com engajamento",
};
function AudienceCard({ row }: { row: InsightAudience }) {
  const [expanded, setExpanded] = useState(false);
  const sorted = [...row.values].sort((a, b) => b.value - a.value);
  const max = Math.max(1, ...row.values.map((v) => v.value));
  return (
    <section className="insight-audience-card">
      <h3>{DIMENSIONS[row.dimension]}</h3>
      <p>
        {AUDIENCES[row.audience]} ·{" "}
        {row.unit === "percent" ? "percentual informado" : "contagem informada"}
      </p>
      {(expanded ? sorted : sorted.slice(0, 8)).map((v) => (
        <div className="audience-row" key={v.label}>
          <span>{v.label}</span>
          <strong>
            {decimal(v.value)}
            {row.unit === "percent" ? "%" : ""}
          </strong>
          <i style={{ width: `${(v.value / max) * 100}%` }} />
        </div>
      ))}
      {sorted.length > 8 ? (
        <button className="text-link" onClick={() => setExpanded(!expanded)}>
          {expanded ? "Mostrar menos" : `Ver ${sorted.length} grupos`}
        </button>
      ) : null}
    </section>
  );
}
function ManualInsights({
  account,
  run,
  busy,
  onClose,
  onSaved,
}: {
  account: AccountWorkspace;
  run: Run;
  busy: boolean;
  onClose: () => void;
  onSaved: (r: InsightReport) => void;
}) {
  const [period, setPeriod] = useState(todayRange),
    [coverage, setCoverage] = useState<InsightReport["coverage"]>("unknown"),
    [entries, setEntries] = useState<Record<string, string>>({}),
    [note, setNote] = useState(""),
    [error, setError] = useState("");
  return (
    <Modal
      title={`Registrar Insights · @${account.username}`}
      subtitle="Transcreva apenas os números que você consegue consultar. Campos vazios permanecem desconhecidos."
      onClose={onClose}
      wide
    >
      <form
        onSubmit={async (e) => {
          e.preventDefault();
          setError("");
          try {
            const data = {
              account: account.username,
              ...period,
              coverage,
              note,
              metrics: Object.fromEntries(
                Object.entries(entries)
                  .filter(([, v]) => v !== "")
                  .map(([k, v]) => [k, Number(v)]),
              ),
            };
            const validated = validateInsightReport(
              data,
              account.username!,
              "manual",
            );
            if (
              await run(
                { type: "RECORD_INSIGHTS", data },
                "Insights manuais salvos apenas nesta conta.",
              )
            ) {
              onSaved(validated);
              onClose();
            }
          } catch (err) {
            setError(
              err instanceof Error ? err.message : "Não foi possível salvar.",
            );
          }
        }}
      >
        <div className="form-grid">
          <Field label="Início do período">
            <input
              required
              type="date"
              value={period.start}
              max={period.end}
              onChange={(e) => setPeriod({ ...period, start: e.target.value })}
            />
          </Field>
          <Field label="Fim do período">
            <input
              required
              type="date"
              value={period.end}
              min={period.start}
              max={localDay()}
              onChange={(e) => setPeriod({ ...period, end: e.target.value })}
            />
          </Field>
        </div>
        <Field
          label="Cobertura dos dados"
          hint="A comparação entre períodos exige a mesma cobertura declarada."
        >
          <select
            value={coverage}
            onChange={(e) =>
              setCoverage(e.target.value as InsightReport["coverage"])
            }
          >
            {Object.entries(COVERAGE_LABELS).map(([key, label]) => (
              <option key={key} value={key}>
                {label}
              </option>
            ))}
          </select>
        </Field>
        {(Object.keys(INSIGHT_GROUPS) as MetricGroup[]).map((group, index) => (
          <details
            className="insight-form-group"
            open={index === 0}
            key={group}
          >
            <summary>{INSIGHT_GROUPS[group]}</summary>
            <div className="form-grid">
              {INSIGHT_METRICS.filter((m) => m.group === group).map((m) => (
                <Field
                  key={m.key}
                  label={
                    m.label +
                    (m.unit === "seconds"
                      ? " · segundos"
                      : m.unit === "percent"
                        ? " · %"
                        : "")
                  }
                  hint={m.help}
                >
                  <input
                    type="number"
                    min="0"
                    max={m.unit === "percent" ? 100 : undefined}
                    step={m.unit === "count" ? "1" : "any"}
                    placeholder="Não informado"
                    value={entries[m.key] || ""}
                    onChange={(e) =>
                      setEntries({ ...entries, [m.key]: e.target.value })
                    }
                  />
                </Field>
              ))}
            </div>
          </details>
        ))}
        <Field
          label="Origem e observações"
          hint="Ex.: números do painel Insights, período completo, somente orgânico. Não misture recortes diferentes."
        >
          <textarea
            maxLength={500}
            value={note}
            onChange={(e) => setNote(e.target.value)}
          />
        </Field>
        <p className="insights-note">
          Para conteúdo individual e recortes de público, use a importação
          CSV/JSON. Estes valores serão identificados como registro manual.
        </p>
        {error ? (
          <div className="notice error" role="alert">
            {error}
          </div>
        ) : null}
        <div className="modal-actions">
          <button className="button secondary" type="button" onClick={onClose}>
            Cancelar
          </button>
          <button className="button primary" disabled={busy}>
            Salvar Insights manuais
          </button>
        </div>
      </form>
    </Modal>
  );
}
function ImportInsights({
  account,
  run,
  busy,
  onClose,
  onSaved,
}: {
  account: AccountWorkspace;
  run: Run;
  busy: boolean;
  onClose: () => void;
  onSaved: (r: InsightReport) => void;
}) {
  const [input, setInput] = useState<unknown>(null),
    [preview, setPreview] = useState<InsightReport[]>([]),
    [fileName, setFileName] = useState(""),
    [error, setError] = useState("");
  const period = todayRange();
  return (
    <Modal
      title={`Importar Insights · @${account.username}`}
      subtitle="CSV ou JSON no modelo Órbita, até 5 MB. A conta precisa corresponder ao espaço selecionado."
      onClose={onClose}
      wide
    >
      <div className="insight-import-help">
        <p>
          Exporte ou consulte seus Insights e adapte os dados ao modelo. Esta
          importação não sincroniza a Meta e não aceita qualquer CSV nativo
          automaticamente. Valores, período e origem precisam permanecer fiéis
          ao relatório consultado.
        </p>
        <div className="metrics-actions">
          <button
            className="button secondary"
            onClick={() =>
              download(
                `orbita-${account.username}-modelo-insights.csv`,
                insightTemplate(account.username!, period.start, period.end),
                "text/csv;charset=utf-8",
              )
            }
          >
            <Download size={15} />
            Modelo CSV
          </button>
          <button
            className="button secondary"
            onClick={() =>
              download(
                `orbita-${account.username}-modelo-insights.json`,
                JSON.stringify(
                  {
                    version: 1,
                    reports: [
                      {
                        account: account.username,
                        ...period,
                        coverage: "unknown",
                        contentWindow: "period",
                        note: "Informe a origem e o recorte dos dados.",
                        metrics: {
                          views: null,
                          reach: null,
                          total_interactions: null,
                        },
                        content: [],
                        audience: [],
                      },
                    ],
                  },
                  null,
                  2,
                ),
                "application/json",
              )
            }
          >
            <Download size={15} />
            Modelo JSON
          </button>
        </div>
        <label className="button primary insight-upload">
          <FileUp size={16} />
          Escolher arquivo de Insights
          <input
            type="file"
            accept=".csv,.json,text/csv,application/json"
            onChange={async (e) => {
              const file = e.target.files?.[0];
              setError("");
              setInput(null);
              setPreview([]);
              if (!file) return;
              try {
                if (file.size > 5_000_000)
                  throw new Error("Use arquivos com até 5 MB.");
                const data = parseInsightFile(await file.text());
                const list = Array.isArray(data) ? data : [data];
                if (!list.length || list.length > 120)
                  throw new Error("Importe entre 1 e 120 relatórios.");
                const reports = list.map((r) =>
                  validateInsightReport(r, account.username!, "file"),
                );
                setInput(data);
                setPreview(reports);
                setFileName(file.name);
              } catch (err) {
                setError(
                  err instanceof Error ? err.message : "Arquivo inválido.",
                );
              }
            }}
          />
        </label>
      </div>
      {error ? (
        <div className="notice error" role="alert">
          {error}
        </div>
      ) : null}
      {preview.length ? (
        <div className="insight-import-preview">
          <strong>
            {fileName} · {preview.length} relatórios validados
          </strong>
          {preview.map((r) => (
            <div key={r.id}>
              <b>
                @{r.account} · {range(r)}
              </b>
              <span>
                {Object.keys(r.metrics).length} métricas · {r.content.length}{" "}
                conteúdos · {r.audience.length} recortes de público
              </span>
            </div>
          ))}
          <p>
            Relatórios idênticos não serão duplicados. Recortes diferentes
            continuam separados; o painel não soma públicos ou períodos
            sobrepostos.
          </p>
        </div>
      ) : null}
      <details className="insight-schema-help">
        <summary>Colunas e formatos do modelo</summary>
        <p>
          CSV: account, start, end, coverage, content_window, scope, content_id,
          title, url, metric, value. Use scope=account, post, carousel, reel,
          story ou live. Uma linha por métrica. Para conteúdo, repita o mesmo
          content_id nas suas métricas. Use números sem separador de milhar e
          ponto nos decimais; deixe valores desconhecidos vazios.
        </p>
        <p>
          JSON: reports é uma lista com account, start, end, metrics, content e
          audience. Em content use id, kind, title, url opcional e metrics. Em
          audience use audience (followers, reached ou engaged), dimension
          (country, city, age, gender, hour, day ou follower_status), unit
          (count ou percent) e values com label e value.
        </p>
        <p>
          coverage aceita organic, paid, combined ou unknown. No CSV,
          content_window aceita period ou lifetime; no JSON, use contentWindow.
          Métricas de vida inteira dos conteúdos ficam identificadas e não são
          tratadas como valores do período.
        </p>
        <p>
          Tempo assistido: watch_time_seconds e avg_watch_time_seconds, em
          segundos. As demais chaves estão em Todas as métricas. Nomes
          adicionais em snake_case são preservados como números inteiros sem
          unidade inferida.
        </p>
      </details>
      <div className="modal-actions">
        <button className="button secondary" onClick={onClose}>
          Cancelar
        </button>
        <button
          className="button primary"
          disabled={busy || !preview.length}
          onClick={async () => {
            if (
              await run(
                { type: "IMPORT_INSIGHTS", data: input },
                "Insights importados nesta conta.",
              )
            ) {
              onSaved(
                [...preview].sort((a, b) => a.end.localeCompare(b.end)).at(-1)!,
              );
              onClose();
            }
          }}
        >
          Importar {preview.length || ""}{" "}
          {preview.length === 1 ? "relatório" : "relatórios"}
        </button>
      </div>
    </Modal>
  );
}
