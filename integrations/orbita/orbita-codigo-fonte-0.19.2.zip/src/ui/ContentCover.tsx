import { useState } from "react";
import { ImageOff } from "lucide-react";
import type { InsightContent } from "../core/types.ts";
import { profilePhotoUrl } from "../core/photos.ts";
import "./content-cover.css";

export function ContentCover({
  content,
  large = false,
}: {
  content: Pick<InsightContent, "thumbnailUrl" | "title">;
  large?: boolean;
}) {
  const url = profilePhotoUrl(content.thumbnailUrl);
  const [failedUrl, setFailedUrl] = useState<string>();
  const available = url !== undefined && url !== failedUrl;
  return (
    <span
      className={`content-cover${large ? " content-cover-large" : ""}`}
      title={
        available
          ? `Miniatura de ${content.title}`
          : url
            ? "A miniatura não carregou. A URL da coleta pode ter expirado."
            : "A fonte não informou uma miniatura utilizável."
      }
    >
      {available ? (
        <img
          src={url}
          alt=""
          width={large ? 180 : 72}
          height={large ? 225 : 90}
          loading="lazy"
          decoding="async"
          referrerPolicy="no-referrer"
          onError={() => setFailedUrl(url)}
        />
      ) : (
        <span className="content-cover-fallback">
          <ImageOff size={large ? 25 : 18} aria-hidden="true" />
          <span>{url ? "Miniatura indisponível" : "Sem miniatura"}</span>
        </span>
      )}
    </span>
  );
}
