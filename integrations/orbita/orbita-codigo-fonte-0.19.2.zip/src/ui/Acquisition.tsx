import { useMemo, useState } from "react";
import { Download, FileUp, Link2, Plus, Target, Trash2 } from "lucide-react";
import type {
  AccountCommand,
  AccountWorkspace,
  AcquisitionChannel,
  ChannelResult,
  FollowerOrigin,
  OriginEvidence,
} from "../core/types.ts";
import { SOURCE_LABELS } from "../core/types.ts";
import {
  ACQUISITION_CHANNELS,
  ORIGIN_EVIDENCE,
  followerAcquisition,
  parseFollowerOrigins,
  setFollowerOrigins,
  validateFollowerOrigin,
} from "../core/acquisition.ts";
import { relationshipAnalysis } from "../core/relationships.ts";
import { localDay } from "../core/insights.ts";
import { download } from "../core/io.ts";
import { Avatar, Empty, Field, Modal } from "./components.tsx";
import { AccountDataStatus } from "./AccountDataStatus.tsx";
type Run = (command: AccountCommand, success?: string) => Promise<boolean>;
const date = (iso: string) =>
  new Date(iso).toLocaleString("pt-BR", {
    dateStyle: "short",
    timeStyle: "short",
  });
const number = (n: number) => n.toLocaleString("pt-BR");
type Scope = "auto" | "new" | "current";
export function AcquisitionPage({
  account,
  run,
  busy,
  onRelationships,
}: {
  account: AccountWorkspace;
  run: Run;
  busy: boolean;
  onRelationships: () => void;
}) {
  const [snapshotId, setSnapshotId] = useState(""),
    [baselineId, setBaselineId] = useState(""),
    [scope, setScope] = useState<Scope>("auto");
  const [channel, setChannel] = useState<AcquisitionChannel | "all">("all"),
    [source, setSource] = useState("all"),
    [query, setQuery] = useState(""),
    [page, setPage] = useState(1);
  const [editing, setEditing] = useState<{
      username: string;
      origin?: FollowerOrigin;
    } | null>(null),
    [reporting, setReporting] = useState(false),
    [importing, setImporting] = useState(false),
    [removing, setRemoving] = useState<ChannelResult | null>(null);
  const history = useMemo(
    () =>
      relationshipAnalysis(
        account.relationships,
        snapshotId,
        baselineId || undefined,
      ),
    [account.relationships, snapshotId, baselineId],
  );
  const resolvedScope =
    scope === "auto" ? (history.comparable ? "new" : "current") : scope;
  const analysis = useMemo(
    () =>
      followerAcquisition(account, {
        snapshotId,
        baselineId: baselineId || undefined,
        scope: resolvedScope,
      }),
    [account, snapshotId, baselineId, resolvedScope],
  );
  const search = query.trim().replace(/^@/, "").toLowerCase();
  const associatedSources = analysis.sources.filter((item) => item.matches > 0);
  const effectiveSource =
    source === "all" ||
    source === "none" ||
    associatedSources.some((item) => item.campaignId === source)
      ? source
      : "all";
  const filtered = analysis.rows.filter(
    (row) =>
      row.username.includes(search) &&
      (channel === "all" || (row.origin?.channel || "unknown") === channel) &&
      (effectiveSource === "all" ||
        (effectiveSource === "none"
          ? row.associations.length === 0
          : row.associations.some((s) => s.campaignId === effectiveSource))),
  );
  const pages = Math.max(1, Math.ceil(filtered.length / 50)),
    currentPage = Math.min(page, pages),
    visible = filtered.slice((currentPage - 1) * 50, currentPage * 50);
  const s = analysis.current,
    previous = analysis.previous;
  const insightTotals = (account.insights || []).filter(
    (r) =>
      r.account === account.username && Object.hasOwn(r.metrics, "follows"),
  );
  const measuredNames = new Set(analysis.rows.map((row) => row.username));
  const outsideOrigins = (account.acquisition?.assignments || []).filter(
    (row) => !measuredNames.has(row.username),
  );
  return (
    <section
      className="acquisition-page"
      aria-label="Origens dos seguidores da conta"
    >
      <div className="growth-heading">
        <div>
          <span className="eyebrow">DE ONDE VÊM OS SEGUIDORES</span>
          <h2>Origens, fontes e evidências</h2>
          <p>
            @{account.username || "seu perfil"} · acompanhe o que foi informado
            e o que foi apenas associado.
          </p>
        </div>
        <div className="metrics-actions">
          <button
            className="button secondary"
            disabled={!account.username || busy}
            onClick={() => setImporting(true)}
          >
            <FileUp size={15} />
            Importar origens
          </button>
          <button
            className="button primary"
            disabled={!account.username || busy}
            onClick={() => setEditing({ username: "" })}
          >
            <Plus size={15} />
            Informar origem
          </button>
        </div>
      </div>
      <div className="acquisition-explanation">
        <Link2 size={19} />
        <p>
          <strong>Origem informada e associação são sinais diferentes.</strong>{" "}
          A base de um scraper mostra onde o perfil foi encontrado. Coincidir
          com um novo seguidor não comprova o motivo do follow. Um total
          atribuído a anúncios também não identifica os @perfis. Os relatórios
          disponíveis em Insights podem trazer totais oficiais já coletados;
          essa leitura não fornece listas de seguidores nem atribuição
          individual.
        </p>
      </div>
      <div className="acquisition-controls">
        <Field label="Medição para analisar origens">
          <select
            value={s?.id || ""}
            onChange={(e) => {
              setSnapshotId(e.target.value);
              setBaselineId("");
              setPage(1);
            }}
            disabled={!s}
          >
            {!s ? (
              <option value="">Importe listas de seguidores primeiro</option>
            ) : (
              [...(account.relationships?.snapshots || [])]
                .reverse()
                .map((item) => (
                  <option key={item.id} value={item.id}>
                    {date(item.at)} ·{" "}
                    {item.followersComplete
                      ? "seguidores completos"
                      : "seguidores parciais"}
                  </option>
                ))
            )}
          </select>
        </Field>
        <Field label="Recorte de seguidores para origens">
          <select
            value={scope}
            onChange={(e) => {
              setScope(e.target.value as Scope);
              setPage(1);
            }}
          >
            <option value="auto">
              Automático ·{" "}
              {history.comparable
                ? "novos entre medições"
                : "observados na medição"}
            </option>
            <option value="new">Novos entre duas medições completas</option>
            <option value="current">Todos os observados na medição</option>
          </select>
        </Field>
        <Field label="Base para identificar novos seguidores">
          <select
            value={baselineId}
            onChange={(e) => {
              setBaselineId(e.target.value);
              setPage(1);
            }}
          >
            <option value="">Automático · completa anterior</option>
            {[...analysis.older].reverse().map((item) => (
              <option key={item.id} value={item.id}>
                {date(item.at)}
              </option>
            ))}
          </select>
        </Field>
      </div>
      {s ? (
        <p className="acquisition-context">
          <strong>
            {resolvedScope === "new"
              ? `Ausentes em ${previous ? date(previous.at) : "uma base completa"}; presentes em ${date(s.at)}`
              : `Seguidores observados em ${date(s.at)}`}
          </strong>
          {!s.followersComplete
            ? " · lista parcial: cobre somente os nomes informados"
            : " · lista de seguidores declarada completa"}
          {s.note ? <span>{s.note}</span> : null}
        </p>
      ) : null}
      <AccountDataStatus account={account} area="acquisition" />
      {outsideOrigins.length ? (
        <section
          className="account-data-records"
          aria-label="Origens registradas fora do recorte"
        >
          <h3>
            {number(outsideOrigins.length)}{" "}
            {outsideOrigins.length === 1
              ? "classificação já registrada"
              : "classificações já registradas"}{" "}
            fora deste recorte
          </h3>
          <p>
            Estes registros pertencem a @{account.username}. Sem uma presença
            observada na lista selecionada, não entram na contagem de seguidores
            acima. Ausência em coleta parcial não comprova que deixaram de
            seguir.
          </p>
          <details open={!s || undefined}>
            <summary>Revisar classificações disponíveis</summary>
            <div className="table-scroll">
              <table>
                <thead>
                  <tr>
                    <th>PERFIL</th>
                    <th>ORIGEM INFORMADA</th>
                    <th>EVIDÊNCIA / FONTE</th>
                    <th>ÚLTIMO REGISTRO</th>
                    <th />
                  </tr>
                </thead>
                <tbody>
                  {outsideOrigins.slice(0, 50).map((row) => (
                    <tr key={row.username}>
                      <td>@{row.username}</td>
                      <td>{ACQUISITION_CHANNELS[row.channel]}</td>
                      <td>
                        {ORIGIN_EVIDENCE[row.evidence]} ·{" "}
                        {row.sourceLabel || "Fonte não informada"}
                      </td>
                      <td>{date(row.updatedAt)}</td>
                      <td>
                        <button
                          className="text-link"
                          disabled={busy}
                          onClick={() =>
                            setEditing({ username: row.username, origin: row })
                          }
                        >
                          Revisar origem
                        </button>
                      </td>
                    </tr>
                  ))}
                </tbody>
              </table>
            </div>
            {outsideOrigins.length > 50 ? (
              <p>
                Mostrando os primeiros 50 registros. Os demais continuam
                preservados no backup desta conta.
              </p>
            ) : null}
          </details>
        </section>
      ) : null}
      <div className="acquisition-cards">
        {(Object.keys(ACQUISITION_CHANNELS) as AcquisitionChannel[]).map(
          (key) => (
            <button
              key={key}
              className={channel === key ? "selected" : ""}
              onClick={() => {
                setChannel(channel === key ? "all" : key);
                setPage(1);
              }}
              aria-pressed={channel === key}
            >
              <span>
                {key === "unknown"
                  ? "Sem origem informada"
                  : key === "prospecting"
                    ? "Prospecção informada"
                    : `${ACQUISITION_CHANNELS[key]} informado`}
              </span>
              <strong>
                {analysis.available ? number(analysis.counts[key]) : "—"}
              </strong>
              <small>
                {key === "unknown"
                  ? "Não é presumido como orgânico"
                  : "Classificação individual declarada"}
              </small>
            </button>
          ),
        )}
      </div>
      {!analysis.available ? (
        <Empty
          icon={<Target />}
          title={
            !s
              ? "Comece pelas suas listas de seguidores"
              : "Ainda não temos uma coorte completa de novos seguidores"
          }
          text={
            !s
              ? "Importe as listas em Seguidores e seguidos. Depois associe evidências e consulte possíveis fontes de prospecção."
              : "Para identificar novos @perfis, precisamos de duas medições completas. Você também pode selecionar todos os observados para revisar a lista disponível."
          }
          action={
            <button className="button secondary" onClick={onRelationships}>
              Abrir seguidores e seguidos
            </button>
          }
        />
      ) : (
        <>
          <div className="acquisition-association-summary">
            <strong>
              {number(analysis.associated)} de {number(analysis.rows.length)}{" "}
              @perfis deste recorte encontrados em bases de prospecção
            </strong>
            <p>
              Uma pessoa pode constar em várias fontes e também ter visto um
              anúncio ou uma publicação. As associações ficam separadas das
              classificações informadas e não são somadas como canais
              exclusivos.
            </p>
          </div>
          {analysis.sources.length ? (
            <section
              className="acquisition-sources"
              aria-label="Fontes de prospecção associadas"
            >
              <h3>Bases que coincidem com seus seguidores</h3>
              <div className="table-scroll">
                <table>
                  <thead>
                    <tr>
                      <th>FONTE CADASTRADA</th>
                      <th>ALVO</th>
                      <th>@PERFIS ENCONTRADOS</th>
                      <th>PROSPECÇÃO INFORMADA</th>
                    </tr>
                  </thead>
                  <tbody>
                    {analysis.sources.map((item) => (
                      <tr key={item.campaignId}>
                        <td>{item.name}</td>
                        <td>{item.target || "Fonte antiga"}</td>
                        <td>{number(item.matches)}</td>
                        <td>{number(item.informed)}</td>
                      </tr>
                    ))}
                  </tbody>
                </table>
              </div>
              <p className="insights-note">
                As fontes podem se sobrepor. “Prospecção informada” vem da sua
                classificação; “encontrados” vem dos registros de
                captura/importação anteriores à medição final. Nenhuma coluna
                comprova causalidade.
              </p>
            </section>
          ) : null}
          <div className="growth-heading">
            <div>
              <h3>Origem por @perfil</h3>
              <p>
                Veja a evidência, a fonte encontrada e o que ainda está
                desconhecido.
              </p>
            </div>
            <button
              className="button secondary"
              disabled={!filtered.length}
              onClick={() =>
                download(
                  `orbita-${account.username}-origens.json`,
                  JSON.stringify(
                    {
                      account: account.username,
                      snapshotId: s?.id,
                      baselineId: previous?.id,
                      scope: resolvedScope,
                      channelFilter: channel,
                      sourceFilter: effectiveSource,
                      query,
                      counts: analysis.counts,
                      associated: analysis.associated,
                      sources: analysis.sources,
                      rows: filtered,
                      aggregateReports: account.acquisition?.reports || [],
                      insightTotals: insightTotals.map((r) => ({
                        id: r.id,
                        start: r.start,
                        end: r.end,
                        coverage: r.coverage,
                        follows: r.metrics.follows,
                        source: r.source,
                        recordedAt: r.recordedAt,
                      })),
                      note: "Classificações manuais atuais e associações observadas; sem comprovação automática da origem individual. Totais agregados não são somados às pessoas.",
                    },
                    null,
                    2,
                  ),
                  "application/json",
                )
              }
            >
              <Download size={15} />
              Exportar análise de origens
            </button>
          </div>
          <div className="acquisition-filters">
            <Field label="Buscar seguidor por origem">
              <input
                value={query}
                onChange={(e) => {
                  setQuery(e.target.value);
                  setPage(1);
                }}
                placeholder="@perfil"
              />
            </Field>
            <Field label="Filtrar canal informado">
              <select
                value={channel}
                onChange={(e) => {
                  setChannel(e.target.value as AcquisitionChannel | "all");
                  setPage(1);
                }}
              >
                <option value="all">Todos os canais informados</option>
                {Object.entries(ACQUISITION_CHANNELS).map(([key, label]) => (
                  <option key={key} value={key}>
                    {label}
                  </option>
                ))}
              </select>
            </Field>
            <Field label="Filtrar fonte de prospecção associada">
              <select
                value={effectiveSource}
                onChange={(e) => {
                  setSource(e.target.value);
                  setPage(1);
                }}
              >
                <option value="all">Todas as fontes</option>
                <option value="none">Sem associação encontrada</option>
                {associatedSources.map((item) => (
                  <option key={item.campaignId} value={item.campaignId}>
                    {item.name}
                  </option>
                ))}
              </select>
            </Field>
          </div>
          {filtered.length ? (
            <div className="table-scroll acquisition-followers">
              <table>
                <thead>
                  <tr>
                    <th>SEGUIDOR OBSERVADO</th>
                    <th>ORIGEM INFORMADA</th>
                    <th>FONTES / ASSOCIAÇÕES</th>
                    <th>REVISAR</th>
                  </tr>
                </thead>
                <tbody>
                  {visible.map((row) => (
                    <tr key={row.username}>
                      <td>
                        <div className="relationship-profile">
                          <Avatar username={row.username} />
                          <a
                            href={`https://www.instagram.com/${row.username}/`}
                            target="_blank"
                            rel="noreferrer"
                          >
                            @{row.username} ↗
                          </a>
                        </div>
                        <small>
                          {row.alreadyInBaseline
                            ? "Já constava na medição base"
                            : resolvedScope === "new"
                              ? "Ausente na base; observado na final"
                              : "Presente na lista selecionada"}
                        </small>
                      </td>
                      <td>
                        <span
                          className={`origin-badge ${row.origin?.channel || "unknown"}`}
                        >
                          {
                            ACQUISITION_CHANNELS[
                              row.origin?.channel || "unknown"
                            ]
                          }
                        </span>
                        {row.origin && row.origin.channel !== "unknown" ? (
                          <>
                            <strong>{row.origin.sourceLabel}</strong>
                            <small>
                              {ORIGIN_EVIDENCE[row.origin.evidence]} · informada
                              em {date(row.origin.updatedAt)}
                            </small>
                            {row.origin.note ? <p>{row.origin.note}</p> : null}
                          </>
                        ) : (
                          <small>Sem evidência individual informada.</small>
                        )}
                      </td>
                      <td>
                        {row.associations.length ? (
                          row.associations.map((item) => (
                            <div
                              className="origin-association"
                              key={item.campaignId}
                            >
                              <strong>{item.name}</strong>
                              <small>
                                {SOURCE_LABELS[
                                  item.kind as keyof typeof SOURCE_LABELS
                                ] || "Fonte"}{" "}
                                · {item.target}
                              </small>
                              <small>
                                Registrado em {date(item.capturedAt)} ·{" "}
                                {item.timing === "within_interval"
                                  ? "dentro do intervalo; ordem do follow desconhecida"
                                  : item.timing === "before_interval"
                                    ? "antes do intervalo"
                                    : "antes da medição final; ordem do follow desconhecida"}
                              </small>
                            </div>
                          ))
                        ) : (
                          <small>
                            Nenhuma fonte correspondente nos registros
                            disponíveis até esta medição.
                          </small>
                        )}
                        {row.outboundAction ? (
                          <small className="origin-outbound">
                            Ação de saída da Órbita:{" "}
                            {row.outboundAction.kind === "followed"
                              ? "Seguindo confirmado"
                              : "solicitação enviada"}{" "}
                            em {date(row.outboundAction.at)}. Não confirma a
                            origem do seguidor recebido.
                          </small>
                        ) : null}
                      </td>
                      <td>
                        <button
                          className="text-link"
                          disabled={busy}
                          aria-label={`Informar origem de @${row.username}`}
                          onClick={() =>
                            setEditing({
                              username: row.username,
                              origin: row.origin,
                            })
                          }
                        >
                          {row.origin && row.origin.channel !== "unknown"
                            ? "Editar origem"
                            : "Informar origem"}
                        </button>
                      </td>
                    </tr>
                  ))}
                </tbody>
              </table>
            </div>
          ) : (
            <Empty
              title="Nenhum seguidor neste filtro"
              text="Confira a busca, o canal informado e a fonte selecionada."
            />
          )}
          <div className="relationship-pagination">
            <span>
              {number(filtered.length)} perfis no filtro · página {currentPage}{" "}
              de {pages}. Exportação inclui todo o filtro.
            </span>
            <button
              className="button secondary"
              disabled={currentPage <= 1}
              onClick={() => setPage(currentPage - 1)}
            >
              Anterior
            </button>
            <button
              className="button secondary"
              disabled={currentPage >= pages}
              onClick={() => setPage(currentPage + 1)}
            >
              Próxima
            </button>
          </div>
        </>
      )}
      <section
        className="acquisition-aggregates"
        aria-label="Resultados agregados por canal"
      >
        <div className="growth-heading">
          <div>
            <h3>Totais informados em relatórios de canal</h3>
            <p>
              Campanhas de anúncios e recortes orgânicos, com período e regra
              próprios.
            </p>
          </div>
          <button
            className="button secondary"
            disabled={!account.username || busy}
            onClick={() => setReporting(true)}
          >
            <Plus size={15} />
            Registrar resultado de canal
          </button>
        </div>
        <p className="insights-note">
          Copie seguidores atribuídos somente se essa métrica estiver disponível
          no relatório consultado. Os valores abaixo não identificam pessoas,
          podem ter janelas diferentes e não são somados. Orgânico não é
          calculado pela sobra de total menos anúncios ou scraper.
        </p>
        {account.acquisition?.reports.length ? (
          <div className="table-scroll">
            <table>
              <thead>
                <tr>
                  <th>CANAL / CAMPANHA</th>
                  <th>PERÍODO</th>
                  <th>SEGUIDORES ATRIBUÍDOS</th>
                  <th>REGRA / JANELA INFORMADA</th>
                  <th>REGISTRO</th>
                  <th />
                </tr>
              </thead>
              <tbody>
                {[...account.acquisition.reports].reverse().map((row) => (
                  <tr key={row.id}>
                    <td>
                      <strong>{row.name}</strong>
                      <small>{ACQUISITION_CHANNELS[row.channel]}</small>
                      {row.note ? <p>{row.note}</p> : null}
                    </td>
                    <td>
                      {row.start} a {row.end}
                    </td>
                    <td>{number(row.followers)}</td>
                    <td>{row.attributionWindow}</td>
                    <td>Manual · {date(row.recordedAt)}</td>
                    <td>
                      <button
                        className="icon-button"
                        aria-label={`Remover resultado de ${row.name}`}
                        disabled={busy}
                        onClick={() => setRemoving(row)}
                      >
                        <Trash2 size={15} />
                      </button>
                    </td>
                  </tr>
                ))}
              </tbody>
            </table>
          </div>
        ) : (
          <p className="acquisition-no-reports">
            Nenhum resultado de canal registrado. A ausência de um relatório não
            significa zero seguidores vindos de anúncios.
          </p>
        )}
        {insightTotals.length ? (
          <details className="growth-group-details">
            <summary>
              Ver contagens já informadas nos Insights · {insightTotals.length}{" "}
              relatórios
            </summary>
            <div className="table-scroll">
              <table>
                <thead>
                  <tr>
                    <th>PERÍODO</th>
                    <th>COBERTURA DECLARADA</th>
                    <th>FOLLOWS INFORMADO</th>
                    <th>ORIGEM DO RELATÓRIO</th>
                  </tr>
                </thead>
                <tbody>
                  {insightTotals.map((row) => (
                    <tr key={row.id}>
                      <td>
                        {row.start} a {row.end}
                      </td>
                      <td>
                        {
                          {
                            paid: "Pago",
                            organic: "Orgânico",
                            combined: "Orgânico e pago combinados",
                            unknown: "Distribuição não informada",
                          }[row.coverage]
                        }
                      </td>
                      <td>{number(row.metrics.follows)}</td>
                      <td>
                        {row.source === "file"
                          ? "Arquivo importado"
                          : "Registro manual"}
                      </td>
                    </tr>
                  ))}
                </tbody>
              </table>
            </div>
          </details>
        ) : null}
      </section>
      <p className="acquisition-footer">
        Classificações manuais atuais são aplicadas ao recorte escolhido, sem
        reconstituir o que você sabia naquela data. As associações usam
        @username e registros anteriores à medição final; mudanças de nome podem
        parecer entrada de outro perfil. Ter visto anúncio, seguido pela Órbita
        ou aparecido numa fonte não prova a causa do follow.
      </p>
      {editing ? (
        <OriginModal
          account={account}
          data={editing}
          run={run}
          busy={busy}
          onClose={() => setEditing(null)}
        />
      ) : null}
      {reporting ? (
        <ChannelResultModal
          account={account.username!}
          run={run}
          busy={busy}
          onClose={() => setReporting(false)}
        />
      ) : null}
      {importing ? (
        <OriginImport
          account={account}
          run={run}
          busy={busy}
          onClose={() => setImporting(false)}
        />
      ) : null}
      {removing ? (
        <Modal
          title="Remover resultado agregado?"
          subtitle={removing.name}
          onClose={() => setRemoving(null)}
        >
          <p className="acquisition-footer">
            A remoção afeta este resultado manual. As classificações individuais
            e as listas de seguidores continuam salvas.
          </p>
          <div className="modal-actions">
            <button
              className="button secondary"
              onClick={() => setRemoving(null)}
            >
              Cancelar
            </button>
            <button
              className="button primary"
              disabled={busy}
              onClick={async () => {
                if (
                  await run(
                    { type: "REMOVE_CHANNEL_RESULT", id: removing.id },
                    "Resultado agregado removido.",
                  )
                )
                  setRemoving(null);
              }}
            >
              Remover resultado
            </button>
          </div>
        </Modal>
      ) : null}
    </section>
  );
}
function OriginModal({
  account,
  data,
  run,
  busy,
  onClose,
}: {
  account: AccountWorkspace;
  data: { username: string; origin?: FollowerOrigin };
  run: Run;
  busy: boolean;
  onClose: () => void;
}) {
  const [username, setUsername] = useState(data.username),
    [channel, setChannel] = useState<AcquisitionChannel>(
      data.origin?.channel || "unknown",
    ),
    [label, setLabel] = useState(data.origin?.sourceLabel || ""),
    [campaignId, setCampaignId] = useState(
      account.data.campaigns.some((c) => c.id === data.origin?.campaignId)
        ? data.origin?.campaignId || ""
        : "",
    );
  const [evidence, setEvidence] = useState<OriginEvidence>(
      data.origin?.evidence || "manual",
    ),
    [note, setNote] = useState(data.origin?.note || ""),
    [error, setError] = useState("");
  return (
    <Modal
      title="Informar origem do seguidor"
      subtitle={`@${account.username} · classificação declarada, sem verificação automática da Meta`}
      onClose={onClose}
    >
      <form
        onSubmit={async (e) => {
          e.preventDefault();
          setError("");
          if (
            await run(
              {
                type: "SET_FOLLOWER_ORIGIN",
                data: {
                  account: account.username,
                  username,
                  channel,
                  sourceLabel: channel === "unknown" ? "" : label,
                  campaignId:
                    channel === "prospecting"
                      ? campaignId || undefined
                      : undefined,
                  evidence,
                  note,
                },
              },
              "Origem informada salva nesta conta.",
            )
          )
            onClose();
        }}
      >
        <Field label="@seguidor para classificar">
          <input
            required
            readOnly={!!data.username}
            value={username}
            onChange={(e) => setUsername(e.target.value)}
            placeholder="@perfil"
          />
        </Field>
        <Field label="Canal informado do seguidor">
          <select
            value={channel}
            onChange={(e) => setChannel(e.target.value as AcquisitionChannel)}
          >
            {Object.entries(ACQUISITION_CHANNELS).map(([key, value]) => (
              <option key={key} value={key}>
                {value}
              </option>
            ))}
          </select>
        </Field>
        {channel === "prospecting" ? (
          <Field label="Campanha de prospecção desta conta">
            <select
              value={campaignId}
              onChange={(e) => {
                setCampaignId(e.target.value);
                const c = account.data.campaigns.find(
                  (c) => c.id === e.target.value,
                );
                if (c) setLabel(`${c.name} · ${c.target}`.slice(0, 150));
              }}
            >
              <option value="">Sem vínculo a campanha cadastrada</option>
              {account.data.campaigns.map((c) => (
                <option key={c.id} value={c.id}>
                  {c.name} · {c.target}
                </option>
              ))}
            </select>
          </Field>
        ) : null}
        {channel !== "unknown" ? (
          <>
            <Field label="Nome ou descrição da origem">
              <input
                required
                maxLength={150}
                value={label}
                onChange={(e) => setLabel(e.target.value)}
                placeholder={
                  channel === "paid"
                    ? "Ex.: nome da campanha de anúncio"
                    : channel === "organic"
                      ? "Ex.: Reel, busca ou indicação informada"
                      : "Ex.: seguidores do perfil de referência"
                }
              />
            </Field>
            <Field label="Como você sabe a origem?">
              <select
                value={evidence}
                onChange={(e) => setEvidence(e.target.value as OriginEvidence)}
              >
                {Object.entries(ORIGIN_EVIDENCE).map(([key, value]) => (
                  <option key={key} value={key}>
                    {value}
                  </option>
                ))}
              </select>
            </Field>
          </>
        ) : (
          <p className="insights-note">
            Origem desconhecida não é orgânico. Ao salvar, uma classificação
            anterior deste @perfil será substituída; as associações observadas
            continuam visíveis.
          </p>
        )}
        <Field label="Evidência ou observação da origem">
          <textarea
            rows={4}
            maxLength={500}
            value={note}
            onChange={(e) => setNote(e.target.value)}
            placeholder="Ex.: pessoa informou que chegou pelo anúncio; registro no atendimento"
          />
        </Field>
        <p className="acquisition-footer">
          Escolha apenas o que sua evidência permite afirmar. Encontrar o perfil
          em uma lista ou ter seguido essa pessoa não comprova a origem. Salvar
          substitui a classificação individual atual.
        </p>
        {error ? (
          <div className="notice error" role="alert">
            {error}
          </div>
        ) : null}
        <div className="modal-actions">
          <button className="button secondary" type="button" onClick={onClose}>
            Cancelar
          </button>
          <button className="button primary" disabled={busy}>
            Salvar origem informada
          </button>
        </div>
      </form>
    </Modal>
  );
}
function ChannelResultModal({
  account,
  run,
  busy,
  onClose,
}: {
  account: string;
  run: Run;
  busy: boolean;
  onClose: () => void;
}) {
  const [channel, setChannel] = useState<"paid" | "organic">("paid"),
    [name, setName] = useState(""),
    [start, setStart] = useState(localDay()),
    [end, setEnd] = useState(localDay()),
    [followers, setFollowers] = useState(""),
    [window, setWindow] = useState(""),
    [note, setNote] = useState(""),
    [error, setError] = useState("");
  return (
    <Modal
      title="Registrar resultado agregado de canal"
      subtitle={`@${account} · número copiado do relatório, sem identificação de @perfis`}
      onClose={onClose}
    >
      <form
        onSubmit={async (e) => {
          e.preventDefault();
          setError("");
          if (followers === "") {
            setError(
              "Informe a contagem observada. Deixe de registrar quando desconhecida.",
            );
            return;
          }
          if (
            await run(
              {
                type: "RECORD_CHANNEL_RESULT",
                data: {
                  account,
                  channel,
                  name,
                  start,
                  end,
                  followers: Number(followers),
                  attributionWindow: window,
                  note,
                },
              },
              "Resultado agregado registrado separadamente das pessoas.",
            )
          )
            onClose();
        }}
      >
        <div className="form-grid">
          <Field label="Canal do resultado agregado">
            <select
              value={channel}
              onChange={(e) => setChannel(e.target.value as "paid" | "organic")}
            >
              <option value="paid">Anúncio</option>
              <option value="organic">Orgânico</option>
            </select>
          </Field>
          <Field label="Campanha ou conteúdo do relatório">
            <input
              required
              maxLength={150}
              value={name}
              onChange={(e) => setName(e.target.value)}
            />
          </Field>
          <Field label="Início do resultado de canal">
            <input
              required
              type="date"
              max={end}
              value={start}
              onChange={(e) => setStart(e.target.value)}
            />
          </Field>
          <Field label="Fim do resultado de canal">
            <input
              required
              type="date"
              min={start}
              max={localDay()}
              value={end}
              onChange={(e) => setEnd(e.target.value)}
            />
          </Field>
          <Field label="Seguidores atribuídos informados no relatório">
            <input
              required
              type="number"
              min="0"
              step="1"
              value={followers}
              onChange={(e) => setFollowers(e.target.value)}
              placeholder="Não informado"
            />
          </Field>
          <Field label="Regra ou janela de atribuição consultada">
            <input
              required
              maxLength={150}
              value={window}
              onChange={(e) => setWindow(e.target.value)}
              placeholder="Copie a regra exibida; indique se não informada"
            />
          </Field>
        </div>
        <Field label="Observação do resultado agregado">
          <textarea
            rows={3}
            maxLength={500}
            value={note}
            onChange={(e) => setNote(e.target.value)}
            placeholder="Fonte do relatório e observações sobre o recorte"
          />
        </Field>
        <p className="acquisition-footer">
          Registre só quando o dado estiver disponível na origem. Este total não
          será distribuído entre nomes nem subtraído do crescimento para inferir
          orgânico.
        </p>
        {error ? (
          <div className="notice error" role="alert">
            {error}
          </div>
        ) : null}
        <div className="modal-actions">
          <button className="button secondary" type="button" onClick={onClose}>
            Cancelar
          </button>
          <button className="button primary" disabled={busy}>
            Salvar resultado de canal
          </button>
        </div>
      </form>
    </Modal>
  );
}
function OriginImport({
  account,
  run,
  busy,
  onClose,
}: {
  account: AccountWorkspace;
  run: Run;
  busy: boolean;
  onClose: () => void;
}) {
  const [preview, setPreview] = useState<{
      data: unknown;
      rows: FollowerOrigin[];
    } | null>(null),
    [error, setError] = useState(""),
    [reading, setReading] = useState(false);
  return (
    <Modal
      title="Importar origens informadas"
      subtitle={`@${account.username} · CSV/JSON no modelo Órbita, até 5 MB`}
      onClose={onClose}
      wide
    >
      <p className="acquisition-footer">
        Importe classificações individuais que você já possui, com @perfil e
        evidência. Um CSV de anúncio com totais não revela os nomes dos
        seguidores. Arquivos de outra conta são rejeitados.
      </p>
      <div className="metrics-actions">
        <button
          className="button secondary"
          onClick={() =>
            download(
              "orbita-modelo-origens.csv",
              `account,username,channel,source_label,evidence,campaign_id,note\r\n${account.username},,,,,,`,
              "text/csv;charset=utf-8",
            )
          }
        >
          Modelo CSV de origens
        </button>
        <button
          className="button secondary"
          onClick={() =>
            download(
              "orbita-modelo-origens.json",
              JSON.stringify(
                { account: account.username, assignments: [] },
                null,
                2,
              ),
              "application/json",
            )
          }
        >
          Modelo JSON de origens
        </button>
      </div>
      <Field label="Arquivo de origens individuais">
        <input
          type="file"
          accept=".json,.csv"
          disabled={reading || busy}
          onChange={async (e) => {
            const file = e.target.files?.[0];
            setPreview(null);
            setError("");
            if (!file) return;
            setReading(true);
            try {
              if (file.size > 5_000_000) throw new Error("Use até 5 MB.");
              const raw = parseFollowerOrigins(await file.text());
              setFollowerOrigins(account, raw);
              const inputs = Array.isArray(raw) ? raw : [raw];
              setPreview({
                data: raw,
                rows: inputs.map((row) => validateFollowerOrigin(row, account)),
              });
            } catch (err) {
              setError(
                err instanceof Error
                  ? err.message
                  : "Não foi possível importar.",
              );
            } finally {
              setReading(false);
            }
          }}
        />
      </Field>
      <details className="growth-group-details">
        <summary>Campos e valores do modelo</summary>
        <p className="acquisition-footer">
          account, username, channel, source_label, evidence; opcionais
          campaign_id e note. channel: organic, paid, prospecting ou unknown.
          evidence: manual, self_report ou tracking. No JSON, use sourceLabel e
          campaignId. O ID da campanha de prospecção deve pertencer a esta
          conta. Datas de atualização são registradas ao salvar.
        </p>
      </details>
      {preview ? (
        <div className="relationship-preview" role="status">
          <strong>
            {preview.rows.length} classificações individuais válidas
          </strong>
          <p>
            {Object.entries(ACQUISITION_CHANNELS)
              .map(
                ([key, label]) =>
                  `${label}: ${preview.rows.filter((r) => r.channel === key).length}`,
              )
              .join(" · ")}
          </p>
          <p>
            Salvar substitui as classificações atuais dos @perfis presentes
            neste arquivo.
          </p>
        </div>
      ) : null}
      {error ? (
        <div className="notice error" role="alert">
          {error}
        </div>
      ) : null}
      <div className="modal-actions">
        <button className="button secondary" onClick={onClose}>
          Cancelar
        </button>
        <button
          className="button primary"
          disabled={!preview || reading || busy}
          onClick={async () => {
            if (
              preview &&
              (await run(
                { type: "IMPORT_FOLLOWER_ORIGINS", data: preview.data },
                "Origens individuais importadas nesta conta.",
              ))
            )
              onClose();
          }}
        >
          Importar classificações de origem
        </button>
      </div>
    </Modal>
  );
}
