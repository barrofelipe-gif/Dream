import { useRef, useState } from "react";
import { AccountDataStatus } from "./AccountDataStatus.tsx";
import { dispatch, isExtension, readOwnRelationships } from "../bridge.ts";
import {
  Download,
  FileUp,
  Heart,
  Plus,
  ShieldCheck,
  Trash2,
  UsersRound,
  ScanLine,
} from "lucide-react";
import type {
  AccountCommand,
  AccountWorkspace,
  RelationshipProtection,
  RelationshipSnapshot,
  ProtectionReason,
  OwnRelationshipReading,
} from "../core/types.ts";
import {
  PROTECTION_REASONS,
  parseRelationshipList,
  relationshipAnalysis,
  relationshipNames,
  relationshipUsername,
  ownRelationshipMeasurement,
} from "../core/relationships.ts";
import { download } from "../core/io.ts";
import { Avatar, Empty, Field, Modal } from "./components.tsx";
type Run = (command: AccountCommand, success?: string) => Promise<boolean>;
type Tab =
  "followers" | "following" | "notBack" | "lost" | "mutual" | "protected";
const LABELS: Record<Tab, string> = {
  followers: "Seus seguidores",
  following: "Você segue",
  notBack: "Não seguem de volta",
  lost: "Saíram da lista",
  mutual: "Mútuos",
  protected: "Protegidos",
};
const number = (n?: number) =>
  n === undefined ? "—" : n.toLocaleString("pt-BR");
const date = (iso: string) =>
  new Date(iso).toLocaleString("pt-BR", {
    dateStyle: "short",
    timeStyle: "short",
  });
const localInput = (d = new Date()) =>
  `${d.getFullYear()}-${String(d.getMonth() + 1).padStart(2, "0")}-${String(d.getDate()).padStart(2, "0")}T${String(d.getHours()).padStart(2, "0")}:${String(d.getMinutes()).padStart(2, "0")}`;
const csvCell = (value: string) =>
  `"${(/^[\s]*[=+\-@]/.test(value) ? "'" : "") + value.replaceAll('"', '""')}"`;
export function RelationshipsPage({
  account,
  run,
  busy,
}: {
  account: AccountWorkspace;
  run: Run;
  busy: boolean;
}) {
  const [selected, setSelected] = useState(""),
    [baseline, setBaseline] = useState(""),
    [tab, setTab] = useState<Tab>("followers");
  const [query, setQuery] = useState(""),
    [hideProtected, setHideProtected] = useState(true),
    [page, setPage] = useState(1);
  const [importing, setImporting] = useState(false),
    [protecting, setProtecting] = useState<{
      username: string;
      existing?: RelationshipProtection;
    } | null>(null),
    [removing, setRemoving] = useState(false),
    [collecting, setCollecting] = useState(false);
  const analysis = relationshipAnalysis(
      account.relationships,
      selected,
      baseline || undefined,
    ),
    s = analysis.current;
  const protections = new Map(analysis.protections.map((p) => [p.username, p]));
  const candidates =
    tab === "followers"
      ? s?.followers
      : tab === "following"
        ? s?.following
        : tab === "notBack"
          ? analysis.notFollowingBack
          : tab === "lost"
            ? analysis.lost
            : tab === "mutual"
              ? analysis.mutual
              : analysis.protections.map((p) => p.username).sort();
  const rows = (candidates || []).filter(
    (n) =>
      n.includes(query.trim().replace(/^@/, "").toLowerCase()) &&
      (!hideProtected ||
        tab === "protected" ||
        tab === "mutual" ||
        !protections.has(n)),
  );
  const pages = Math.max(1, Math.ceil(rows.length / 50)),
    currentPage = Math.min(page, pages),
    visible = rows.slice((currentPage - 1) * 50, currentPage * 50);
  const changeTab = (next: Tab) => {
    setTab(next);
    setPage(1);
  };
  const counts: Record<Tab, number | undefined> = {
    followers: s?.followers.length,
    following: s?.following.length,
    notBack: analysis.notFollowingBack?.length,
    lost: analysis.lost?.length,
    mutual: s ? analysis.mutual.length : undefined,
    protected: analysis.protections.length,
  };
  return (
    <section
      className="relationships-page"
      aria-label="Seguidores e seguidos da conta"
    >
      <div className="growth-heading">
        <div>
          <span className="eyebrow">
            RELAÇÕES DE @{account.username || "SEU PERFIL"}
          </span>
          <h2>Quem está na sua rede</h2>
          <p>
            Confira reciprocidade e mudanças entre listas. Mantenha amigos e
            perfis importantes protegidos.
          </p>
        </div>
        <div className="metrics-actions">
          <button
            className="button primary"
            disabled={!account.username || busy}
            onClick={() => setCollecting(true)}
          >
            <ScanLine size={15} />
            Ler minha rede
          </button>
          <button
            className="button secondary"
            disabled={!account.username || busy}
            onClick={() => setProtecting({ username: "" })}
          >
            <Heart size={15} />
            Proteger perfil
          </button>
          <button
            className="button primary"
            disabled={!account.username || busy}
            onClick={() => setImporting(true)}
          >
            <FileUp size={15} />
            Importar medição
          </button>
        </div>
      </div>
      <p className="relationships-intro">
        Análise local das suas listas, inclusive em conta pessoal. Os dados são
        lidos da página carregada, importados ou informados por você. Cada
        leitura é uma medição e não acompanha mudanças em tempo real. A revisão
        para deixar de seguir fica no Ciclo de prospecção; nenhuma ação é
        iniciada por esta análise.
      </p>
      <AccountDataStatus account={account} area="network" />
      <div className="relationship-cards">
        {(["notBack", "lost", "mutual", "protected"] as Tab[]).map((key) => (
          <button
            key={key}
            className={tab === key ? "selected" : ""}
            onClick={() => changeTab(key)}
            aria-pressed={tab === key}
          >
            <span>{LABELS[key]}</span>
            <strong>{number(counts[key])}</strong>
            <small>
              {key === "protected"
                ? "Amigos e perfis que você quer manter"
                : key === "lost"
                  ? "Entre duas listas completas"
                  : key === "notBack"
                    ? "Nos seguidos desta medição"
                    : "Presença nas duas listas"}
            </small>
          </button>
        ))}
      </div>
      {s ? (
        <>
          <div className="relationship-history">
            <Field label="Medição de seguidores e seguidos">
              <select
                value={s.id}
                onChange={(e) => {
                  setSelected(e.target.value);
                  setBaseline("");
                  setPage(1);
                }}
              >
                {[...(account.relationships?.snapshots || [])]
                  .reverse()
                  .map((item) => (
                    <option key={item.id} value={item.id}>
                      {date(item.at)} ·{" "}
                      {item.followersComplete && item.followingComplete
                        ? "declarada completa"
                        : "com lista parcial"}
                    </option>
                  ))}
              </select>
            </Field>
            <Field label="Comparar seguidores com">
              <select
                value={baseline}
                onChange={(e) => {
                  setBaseline(e.target.value);
                  setPage(1);
                }}
              >
                <option value="">Automático · medição completa anterior</option>
                {[...analysis.older].reverse().map((item) => (
                  <option key={item.id} value={item.id}>
                    {date(item.at)}
                  </option>
                ))}
              </select>
            </Field>
            <button
              className="icon-button"
              aria-label="Exportar medição de relações selecionada"
              onClick={() =>
                download(
                  `orbita-${account.username}-relacoes.json`,
                  JSON.stringify(
                    { type: "orbita-connections-snapshot", snapshot: s },
                    null,
                    2,
                  ),
                  "application/json",
                )
              }
            >
              <Download size={17} />
            </button>
            <button
              className="icon-button"
              aria-label="Remover medição de relações selecionada"
              disabled={busy}
              onClick={() => setRemoving(true)}
            >
              <Trash2 size={17} />
            </button>
          </div>
          <div className="relationship-context">
            <strong>Dados de {date(s.at)}</strong>
            <span>
              {number(s.followers.length)} seguidores ·{" "}
              {s.followersComplete
                ? "lista declarada completa"
                : "lista parcial"}
            </span>
            <span>
              {number(s.following.length)} seguidos ·{" "}
              {s.followingComplete
                ? "lista declarada completa"
                : "lista parcial"}
            </span>
            <span>
              {s.source === "file" ? "Arquivo local" : "Registro manual"} ·
              registrado em {date(s.recordedAt)}
            </span>
            {s.note ? <p>{s.note}</p> : null}
          </div>
          {tab === "lost" && analysis.comparable ? (
            <div className="relationship-explanation">
              <strong>
                Presentes em {date(analysis.previous!.at)}, ausentes em{" "}
                {date(s.at)}.
              </strong>
              <p>
                Isso indica que esses @perfis saíram da lista observada. Troca
                de nome, desativação, bloqueio ou remoção também podem explicar
                a diferença. Não identificamos o motivo nem a hora exata.
              </p>
            </div>
          ) : null}
          {tab === "notBack" && s.followersComplete ? (
            <p className="insights-note">
              Esses perfis aparecem entre quem você segue e não aparecem na
              lista completa de seguidores informada para esta medição.
              {!s.followingComplete
                ? " Como os seguidos estão parciais, o resultado cobre apenas os perfis informados."
                : ""}{" "}
              Compare sempre listas do mesmo levantamento.
            </p>
          ) : null}
        </>
      ) : null}
      <div className="relationship-list-heading">
        <div role="group" aria-label="Listas de relações">
          {(Object.keys(LABELS) as Tab[]).map((key) => (
            <button
              className={tab === key ? "selected" : ""}
              aria-pressed={tab === key}
              key={key}
              onClick={() => changeTab(key)}
            >
              {LABELS[key]}
            </button>
          ))}
        </div>
        <button
          className="button secondary"
          disabled={!rows.length}
          onClick={() => {
            const data = [
              [
                "username",
                "grupo",
                "protegido",
                "motivo",
                "observacao",
                "medicao",
                "base",
              ],
              ...rows.map((n) => {
                const p = protections.get(n);
                return [
                  n,
                  LABELS[tab],
                  p ? "sim" : "nao",
                  p ? PROTECTION_REASONS[p.reason] : "",
                  p?.note || "",
                  s?.at || "",
                  tab === "lost" ? analysis.previous?.at || "" : "",
                ];
              }),
            ];
            download(
              `orbita-${account.username}-revisao-relacoes.csv`,
              "\uFEFF" +
                data.map((row) => row.map(csvCell).join(",")).join("\r\n"),
              "text/csv;charset=utf-8",
            );
          }}
        >
          <Download size={15} />
          Exportar revisão
        </button>
      </div>
      <div className="relationship-filters">
        <Field label="Buscar @perfil nas relações">
          <input
            value={query}
            onChange={(e) => {
              setQuery(e.target.value);
              setPage(1);
            }}
            placeholder="Digite o @perfil"
          />
        </Field>
        {tab === "notBack" || tab === "lost" ? (
          <label className="relationship-check">
            <input
              type="checkbox"
              checked={hideProtected}
              onChange={(e) => {
                setHideProtected(e.target.checked);
                setPage(1);
              }}
            />
            Ocultar perfis protegidos nesta revisão
          </label>
        ) : null}
      </div>
      {candidates === undefined ? (
        <Empty
          icon={<UsersRound />}
          title={
            !s
              ? "Comece com suas listas de seguidores e seguidos"
              : tab === "lost"
                ? "Precisamos de duas medições completas de seguidores"
                : "A lista de seguidores precisa estar completa"
          }
          text={
            !s
              ? "Leia os nomes carregados da sua própria rede ou importe as listas do Instagram. A primeira medição será a base das próximas comparações."
              : tab === "lost"
                ? "Importe outro levantamento completo em uma data posterior. Uma primeira lista ou uma coleta parcial não identifica quem saiu."
                : "Ausência em uma lista parcial não comprova que a pessoa não segue você."
          }
          action={
            <button
              className="button primary"
              disabled={!account.username || busy}
              onClick={() => (s ? setImporting(true) : setCollecting(true))}
            >
              {s ? "Importar medição completa" : "Ler minha rede"}
            </button>
          }
        />
      ) : rows.length ? (
        <>
          <p className="insights-note">
            {number(rows.length)} perfis no filtro · {number(candidates.length)}{" "}
            nesta lista antes dos filtros. Proteções são escolhas suas e não
            alteram os dados observados.
          </p>
          <div className="table-scroll relationship-table">
            <table>
              <thead>
                <tr>
                  <th>PERFIL</th>
                  <th>SUA ESCOLHA</th>
                  <th>OBSERVAÇÃO</th>
                  <th>REVISAR</th>
                </tr>
              </thead>
              <tbody>
                {visible.map((name) => {
                  const p = protections.get(name);
                  return (
                    <tr key={name}>
                      <td>
                        <div className="relationship-profile">
                          <Avatar username={name} />
                          <a
                            href={`https://www.instagram.com/${name}/`}
                            target="_blank"
                            rel="noreferrer"
                          >
                            @{name} ↗
                          </a>
                        </div>
                      </td>
                      <td>
                        {p ? (
                          <span className="relationship-protected">
                            <ShieldCheck size={14} />
                            {PROTECTION_REASONS[p.reason]}
                          </span>
                        ) : (
                          "Sem proteção informada"
                        )}
                      </td>
                      <td>{p?.note || "—"}</td>
                      <td>
                        <button
                          className="text-link"
                          disabled={busy}
                          aria-label={`${p ? "Editar proteção de" : "Proteger"} @${name}`}
                          onClick={() =>
                            setProtecting({ username: name, existing: p })
                          }
                        >
                          {p ? "Editar proteção" : "Proteger / manter"}
                        </button>
                      </td>
                    </tr>
                  );
                })}
              </tbody>
            </table>
          </div>
          <div className="relationship-pagination">
            <span>
              Página {currentPage} de {pages} · até 50 perfis por página. A
              exportação inclui todo o filtro.
            </span>
            <button
              className="button secondary"
              disabled={currentPage <= 1}
              onClick={() => setPage(currentPage - 1)}
            >
              Anterior
            </button>
            <button
              className="button secondary"
              disabled={currentPage >= pages}
              onClick={() => setPage(currentPage + 1)}
            >
              Próxima
            </button>
          </div>
        </>
      ) : (
        <Empty
          icon={<ShieldCheck />}
          title={
            tab === "protected"
              ? "Nenhum perfil protegido neste filtro"
              : tab === "followers" || tab === "following"
                ? "Nenhum nome observado neste filtro"
                : "Nenhum perfil para revisar neste filtro"
          }
          text={
            tab === "followers" || tab === "following"
              ? "Confira a busca. Uma coleta parcial mostra somente nomes carregados; zero nomes observados não significa uma rede vazia. Leia mais nomes na extensão ou importe as listas do Instagram."
              : "Confira a busca e a opção de ocultar protegidos. Você pode manter um perfil mesmo sem reciprocidade."
          }
        />
      )}
      <p className="relationships-intro">
        A correspondência usa @username, sem identificação numérica. Uma troca
        de nome pode parecer saída e entrada de perfis diferentes. Os arquivos
        nativos nem sempre identificam a conta proprietária: a origem e a
        completude são conferidas e declaradas por você. Suas listas e proteções
        ficam separadas por conta e entram no backup.
      </p>
      {importing && account.username ? (
        <RelationshipImport
          account={account.username}
          busy={busy}
          run={run}
          onClose={() => setImporting(false)}
          onSaved={() => {
            setSelected("");
            setBaseline("");
            setPage(1);
          }}
        />
      ) : null}
      {collecting && account.username ? (
        <OwnRelationshipsModal
          key={account.id}
          account={account}
          busy={busy}
          run={run}
          onClose={() => setCollecting(false)}
          onSaved={() => {
            setSelected("");
            setBaseline("");
            setTab("followers");
            setPage(1);
          }}
          onImport={() => {
            setCollecting(false);
            setImporting(true);
          }}
        />
      ) : null}
      {protecting ? (
        <ProtectionModal
          data={protecting}
          busy={busy}
          run={run}
          onClose={() => setProtecting(null)}
        />
      ) : null}
      {removing && s ? (
        <Modal
          title="Remover esta medição?"
          subtitle={`@${account.username} · ${date(s.at)}`}
          onClose={() => setRemoving(false)}
        >
          <p className="relationships-intro">
            Esta medição sairá do histórico e as comparações disponíveis podem
            mudar. Seus perfis protegidos continuam salvos. Exporte a medição ou
            o backup antes de removê-la se quiser guardá-la.
          </p>
          <div className="modal-actions">
            <button
              className="button secondary"
              onClick={() => setRemoving(false)}
            >
              Cancelar
            </button>
            <button
              className="button primary"
              disabled={busy}
              onClick={async () => {
                if (
                  await run(
                    { type: "REMOVE_RELATIONSHIP_SNAPSHOT", id: s.id },
                    "Medição removida. Proteções preservadas.",
                  )
                ) {
                  setRemoving(false);
                  setSelected("");
                  setBaseline("");
                }
              }}
            >
              Remover medição
            </button>
          </div>
        </Modal>
      ) : null}
    </section>
  );
}

function OwnRelationshipsModal({
  account,
  run,
  busy,
  onClose,
  onSaved,
  onImport,
}: {
  account: AccountWorkspace;
  run: Run;
  busy: boolean;
  onClose: () => void;
  onSaved: () => void;
  onImport: () => void;
}) {
  const [readings, setReadings] = useState<
    Partial<Record<"followers" | "following", OwnRelationshipReading>>
  >({});
  const [opened, setOpened] = useState<"followers" | "following" | null>(null);
  const [working, setWorking] = useState("");
  const [error, setError] = useState("");
  const [confirmed, setConfirmed] = useState(false);
  const lock = useRef(false);
  const username = account.username!;
  async function collect(
    kind: "followers" | "following",
    operation: "open" | "read",
  ) {
    if (lock.current || busy || !isExtension) return;
    lock.current = true;
    setWorking(`${operation}:${kind}`);
    setError("");
    setConfirmed(false);
    try {
      if (operation === "open") {
        await dispatch({ type: "OPEN_OWN_RELATIONSHIPS", kind }, account.id);
        setOpened(kind);
      } else {
        setReadings((old) =>
          kind === "followers" ? {} : { followers: old.followers },
        );
        const result = await readOwnRelationships(account.id, kind);
        if (
          result.account !== username ||
          result.kind !== kind ||
          result.complete !== false
        )
          throw new Error(
            "A leitura não pertence à lista e à conta selecionadas.",
          );
        const usernames = relationshipNames(result.usernames);
        if (usernames.includes(username))
          throw new Error(
            "Sua própria conta apareceu na lista. Confira o diálogo aberto antes de ler novamente.",
          );
        setReadings((old) => ({ ...old, [kind]: { ...result, usernames } }));
      }
    } catch (e) {
      setError(
        e instanceof Error ? e.message : "Não foi possível ler esta lista.",
      );
    } finally {
      lock.current = false;
      setWorking("");
    }
  }
  async function save() {
    if (
      lock.current ||
      busy ||
      !confirmed ||
      !readings.followers ||
      !readings.following
    )
      return;
    lock.current = true;
    setWorking("save");
    setError("");
    try {
      const data = ownRelationshipMeasurement(
        username,
        readings.followers,
        readings.following,
      );
      if (
        await run(
          { type: "RECORD_RELATIONSHIPS", data },
          "Nomes carregados registrados como medição parcial desta conta.",
        )
      ) {
        onSaved();
        onClose();
      }
    } catch (e) {
      setError(
        e instanceof Error
          ? e.message
          : "Não foi possível salvar esta medição.",
      );
    } finally {
      lock.current = false;
      setWorking("");
    }
  }
  return (
    <Modal
      title={`Ler minha rede · @${username}`}
      subtitle="Leitura dos nomes já carregados nas suas listas. Nada é seguido ou removido."
      onClose={onClose}
      wide
    >
      <p className="relationships-intro">
        Conecte esta conta na extensão. Abra uma lista, role o quanto quiser no
        Instagram e volte ao painel para ler os nomes carregados. Depois repita
        na outra lista. O sistema não rola nem percorre todos os seguidores
        automaticamente.
      </p>
      {!isExtension ? (
        <div className="account-data-records">
          <h3>Abra este painel pela extensão instalada</h3>
          <p>
            O painel web não acessa a sessão do Instagram. Na extensão, conecte
            @{username} e abra Seguidores e seguidos. Você também pode importar
            o arquivo de relações do Instagram agora.
          </p>
          <button className="button secondary" onClick={onImport}>
            Importar arquivos do Instagram
          </button>
        </div>
      ) : null}
      <div className="relationship-collection-steps">
        {(["followers", "following"] as const).map((kind, i) => {
          const reading = readings[kind];
          const blocked =
            !!working ||
            busy ||
            !isExtension ||
            (kind === "following" && !readings.followers);
          return (
            <section
              key={kind}
              aria-label={`Ler ${kind === "followers" ? "seguidores" : "seguidos"}`}
            >
              <h3>
                {i + 1}.{" "}
                {kind === "followers" ? "Seus seguidores" : "Quem você segue"}
              </h3>
              <p>
                {kind === "followers"
                  ? "Leia a lista Seguidores da sua conta."
                  : "Depois dos seguidores, leia a lista Seguindo da mesma conta."}
              </p>
              <div className="relationship-collection-actions">
                <button
                  className="button secondary"
                  disabled={blocked}
                  onClick={() => void collect(kind, "open")}
                >
                  {working === `open:${kind}`
                    ? "Abrindo…"
                    : "Abrir minha lista"}
                </button>
                <button
                  className="button primary"
                  disabled={blocked || opened !== kind}
                  onClick={() => void collect(kind, "read")}
                >
                  {working === `read:${kind}`
                    ? "Lendo…"
                    : "Ler nomes carregados"}
                </button>
              </div>
              {reading ? (
                <div className="relationship-collection-preview">
                  <strong>
                    {number(reading.usernames.length)} nomes observados · lista
                    parcial
                  </strong>
                  <p>{date(reading.at)}</p>
                  <p>
                    {reading.usernames
                      .slice(0, 40)
                      .map((n) => `@${n}`)
                      .join(", ") ||
                      "Nenhum nome identificado nesta leitura. Isso não significa que sua lista esteja vazia."}
                    {reading.usernames.length > 40
                      ? ` · e mais ${number(reading.usernames.length - 40)} nomes na prévia completa.`
                      : ""}
                  </p>
                </div>
              ) : (
                <p>
                  Aguardando leitura · nenhum número de seguidores é usado para
                  preencher nomes.
                </p>
              )}
            </section>
          );
        })}
      </div>
      <p className="relationships-intro">
        <strong>Esta medição será sempre parcial.</strong> Perfis que aparecem
        nas duas listas podem ser reconhecidos como mútuos. Quem não aparece
        pode simplesmente não ter sido carregado; esta leitura não identifica
        quem deixou de seguir ou quem não segue de volta.
      </p>
      <label className="relationship-check">
        <input
          type="checkbox"
          checked={confirmed}
          disabled={
            !readings.followers || !readings.following || !!working || busy
          }
          onChange={(e) => setConfirmed(e.target.checked)}
        />
        Conferi as duas listas de @{username} e quero salvar somente estes nomes
        como uma medição parcial.
      </label>
      {error ? (
        <p className="form-error" role="alert">
          {error}
        </p>
      ) : null}
      <div className="modal-actions">
        <button
          className="button secondary"
          onClick={onImport}
          disabled={!!working || busy}
        >
          Importar listas completas
        </button>
        <button
          className="button primary"
          disabled={
            !confirmed ||
            !readings.followers ||
            !readings.following ||
            !!working ||
            busy
          }
          onClick={() => void save()}
        >
          {working === "save" ? "Salvando…" : "Salvar medição parcial"}
        </button>
      </div>
    </Modal>
  );
}

function RelationshipImport({
  account,
  busy,
  run,
  onClose,
  onSaved,
}: {
  account: string;
  busy: boolean;
  run: Run;
  onClose: () => void;
  onSaved: () => void;
}) {
  const [at, setAt] = useState(() => localInput()),
    [note, setNote] = useState("");
  const [followers, setFollowers] = useState(""),
    [following, setFollowing] = useState("");
  const [files, setFiles] = useState<{ followers: File[]; following: File[] }>({
    followers: [],
    following: [],
  });
  const [complete, setComplete] = useState({
      followers: false,
      following: false,
    }),
    [confirmed, setConfirmed] = useState(false);
  const [error, setError] = useState(""),
    [preview, setPreview] = useState<{
      followers: string[];
      following: string[];
      duplicates: number;
    } | null>(null),
    [reading, setReading] = useState(false);
  const invalidate = () => {
    setPreview(null);
    setError("");
  };
  async function readLists() {
    setError("");
    setPreview(null);
    setReading(true);
    try {
      const all = [...files.followers, ...files.following];
      if (
        all.length > 50 ||
        all.reduce((n, f) => n + f.size, 0) > 20_000_000 ||
        all.some(
          (f) => f.size > 5_000_000 || !/\.(json|txt|csv)$/i.test(f.name),
        )
      )
        throw new Error(
          "Use até 50 arquivos JSON/TXT/CSV, 5 MB por arquivo e 20 MB no total. Selecione somente as listas de conexões, sem ZIP ou HTML.",
        );
      const result = {
        followers: [] as string[],
        following: [] as string[],
        duplicates: 0,
      };
      for (const kind of ["followers", "following"] as const) {
        const typed = kind === "followers" ? followers : following;
        if (!files[kind].length && !typed.trim())
          throw new Error(
            `Informe a lista de ${kind === "followers" ? "seguidores" : "seguidos"}. Para uma lista realmente vazia, use [] em JSON.`,
          );
        if (files[kind].length && typed.trim())
          throw new Error(
            "Use arquivos ou texto em cada lista, sem misturar os dois modos no mesmo campo.",
          );
        const names: string[] = [];
        const entries = files[kind].length
          ? await Promise.all(
              files[kind].map(async (f) => ({
                text: await f.text(),
                name: f.name,
              })),
            )
          : [{ text: typed, name: "" }];
        for (const entry of entries) {
          const parsed = parseRelationshipList(
            entry.text,
            kind,
            account,
            entry.name,
          );
          names.push(...parsed.names);
          result.duplicates += parsed.duplicates;
        }
        const unique = relationshipNames(names);
        result.duplicates += names.length - unique.length;
        result[kind] = unique;
      }
      setPreview(result);
    } catch (e) {
      setError(
        e instanceof Error ? e.message : "Não foi possível ler as listas.",
      );
    } finally {
      setReading(false);
    }
  }
  return (
    <Modal
      title={`Importar relações · @${account}`}
      subtitle="Uma medição das suas listas, com data e origem conferidas."
      onClose={onClose}
      wide
    >
      <form
        onSubmit={async (e) => {
          e.preventDefault();
          setError("");
          if (!preview || !confirmed) return;
          try {
            const success = await run(
              {
                type: "RECORD_RELATIONSHIPS",
                data: {
                  account,
                  at: new Date(at).toISOString(),
                  source:
                    files.followers.length || files.following.length
                      ? "file"
                      : "manual",
                  followers: preview.followers,
                  following: preview.following,
                  followersComplete: complete.followers,
                  followingComplete: complete.following,
                  note,
                },
              },
              "Medição de relações registrada nesta conta.",
            );
            if (success) {
              onSaved();
              onClose();
            }
          } catch (e) {
            setError(
              e instanceof Error ? e.message : "Não foi possível salvar.",
            );
          }
        }}
      >
        <p className="relationships-intro">
          Na Central de Contas do Instagram, procure exportar suas informações,
          selecione esta conta e as listas de seguidores/seguidos em JSON, com
          todo o período disponível. Descompacte no computador e selecione
          somente esses arquivos aqui. O nome do caminho pode variar na Meta.{" "}
          <a
            href="https://about.fb.com/news/2023/10/manage-your-information-across-apps/"
            target="_blank"
            rel="noreferrer"
          >
            Orientação da Meta ↗
          </a>
        </p>
        <Field
          label="Data e hora do levantamento"
          hint={`Quando as listas foram observadas ou o arquivo foi gerado, não quando cada pessoa começou a seguir. Fuso do navegador: ${Intl.DateTimeFormat().resolvedOptions().timeZone}.`}
        >
          <input
            required
            type="datetime-local"
            value={at}
            max={localInput()}
            onChange={(e) => setAt(e.target.value)}
          />
        </Field>
        <div className="relationship-import-columns">
          {(["followers", "following"] as const).map((kind) => (
            <section key={kind}>
              <h3>
                {kind === "followers" ? "Quem segue você" : "Quem você segue"}
              </h3>
              <Field
                label={
                  kind === "followers"
                    ? "Arquivos de seguidores"
                    : "Arquivos de seguidos"
                }
                hint={
                  kind === "followers"
                    ? "Inclua todos os followers_1.json, followers_2.json etc. do mesmo levantamento. Em CSV, use uma coluna com cabeçalho username."
                    : "Ex.: following.json do mesmo levantamento. Em CSV, use uma coluna com cabeçalho username."
                }
              >
                <input
                  type="file"
                  multiple
                  accept=".json,.txt,.csv"
                  disabled={reading}
                  onChange={(e) => {
                    setFiles({
                      ...files,
                      [kind]: Array.from(e.target.files || []),
                    });
                    invalidate();
                  }}
                />
              </Field>
              <Field
                label={
                  kind === "followers"
                    ? "Ou informe seguidores em texto"
                    : "Ou informe seguidos em texto"
                }
                hint="Um @perfil ou link por linha, sem cabeçalho; também aceita uma lista JSON. Uma lista vazia deve ser []."
              >
                <textarea
                  rows={5}
                  disabled={reading}
                  value={kind === "followers" ? followers : following}
                  onChange={(e) => {
                    if (kind === "followers") setFollowers(e.target.value);
                    else setFollowing(e.target.value);
                    invalidate();
                  }}
                />
              </Field>
              <label className="relationship-check">
                <input
                  type="checkbox"
                  checked={complete[kind]}
                  onChange={(e) =>
                    setComplete({ ...complete, [kind]: e.target.checked })
                  }
                />
                Declaro a lista de{" "}
                {kind === "followers" ? "seguidores" : "seguidos"} completa,
                incluindo todas as partes e todo o período
              </label>
            </section>
          ))}
        </div>
        <p className="insights-note">
          Deixe “completa” desmarcado se trouxe apenas perfis carregados na tela
          ou uma seleção. Ausência em lista parcial não comprova falta de
          reciprocidade nem perda de seguidor.
        </p>
        <Field label="Observação da medição">
          <input
            maxLength={500}
            value={note}
            onChange={(e) => setNote(e.target.value)}
            placeholder="Ex.: exportação completa de novembro"
          />
        </Field>
        <button
          className="button secondary"
          type="button"
          disabled={reading || busy}
          onClick={() => void readLists()}
        >
          {reading ? "Conferindo listas…" : "Conferir listas"}
        </button>
        {preview ? (
          <div className="relationship-preview" role="status">
            <strong>
              {number(preview.followers.length)} seguidores ·{" "}
              {number(preview.following.length)} seguidos
            </strong>
            <p>
              {preview.duplicates} repetições normalizadas. Nenhuma linha
              inválida foi descartada. Limite de 20.000 perfis por lista.
            </p>
            <p>
              Amostra de seguidores:{" "}
              {preview.followers
                .slice(0, 3)
                .map((n) => `@${n}`)
                .join(", ") || "lista explicitamente vazia"}
              . Amostra de seguidos:{" "}
              {preview.following
                .slice(0, 3)
                .map((n) => `@${n}`)
                .join(", ") || "lista explicitamente vazia"}
              .
            </p>
          </div>
        ) : null}
        <label className="relationship-check">
          <input
            required
            type="checkbox"
            checked={confirmed}
            onChange={(e) => setConfirmed(e.target.checked)}
          />
          Conferi que as duas listas pertencem a @{account}, vêm do mesmo
          levantamento e correspondem à data informada
        </label>
        {error ? (
          <div className="notice error" role="alert">
            {error}
          </div>
        ) : null}
        <div className="modal-actions">
          <button className="button secondary" type="button" onClick={onClose}>
            Cancelar
          </button>
          <button
            className="button primary"
            disabled={busy || reading || !preview || !confirmed}
          >
            Salvar medição de relações
          </button>
        </div>
      </form>
    </Modal>
  );
}
function ProtectionModal({
  data,
  busy,
  run,
  onClose,
}: {
  data: { username: string; existing?: RelationshipProtection };
  busy: boolean;
  run: Run;
  onClose: () => void;
}) {
  const [username, setUsername] = useState(data.username),
    [reason, setReason] = useState<ProtectionReason>(
      data.existing?.reason || "friend",
    ),
    [note, setNote] = useState(data.existing?.note || ""),
    [error, setError] = useState("");
  return (
    <Modal
      title={
        data.existing ? "Editar perfil protegido" : "Proteger e manter perfil"
      }
      subtitle="Uma escolha pessoal, independente de seguir você de volta."
      onClose={onClose}
    >
      <form
        onSubmit={async (e) => {
          e.preventDefault();
          setError("");
          try {
            const name = relationshipUsername(username);
            if (
              await run(
                { type: "PROTECT_RELATIONSHIP", username: name, reason, note },
                "Perfil protegido nesta conta.",
              )
            )
              onClose();
          } catch (e) {
            setError(
              e instanceof Error ? e.message : "Não foi possível proteger.",
            );
          }
        }}
      >
        <Field label="@perfil para manter">
          <input
            required
            maxLength={100}
            readOnly={!!data.username}
            value={username}
            onChange={(e) => setUsername(e.target.value)}
            placeholder="@amigo.ou.perfil"
          />
        </Field>
        <Field label="Motivo da proteção">
          <select
            value={reason}
            onChange={(e) => setReason(e.target.value as ProtectionReason)}
          >
            {Object.entries(PROTECTION_REASONS).map(([key, label]) => (
              <option key={key} value={key}>
                {label}
              </option>
            ))}
          </select>
        </Field>
        <Field label="Anotação sobre o perfil">
          <textarea
            maxLength={500}
            rows={3}
            value={note}
            onChange={(e) => setNote(e.target.value)}
            placeholder="Ex.: amigo de infância; manter mesmo sem seguir de volta"
          />
        </Field>
        <p className="relationships-intro">
          O perfil fica oculto por padrão nas revisões de falta de reciprocidade
          e de saídas, e aparece na lista Protegidos. Você pode revogar ou
          editar esta escolha depois.
        </p>
        {error ? (
          <div className="notice error" role="alert">
            {error}
          </div>
        ) : null}
        <div className="modal-actions">
          {data.existing ? (
            <button
              type="button"
              className="button secondary"
              disabled={busy}
              onClick={async () => {
                if (
                  await run(
                    { type: "UNPROTECT_RELATIONSHIP", username: data.username },
                    "Proteção removida nesta conta.",
                  )
                )
                  onClose();
              }}
            >
              Remover proteção
            </button>
          ) : null}
          <button className="button secondary" type="button" onClick={onClose}>
            Cancelar
          </button>
          <button className="button primary" disabled={busy}>
            <ShieldCheck size={15} />
            Salvar proteção
          </button>
        </div>
      </form>
    </Modal>
  );
}
