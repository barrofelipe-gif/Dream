import { trustedHostedPage } from "./core/hosted.ts";
import { hostedSessionMatches } from "./core/hosted-session.ts";
import { withDeadline } from "./extension/page-channel.ts";

/** One pending authorization read per page scope; completed checks are never cached. */
export function createHostedSessionCheck(scope: string | null | undefined) {
  let pending: Promise<void> | undefined;
  return (): Promise<void> => {
    if (pending) return pending;
    const controller = new AbortController();
    const current = withDeadline(
      async () => {
        const response = await fetch("/api/growth/orbita/session", {
          credentials: "same-origin",
          cache: "no-store",
          redirect: "manual",
          signal: controller.signal,
        });
        if (
          !response.ok ||
          response.type === "opaqueredirect" ||
          !hostedSessionMatches(await response.json(), scope)
        )
          throw new Error(
            "Sua sessão do app não está disponível. Entre novamente para continuar.",
          );
      },
      Date.now() + 10000,
      "conferência da sessão do app",
    ).finally(() => {
      controller.abort();
      if (pending === current) pending = undefined;
    });
    pending = current;
    return current;
  };
}

export async function verifyHostedActor(signal?: AbortSignal): Promise<void> {
  if (typeof location === "undefined" || !trustedHostedPage(location.href))
    return;
  const scope = document
    .querySelector('meta[name="orbita-user"]')
    ?.getAttribute("content");
  const deadline = AbortSignal.timeout(10000);
  const requestSignal = signal ? AbortSignal.any([signal, deadline]) : deadline;
  try {
    const response = await fetch("/api/growth/orbita/session", {
      credentials: "same-origin",
      cache: "no-store",
      redirect: "manual",
      signal: requestSignal,
    });
    if (
      !response.ok ||
      response.type === "opaqueredirect" ||
      !hostedSessionMatches(await response.json(), scope)
    )
      throw new Error(
        "O usuário do app mudou ou a sessão expirou. Reabra a Órbita antes de salvar dados.",
      );
    if (requestSignal.aborted)
      throw new Error("Operação cancelada antes de salvar dados.");
  } catch (error) {
    if (!signal?.aborted)
      window.dispatchEvent(
        new CustomEvent("orbita-transport-error", {
          detail: "Sessão do app indisponível.",
        }),
      );
    throw error;
  }
}
