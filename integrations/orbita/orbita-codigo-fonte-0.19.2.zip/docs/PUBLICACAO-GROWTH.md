# Publicação no Growth

## Atualização 0.18.1 — 03/11/2026

Patch do leitor do Radar para a barra plana de ícones e números da publicação. O vínculo entre ícone e contador é conferido sem somar números de comentários, sugestões ou outras ações; valores abreviados/ambíguos continuam desconhecidos. A validação do DOM real foi somente de leitura. Não há novos comandos, permissões ou mudanças nos controles da fila.

O aviso normal de teto diário atingido deixou de ser registrado como falha da interface. O marcador se limita ao aviso identificado de teto diário; falhas reais, orçamento e aviso pendente do Instagram continuam na captura. Duas regressões reproduziram a classificação incorreta antes do ajuste e passaram depois.

Suíte integrada final: 375 aprovados, zero falhas, e compilação concluída (`output/test-v0181.log` e `output/build-v0181.log`). O journal final inclui ORB-040 e ORB-041. O mínimo permanece 0.18.0, inclusive nas mensagens de conexão: a extensão 0.18.0 continua aceita e a atualização do leitor para 0.18.1 é opcional. Os artefatos 0.18.0 foram preservados.

## Atualização 0.18.0 — 03/11/2026

A versão acrescenta capas no ranking, lista e detalhe das publicações, com fallback para imagem ausente/expirada. A reimportação do mesmo relatório enriquece somente as capas sem duplicar a medição nem reescrever ID, data e métricas. Campanhas por perfil agrupam três fontes; a leitura da própria rede mantém as medições sempre parciais. Os estados sem dados mostram as medições necessárias, sem inventar resultados ou origens.

A leitura do estado Seguindo foi ajustada para separar o controle do perfil dos botões de sugestões no cabeçalho. A conferência explícita de um resultado incerto é somente de leitura, registra o estado observado e preserva tentativas e fila pausada. Essa observação não comprova o clique anterior nem habilita deixar de seguir. Somente uma observação nativa de Não seguindo da mesma conta pode permitir a devolução manual à revisão, com confirmação explícita; Seguindo e Solicitado não permitem esse retorno.

Suíte integrada: 371 aprovados, zero falhas; TypeScript/Vite/esbuild concluídos, conforme `output/test-v0180.log` e `output/build-v0180.log`. O adaptador de capas aprovou 14 testes. A QA de miniaturas no navegador descartável verificou imagem carregada, ausência, falha e renovação de URL; não houve overflow da página em 390 px. Dados, logs, imagens de QA, perfis descartáveis e credenciais não acompanham os pacotes. O journal final registra ORB-036 a ORB-039.

As novas operações exigem extensão 0.18.0 ou posterior. As permissões foram preservadas. A validação do clique de deixar de seguir continua limitada ao DOM fictício; o acompanhamento da sessão real é realizado separadamente pelo coordenador. A consulta secundária ao Claude para o leitor do radar expirou sem parecer; não foi tratada como revisão concluída.

## Atualização 0.17.0 — 03/11/2026

O ciclo de prospecção acrescenta revisão por prazo e reciprocidade, com escolha explícita dos perfis para deixar de seguir. A configuração começa desativada, sem prazo ou política presumidos. A fila e a confirmação de início distinguem seguir e deixar de seguir; as duas ações compartilham os controles existentes. O painel exige extensão 0.17.0 ou posterior e o worker confere a seleção exata de IDs/ações antes de iniciar unfollow.

A suíte final aprovou 331 testes e a compilação TypeScript/Vite/esbuild passou. Duas regressões determinísticas comprovaram a correção do timer adiantado: o solicitante agora aguarda o mesmo prazo absoluto conferido pelo relay, sem retransmitir a operação, e limpa o timer reagendado ao encerrar. Evidências locais: `output/test-v0170.log`, `output/build-v0170.log` e `output/hosted-deadline-early-{before,after}-v0170.log`.

A jornada no Chrome isolado usou somente DOM e contas fictícias: configuração de 7 dias/revisar todos; protegidos e históricos restaurados não selecionáveis; revisão da fila e START; exatamente um clique mutativo fictício; uma tentativa; um evento de deixar de seguir e nenhum de seguir; prova preservada; tokens limpos e modo pausado. A tela de 390 px não apresentou overflow da página. Evidências locais: `output/playwright/v0170/ui-qa-confirmed.log` e capturas desktop/mobile. Nenhuma relação real do Instagram foi alterada; o clique de deixar de seguir em perfil real continua sem validação. Esses dados e perfis descartáveis não acompanham os pacotes.

Foi solicitada uma segunda opinião do Claude Code para o ciclo. O processo expirou após cinco minutos sem retornar parecer; nenhuma conclusão foi presumida.

## Publicação inicial 0.15.0

Destino autorizado pelo usuário em 03/11/2026: app BFF, Growth → Instagram → Crescimento · Órbita. Projeto existente Vercel `bff-painel-pendencias`, equipe `felipe-461d`, repositório `barrofelipe-gif/Dream`. Integração preparada em worktree isolado a partir do commit publicado `09d7a6eea085c827ca66b8680f0f80e594f36a9d`, preservando alterações de Telegram não publicadas em outro checkout.

O painel e seu download são protegidos pelo login de administrador do app. O modo manual usa armazenamento por usuário/navegador; o modo conectado usa diretamente o cadastro local da extensão. Não há nova tabela, variável de ambiente, armazenamento de senha ou envio de listas ao servidor. O teste real no Instagram continua dependendo da instalação e sessão do usuário; nenhuma ação de seguir foi executada nesta validação.

## Segunda opinião e decisões

O Claude Code recebeu seis arquivos de implementação, sem credenciais, por meio do script local autorizado. A resposta foi lida. Foram incorporados: tratamento do redirecionamento de login e respostas inválidas, recusa de escopo ausente no modo hospedado, tratamento de falha na abertura, avisos de invalidação sem `oldValue/newValue` e maior restrição ao contexto nativo.

Divergências verificadas: o import de `main.tsx` está incluído no bundle único do esbuild, sem chunk externo; os arquivos privados têm inclusão explícita no tracing do Next, confirmada no manifesto compilado. Não foi adicionada abertura genérica de caminhos para contornar a allowlist. O manifest não tem `externally_connectable`; o worker confere remetente/rota e as validações de conta/sessão já existentes. Não duplicamos cookies ou tokens do login do app na extensão. A hipótese de expor a extensão diretamente com uma alteração futura no manifest não foi tratada como falha presente.

O teste encontrou que os eventos de storage não chegam ao content script, porque o cadastro está em `TRUSTED_CONTEXTS`. A proteção foi mantida. A interface recebe avisos após mensagens confirmadas e consulta somente o estado local para atualizar; uma leitura periódica visível cobre alterações do painel nativo e alarmes. Isso não repete mutações nem acessa o Instagram.

## Evidências locais

- Suíte da Órbita: `output/test-v0150.log`.
- Compilação TypeScript/Vite/esbuild: `output/build-v0150.log`.
- Extensão instalada em Chrome descartável, dentro de iframe com CSP: `output/hosting/native-connect-verified.log`.
- Gravação e atualização ao vivo da medição; recusa de sessão 403 sem criar conta: `output/hosting/native-write-verified.log`.
- Preservação de aviso, três tentativas e modo pausado; bloqueio por redirecionamento para login: `output/hosting/final-qa.log`.
- Isolamento de dois usuários no modo manual, sem chave global e tela de 390 px: `output/hosting/final-qa.log`.

As evidências de navegador usam uma conta fictícia, HTML de integração e sessão do app simulada. Não equivalem à validação de coleta/execução em contas reais. Os dados fictícios não estão incluídos nos pacotes de produção.

## Entrada final no app

A área Growth → Instagram → Crescimento · Órbita oferece a entrada para o painel completo em `/api/growth/orbita/painel`, no mesmo domínio e com o mesmo login, com link **Voltar ao Growth**. A entrada atual não depende de iframe. Na conferência em produção, a versão incorporada ficava em `about:blank` em certas recargas. Montagem no cliente e carregamento imediato não resolveram a recarga observada; a causa exata não foi isolada. O fluxo por rota própria já abriu repetidamente com o login de administrador e foi escolhido para a entrada final. A decisão remove a dependência da incorporação, sem afirmar que sua causa foi corrigida.

O pacote 0.15.0 foi baixado pela própria interface autenticada para `C:/Users/PC/Downloads/orbita-0.15.0.zip`: 593.860 bytes, SHA-256 BF3BD1BABABB93B4688EAC9BD682EC2697AF18A93363DAC1343C86E230398F0C. O arquivo corresponde ao artefato publicado e seu manifest informa 0.15.0. Não foi instalado no perfil real do usuário pelo agente.

Foram cadastrados os dois @ informados no modo manual do Chrome do usuário, com espaços separados, sem medições fictícias. A execução continua dependente da extensão e da confirmação da sessão correspondente. Os cadastros locais do modo manual e da extensão são armazenamentos distintos.
