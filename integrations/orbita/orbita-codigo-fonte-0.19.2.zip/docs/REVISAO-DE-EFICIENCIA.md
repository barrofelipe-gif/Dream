# Segunda opinião e revisão de eficiência

Consulta ao Claude Code realizada em 03/11/2026 pelo script autorizado `Consultar-Claude.ps1`. Foram enviados somente a pergunta técnica e `src/extension/background.ts`, sem credenciais, listas ou histórico da conta. A resposta foi recebida e lida; o revisor não executou testes. Resultado integral local: `output/claude-efficiency-review.txt`.

## Achado confirmado

O prazo de 18 segundos de `loaded()` limitava apenas o laço. Um `STATUS`, `tabs.get` ou `executeScript` pendente podia impedir a próxima verificação do relógio e a liberação de `runnerActive`. A reprodução isolada da revisão local manteve um STATUS sem resposta pendente após 20 segundos virtuais. Isso comprova uma falha de encerramento, sem comprovar por que uma aba real ficou na página inicial.

A correção adotada limita as esperas, preserva uma única entrega das ações e distingue o estágio da falha. Expirar uma leitura não autoriza repetir uma importação ou um clique. O resultado tardio de uma operação enviada pode continuar desconhecido.

## Sugestões conferidas e divergências

- **Reinjeção:** o catch anterior permitia reinjetar por qualquer rejeição. Restringir ao erro explícito de receptor inexistente e limitar a uma inicialização por preparação é útil. A hipótese de listeners duplicados, porém, já é contida pelo marcador global de `content.ts`.
- **Lock por conta:** não adotado. O executor global acompanha a única sessão Instagram do perfil do Chrome; permitir execuções paralelas entre contas sem sessões isoladas poderia provocar disputa. O defeito confirmado é a espera sem prazo que impede liberar esse lock.
- **Recuperação após reinício:** `account-store.ts` já chama `recoverInterrupted` em `storeReady`, além de `onStartup`. A hipótese de recuperação apenas no startup do navegador não se aplica ao projeto completo.
- **Orçamento:** `audit("attempt", ...)` atualiza os contadores em `core/domain.ts`. A ausência de incremento explícito em `background.ts` não é defeito de contagem.
- **Watchdog de alarme:** não introduzido como tentativa automática de recuperação. O catch da fila pausa e limpa o agendamento, e a retomada permanece explícita. Uma hipótese sobre alarme concorrente não justifica reenviar operações ou iniciar outro candidato automaticamente.

## Limites

Esta consulta sustenta a correção de uma falha concreta de espera. Ela não demonstra compatibilidade com todo layout do Instagram, estabilidade superior aos concorrentes ou crescimento comercial. As provas de regressão, build e jornada serão registradas junto ao lançamento consolidado; não confundir testes simulados com novas ações em uma conta real.
