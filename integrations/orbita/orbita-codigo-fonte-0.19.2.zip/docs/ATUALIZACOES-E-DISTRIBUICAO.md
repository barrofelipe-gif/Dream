# Atualizações da Órbita

## Resultado da revisão de 03/11/2026

O painel web 0.19.1 está publicado; o nativo instalado e o download nativo continuam na 0.19.0. Não há atualização nativa pendente. Correções exclusivamente do painel usam `npm run build:web` e não exigem recarregar a extensão.

A instalação atual é sem compactação. Hospedar outro ZIP não a transforma em uma instalação que recebe atualizações automaticamente. O canal recomendado para distribuição futura é a Chrome Web Store, com visibilidade não listada como proposta a confirmar com o publicador. O Chrome consulta atualizações periodicamente e as aplica quando a extensão está ociosa; não há promessa de atualização imediata.

No Windows, hospedagem própria de extensões é uma opção de ambientes administrados por políticas empresariais. Não será implantada uma política de administração neste computador para resolver uma atualização de desenvolvimento. A restrição do controle do navegador a `chrome://extensions` permanece respeitada.

`runtime.reload()` é uma API legítima da extensão que recarrega o código disponível localmente; não baixa um ZIP. A versão 0.19.0 instalada não expõe um comando dessa natureza. Não foi criado um comando de recarga para contornar a restrição da ferramenta, nem foram alterados perfil do Chrome, registro ou permissões.

## Pacote técnico preparado

`scripts/prepare-chrome-store.ps1` converte somente o conteúdo `dist/` do ZIP nativo congelado 0.19.0 em um ZIP com `manifest.json` na raiz, formato de envio à loja. Não compila código, instala software ou realiza uploads. O script verifica o SHA256 original, os recursos do manifest e a igualdade de todos os 16 arquivos com o nativo revisado. Recusa sobrescrever um candidato existente.

Resultado: `entrega/chrome-web-store/orbita-cws-0.19.0-candidato.zip` e `VALIDACAO-PACOTE.json`. Nenhum arquivo de cadastro, perfil do navegador, credencial, relatório real ou backup é adicionado. Trata-se de candidato técnico, não de publicação submetida ou aprovada. A ficha de envio ainda precisa da identificação do publicador, informações de suporte e privacidade, imagens de apresentação e orientações de revisão adequadas.

## Migração da instalação de desenvolvimento

### Conexão brasileira

O usuário pediu que os acessos às contas do Instagram usem conexão do Brasil. A checagem feita no próprio Chrome, em `https://www.cloudflare.com/cdn-cgi/trace`, retornou `loc=BR`, com `warp=off` e `gateway=off`. O IP não foi salvo. O executor nativo abre e controla abas desse Chrome; não foi encontrado mecanismo de proxy na extensão. Não foi alterada nenhuma configuração de rede. O painel hospedado não transfere esses cliques para um navegador de servidor.

Essa conferência identifica o país daquela navegação; não foi implantada uma trava geográfica permanente nem feita uma medição de todas as possíveis rotas por destino. Endereço postal de cadastro na loja continua dependente dos dados reais do publicador.

### Dados da instalação

Não se deve presumir que a loja conservará o ID atual. O manifest não fixa uma `key`; a chave de um item novo da loja não migra o armazenamento existente. A estratégia é usar os backups validados da própria Órbita, sem copiar armazenamento por console ou editar arquivos internos do Chrome.

Antes de migrar, a execução da instalação antiga deve estar pausada, com exportação por conta e conferência dos históricos, fontes, listas, proteções, avisos, limites e contadores. Não é necessário executar essa mudança enquanto o item da loja ainda não estiver disponível. A instalação antiga deve permanecer guardada até a conferência dos dados; sua execução não pode concorrer com a versão da loja.

O código atual conserva os dados históricos no backup, mas revoga execução e autorizações: `accountBackup()` em `src/core/accounts.ts` limpa a conexão e prepara o estado pausado; `restoreState()` em `src/core/domain.ts` transforma itens queued/attempting em uncertain; `validateContinuousState(..., restored=true)` em `src/core/continuous.ts` revoga a ativação contínua. Portanto, não se promete transferir uma fila executável e suas autorizações literalmente. A nova instalação exige conferir a sessão e revisar a ativação; nenhuma ação deve ser repetida como efeito da migração.

## Segunda opinião e divergências verificadas

Foi concluída uma consulta ao Claude Code com somente a pergunta técnica, o manifest e o script do build web, sem credenciais ou cadastros. A resposta foi lida em `output/claude-atualizacoes.log`. Um agente Codex GPT-6.1 Sol com raciocínio `max` revisou separadamente o código e as fontes primárias. Nenhuma dessas consultas altera o modelo ou a configuração da conversa principal.

Claude sugeriu hospedagem própria administrada como primeira opção. Esse caminho não foi adotado: exige políticas empresariais que não fazem parte da instalação atual, enquanto a documentação do Chrome orienta a loja para a distribuição comum no Windows. Também não foi adotada a sugestão de restaurar armazenamento diretamente pelo console: os validadores e a revogação das autorizações da Órbita devem ser preservados.

A observação do Claude sobre os nomes `hosted.js` e `hosted-content.js` não é um defeito: são artefatos diferentes. `src/hosted.ts` gera o painel web; `src/extension/hosted-content.ts` gera o conector instalado pelo build completo. A consulta recebeu somente o script web e não tinha contexto para verificar esse segundo build.

## Fontes primárias consultadas

- [Distribuição de extensões](https://developer.chrome.com/docs/extensions/how-to/distribute).
- [Ciclo de atualização e ociosidade](https://developer.chrome.com/docs/extensions/develop/concepts/extensions-update-lifecycle).
- [API runtime e recarga de instalações sem compactação](https://developer.chrome.com/docs/extensions/reference/api/runtime).
- [Identidade e manifest key](https://developer.chrome.com/docs/extensions/reference/manifest/key).
- [Armazenamento por extensão e remoção](https://developer.chrome.com/docs/extensions/reference/api/storage).
- [Envio à Chrome Web Store](https://developer.chrome.com/docs/webstore/publish).

Nenhum pacote foi enviado à loja, nenhum cadastro foi criado e nenhum termo foi aceito nesta revisão. A instalação atual e a rotina real não foram modificadas.
