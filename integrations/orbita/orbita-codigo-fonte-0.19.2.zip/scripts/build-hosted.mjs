import { build } from "esbuild";

// Web-only releases replace only the hosted bundle and its generated CSS.
// They do not rebuild or install the native executor or its manifest.
await build({
  entryPoints: ["src/hosted.ts"],
  outfile: "dist/hosted.js",
  bundle: true,
  format: "esm",
  target: "chrome120",
  minify: true,
});
