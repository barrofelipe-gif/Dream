import { build as viteBuild } from "vite";
import { build } from "esbuild";
await viteBuild({ base: "./", build: { outDir: "dist", emptyOutDir: true } });
await build({
  entryPoints: ["src/extension/background.ts"],
  outfile: "dist/background.js",
  bundle: true,
  format: "esm",
  target: "chrome120",
  sourcemap: true,
});
await build({
  entryPoints: ["src/extension/content.ts"],
  outfile: "dist/content.js",
  bundle: true,
  format: "iife",
  target: "chrome120",
  sourcemap: true,
});
console.log("Extensão pronta em dist/.");

await build({
  entryPoints: ["src/extension/hosted-content.ts"],
  outfile: "dist/hosted-content.js",
  bundle: true,
  format: "iife",
  target: "chrome120",
});
await import("./build-hosted.mjs");
