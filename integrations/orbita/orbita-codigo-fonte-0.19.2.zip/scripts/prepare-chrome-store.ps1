#Requires -Version 7.3
[CmdletBinding()]
param(
    [string] $NativeZip = (Join-Path $PSScriptRoot '..\entrega\orbita-0.19.0.zip'),
    [string] $ExpectedSha256 = '4F38EE01CE200571F225CFA58FA1337E812E4EF54455792779E483B17C32C4AF'
)
$ErrorActionPreference = 'Stop'
Add-Type -AssemblyName System.IO.Compression.FileSystem
$nativePath = (Resolve-Path -LiteralPath $NativeZip).ProviderPath
$sourceHash = (Get-FileHash -LiteralPath $nativePath -Algorithm SHA256).Hash
if ($sourceHash -ne $ExpectedSha256) { throw 'O ZIP nativo não corresponde ao artefato revisado.' }
$source = [IO.Compression.ZipFile]::OpenRead($nativePath)
try {
    $entry = $source.GetEntry('dist/manifest.json')
    if (-not $entry) { throw 'Manifest nativo ausente em dist/manifest.json.' }
    $reader = [IO.StreamReader]::new($entry.Open())
    try { $manifest = $reader.ReadToEnd() | ConvertFrom-Json } finally { $reader.Dispose() }
    if ($manifest.manifest_version -ne 3 -or $manifest.version -notmatch '^\d+(\.\d+){1,3}$') {
        throw 'Manifest/version inválidos.'
    }
    $outputFolder = Join-Path $PSScriptRoot '..\entrega\chrome-web-store'
    [IO.Directory]::CreateDirectory($outputFolder) | Out-Null
    $candidatePath = Join-Path $outputFolder "orbita-cws-$($manifest.version)-candidato.zip"
    if (Test-Path -LiteralPath $candidatePath) { throw 'O candidato já existe; não será sobrescrito.' }
    $destination = [IO.Compression.ZipFile]::Open($candidatePath, [IO.Compression.ZipArchiveMode]::Create)
    try {
        foreach ($file in $source.Entries) {
            if (-not $file.FullName.StartsWith('dist/', [StringComparison]::Ordinal) -or $file.FullName.EndsWith('/')) { continue }
            $relative = $file.FullName.Substring(5)
            if ($relative -match '(^/|\\|:|(^|/)\.\.(/|$))') { throw 'Caminho de arquivo inválido.' }
            $copy = $destination.CreateEntry($relative, [IO.Compression.CompressionLevel]::Optimal)
            $copy.LastWriteTime = $file.LastWriteTime
            $inputStream = $file.Open()
            $outputStream = $copy.Open()
            try { $inputStream.CopyTo($outputStream) } finally { $inputStream.Dispose(); $outputStream.Dispose() }
        }
    } finally { $destination.Dispose() }
    $candidate = [IO.Compression.ZipFile]::OpenRead($candidatePath)
    try {
        $names = @($candidate.Entries.FullName)
        if ($names.Count -ne ($names | Sort-Object -Unique).Count -or -not $candidate.GetEntry('manifest.json')) {
            throw 'Manifest na raiz ou nomes de arquivos inválidos.'
        }
        $required = @($manifest.background.service_worker, 'index.html') + @($manifest.icons.PSObject.Properties.Value) + @($manifest.content_scripts.js)
        foreach ($requiredFile in $required) {
            if (-not $candidate.GetEntry($requiredFile)) { throw "Recurso obrigatório ausente: $requiredFile" }
        }
        foreach ($file in $candidate.Entries) {
            $original = $source.GetEntry("dist/$($file.FullName)")
            if (-not $original) { throw 'Arquivo sem origem no ZIP revisado.' }
            $first = $original.Open(); $second = $file.Open()
            try {
                $firstHash = [Convert]::ToHexString([Security.Cryptography.SHA256]::HashData($first))
                $secondHash = [Convert]::ToHexString([Security.Cryptography.SHA256]::HashData($second))
                if ($firstHash -ne $secondHash) { throw "Conteúdo divergente: $($file.FullName)" }
            } finally { $first.Dispose(); $second.Dispose() }
        }
        $report = [ordered]@{
            nativeVersion = $manifest.version
            candidateFile = [IO.Path]::GetFileName($candidatePath)
            candidateSha256 = (Get-FileHash -LiteralPath $candidatePath -Algorithm SHA256).Hash
            sourceNativeSha256 = $sourceHash
            filesVerifiedAgainstFrozenNative = $names.Count
            manifestAtZipRoot = $true
            referencedManifestResourcesPresent = $true
            nativeCodeChanged = $false
            permissionsChanged = $false
            installedExtensionTouched = $false
            uploadedToStore = $false
            storeApproved = $false
            status = 'technical_candidate_not_submitted'
        }
        $report | ConvertTo-Json -Depth 6 | Set-Content -LiteralPath (Join-Path $outputFolder 'VALIDACAO-PACOTE.json') -Encoding utf8
        $report | ConvertTo-Json -Depth 6
    } finally { $candidate.Dispose() }
} finally { $source.Dispose() }
