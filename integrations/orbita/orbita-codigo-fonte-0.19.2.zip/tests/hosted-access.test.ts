import test from "node:test";
import assert from "node:assert/strict";
import { JSDOM } from "jsdom";
import { verifyHostedActor } from "../src/hosted-access.ts";
import { build } from "esbuild";
import { runInNewContext } from "node:vm";
import { fileURLToPath } from "node:url";

const hostedFixture = (
  await build({
    entryPoints: [fileURLToPath(new URL("../src/hosted.ts", import.meta.url))],
    bundle: true,
    write: false,
    format: "iife",
    platform: "browser",
    logLevel: "silent",
    plugins: [
      {
        name: "fixture-main",
        setup(b) {
          b.onResolve({ filter: /(^|\/)main\.tsx$/ }, () => ({
            path: "main",
            namespace: "fixture-main",
          }));
          b.onLoad({ filter: /.*/, namespace: "fixture-main" }, () => ({
            contents:
              "document.getElementById('root').textContent='QA montado';",
          }));
        },
      },
    ],
  })
).outputFiles[0].text;
const turn = () => new Promise<void>((resolve) => setImmediate(resolve));
function hostedPage(
  fetcher: (url: string, options?: RequestInit) => Promise<unknown>,
) {
  const dom = new JSDOM(
    `<meta name="orbita-user" content="${"a".repeat(32)}"><span id="connection-mode"></span><section id="setup"><button id="connect-extension">Conectar</button><button id="manual-mode">Manual</button><p id="connection-status"></p></section><div id="root"></div>`,
    {
      url: "https://app.bfffitnessatacado.com.br/api/growth/orbita/painel",
      pretendToBeVisual: true,
    },
  );
  dom.window.localStorage.setItem("qa-preserved", "dados locais mantidos");
  runInNewContext(hostedFixture, {
    window: dom.window,
    document: dom.window.document,
    location: dom.window.location,
    fetch: fetcher,
    setTimeout,
    clearTimeout,
    setInterval,
    clearInterval,
    AbortController,
    AbortSignal,
    Date,
    crypto,
    console,
  });
  return {
    dom,
    manual: dom.window.document.getElementById(
      "manual-mode",
    ) as HTMLButtonElement,
    check: () =>
      dom.window.dispatchEvent(
        new dom.window.CustomEvent("orbita-transport-error"),
      ),
    close: () => dom.window.close(),
  };
}

for (const phase of ["fetch", "json"] as const)
  test(`abertura hospedada libera os botões quando ${phase} da sessão não termina`, async (t) => {
    t.mock.timers.enable({
      apis: ["Date", "setTimeout", "setInterval"],
      now: 1_800_000_000_000,
    });
    let signal: AbortSignal | null | undefined;
    const env = hostedPage(async (_url, options) => {
      signal = options?.signal;
      if (phase === "fetch") return new Promise(() => {});
      return { ok: true, type: "basic", json: () => new Promise(() => {}) };
    });
    try {
      env.manual.click();
      await turn();
      assert.equal(env.manual.disabled, true);
      t.mock.timers.tick(10001);
      await turn();
      assert.equal(
        env.manual.disabled,
        false,
        "a falha deve permitir reabrir/verificar sem espera infinita",
      );
      assert.equal(signal?.aborted, true);
      assert.match(
        env.dom.window.document.getElementById("connection-status")!
          .textContent!,
        /tempo|prazo/i,
      );
      assert.equal(
        env.dom.window.localStorage.getItem("qa-preserved"),
        "dados locais mantidos",
      );
    } finally {
      t.mock.timers.reset();
      env.close();
    }
  });

test("verificações concorrentes compartilham somente a leitura pendente e conferem outra vez depois", async (t) => {
  t.mock.timers.enable({
    apis: ["Date", "setTimeout", "setInterval"],
    now: 1_800_000_000_000,
  });
  const pending: Array<(value: unknown) => void> = [];
  let reads = 0;
  const env = hostedPage(async () => {
    reads++;
    return new Promise((resolve) => pending.push(resolve));
  });
  try {
    env.check();
    env.check();
    env.dom.window.document.dispatchEvent(
      new env.dom.window.Event("visibilitychange"),
    );
    assert.equal(reads, 1);
    pending[0]({
      ok: true,
      type: "basic",
      json: async () => ({ ready: true, userScope: "a".repeat(32) }),
    });
    await turn();
    env.check();
    env.check();
    assert.equal(
      reads,
      2,
      "uma verificação concluída não deve virar cache de autorização",
    );
    pending[1]({
      ok: true,
      type: "basic",
      json: async () => ({ ready: true, userScope: "b".repeat(32) }),
    });
    await turn();
    assert.match(
      env.dom.window.document.body.textContent!,
      /Confira sua sessão/,
    );
    assert.equal(
      env.dom.window.localStorage.getItem("qa-preserved"),
      "dados locais mantidos",
    );
  } finally {
    t.mock.timers.reset();
    env.close();
  }
});

test("sessão pendente bloqueia após o prazo e resposta tardia não reabre o painel", async (t) => {
  t.mock.timers.enable({
    apis: ["Date", "setTimeout", "setInterval"],
    now: 1_800_000_000_000,
  });
  let release!: (value: unknown) => void;
  const env = hostedPage(
    async () =>
      new Promise((resolve) => {
        release = resolve;
      }),
  );
  try {
    env.check();
    t.mock.timers.tick(10001);
    await turn();
    assert.match(
      env.dom.window.document.body.textContent!,
      /Confira sua sessão/,
    );
    release({
      ok: true,
      type: "basic",
      json: async () => ({ ready: true, userScope: "a".repeat(32) }),
    });
    await turn();
    assert.match(
      env.dom.window.document.body.textContent!,
      /Confira sua sessão/,
    );
    assert.equal(
      env.dom.window.localStorage.getItem("qa-preserved"),
      "dados locais mantidos",
    );
  } finally {
    t.mock.timers.reset();
    env.close();
  }
});

test("salvar no modo hospedado exige a identidade que abriu o painel", async () => {
  const dom = new JSDOM(
    `<meta name="orbita-user" content="${"a".repeat(32)}">`,
    { url: "https://app.bfffitnessatacado.com.br/api/growth/orbita/painel" },
  );
  const originals = new Map<string, PropertyDescriptor | undefined>();
  let reads = 0,
    scope = "a".repeat(32),
    failures = 0;
  for (const [key, value] of Object.entries({
    window: dom.window,
    document: dom.window.document,
    location: dom.window.location,
    CustomEvent: dom.window.CustomEvent,
    fetch: async () => {
      reads++;
      return {
        ok: true,
        type: "basic",
        json: async () => ({ ready: true, userScope: scope }),
      };
    },
  })) {
    originals.set(key, Object.getOwnPropertyDescriptor(globalThis, key));
    Object.defineProperty(globalThis, key, {
      value,
      writable: true,
      configurable: true,
    });
  }
  dom.window.addEventListener("orbita-transport-error", () => failures++);
  try {
    await verifyHostedActor();
    scope = "b".repeat(32);
    await assert.rejects(verifyHostedActor(), /usuário/);
    assert.equal(reads, 2);
    assert.equal(failures, 1);
  } finally {
    for (const [key, value] of originals)
      value
        ? Object.defineProperty(globalThis, key, value)
        : Reflect.deleteProperty(globalThis, key);
    dom.window.close();
  }
});
test("prévia independente não consulta o login do app", async () => {
  const oldLocation = Object.getOwnPropertyDescriptor(globalThis, "location"),
    oldFetch = globalThis.fetch;
  let reads = 0;
  Object.defineProperty(globalThis, "location", {
    value: { href: "http://127.0.0.1:4173/" },
    configurable: true,
  });
  globalThis.fetch = async () => {
    reads++;
    throw Error("Não deve consultar");
  };
  try {
    await verifyHostedActor();
    assert.equal(reads, 0);
  } finally {
    globalThis.fetch = oldFetch;
    oldLocation
      ? Object.defineProperty(globalThis, "location", oldLocation)
      : Reflect.deleteProperty(globalThis, "location");
  }
});
