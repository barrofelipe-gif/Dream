import test from "node:test";
import assert from "node:assert/strict";
import { applyCommand, initialState, restoreState } from "../src/core/domain.ts";
import { campaignMembers, groupedCampaigns, profileCampaignPlan } from "../src/core/campaigns.ts";

const create = { type: "CREATE_PROFILE_CAMPAIGN", name: "Campanha fictícia", profile: "@qa.origem", postUrl: "https://www.instagram.com/qa.origem/p/QApost/?img_index=1" } as const;
test("um cadastro prepara três fontes com perfil e publicação canônicos, sem capturar ou seguir", () => {
  const original = initialState();
  const state = applyCommand(original, create);
  assert.deepEqual(original, initialState());
  assert.equal(state.campaigns.length, 3);
  assert.deepEqual(state.campaigns.map((c) => c.kind), ["followers", "commenters", "likers"]);
  assert.deepEqual(state.campaigns.map((c) => c.target), ["@qa.origem", "https://www.instagram.com/p/QApost/", "https://www.instagram.com/p/QApost/"]);
  assert.equal(new Set(state.campaigns.map((c) => c.group!.id)).size, 1);
  assert.equal(new Set(state.campaigns.map((c) => c.id)).size, 3);
  assert.equal(state.candidates.length, 0);
  assert.equal(state.runtime.mode, "paused");
  assert.equal(state.audit.some((a) => a.kind === "attempt"), false);
});
test("post de outro perfil ou domínio e link incompleto não deixam fontes pela metade", () => {
  const state = initialState(), before = structuredClone(state);
  for (const postUrl of ["", "https://evil.test/p/QApost/", "https://www.instagram.com/qa.outra/p/QApost/", "https://www.instagram.com/qa.origem/", "https://www.instagram.com:8443/p/QApost/"])
    assert.throws(() => applyCommand(state, { ...create, postUrl }));
  assert.deepEqual(state, before);
});
test("o mesmo perfil e publicação não criam três novas fontes ao repetir o cadastro", () => {
  const state = applyCommand(initialState(), create);
  assert.throws(() => applyCommand(state, create), /já têm/);
  assert.equal(state.campaigns.length, 3);
});
test("grupo acumula fontes e conta a pessoa uma vez, sem perder a origem nem aprovar", () => {
  let state = applyCommand(initialState(), create);
  const [followers, comments, likes] = state.campaigns;
  for (const source of [followers, comments, likes]) state = applyCommand(state, { type: "IMPORT", campaignId: source.id, candidates: [{ username: "qa.pessoa" }], url: source.target });
  state = applyCommand(state, { type: "IMPORT", campaignId: followers.id, candidates: [{ username: "qa.outra" }], url: followers.target });
  const groups = groupedCampaigns(state.campaigns);
  assert.equal(groups.length, 1);
  assert.equal(groups[0].sources.length, 3);
  assert.equal(campaignMembers(state.candidates, groups[0].sources).length, 2);
  assert.equal(state.candidates[0].sources.length, 3);
  assert.equal(state.candidates.every((c) => c.stage === "new"), true);
});
test("backup mantém o grupo e rejeita fonte que declara outro perfil ou publicação", () => {
  const state = applyCommand(initialState(), create);
  const restored = restoreState(JSON.parse(JSON.stringify(state)));
  assert.deepEqual(restored.campaigns, state.campaigns);
  const invalid = structuredClone(state);
  invalid.campaigns[1].target = "https://www.instagram.com/p/OtherCode/";
  assert.throws(() => restoreState(invalid), /não corresponde/);
});
test("fontes antigas continuam avulsas e URLs públicas prefixadas são normalizadas", () => {
  const state = applyCommand(initialState(), { type: "CREATE_CAMPAIGN", name: "Avulsa", kind: "followers", target: "@qa.origem" });
  assert.equal(groupedCampaigns(state.campaigns)[0].profile, undefined);
  const plan = profileCampaignPlan("Reel", "https://instagram.com/QA.Origem/", "https://instagram.com/qa.origem/reel/QAcode/?igsh=test");
  assert.equal(plan.profile, "qa.origem");
  assert.equal(plan.postUrl, "https://www.instagram.com/reel/QAcode/");
});
test("agrupar fontes já coletadas preserva IDs, 12/5/11 salvos e cinco candidatos na fila", () => {
  let state = initialState();
  for (const [kind, count] of [["followers", 12], ["commenters", 5], ["likers", 11]] as const) {
    state = applyCommand(state, { type: "CREATE_CAMPAIGN", name: `Legado ${kind}`, kind, target: kind === "followers" ? "@qa.origem" : "https://www.instagram.com/p/QApost/" });
    const campaign = state.campaigns[0];
    state = applyCommand(state, { type: "IMPORT", campaignId: campaign.id, candidates: Array.from({ length: count }, (_, i) => ({ username: `qa.${kind}${i}` })), url: campaign.target });
  }
  state.runtime.account = "qa.conta";
  const selected = state.candidates.slice(0, 5).map((candidate) => candidate.id);
  state = applyCommand(state, { type: "APPROVE", ids: selected });
  state = applyCommand(state, { type: "QUEUE", ids: selected });
  const candidatesBefore = structuredClone(state.candidates), runtimeBefore = structuredClone(state.runtime);
  const idsBefore = state.campaigns.map((campaign) => campaign.id).sort();
  state = applyCommand(state, create);
  assert.deepEqual(state.candidates, candidatesBefore);
  assert.deepEqual(state.runtime, runtimeBefore);
  assert.deepEqual(state.campaigns.map((campaign) => campaign.id).sort(), idsBefore);
  assert.equal(state.candidates.filter((candidate) => candidate.stage === "queued").length, 5);
  const [group] = groupedCampaigns(state.campaigns);
  assert.equal(groupedCampaigns(state.campaigns).length, 1);
  assert.deepEqual(group.sources.map((source) => campaignMembers(state.candidates, [source]).length), [12, 5, 11]);
  assert.equal(campaignMembers(state.candidates, group.sources).length, 28);
});
