import test from "node:test";
import assert from "node:assert/strict";
import { createRequire } from "node:module";
import { runInNewContext } from "node:vm";
import { fileURLToPath } from "node:url";
import { buildSync } from "esbuild";
import { act, createElement } from "react";
import { createRoot } from "react-dom/client";
import { JSDOM } from "jsdom";
import { initialStore, workspace } from "../src/core/accounts.ts";
import type { Command, SpecialCommand } from "../src/core/types.ts";

const compiled = buildSync({
  entryPoints: [fileURLToPath(new URL("../src/ui/App.tsx", import.meta.url))],
  bundle: true,
  platform: "node",
  format: "cjs",
  packages: "external",
  loader: { ".css": "empty" },
  write: false,
}).outputFiles[0].text;
const mod = { exports: {} as any };
const sandbox: Record<string, any> = {
  module: mod,
  exports: mod.exports,
  require: createRequire(import.meta.url),
  console,
  window: {},
  structuredClone,
  crypto,
  URL,
  setTimeout,
  clearTimeout,
  setInterval,
  clearInterval,
};
runInNewContext(compiled, sandbox);
const { SettingsPage } = mod.exports;

async function fixture(
  t: any,
  allDaySupported: boolean,
  existingAllDay?: boolean,
) {
  const account = workspace(initialStore());
  account.username = "qa.settings";
  account.data.runtime.account = account.username;
  Object.assign(account.data.settings, {
    dailyLimit: 5,
    sessionLimit: 5,
    intervalMinutes: 5,
    startHour: "09:00",
    endHour: "21:00",
  });
  if (existingAllDay === undefined) delete account.data.settings.allDay;
  else account.data.settings.allDay = existingAllDay;
  const before = structuredClone(account);
  const commands: Array<Command | SpecialCommand> = [];
  let refreshes = 0;
  const props = {
    account,
    state: account.data,
    busy: false,
    flash: () => {},
    onCycle: () => {},
    capability: { status: "supported", allDaySchedule: allDaySupported },
    onRefreshCapability: () => {
      refreshes++;
    },
    run: async (command: Command | SpecialCommand) => {
      commands.push(command);
      return true;
    },
  };
  const dom = new JSDOM("<div id='root'></div>", {
    url: "https://qa.invalid/",
  });
  const originals = new Map<string, PropertyDescriptor | undefined>();
  for (const [key, value] of Object.entries({
    window: dom.window,
    document: dom.window.document,
    HTMLElement: dom.window.HTMLElement,
    Event: dom.window.Event,
    IS_REACT_ACT_ENVIRONMENT: true,
  })) {
    originals.set(key, Object.getOwnPropertyDescriptor(globalThis, key));
    Object.defineProperty(globalThis, key, {
      configurable: true,
      writable: true,
      value,
    });
    sandbox[key] = value;
  }
  const root = createRoot(dom.window.document.getElementById("root")!);
  t.after(async () => {
    await act(async () => root.unmount());
    dom.window.close();
    for (const [key, descriptor] of originals) {
      if (descriptor) Object.defineProperty(globalThis, key, descriptor);
      else Reflect.deleteProperty(globalThis, key);
      delete sandbox[key];
    }
    sandbox.window = {};
  });
  await act(async () => root.render(createElement(SettingsPage, props)));
  const doc = dom.window.document;
  const toggle = doc.querySelector<HTMLInputElement>(
    ".settings-all-day input",
  )!;
  const times = [
    ...doc.querySelectorAll<HTMLInputElement>('input[type="time"]'),
  ];
  const save = [...doc.querySelectorAll<HTMLButtonElement>("button")].find(
    (button) => button.textContent?.trim() === "Salvar preferências",
  )!;
  const click = async (element: HTMLElement) => {
    await act(async () => element.click());
  };
  return {
    root,
    props,
    account,
    before,
    commands,
    doc,
    toggle,
    times,
    save,
    click,
    refreshes: () => refreshes,
    dom,
  };
}

test("legado sem allDay fica desmarcado; extensão sem flag não habilita 24h nem recarrega", async (t) => {
  const f = await fixture(t, false);
  assert.equal(f.toggle.checked, false);
  assert.equal(f.toggle.disabled, true);
  assert.deepEqual(
    f.times.map((input) => [input.value, input.disabled]),
    [
      ["09:00", false],
      ["21:00", false],
    ],
  );
  assert.match(
    f.doc.querySelector(".settings-all-day")!.textContent!,
    /0\.19\.1 ou posterior/,
  );
  await f.click(f.toggle);
  assert.equal(f.toggle.checked, false);
  const refresh = [...f.doc.querySelectorAll<HTMLButtonElement>("button")].find(
    (button) => button.textContent?.includes("Conferir recurso de 24 horas"),
  )!;
  await f.click(refresh);
  assert.equal(f.refreshes(), 1);
  assert.deepEqual(f.commands, []);
  await f.click(f.save);
  assert.equal(f.commands.length, 1);
  const command = JSON.parse(JSON.stringify(f.commands[0])) as Extract<
    Command,
    { type: "SETTINGS" }
  >;
  assert.equal(command.type, "SETTINGS");
  assert.equal(command.settings.allDay, undefined);
  assert.deepEqual(f.account, f.before);
});

test("24h autorizado preserva 09–21 e limites 5/5/5 ao salvar", async (t) => {
  const f = await fixture(t, true);
  await f.click(f.toggle);
  assert.equal(f.toggle.checked, true);
  assert.deepEqual(
    f.times.map((input) => [input.value, input.disabled]),
    [
      ["09:00", true],
      ["21:00", true],
    ],
  );
  assert.equal(f.commands.length, 0);
  await f.click(f.save);
  assert.equal(f.commands.length, 1);
  const command = JSON.parse(JSON.stringify(f.commands[0])) as Extract<
    Command,
    { type: "SETTINGS" }
  >;
  assert.equal(command.type, "SETTINGS");
  assert.equal(command.settings.allDay, true);
  assert.deepEqual(
    [command.settings.startHour, command.settings.endHour],
    ["09:00", "21:00"],
  );
  assert.deepEqual(
    [
      command.settings.dailyLimit,
      command.settings.sessionLimit,
      command.settings.intervalMinutes,
    ],
    [5, 5, 5],
  );
  assert.match(
    f.doc.querySelector(".settings-all-day")!.textContent!,
    /ações e consultas de fontes também durante a madrugada/,
  );
  assert.deepEqual(f.account, f.before);
});

test("desligar 24h reabilita os mesmos horários, sem alterar teto ou intervalo", async (t) => {
  const f = await fixture(t, true, true);
  assert.ok(f.times.every((input) => input.disabled));
  await f.click(f.toggle);
  assert.equal(f.toggle.checked, false);
  assert.deepEqual(
    f.times.map((input) => [input.value, input.disabled]),
    [
      ["09:00", false],
      ["21:00", false],
    ],
  );
  await f.click(f.save);
  const command = JSON.parse(JSON.stringify(f.commands[0])) as Extract<
    Command,
    { type: "SETTINGS" }
  >;
  assert.equal(command.settings.allDay, false);
  assert.deepEqual(
    [
      command.settings.dailyLimit,
      command.settings.sessionLimit,
      command.settings.intervalMinutes,
    ],
    [5, 5, 5],
  );
  assert.deepEqual(f.account, f.before);
});

test("allDay salvo com capability ausente fica pendente e submit não envia 24h", async (t) => {
  const f = await fixture(t, false, true);
  assert.equal(f.toggle.checked, true);
  assert.equal(f.toggle.disabled, true);
  assert.equal(f.save.disabled, true);
  assert.match(
    f.doc.querySelector(".settings-all-day")!.textContent!,
    /permanece pendente/,
  );
  await act(async () =>
    f.doc
      .querySelector("form")!
      .dispatchEvent(
        new f.dom.window.Event("submit", { bubbles: true, cancelable: true }),
      ),
  );
  assert.deepEqual(f.commands, []);
  assert.deepEqual(f.account, f.before);
});

test("perder capability após o toggle bloqueia salvar a configuração 24h", async (t) => {
  const f = await fixture(t, true);
  await f.click(f.toggle);
  await act(async () =>
    f.root.render(
      createElement(SettingsPage, {
        ...f.props,
        capability: { status: "supported", allDaySchedule: false },
      }),
    ),
  );
  assert.equal(f.toggle.checked, true);
  assert.equal(f.save.disabled, true);
  await f.click(f.save);
  assert.deepEqual(f.commands, []);
});
