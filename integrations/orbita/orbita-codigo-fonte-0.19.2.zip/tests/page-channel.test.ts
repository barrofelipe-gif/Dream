import test from "node:test";
import assert from "node:assert/strict";
import { PageDeadlineError, readPageMessage, withDeadline } from "../src/extension/page-channel.ts";

test("deadline vencido não inicia operação e um timer antecipado não a repete", async (t) => {
  let now = 100, calls = 0, settled = false;
  t.mock.method(Date, "now", () => now);
  t.mock.timers.enable({ apis: ["setTimeout"] });
  await assert.rejects(withDeadline(async () => { calls++; }, 99, "vencido"), PageDeadlineError);
  assert.equal(calls, 0);
  const operation = withDeadline(() => { calls++; return new Promise(() => {}); }, 1100, "STATUS");
  const rejected = assert.rejects(operation, (error: unknown) => error instanceof PageDeadlineError && error.phase === "STATUS");
  void operation.catch(() => { settled = true; });
  t.mock.timers.tick(1000);
  await Promise.resolve();
  assert.equal(settled, false);
  assert.equal(calls, 1);
  now = 1100;
  t.mock.timers.tick(1000);
  await rejected;
  assert.equal(calls, 1);
});

test("resposta atrasada não vence o prazo mesmo quando o timer ainda não disparou", async (t) => {
  let now = 0, resolve!: (value: string) => void;
  t.mock.method(Date, "now", () => now);
  const operation = withDeadline(() => new Promise<string>((done) => { resolve = done; }), 100, "navegação");
  const rejected = assert.rejects(operation, PageDeadlineError);
  now = 101; resolve("atrasada");
  await rejected;
});

test("somente receiver inexistente permite uma injeção, compartilhada entre leituras", async () => {
  const budget = { injectionUsed: false };
  let sent = 0, injected = 0;
  const channel = { async sendMessage() { sent++; if (sent !== 2) throw new Error("Could not establish connection. Receiving end does not exist."); return { ok: true }; }, async inject() { injected++; } };
  assert.deepEqual(await readPageMessage(channel, 1, { type: "STATUS" }, Date.now() + 4000, "STATUS", budget), { ok: true });
  await assert.rejects(readPageMessage(channel, 1, { type: "STATUS" }, Date.now() + 4000, "sessão", budget), /Receiving end/);
  assert.equal(sent, 3); assert.equal(injected, 1);
});

test("port closed e falha desconhecida não reinjetam nem reenviam a leitura", async () => {
  for (const message of ["The message port closed before a response was received.", "Frame was removed."]) {
    let sent = 0, injected = 0;
    await assert.rejects(readPageMessage({ async sendMessage() { sent++; throw new Error(message); }, async inject() { injected++; } }, 1, { type: "STATUS" }), new RegExp(message.replace(/[.]/g, "\\.")));
    assert.equal(sent, 1); assert.equal(injected, 0);
  }
});

test("STATUS sem retorno expira; rejeição tardia de receiver não dispara fallback", async (t) => {
  let now = 0, sent = 0, injected = 0, fail!: (error: Error) => void;
  t.mock.method(Date, "now", () => now);
  t.mock.timers.enable({ apis: ["setTimeout"] });
  const request = readPageMessage({ sendMessage() { sent++; return new Promise((_resolve, reject) => { fail = reject; }); }, async inject() { injected++; } }, 1, { type: "STATUS" }, 4000, "STATUS");
  const rejected = assert.rejects(request, PageDeadlineError);
  now = 4000; t.mock.timers.tick(4000); await rejected;
  fail(new Error("Could not establish connection. Receiving end does not exist."));
  await Promise.resolve(); await Promise.resolve();
  assert.equal(sent, 1); assert.equal(injected, 0);
});

test("injeção e resposta compartilham deadline original, sem renovar quatro segundos", async (t) => {
  let now = 0, sent = 0, injected = 0;
  t.mock.method(Date, "now", () => now);
  t.mock.timers.enable({ apis: ["setTimeout"] });
  const request = readPageMessage({ async sendMessage() { sent++; now = 3000; throw new Error("Receiving end does not exist."); }, inject() { injected++; return new Promise(() => {}); } }, 1, { type: "STATUS" }, 4000, "STATUS");
  const rejected = assert.rejects(request, PageDeadlineError);
  for (let i = 0; i < 6; i++) await Promise.resolve();
  assert.equal(injected, 1);
  now = 4000; t.mock.timers.tick(1000); await rejected;
  assert.equal(sent, 1); assert.equal(injected, 1);
});

test("canal recusa mutações antes de qualquer entrega ou injeção", async () => {
  for (const type of ["FOLLOW", "UNFOLLOW", "CAPTURE", "AUTHORIZE_CLICK"]) {
    let sent = 0, injected = 0;
    await assert.rejects(readPageMessage({ async sendMessage() { sent++; }, async inject() { injected++; } }, 1, { type }), /não aceita/);
    assert.equal(sent, 0); assert.equal(injected, 0);
  }
});
