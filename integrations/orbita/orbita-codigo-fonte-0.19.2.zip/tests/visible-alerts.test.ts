import test from "node:test";
import assert from "node:assert/strict";
import { createRequire } from "node:module";
import { runInNewContext } from "node:vm";
import { fileURLToPath } from "node:url";
import { buildSync } from "esbuild";
import { createElement } from "react";
import { renderToStaticMarkup } from "react-dom/server";
import { JSDOM } from "jsdom";
import { initialState } from "../src/core/domain.ts";
import { visibleProblemAlerts } from "../src/problems-client.ts";

const compiled = buildSync({
  entryPoints: [fileURLToPath(new URL("../src/ui/Safety.tsx", import.meta.url))],
  bundle: true,
  platform: "node",
  format: "cjs",
  packages: "external",
  write: false,
}).outputFiles[0].text;
const mod = { exports: {} as any };
runInNewContext(compiled, {
  module: mod,
  exports: mod.exports,
  require: createRequire(import.meta.url),
  console,
});

function fixture(warning = false) {
  const state = initialState();
  state.runtime.account = "qa.alerts";
  state.dailyAttempts[`${state.runtime.account}|${new Date().toDateString()}`] = 5;
  state.settings.hasPendingWarning = warning;
  const before = structuredClone(state);
  const html = renderToStaticMarkup(createElement(mod.exports.SafetyNotices, { state }));
  assert.deepEqual(state, before);
  return new JSDOM(`<main>${html}<p role="alert">Falha real ao importar os dados.</p></main>`).window.document;
}

test("teto atingido continua visível e acessível sem virar incidente", () => {
  const doc = fixture();
  assert.ok([...doc.querySelectorAll('[role="alert"]')].some(e => e.textContent?.includes("Teto de hoje atingido")));
  const captured = visibleProblemAlerts(doc).map(e => e.textContent);
  assert.deepEqual(captured, ["Falha real ao importar os dados."]);
});

test("falhas reais e aviso pendente do Instagram continuam na captura", () => {
  const doc = fixture(true);
  const captured = visibleProblemAlerts(doc).map(e => e.textContent || "");
  assert.equal(captured.length, 2);
  assert.ok(captured.some(t => t.includes("Interrompa e confira o Instagram")));
  assert.ok(captured.some(t => t.includes("Falha real ao importar os dados.")));
  assert.ok(captured.every(t => !t.includes("Teto de hoje atingido")));
});
