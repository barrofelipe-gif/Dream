import test from "node:test";
import assert from "node:assert/strict";
import {
  accountBackup,
  accountCommand,
  applyScopedCommand,
  initialStore,
  migrateStore,
  workspace,
} from "../src/core/accounts.ts";
import {
  applyCommand,
  audit,
  mergeCandidates,
  restoreState,
} from "../src/core/domain.ts";
import {
  applyCandidateRelationshipObservation,
  validateCandidateRelationshipObservation,
} from "../src/core/relationship-observation.ts";
import { unfollowEligibility } from "../src/core/prospecting.ts";
import type { CandidateRelationshipReading } from "../src/core/relationship-observation.ts";

function fixture() {
  const store = accountCommand(initialStore(), {
    type: "ADD_ACCOUNT",
    username: "qa.owner",
  });
  const account = workspace(store);
  account.data = applyCommand(account.data, {
    type: "CREATE_CAMPAIGN",
    name: "Fixture de resultado",
    kind: "followers",
    target: "qa.reference",
  });
  mergeCandidates(account.data, account.data.campaigns[0].id, [
    { username: "qa.target" },
  ]);
  const candidate = account.data.candidates[0];
  candidate.stage = "uncertain";
  candidate.queueAccount = account.username;
  candidate.queuedAction = "follow";
  candidate.lastResult =
    "O clique foi enviado, mas o resultado não pôde ser confirmado.";
  account.data.settings.hasPendingWarning = true;
  account.data.settings.reviewAfterDays = 1;
  account.data.settings.reviewPolicy = "review_all";
  audit(
    account.data,
    "attempt",
    "Fixture de tentativa já consumida",
    candidate.username,
  );
  const now = new Date();
  const reading: CandidateRelationshipReading = {
    account: account.username!,
    username: candidate.username,
    at: now.toISOString(),
    status: "following",
  };
  return { store, account, candidate, now, reading };
}

test("conferência somente leitura marca Seguindo sem fabricar clique ou repor orçamento", () => {
  const { account, candidate, now, reading } = fixture();
  const before = structuredClone(account.data);
  applyCandidateRelationshipObservation(account, candidate.id, reading, now);
  assert.equal(candidate.stage, "followed");
  assert.deepEqual(candidate.relationshipObserved, {
    account: account.username,
    at: reading.at,
    status: "following",
    source: "instagram",
  });
  assert.equal(candidate.lastResult, before.candidates[0].lastResult);
  assert.equal(candidate.confirmedFollowAt, undefined);
  assert.equal(candidate.confirmedFollowAccount, undefined);
  assert.equal(candidate.confirmedFollowSource, undefined);
  assert.deepEqual(account.data.dailyAttempts, before.dailyAttempts);
  assert.deepEqual(account.data.lastAttempts, before.lastAttempts);
  assert.deepEqual(account.data.settings, before.settings);
  assert.deepEqual(account.data.runtime, before.runtime);
  assert.equal(account.data.audit[0].kind, "relationship_verified");
  assert.equal(
    account.data.audit.filter((a) => a.kind === "followed").length,
    0,
  );
  assert.equal(
    unfollowEligibility(
      account,
      candidate,
      new Date(now.getTime() + 10 * 86400000),
    ).eligible,
    false,
  );
});

test("Solicitado é registrado como pedido; Seguir mantém a incerteza e nunca volta à fila", () => {
  for (const status of ["requested", "not_following"] as const) {
    const { account, candidate, reading, now } = fixture();
    applyCandidateRelationshipObservation(
      account,
      candidate.id,
      { ...reading, status },
      now,
    );
    assert.equal(
      candidate.stage,
      status === "requested" ? "requested" : "uncertain",
    );
    assert.equal(candidate.relationshipObserved?.status, status);
    assert.equal(candidate.confirmedFollowSource, undefined);
    assert.equal(account.data.audit[0].kind, "relationship_verified");
  }
});

test("conferência exige dono, alvo, paused, resultado uncertain de follow e leitura recente atomicamente", () => {
  const changes = [
    (f: ReturnType<typeof fixture>) => (f.reading.account = "qa.other"),
    (f: ReturnType<typeof fixture>) => (f.reading.username = "qa.other"),
    (f: ReturnType<typeof fixture>) =>
      (f.account.data.runtime.account = "qa.other"),
    (f: ReturnType<typeof fixture>) =>
      (f.account.data.runtime.mode = "running"),
    (f: ReturnType<typeof fixture>) => (f.candidate.stage = "approved"),
    (f: ReturnType<typeof fixture>) => (f.candidate.queuedAction = "unfollow"),
    (f: ReturnType<typeof fixture>) => (f.candidate.queueAccount = "qa.other"),
    (f: ReturnType<typeof fixture>) =>
      (f.reading.at = new Date(f.now.getTime() - 121000).toISOString()),
    (f: ReturnType<typeof fixture>) =>
      (f.reading.at = new Date(f.now.getTime() + 61000).toISOString()),
    (f: ReturnType<typeof fixture>) => (f.reading.status = "unknown" as never),
  ];
  for (const change of changes) {
    const f = fixture();
    change(f);
    const before = structuredClone(f.account);
    assert.throws(() =>
      applyCandidateRelationshipObservation(
        f.account,
        f.candidate.id,
        f.reading,
        f.now,
      ),
    );
    assert.deepEqual(f.account, before);
  }
});

test("prova anterior preservada não se torna um novo ciclo de unfollow após observação", () => {
  const { account, candidate, now, reading } = fixture();
  candidate.confirmedFollowAt = new Date(
    now.getTime() - 40 * 86400000,
  ).toISOString();
  candidate.confirmedFollowAccount = account.username;
  candidate.confirmedFollowSource = "orbita";
  const proof = [
    candidate.confirmedFollowAt,
    candidate.confirmedFollowAccount,
    candidate.confirmedFollowSource,
  ];
  applyCandidateRelationshipObservation(account, candidate.id, reading, now);
  assert.deepEqual(
    [
      candidate.confirmedFollowAt,
      candidate.confirmedFollowAccount,
      candidate.confirmedFollowSource,
    ],
    proof,
  );
  assert.equal(
    unfollowEligibility(
      account,
      candidate,
      new Date(now.getTime() + 10 * 86400000),
    ).eligible,
    false,
  );
  // A later, separately confirmed native action can supply a genuinely newer proof.
  candidate.confirmedFollowAt = new Date(now.getTime() + 1000).toISOString();
  assert.equal(
    unfollowEligibility(
      account,
      candidate,
      new Date(now.getTime() + 10 * 86400000),
    ).eligible,
    true,
  );
});

test("migração preserva observação nativa e RESTORE a identifica como histórico sem prova de clique", () => {
  const { store, account, candidate, reading, now } = fixture();
  applyCandidateRelationshipObservation(account, candidate.id, reading, now);
  const observation = structuredClone(candidate.relationshipObserved);
  const reloaded = migrateStore(structuredClone(store));
  assert.deepEqual(
    workspace(reloaded).data.candidates[0].relationshipObserved,
    observation,
  );
  const backup = accountBackup(account);
  const backupBefore = structuredClone(backup);
  const restored = applyScopedCommand(store, account.id, {
    type: "RESTORE",
    data: backup,
  });
  const restoredCandidate = workspace(restored).data.candidates[0];
  assert.equal(restoredCandidate.relationshipObserved?.source, "restored");
  assert.equal(restoredCandidate.relationshipObserved?.status, "following");
  assert.equal(restoredCandidate.stage, "followed");
  assert.equal(restoredCandidate.confirmedFollowSource, undefined);
  assert.deepEqual(backup, backupBefore);
  assert.deepEqual(
    workspace(restored).data.dailyAttempts,
    account.data.dailyAttempts,
  );
  assert.deepEqual(
    workspace(restored).data.lastAttempts,
    account.data.lastAttempts,
  );
  const legacy = restoreState(account.data);
  assert.equal(legacy.candidates[0].relationshipObserved?.source, "restored");
});

test("persistência e backup recusam observação de outro dono, fonte ou calendário inválidos", () => {
  for (const patch of [
    { account: "qa.other" },
    { source: "orbita" },
    { at: "2026-02-30T12:00:00Z" },
    { status: "already" },
    { at: "2050-01-01T12:00:00Z" },
  ]) {
    const { store, candidate, reading } = fixture();
    candidate.relationshipObserved = {
      account: reading.account,
      at: reading.at,
      status: "following",
      source: "instagram",
      ...patch,
    } as never;
    assert.throws(() => migrateStore(structuredClone(store)), /observação/);
    assert.throws(() => restoreState(workspace(store).data), /observação/);
  }
  const { candidate } = fixture();
  candidate.relationshipObserved = null as never;
  assert.throws(
    () => validateCandidateRelationshipObservation(candidate, "qa.owner"),
    /observação/,
  );
});

test("uma resposta antiga não substitui observação mais recente em outra aba", () => {
  const { account, candidate, reading, now } = fixture();
  applyCandidateRelationshipObservation(
    account,
    candidate.id,
    { ...reading, status: "not_following" },
    now,
  );
  const before = structuredClone(account);
  assert.throws(
    () =>
      applyCandidateRelationshipObservation(
        account,
        candidate.id,
        { ...reading, at: new Date(now.getTime() - 1).toISOString() },
        now,
      ),
    /mais recente/,
  );
  assert.deepEqual(account, before);
});

test("uncertain só retorna à revisão por escolha explícita após observar Seguir nativamente", () => {
  const { store, account, candidate, reading, now } = fixture();
  assert.throws(
    () =>
      applyScopedCommand(store, account.id, {
        type: "RETURN_TO_REVIEW",
        id: candidate.id,
        confirmed: true,
      }),
    /sem clique/,
  );
  applyCandidateRelationshipObservation(
    account,
    candidate.id,
    { ...reading, status: "not_following" },
    now,
  );
  const before = structuredClone(account.data);
  assert.throws(
    () =>
      applyScopedCommand(store, account.id, {
        type: "RETURN_TO_REVIEW",
        id: candidate.id,
      }),
    /confirme manualmente/,
  );
  const restored = applyScopedCommand(store, account.id, {
    type: "RETURN_TO_REVIEW",
    id: candidate.id,
    confirmed: true,
  });
  const returned = workspace(restored).data;
  assert.equal(returned.candidates[0].stage, "new");
  assert.equal(returned.candidates[0].queueAccount, undefined);
  assert.equal(returned.candidates[0].queuedAction, undefined);
  assert.equal(
    returned.candidates[0].relationshipObserved?.status,
    "not_following",
  );
  assert.deepEqual(returned.dailyAttempts, before.dailyAttempts);
  assert.deepEqual(returned.lastAttempts, before.lastAttempts);
  assert.deepEqual(returned.settings, before.settings);
  assert.deepEqual(returned.runtime, before.runtime);
  assert.equal(
    returned.candidates.some((row) => row.stage === "queued"),
    false,
  );
});

test("observação positiva, restaurada ou de outra conta nunca permite recomeçar follow", () => {
  for (const status of ["following", "requested", "not_following"] as const) {
    const { store, account, candidate, reading, now } = fixture();
    applyCandidateRelationshipObservation(
      account,
      candidate.id,
      { ...reading, status },
      now,
    );
    if (status === "not_following")
      candidate.relationshipObserved!.source = "restored";
    assert.throws(() =>
      applyScopedCommand(store, account.id, {
        type: "RETURN_TO_REVIEW",
        id: candidate.id,
        confirmed: true,
      }),
    );
    candidate.stage = "uncertain";
    if (status === "not_following") {
      candidate.relationshipObserved!.source = "instagram";
      candidate.relationshipObserved!.account = "qa.other";
    }
    assert.throws(() =>
      applyScopedCommand(store, account.id, {
        type: "RETURN_TO_REVIEW",
        id: candidate.id,
        confirmed: true,
      }),
    );
  }
});
