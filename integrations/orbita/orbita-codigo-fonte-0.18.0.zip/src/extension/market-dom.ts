import { marketUrl } from "../core/market.ts";
import {
  detectAccount,
  exactCount,
  pageRestriction,
  usernameFromHref,
} from "./dom.ts";
import type { MarketPageReading } from "../core/types.ts";

const labelMatches = (root: Element, re: RegExp) =>
  [...root.querySelectorAll("[aria-label]")].filter((e) =>
    re.test((e.getAttribute("aria-label") || "").trim()),
  );
const hasPostActions = (root: Element) =>
  labelMatches(root, /^(curtir|descurtir|like|unlike)$/i).length > 0 &&
  labelMatches(root, /^(comentar|comment)$/i).length > 0;
const commentPath = (a: Element, base: string) => {
  try {
    const u = new URL(a.getAttribute("href") || "", base);
    return u.origin === "https://www.instagram.com" &&
      /^\/(?:p|reel)\/[\w-]+\/c\/\d+\/?$/.test(u.pathname)
      ? u.pathname
      : undefined;
  } catch {
    return undefined;
  }
};
function postText(root: Element, base: string, modern: boolean) {
  if (!modern) return (root as HTMLElement).innerText ?? root.textContent ?? "";
  const copy = root.cloneNode(true) as Element;
  for (const anchor of [...copy.querySelectorAll("a[href]")]) {
    if (!commentPath(anchor, base) || !copy.contains(anchor)) continue;
    let removed = false;
    for (
      let row = anchor.parentElement;
      row && row !== copy;
      row = row.parentElement
    ) {
      const ids = new Set(
        [...row.querySelectorAll("a[href]")]
          .map((a) => commentPath(a, base))
          .filter(Boolean),
      );
      if (ids.size > 1) break;
      const reply = [...row.querySelectorAll('button,[role="button"]')].some(
        (b) => /^(responder|reply)$/i.test((b.textContent || "").trim()),
      );
      if (
        reply &&
        labelMatches(row, /^(curtir|descurtir|like|unlike)$/i).length
      ) {
        row.remove();
        removed = true;
        break;
      }
    }
    if (!removed)
      throw new Error(
        "Os comentários não puderam ser separados da publicação. Registre a referência manualmente.",
      );
  }
  return copy.textContent || "";
}
function iconCount(root: Element, label: RegExp): number | undefined {
  const controls = new Set(
    labelMatches(root, label)
      .map((e) => e.closest('button,[role="button"]'))
      .filter((e): e is Element => !!e),
  );
  if (controls.size !== 1) return;
  const control = [...controls][0];
  for (
    let group = control.parentElement;
    group && root.contains(group);
    group = group.parentElement
  ) {
    const actionTypes = [
      /^(curtir|descurtir|like|unlike)$/i,
      /^(comentar|comment)$/i,
      /^(repostar|repost)$/i,
    ].filter((re) => labelMatches(group, re).length);
    if (actionTypes.length > 1) return;
    const numbers = [...group.querySelectorAll('button,[role="button"]')]
      .map((e) => (e.textContent || "").trim())
      .filter((s) => /^\d+(?:[., \u00a0]\d{3})*$/.test(s));
    if (numbers.length === 1) return exactCount(numbers[0]);
    if (numbers.length > 1) return;
    if (group === root) break;
  }
}

export function readMarketPage(
  doc: Document,
  url: string,
  expectedOwn?: string,
): MarketPageReading {
  const clean = marketUrl(url, true),
    path = new URL(clean).pathname,
    blocked = pageRestriction(doc, path);
  if (blocked) throw new Error(blocked);
  const kind = /^\/reel\//.test(path)
    ? "reel"
    : /^\/p\//.test(path)
      ? "post"
      : "profile";
  if (
    expectedOwn &&
    (kind !== "profile" ||
      usernameFromHref(path) !== expectedOwn ||
      detectAccount(doc) !== expectedOwn)
  )
    throw new Error(
      "A sessão e o perfil precisam corresponder à conta selecionada.",
    );
  let scope: Element | null = doc.querySelector("main header");
  let metricsScope: Element | null = null;
  let creator = kind === "profile" ? usernameFromHref(path) || "" : "";
  let modern = false;
  if (kind !== "profile") {
    const dates = [
      ...doc.querySelectorAll<HTMLAnchorElement>("a[href]"),
    ].filter((a) => {
      try {
        return (
          !!a.querySelector("time") &&
          marketUrl(new URL(a.getAttribute("href")!, clean).href, true) ===
            clean
        );
      } catch {
        return false;
      }
    });
    const articles = new Set(
      dates
        .map((a) => a.closest("article"))
        .filter((a): a is HTMLElement => !!a),
    );
    if (articles.size === 0 && dates.length === 1) {
      const date = dates[0];
      const owner = new URL(date.getAttribute("href")!, clean).pathname
        .match(/^\/([a-z0-9._]{1,30})\/(?:p|reel)\/[\w-]+\/?$/i)?.[1]
        ?.toLowerCase();
      const boundary = date.closest('main,[role="main"],[role="dialog"]');
      if (owner && boundary) {
        for (
          let candidate = date.parentElement;
          candidate && candidate !== boundary;
          candidate = candidate.parentElement
        ) {
          const datedPosts = new Set(
            [...candidate.querySelectorAll<HTMLAnchorElement>("a[href]")]
              .filter((a) => a.querySelector("time"))
              .flatMap((a) => {
                try {
                  return [
                    marketUrl(
                      new URL(a.getAttribute("href")!, clean).href,
                      true,
                    ),
                  ];
                } catch {
                  return [];
                }
              }),
          );
          if (datedPosts.size !== 1 || !datedPosts.has(clean)) break;
          if (
            !metricsScope &&
            hasPostActions(candidate) &&
            ![...candidate.querySelectorAll("a[href]")].some((a) =>
              commentPath(a, clean),
            )
          )
            metricsScope = candidate;
          const options = labelMatches(
            candidate,
            /^(mais opções|more options)$/i,
          );
          const hasOwner = [...candidate.querySelectorAll("a[href]")].some(
            (a) => usernameFromHref(a.getAttribute("href") || "") === owner,
          );
          if (metricsScope && options.length === 1 && hasOwner) {
            articles.add(candidate as HTMLElement);
            creator = owner;
            modern = true;
            break;
          }
          if (candidate.querySelector("article")) break;
        }
      }
    }
    if (articles.size !== 1)
      throw new Error(
        "A publicação não pôde ser confirmada por um link de data único no conteúdo carregado. Registre a referência manualmente.",
      );
    scope = [...articles][0];
    if (scope.querySelector("article"))
      throw new Error(
        "A página mistura publicações; registre a referência manualmente.",
      );
  }
  if (!scope)
    throw new Error(
      "A página não mostrou um cabeçalho ou publicação reconhecível. Abra no Instagram e registre a referência manualmente.",
    );
  const text = postText(scope, clean, modern);
  if (!text.trim())
    throw new Error("O texto da página ainda não está disponível.");
  if (
    /(?:esta conta [ée] privada|this account is private|conte[uú]do indispon[ií]vel|content unavailable)/i.test(
      text,
    )
  )
    throw new Error("O conteúdo está privado ou indisponível; não foi lido.");
  if (
    kind === "profile" &&
    ![...scope.querySelectorAll("h1,h2")].some(
      (h) => h.textContent?.trim().toLowerCase() === usernameFromHref(path),
    )
  )
    throw new Error("Não foi possível confirmar o perfil no cabeçalho.");
  const metrics: MarketPageReading["metrics"] = {};
  if (kind !== "profile") {
    const labels = {
      views: /^(\d+(?:[., \u00a0]\d{3})*)\s+(?:visualizaç[õo]es|views)$/i,
      likes: /^(\d+(?:[., \u00a0]\d{3})*)\s+(?:curtidas|likes)$/i,
      comments:
        /^(?:ver todos os |view all )?(\d+(?:[., \u00a0]\d{3})*)\s+(?:coment[áa]rios|comments)$/i,
    };
    const metricText = metricsScope
      ? ((metricsScope as HTMLElement).innerText ??
        metricsScope.textContent ??
        "")
      : text;
    const lines = metricText.split(/[\r\n]+/).map((s) => s.trim());
    for (const [key, re] of Object.entries(labels)) {
      const values = new Set(
        lines
          .map((s) => s.match(re)?.[1])
          .filter((s): s is string => !!s)
          .map((s) =>
            new Set(
              s.match(/[., \u00a0]/g)?.map((c) => (c === "\u00a0" ? " " : c)),
            ).size > 1
              ? undefined
              : exactCount(s),
          )
          .filter((n): n is number => n !== undefined),
      );
      if (values.size === 1)
        metrics[key as keyof typeof metrics] = [...values][0];
    }
    if (metricsScope) {
      const likes = iconCount(
        metricsScope,
        /^(curtir|descurtir|like|unlike)$/i,
      );
      const comments = iconCount(metricsScope, /^(comentar|comment)$/i);
      if (likes !== undefined) metrics.likes = likes;
      if (comments !== undefined) metrics.comments = comments;
    }
  }
  return {
    url: clean,
    kind,
    creator,
    text: text.slice(0, 2200),
    metrics,
    observedAt: new Date().toISOString(),
  };
}
