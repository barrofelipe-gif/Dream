import test from "node:test";
import assert from "node:assert/strict";
import { JSDOM } from "jsdom";
import {
  collectLoaded,
  detectAccount,
  pageRestriction,
  profileControls,
  readOwnRelationships,
  unfollowMenu,
  usernameFromHref,
} from "../src/extension/dom.ts";
const documentOf = (html: string) =>
  new JSDOM(html, { url: "https://www.instagram.com/alvo/" }).window.document;

// Sanitized from the observed profile/menu structure; no account or client data.
const followingProfile = '<nav><a href="/minha.conta/">Perfil</a></nav><main><header><h2>alvo</h2><button id="following">Seguindo<svg><title>Ícone de seta para baixo</title></svg></button></header></main>';
const followingMenu = (username = "alvo") => `<div role="dialog"><div><span>${username}</span></div><div><span>Amigos Próximos</span></div><div><span>Favoritos</span></div><div><span>Silenciar</span></div><div><span>Restringir</span></div><div role="button" id="unfollow"><div><span><span>Deixar de seguir</span></span></div></div></div>`;

test("coleta todos os perfis carregados acima de 11 e deduplica avatares", () => {
  const links = Array.from({ length: 73 }, (_, i) => `<a href="/qa.pessoa${i}/">avatar</a><a href="/qa.pessoa${i}/">qa.pessoa${i}</a>`).join("");
  const doc = documentOf(`<main><a href="/qa.origem/p/QApost/"><time datetime="2026-10-01T12:00:00Z">data</time></a></main><div role="dialog"><div role="heading">Curtidas</div>${links}</div>`);
  assert.equal(collectLoaded(doc, "likers", "https://www.instagram.com/p/QApost/", "minha.conta", "qa.origem").candidates.length, 73);
  assert.throws(() => collectLoaded(doc, "likers", "https://www.instagram.com/p/QApost/", "minha.conta", "outro.perfil"), /pertence ao perfil/);
});

test("rede própria lê somente diálogo, sessão e rota correspondentes; retorno sempre parcial", () => {
  const html = '<nav><a href="/minha.conta/">Perfil</a></nav><main><header><h2>minha.conta</h2></header><a href="/sugestao/">sugestao</a></main><div role="dialog"><div role="heading">Seguidores</div><a href="/qa.pessoa/">avatar</a><a href="/qa.pessoa/">qa.pessoa</a><a href="/qa.outra/">qa.outra</a></div>';
  const result = readOwnRelationships(documentOf(html), "/minha.conta/followers/", "minha.conta", "followers");
  assert.deepEqual(result.usernames, ["qa.pessoa", "qa.outra"]);
  assert.equal(result.complete, false);
  assert.equal(result.account, "minha.conta");
  assert.ok(Number.isFinite(Date.parse(result.at)));
  assert.throws(() => readOwnRelationships(documentOf(html), "/minha.conta/following/", "minha.conta", "following"), /somente a lista Seguindo/);
  assert.throws(() => readOwnRelationships(documentOf(html), "/outra.conta/followers/", "minha.conta", "followers"), /própria conta/);
  assert.throws(() => readOwnRelationships(documentOf(html.replace('href="/minha.conta/"', 'href="/outra.conta/"')), "/minha.conta/followers/", "minha.conta", "followers"), /conta da sessão/);
  assert.throws(() => readOwnRelationships(documentOf(html + '<div role="dialog">Outro modal</div>'), "/minha.conta/followers/", "minha.conta", "followers"), /somente a lista/);
});

test("coletor acumula novos trechos e ignora retorno tardio de uma fonte anterior", async () => {
  const keys = ["document", "location", "chrome", "__orbita_content_v1__"];
  const descriptors = new Map(keys.map((key) => [key, Object.getOwnPropertyDescriptor(globalThis, key)]));
  const dom = new JSDOM('<nav><a href="/minha.conta/">Perfil</a></nav><div role="dialog"></div>', { url: "https://www.instagram.com/qa.origem/followers/" });
  const put = (key: string, value: unknown) => Object.defineProperty(globalThis, key, { configurable: true, writable: true, value });
  let listener: Function | undefined, finishPrevious: Function | undefined;
  const captures: any[] = [], saved = new Set<string>();
  const render = (start: number, count: number) => { dom.window.document.querySelector('[role="dialog"]')!.innerHTML = Array.from({ length: count }, (_, i) => `<a href="/qa.pessoa${start + i}/">qa.pessoa${start + i}</a>`).join(""); };
  const settle = () => new Promise((resolve) => setTimeout(resolve, 0));
  try {
    put("document", dom.window.document); put("location", dom.window.location); put("__orbita_content_v1__", false);
    put("chrome", { runtime: { id: "fixture-extension", onMessage: { addListener(fn: Function) { listener = fn; } }, async sendMessage(message: any) {
      if (message.type !== "CAPTURE") return { ok: false };
      captures.push(message);
      if (message.campaignId === "previous-source") return new Promise((resolve) => { finishPrevious = resolve; });
      message.candidates.forEach((candidate: any) => saved.add(candidate.username));
      return { ok: true, total: saved.size };
    } } });
    const modulePath = "../src/extension/content.ts?fixture-collector-accumulation";
    await import(modulePath);
    const show = (id: string) => listener!({ type: "COLLECTOR", campaign: { id, name: "Fonte fictícia", kind: "followers", target: "@qa.origem" }, savedCount: 0 }, { id: "fixture-extension" }, () => {});
    const shadow = () => dom.window.document.querySelector("#orbita-collector")!.shadowRoot!;
    render(0, 30); show("previous-source"); (shadow().querySelector("#capture") as HTMLElement).click(); await settle();
    render(0, 25); show("current-source"); (shadow().querySelector("#capture") as HTMLElement).click(); await settle();
    assert.match(shadow().querySelector("#progress")!.textContent!, /25 carregados agora · 25 únicos salvos/);
    finishPrevious!({ ok: true, total: 999 }); await settle();
    assert.match(shadow().querySelector("#progress")!.textContent!, /25 únicos salvos/);
    render(20, 20); (shadow().querySelector("#capture") as HTMLElement).click(); await settle();
    assert.equal(captures.at(-1).candidates.length, 15);
    assert.match(shadow().querySelector("#progress")!.textContent!, /20 carregados agora · 40 únicos salvos/);
    assert.equal(captures.length, 3);
  } finally {
    dom.window.close();
    for (const key of keys) { const descriptor = descriptors.get(key); if (descriptor) Object.defineProperty(globalThis, key, descriptor); else delete (globalThis as any)[key]; }
  }
});

test("Seguindo com descrição SVG mantém o estado e o botão único do perfil", () => {
  const doc = documentOf(followingProfile);
  const controls = profileControls(doc, "/alvo/", "alvo");
  assert.equal(controls.state, "followed");
  assert.equal(controls.following, doc.querySelector("#following"));
  assert.equal(controls.follow, undefined);
  doc.querySelector("header")!.insertAdjacentHTML("beforeend", "<button>Seguir</button>");
  assert.ok(profileControls(doc, "/alvo/", "alvo").error);
});

test("deixar de seguir exige menu único, identidade e todas as opções observadas", () => {
  const valid = documentOf(followingProfile + followingMenu());
  assert.equal(unfollowMenu(valid, "/alvo/", "alvo").unfollow, valid.querySelector("#unfollow"));
  for (const html of [
    followingProfile + followingMenu("outra.pessoa"),
    followingProfile + followingMenu() + '<div role="dialog">Outro diálogo</div>',
    followingProfile + '<div role="dialog"><span>alvo</span><div role="button">Deixar de seguir</div></div>',
    followingProfile + followingMenu().replace('<div><span>Restringir</span></div>', ""),
    followingProfile + followingMenu().slice(0, -6) + '<div role="button">Deixar de seguir</div></div>',
  ]) assert.equal(unfollowMenu(documentOf(html), "/alvo/", "alvo").unfollow, undefined);
  assert.equal(unfollowMenu(valid, "/outro/", "alvo").unfollow, undefined);
});

test("menu aceita textos completos PT e EN das opções, mantendo correspondência exata", () => {
  // Same DIV layout as the isolated Chrome reproduction, without roles on the four options.
  for (const [friends, favorites, mute, restrict, unfollow] of [
    ["Adicionar à lista Amigos Próximos", "Adicionar aos Favoritos", "Silenciar", "Restringir", "Deixar de seguir"],
    ["Add to close friends list", "Add to favorites", "Mute", "Restrict", "Unfollow"],
  ]) {
    const menu = `<div role="dialog"><div>alvo</div><div>${friends}</div><div>${favorites}</div><div>${mute}</div><div>${restrict}</div><div role="button" id="unfollow"><span>${unfollow}</span></div></div>`;
    const doc = documentOf(followingProfile + menu);
    assert.equal(unfollowMenu(doc, "/alvo/", "alvo").unfollow, doc.querySelector("#unfollow"));
    assert.equal(unfollowMenu(documentOf(followingProfile + menu.replace(friends, `${friends} texto adicional`)), "/alvo/", "alvo").unfollow, undefined);
  }
});

test("executor de deixar de seguir envia um único clique autorizado e para em estados incertos", async (t) => {
  const originalTimer = globalThis.setTimeout;
  const keys = ["document", "location", "chrome", "__orbita_content_v1__"];
  const descriptors = new Map(keys.map((key) => [key, Object.getOwnPropertyDescriptor(globalThis, key)]));
  const put = (key: string, value: unknown) => Object.defineProperty(globalThis, key, { configurable: true, writable: true, value });
  let serial = 0;
  try {
    // Only synthetic DOM timers are accelerated. These tests never open a browser.
    globalThis.setTimeout = ((callback: (...args: any[]) => void, _delay?: number, ...args: any[]) => originalTimer(callback, 0, ...args)) as typeof setTimeout;
    for (const scenario of ["confirmed", "additional-dialog", "already-not-following", "wrong-session", "replaced-button", "expired", "denied", "platform-warning", "unknown-after-click"] as const) {
      await t.test(scenario, async () => {
        const dom = new JSDOM(followingProfile, { url: "https://www.instagram.com/alvo/" });
        const doc = dom.window.document;
        let listener: Function | undefined;
        let opened = 0, clicked = 0;
        const authorizations: any[] = [];
        if (scenario === "already-not-following") doc.querySelector("#following")!.textContent = "Seguir";
        if (scenario === "wrong-session") doc.querySelector("nav a")!.setAttribute("href", "/outra.conta/");
        doc.querySelector("#following")!.addEventListener("click", () => {
          opened++;
          doc.body.insertAdjacentHTML("beforeend", followingMenu());
          doc.querySelector("#unfollow")!.addEventListener("click", () => {
            clicked++;
            doc.querySelector('[role="dialog"]')!.remove();
            if (scenario === "additional-dialog") doc.body.insertAdjacentHTML("beforeend", '<div role="dialog"><button>Deixar de seguir</button></div>');
            else if (scenario === "platform-warning") doc.body.insertAdjacentHTML("beforeend", '<div role="dialog">Tente novamente mais tarde</div>');
            else if (scenario === "unknown-after-click") doc.querySelector("#following")!.textContent = "Carregando";
            else doc.querySelector("#following")!.textContent = "Seguir";
          });
        });
        put("document", doc);
        put("location", dom.window.location);
        put("__orbita_content_v1__", false);
        put("chrome", { runtime: { id: "fixture-extension", onMessage: { addListener(fn: Function) { listener = fn; } }, async sendMessage(message: any) {
          if (message.type !== "AUTHORIZE_CLICK") return { ok: false };
          authorizations.push(message);
          if (scenario === "replaced-button") {
            const button = doc.querySelector("#unfollow")!;
            button.replaceWith(button.cloneNode(true));
          }
          return { ok: scenario !== "denied" };
        } } });
        await import(`../src/extension/content.ts?fixture-unfollow=${serial++}`);
        const result: any = await new Promise((resolve) => listener!({ type: "UNFOLLOW", username: "alvo", expectedAccount: "minha.conta", token: "one-use", expiresAt: Date.now() + (scenario === "expired" ? -1 : 10000) }, { id: "fixture-extension" }, resolve));
        assert.equal(result.action, "unfollow");
        if (scenario === "confirmed") {
          assert.equal(result.stage, "unfollowed");
          assert.equal(result.clickSent, true);
          assert.equal(clicked, 1);
        } else if (["additional-dialog", "platform-warning", "unknown-after-click"].includes(scenario)) {
          assert.equal(result.stage, "uncertain");
          assert.equal(result.stop, true);
          assert.equal(clicked, 1);
        } else {
          assert.equal(result.stage, "failed");
          assert.equal(result.stop, true);
          assert.equal(clicked, 0);
        }
        assert.ok(opened <= 1);
        assert.ok(authorizations.length <= 1);
        if (authorizations.length) assert.equal(authorizations[0].action, "unfollow");
        if (["already-not-following", "wrong-session", "expired"].includes(scenario)) {
          assert.equal(opened, 0);
          assert.equal(authorizations.length, 0);
        }
        if (scenario === "already-not-following") assert.match(result.message, /nenhum clique foi enviado/);
        if (scenario === "platform-warning") assert.equal(result.platformWarning, true);
        dom.window.close();
      });
    }
  } finally {
    globalThis.setTimeout = originalTimer;
    for (const key of keys) {
      const descriptor = descriptors.get(key);
      if (descriptor) Object.defineProperty(globalThis, key, descriptor);
      else delete (globalThis as any)[key];
    }
  }
});
test("identifica a conta apenas pelo menu de Perfil, não por conteúdo ou sugestões", () => {
  const doc = documentOf(
    '<nav><a href="/minha.conta/">Perfil</a></nav><main><a href="/falso/">Perfil</a><article><a href="/outro/">Profile</a></article></main>',
  );
  assert.equal(detectAccount(doc), "minha.conta");
  assert.equal(
    detectAccount(documentOf('<main><a href="/falso/">Perfil</a></main>')),
    null,
  );
  assert.equal(
    detectAccount(
      documentOf(
        '<nav><a href="/um/">Perfil</a><a href="/dois/">Profile</a></nav>',
      ),
    ),
    null,
  );
});
test("captura modal carregado e exclui links externos, rotas e conta própria", () => {
  const doc = documentOf(
    '<a href="/fora/">Sugestão fora da lista</a><div role="dialog"><a href="/ana/">ana</a><a href="/ana/">foto</a><a href="/bia/">bia</a><a href="/minha/">minha</a><a href="/explore/">Explorar</a><a href="https://evil.test/roubo/">externo</a></div>',
  );
  const result = collectLoaded(doc, "followers", "@alvo", "minha");
  assert.deepEqual(
    result.candidates.map((c) => c.username),
    ["ana", "bia"],
  );
  assert.equal(result.candidates[0].followers, undefined);
  assert.match(result.message, /parcial/);
});
test("captura recusa modais ausentes ou ambíguos", () => {
  assert.throws(() =>
    collectLoaded(
      documentOf('<main><a href="/ana/">Ana</a></main>'),
      "followers",
      "@alvo",
    ),
  );
  assert.throws(() =>
    collectLoaded(
      documentOf('<div role="dialog"></div><div role="dialog"></div>'),
      "likers",
      "url",
    ),
  );
});
test("comentários não capturam a barra lateral de sugestões", () => {
  const doc = documentOf(
    '<aside><a href="/sugerido/">Sugerido</a></aside><main><article><ul><li><a href="/ana/">Ana</a><span>Comentário</span></li><li><a href="/bia/">Bia</a></li></ul></article></main>',
  );
  assert.deepEqual(
    collectLoaded(doc, "commenters", "url").candidates.map((c) => c.username),
    ["ana", "bia"],
  );
});
test("seguir exige identidade do perfil e um único botão no cabeçalho", () => {
  const doc = documentOf(
    "<main><header><h2>alvo</h2><button>Seguir</button></header><section><button>Seguir</button></section></main>",
  );
  assert.ok(profileControls(doc, "/alvo/", "alvo").follow);
  assert.ok(profileControls(doc, "/outro/", "alvo").error);
  assert.ok(profileControls(doc, "/alvo/", "falso").error);
  const ambiguous = documentOf(
    "<main><header><h2>alvo</h2><button>Seguir</button><button>Seguir</button></header></main>",
  );
  assert.ok(profileControls(ambiguous, "/alvo/", "alvo").error);
});
test("estado existente nunca oferece clique de seguir", () => {
  for (const [label, state] of [
    ["Seguindo", "followed"],
    ["Following", "followed"],
    ["Solicitado", "requested"],
    ["Requested", "requested"],
  ]) {
    const controls = profileControls(
      documentOf(
        `<main><header><h2>alvo</h2><button>${label}</button></header></main>`,
      ),
      "/alvo/",
      "alvo",
    );
    assert.equal(controls.state, state);
    assert.equal(controls.follow, undefined);
  }
});

test("controle principal ignora sugestões no mesmo header sem aceitar controle de outro perfil", () => {
  const suggestions = Array.from({ length: 9 }, (_, index) => `<div><a href="/qa.sugestao${index}/">qa.sugestao${index}</a><button>Seguir</button></div>`).join("");
  const html = `<main><header><div><section><a href="/alvo/" role="link"><h2>alvo</h2></a></section></div><section></section><section><button id="target">Seguindo<svg><title>Ícone de seta para baixo</title></svg></button><button>Enviar mensagem</button><button>Contas semelhantes</button></section><section></section><section></section><section>${suggestions}</section></header></main>`;
  const doc = documentOf(html);
  assert.equal(profileControls(doc, "/alvo/", "alvo").state, "followed");
  assert.equal(profileControls(doc, "/alvo/", "alvo").following, doc.querySelector("#target"));
  doc.querySelector("#target")!.remove();
  assert.ok(profileControls(doc, "/alvo/", "alvo").error);
  assert.ok(profileControls(documentOf(html), "/outro/", "alvo").error);
});

test("sugestões entrando depois do follow confirmam o alvo com um único clique", async () => {
  const keys = ["document", "location", "chrome", "__orbita_content_v1__"];
  const descriptors = new Map(keys.map((key) => [key, Object.getOwnPropertyDescriptor(globalThis, key)]));
  const originalTimer = globalThis.setTimeout;
  const dom = new JSDOM('<nav><a href="/minha.conta/">Perfil</a></nav><main><header><div><section><a href="/alvo/" role="link"><h2>alvo</h2></a></section></div><section></section><section><button id="target">Seguir</button><button>Enviar mensagem</button><button>Contas semelhantes</button></section><section></section><section></section><section id="suggestions"></section></header></main>', { url: "https://www.instagram.com/alvo/" });
  let listener: Function | undefined;
  let targetClicks = 0, suggestionClicks = 0, authorizations = 0;
  const put = (key: string, value: unknown) => Object.defineProperty(globalThis, key, { configurable: true, writable: true, value });
  try {
    const doc = dom.window.document;
    doc.querySelector("#target")!.addEventListener("click", () => {
      targetClicks++;
      doc.querySelector("#target")!.innerHTML = 'Seguindo<svg><title>Ícone de seta para baixo</title></svg>';
      doc.querySelector("#suggestions")!.innerHTML = Array.from({ length: 9 }, (_, i) => `<div><a href="/qa.sugestao${i}/">qa.sugestao${i}</a><button>Seguir</button></div>`).join("");
      doc.querySelectorAll("#suggestions button").forEach((button) => button.addEventListener("click", () => suggestionClicks++));
    });
    put("document", doc); put("location", dom.window.location); put("__orbita_content_v1__", false);
    put("chrome", { runtime: { id: "fixture-extension", onMessage: { addListener(fn: Function) { listener = fn; } }, async sendMessage(message: any) {
      if (message.type !== "AUTHORIZE_CLICK") return { ok: false };
      assert.equal(message.action, "follow"); authorizations++; return { ok: true };
    } } });
    globalThis.setTimeout = ((callback: (...args: any[]) => void, _delay?: number, ...args: any[]) => originalTimer(callback, 0, ...args)) as typeof setTimeout;
    const modulePath = "../src/extension/content.ts?fixture-follow-suggestions";
    await import(modulePath);
    const result: any = await new Promise((resolve) => listener!({ type: "FOLLOW", username: "alvo", expectedAccount: "minha.conta", token: "one-use", expiresAt: Date.now() + 10000 }, { id: "fixture-extension" }, resolve));
    assert.equal(result.stage, "followed");
    assert.equal(result.clickSent, true);
    assert.equal(targetClicks, 1);
    assert.equal(suggestionClicks, 0);
    assert.equal(authorizations, 1);
    await new Promise((resolve) => originalTimer(resolve, 0));
    for (const [label, status] of [["Seguindo", "following"], ["Solicitado", "requested"], ["Seguir", "not_following"]]) {
      doc.querySelector("#target")!.textContent = label;
      const observed: any = await new Promise((resolve) => listener!({ type: "PROFILE_RELATIONSHIP_STATE", username: "alvo", expectedAccount: "minha.conta" }, { id: "fixture-extension" }, resolve));
      assert.equal(observed.ok, true);
      assert.equal(observed.data.status, status);
      assert.equal(observed.data.account, "minha.conta");
      assert.equal(observed.data.username, "alvo");
      assert.equal(targetClicks, 1);
      assert.equal(suggestionClicks, 0);
      assert.equal(authorizations, 1);
    }
  } finally {
    globalThis.setTimeout = originalTimer; dom.window.close();
    for (const key of keys) { const descriptor = descriptors.get(key); if (descriptor) Object.defineProperty(globalThis, key, descriptor); else delete (globalThis as any)[key]; }
  }
});
test("desafios e restrições interrompem; texto normal de posts não dispara bloqueio", () => {
  assert.ok(pageRestriction(documentOf(""), "/challenge/123"));
  assert.ok(
    pageRestriction(
      documentOf('<div role="dialog">Tente novamente mais tarde</div>'),
      "/alvo/",
    ),
  );
  assert.equal(
    pageRestriction(
      documentOf(
        "<article>Tente novamente mais tarde: uma história sobre viagens</article>",
      ),
      "/alvo/",
    ),
    null,
  );
});
test("links de mídia e domínios parecidos nunca viram usernames", () => {
  assert.equal(usernameFromHref("/p/abc/"), null);
  assert.equal(usernameFromHref("https://instagram.com.evil.test/ana/"), null);
  assert.equal(usernameFromHref("/ana/?x=1"), "ana");
});
test("não perde o nome em âncora duplicada depois do avatar", () => {
  const doc = documentOf(
    '<div role="dialog"><a href="/ana/"><img alt="avatar"></a><a href="/ana/">Ana Artista</a></div>',
  );
  assert.equal(
    collectLoaded(doc, "followers", "@alvo").candidates[0].name,
    "Ana Artista",
  );
});
test("autor da publicação não é incluído entre comentaristas", () => {
  const doc = documentOf(
    '<main><article><header><a href="/autor/">autor</a></header><ul><li><a href="/autor/">autor</a>Legenda</li><li><a href="/ana/">ana</a>Comentário</li></ul></article></main>',
  );
  assert.deepEqual(
    collectLoaded(doc, "commenters", "url").candidates.map((c) => c.username),
    ["ana"],
  );
});

const divComment = (
  user: string,
  id: string,
  code = "QApost",
  text = "Texto de teste",
) =>
  `<div data-row><div><a role="link" href="/${user}/"><img alt="Foto do perfil" src="https://scontent.cdninstagram.com/${user}.jpg"></a></div><div><div><div><span><a role="link" href="/${user}/"><div><span>${user}</span></div></a></span><span><a role="link" href="/p/${code}/c/${id}/"><time datetime="2026-10-10T12:00:00Z">3 sem</time></a></span></div><div><span>${text}</span></div></div><div><div role="button"><span>1 curtida</span></div><div role="button"><span>Responder</span></div></div></div><div role="button"><svg aria-label="Curtir"></svg></div></div>`;
const modernPost = (rows: string, ownerCode = "QApost") =>
  documentOf(
    `<nav><a href="/qa.nav/">qa.nav</a></nav><main role="main"><div><a href="/qa.owner/">qa.owner</a><span>Legenda de teste</span><time datetime="2026-10-10T12:00:00Z">3 sem</time></div><div>${rows}</div><div role="button"><svg aria-label="Curtir"></svg></div><a href="/qa.owner/p/${ownerCode}/"><time datetime="2026-10-10T12:00:00Z">3 semanas</time></a></main><aside><a href="/qa.suggested/">qa.suggested</a></aside>`,
  );
test("comentários DIV usam permalink da fonte e excluem autor, conta própria e menções", () => {
  const doc = modernPost(
    divComment(
      "qa.client",
      "100",
      "QApost",
      'Oi <a href="/qa.mentioned/">qa.mentioned</a>',
    ) +
      divComment("qa.owner", "101") +
      divComment("qa.own", "102") +
      divComment("qa.client", "103"),
  );
  const result = collectLoaded(
    doc,
    "commenters",
    "https://www.instagram.com/p/QApost/",
    "qa.own",
  );
  assert.deepEqual(
    result.candidates.map((c) => c.username),
    ["qa.client"],
  );
  assert.equal(
    result.candidates[0].avatarUrl,
    "https://scontent.cdninstagram.com/qa.client.jpg",
  );
});
test("comentários DIV recusam permalink de outro post e dono não confirmado pelo shortcode", () => {
  assert.throws(() =>
    collectLoaded(
      modernPost(divComment("qa.client", "100", "OtherPost")),
      "commenters",
      "https://www.instagram.com/p/QApost/",
    ),
  );
  assert.throws(() =>
    collectLoaded(
      modernPost(divComment("qa.client", "100"), "OtherPost"),
      "commenters",
      "https://www.instagram.com/p/QApost/",
    ),
  );
});
test("legenda, sugestões e linhas DIV sem ação de comentário não são candidatos", () => {
  const doc = modernPost(
    divComment("qa.client", "100").replace(
      "<span>Responder</span>",
      "<span>Ver perfil</span>",
    ),
  );
  assert.throws(() =>
    collectLoaded(doc, "commenters", "https://www.instagram.com/p/QApost/"),
  );
});
test("curtidas exigem título próprio do diálogo e não capturam comentários de um postmodal", () => {
  assert.throws(() =>
    collectLoaded(
      documentOf(
        '<div role="dialog"><div role="heading">Comentários</div><a href="/qa.commenter/">qa.commenter</a></div>',
      ),
      "likers",
      "https://www.instagram.com/p/QApost/",
    ),
  );
  const doc = documentOf(
    '<div role="dialog"><div role="heading">Publicação</div><a href="/qa.outside/">qa.outside</a><div role="dialog"><div><div role="heading">Curtidas</div><svg aria-label="Fechar"></svg></div><a href="/qa.liker/">qa.liker</a><a href="/qa.liker/">Foto</a></div></div>',
  );
  assert.deepEqual(
    collectLoaded(
      doc,
      "likers",
      "https://www.instagram.com/p/QApost/",
    ).candidates.map((c) => c.username),
    ["qa.liker"],
  );
});
test("curtidas recusam dois diálogos tipados e aceitam heading Likes", () => {
  assert.throws(() =>
    collectLoaded(
      documentOf(
        '<div role="dialog"><div role="heading">Curtidas</div></div><div role="dialog"><div role="heading">Likes</div></div>',
      ),
      "likers",
      "https://www.instagram.com/p/QApost/",
    ),
  );
  assert.deepEqual(
    collectLoaded(
      documentOf(
        '<div role="dialog"><div role="heading">Likes</div><a href="/qa.liker/">qa.liker</a></div>',
      ),
      "likers",
      "https://www.instagram.com/p/QApost/",
    ).candidates.map((c) => c.username),
    ["qa.liker"],
  );
});
