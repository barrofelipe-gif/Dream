import test from "node:test";
import assert from "node:assert/strict";
import { ACCOUNT_STORE_KEY, initialStore } from "../src/core/accounts.ts";
import type { AccountStore, Candidate } from "../src/core/types.ts";
import {
  applyCommand,
  attemptsToday,
  audit,
  initialState,
  restoreState,
  validateSettings,
} from "../src/core/domain.ts";
import {
  budgetStopReason,
  pendingWarningReason,
  safetyAssessment,
  sessionLimit,
  STARTER,
  intervalReadyAt,
  lastAttemptTime,
} from "../src/core/safety.ts";

test("começo guiado define um piloto pequeno sem qualquer aumento automático", () => {
  const state = initialState();
  assert.equal(state.settings.dailyLimit, 5);
  assert.equal(state.settings.intervalMinutes, 15);
  assert.equal(sessionLimit(state.settings), 5);
  const assessment = safetyAssessment(state, 0);
  assert.equal(assessment.expanded, false);
  assert.equal(assessment.label, "Começo guiado configurado");
});
test("preferências antigas e backups recebem o controle de lote sem apagar os limites anteriores", () => {
  const settings = {
    ...initialState().settings,
    dailyLimit: 20,
    intervalMinutes: 10,
  };
  delete settings.sessionLimit;
  delete settings.hasPendingWarning;
  const validated = validateSettings(settings);
  assert.equal(validated.dailyLimit, 20);
  assert.equal(validated.sessionLimit, 5);
  assert.equal(validated.hasPendingWarning, false);
  const restored = restoreState({ ...initialState(), settings });
  assert.equal(restored.settings.dailyLimit, 20);
  assert.equal(restored.settings.sessionLimit, 5);
});
test("aplicar começo guiado pausa e mantém contadores, exclusões e aviso pendente", () => {
  const state = initialState();
  state.runtime.account = "conta";
  state.runtime.mode = "running";
  state.runtime.activeToken = "token";
  state.settings.dailyLimit = 100;
  state.settings.sessionLimit = 30;
  state.settings.hasPendingWarning = true;
  state.settings.exclusions = ["protegido"];
  audit(state, "attempt", "Tentativa");
  const guided = applyCommand(state, { type: "APPLY_STARTER" });
  assert.equal(guided.settings.dailyLimit, STARTER.dailyLimit);
  assert.equal(guided.settings.sessionLimit, 5);
  assert.equal(guided.settings.hasPendingWarning, true);
  assert.deepEqual(guided.settings.exclusions, ["protegido"]);
  assert.equal(attemptsToday(guided), 1);
  assert.equal(guided.runtime.sessionAttempts, 1);
  assert.equal(guided.runtime.mode, "paused");
  assert.equal(guided.runtime.activeToken, undefined);
});
test("cada tentativa consome também o lote, inclusive sem sucesso confirmado", () => {
  const state = initialState();
  state.runtime.account = "conta";
  state.settings.dailyLimit = 20;
  state.settings.sessionLimit = 2;
  audit(state, "attempt", "Já seguia");
  assert.equal(budgetStopReason(state, attemptsToday(state)), null);
  audit(state, "attempt", "Sem confirmação");
  assert.match(
    budgetStopReason(state, attemptsToday(state))!,
    /Lote encerrado/,
  );
  assert.equal(attemptsToday(state), 2);
});
test("aviso pendente tem prioridade sobre o saldo disponível", () => {
  const state = applyCommand(initialState(), { type: "REPORT_WARNING" });
  assert.equal(state.settings.hasPendingWarning, true);
  assert.ok(pendingWarningReason(state.settings));
  assert.match(budgetStopReason(state, 0)!, /aviso/);
  assert.equal(safetyAssessment(state, 0).notices[0].severity, "stop");
  assert.equal(safetyAssessment(state, 0).nextBatch, 0);
});
test("alterar controles invalida a autorização de uma ação ainda não enviada", () => {
  const state = initialState();
  state.runtime.mode = "running";
  state.runtime.activeToken = "token";
  state.runtime.nextRun = Date.now();
  const saved = applyCommand(state, {
    type: "SETTINGS",
    settings: { ...state.settings, dailyLimit: 10 },
  });
  assert.equal(saved.runtime.mode, "paused");
  assert.equal(saved.runtime.activeToken, undefined);
  assert.equal(saved.runtime.nextRun, undefined);
});
test("fila grande não aumenta o orçamento diário nem implica novos seguidores", () => {
  let state = applyCommand(initialState(), { type: "DEMO" });
  state.candidates.forEach((c) => {
    c.stage = "queued";
  });
  const assessment = safetyAssessment(state, 4);
  assert.equal(assessment.queued, 5);
  assert.equal(assessment.remaining, 1);
  assert.equal(assessment.nextBatch, 1);
  assert.ok(assessment.notices.some((n) => n.id === "backlog"));
  assert.ok(assessment.notices.some((n) => n.id === "near"));
  assert.equal(
    state.candidates.some((c) => c.stage === "followed"),
    false,
  );
});
test("avisa sobre várias fontes e sobre volume maior que o piloto", () => {
  let state = applyCommand(initialState(), {
    type: "CREATE_CAMPAIGN",
    name: "A",
    kind: "followers",
    target: "@um",
  });
  state = applyCommand(state, {
    type: "CREATE_CAMPAIGN",
    name: "B",
    kind: "following",
    target: "@dois",
  });
  state.settings.intervalMinutes = 1;
  const a = safetyAssessment(state, 0);
  assert.ok(a.notices.some((n) => n.id === "sources"));
  assert.ok(a.notices.some((n) => n.id === "pace"));
  assert.equal(a.sources, 2);
});
test("teto diário atingido zera o lote planejado sem sugerir que o próximo dia é seguro", () => {
  const state = applyCommand(initialState(), { type: "DEMO" });
  state.candidates[0].stage = "queued";
  const a = safetyAssessment(state, 5);
  assert.equal(a.nextBatch, 0);
  assert.match(a.notices.find((n) => n.id === "daily")!.text, /não comprova/);
});
test("lotes inválidos e campos de aviso adulterados são rejeitados", () => {
  for (const sessionLimit of [0, -1, 1.5, 501, NaN])
    assert.throws(() =>
      validateSettings({ ...initialState().settings, sessionLimit }),
    );
  assert.throws(() =>
    validateSettings({
      ...initialState().settings,
      hasPendingWarning: "false" as unknown as boolean,
    }),
  );
});
test("restaurar um backup anterior não apaga aviso atual nem devolve tentativas consumidas", () => {
  const oldBackup = initialState();
  let current = initialState();
  current.runtime.account = "conta";
  audit(current, "attempt", "Tentativa real registrada");
  current = applyCommand(current, { type: "REPORT_WARNING" });
  const restored = applyCommand(current, { type: "RESTORE", data: oldBackup });
  restored.runtime.account = "conta";
  assert.equal(restored.settings.hasPendingWarning, true);
  assert.equal(attemptsToday(restored), 1);
  assert.equal(restored.runtime.mode, "paused");
  assert.equal(lastAttemptTime(restored), lastAttemptTime(current));
});
test("pausar e aplicar o piloto não encurtam o intervalo entre tentativas", () => {
  const state = initialState();
  state.runtime.account = "conta";
  audit(state, "attempt", "Tentativa");
  const expected = lastAttemptTime(state) + 15 * 60000;
  assert.equal(
    intervalReadyAt(applyCommand(state, { type: "PAUSE" })),
    expected,
  );
  assert.equal(
    intervalReadyAt(applyCommand(state, { type: "APPLY_STARTER" })),
    expected,
  );
});
test("o intervalo sobrevive ao corte do histórico e mantém a conta correspondente", () => {
  const state = initialState();
  state.runtime.account = "conta";
  audit(state, "attempt", "Tentativa");
  const expected = intervalReadyAt(state);
  state.audit = [];
  assert.equal(intervalReadyAt(state), expected);
  state.runtime.account = "outra";
  assert.equal(intervalReadyAt(state), 0);
});
test("backup restaura a última tentativa sem antecipar o relógio atual da conta", () => {
  const state = initialState();
  state.runtime.account = "conta";
  audit(state, "attempt", "Tentativa");
  const restored = restoreState(JSON.parse(JSON.stringify(state)));
  restored.runtime.account = "conta";
  assert.equal(intervalReadyAt(restored), intervalReadyAt(state));
  const newer = new Date(Date.now() + 1000).toISOString();
  state.lastAttempts = { "@conta": newer };
  const merged = applyCommand(state, { type: "RESTORE", data: restored });
  merged.runtime.account = "conta";
  assert.equal(lastAttemptTime(merged), Date.parse(newer));
});

test("worker vincula ação, conta e seleção revisada sem repetir mutações", async (t) => {
  const originalTimer = globalThis.setTimeout;
  const descriptors = new Map(["chrome", "addEventListener"].map((key) => [key, Object.getOwnPropertyDescriptor(globalThis, key)]));
  const saved: Record<string, any> = {};
  let messageListener: Function | undefined, alarmListener: Function | undefined;
  let currentUrl = "https://www.instagram.com/alvo/";
  let delivery: (message: any) => Promise<any> = async () => ({ action: "follow", stage: "failed", message: "Fixture sem ação", stop: true });
  const sent: any[] = [];
  let created = 0;
  const extensionId = "fixture-extension";
  const dashboard = { id: extensionId, url: "chrome-extension://fixture-extension/index.html" };
  const source = () => ({ id: extensionId, tab: { id: 41 }, url: currentUrl });
  const route = (message: any, sender = dashboard): Promise<any> => new Promise((resolve) => messageListener!(message, sender, resolve));
  const root = () => saved[ACCOUNT_STORE_KEY] as AccountStore;
  const candidate = () => root().accounts[0].data.candidates[0];
  const data = () => root().accounts[0].data;
  const fixture = (stage: "queued" | "attempting" = "attempting", action: "follow" | "unfollow" = "unfollow") => {
    const store = initialStore();
    const account = store.accounts[0];
    account.id = store.activeId = "workspace-a";
    account.username = "minha.conta";
    account.verifiedAt = new Date().toISOString();
    store.sessionUsername = account.username;
    const state = account.data;
    const hour = new Date().getHours();
    state.settings = { ...state.settings, startHour: `${String(hour).padStart(2, "0")}:00`, endHour: `${String((hour + 1) % 24).padStart(2, "0")}:00`, reviewAfterDays: 7, reviewPolicy: "review_all" };
    const now = new Date().toISOString();
    const c: Candidate = { id: "candidate-a", username: "alvo", name: "Alvo fictício", note: "", stage, queueAccount: account.username, queuedAction: action, createdAt: now, updatedAt: now, sources: [{ campaignId: "fixture-source", url: "https://www.instagram.com/origem/followers/", at: now }] };
    if (action === "unfollow") Object.assign(c, { confirmedFollowAt: new Date(Date.now() - 30 * 86_400_000).toISOString(), confirmedFollowAccount: account.username, confirmedFollowSource: "orbita" });
    state.candidates = [c];
    state.runtime = { mode: "running", account: account.username, workerTabId: 41, pauseReason: "Fixture", sessionAttempts: 0 };
    if (stage === "attempting") {
      audit(state, "attempt", "Tentativa fictícia", c.username);
      Object.assign(state.runtime, { activeToken: "one-use", activeCandidateId: c.id, activeAction: action, activeExpiresAt: Date.now() + 10000 });
    }
    saved[ACCOUNT_STORE_KEY] = structuredClone(store);
    currentUrl = "https://www.instagram.com/alvo/";
    sent.length = 0;
    created = 0;
    return store;
  };
  const authorize = (extra: object = {}, sender = source()) => route({ type: "AUTHORIZE_CLICK", username: "alvo", expectedAccount: "minha.conta", token: "one-use", action: "unfollow", ...extra }, sender);
  const waitFor = async (condition: () => boolean) => {
    for (let i = 0; i < 150; i++) {
      if (condition()) { await new Promise((resolve) => originalTimer(resolve, 1)); return; }
      await new Promise((resolve) => originalTimer(resolve, 2));
    }
    assert.fail("O worker fictício não concluiu a operação dentro do limite do teste.");
  };
  try {
    Object.defineProperty(globalThis, "chrome", { configurable: true, writable: true, value: {
      runtime: { id: extensionId, getURL: (path: string) => `chrome-extension://${extensionId}/${path}`, getManifest: () => ({ version: "0.0.0-test" }), onMessage: { addListener(fn: Function) { messageListener = fn; } }, onStartup: { addListener() {} } },
      storage: { local: { async get(keys: string | string[]) { return Object.fromEntries((Array.isArray(keys) ? keys : [keys]).map((key) => [key, structuredClone(saved[key])])); }, async set(value: object) { Object.assign(saved, structuredClone(value)); }, async setAccessLevel() {} } },
      alarms: { async clear() {}, async create() {}, async get() {}, onAlarm: { addListener(fn: Function) { alarmListener = fn; } } },
      action: { onClicked: { addListener() {} } }, scripting: { async executeScript() { assert.fail("Não reinjetar para repetir uma mutação."); } },
      tabs: { async get(id: number) { return { id, status: "complete", url: currentUrl }; }, async update(id: number, options: any) { currentUrl = options.url; return { id, url: currentUrl }; }, async create(options: any) { created++; currentUrl = options.url; return { id: 41, url: currentUrl }; }, async sendMessage(_id: number, message: any) {
        if (message.type === "STATUS") return { account: "minha.conta", restricted: null, url: currentUrl };
        sent.push(message);
        return delivery(message);
      } },
    } });
    Object.defineProperty(globalThis, "addEventListener", { configurable: true, writable: true, value() {} });
    globalThis.setTimeout = ((callback: (...args: any[]) => void, delay?: number, ...args: any[]) => originalTimer(callback, delay === 12000 ? 35 : 0, ...args)) as typeof setTimeout;
    const modulePath = "../src/extension/background.ts?executor-safety";
    await import(modulePath);
    assert.equal((await route({ type: "GET_STATE" })).ok, true);

    await t.test("token é de uso único e a última tentativa reservada continua autorizável", async () => {
      fixture();
      data().runtime.sessionAttempts = 5;
      data().dailyAttempts[`minha.conta|${new Date().toDateString()}`] = 5;
      assert.equal((await authorize()).ok, true);
      assert.equal(data().runtime.activeToken, undefined);
      assert.equal((await authorize()).ok, false);
    });
    for (const scenario of ["wrong-action", "missing-action", "expired", "wrong-account", "wrong-tab", "wrong-route", "protected", "restored-proof", "not-due", "warning", "over-session", "over-daily"] as const) {
      await t.test(`autorização recusa ${scenario}`, async () => {
        fixture();
        let extra: any = {}, sender: any = source();
        if (scenario === "wrong-action") extra.action = "follow";
        if (scenario === "missing-action") extra.action = undefined;
        if (scenario === "expired") data().runtime.activeExpiresAt = Date.now() - 1;
        if (scenario === "wrong-account") extra.expectedAccount = "outra.conta";
        if (scenario === "wrong-tab") sender = { ...source(), tab: { id: 42 } };
        if (scenario === "wrong-route") sender.url = "https://www.instagram.com/outro/";
        if (scenario === "protected") root().accounts[0].relationships = { version: 1, snapshots: [], protections: [{ username: "alvo", enabled: true, reason: "friend", note: "", updatedAt: new Date().toISOString() }] };
        if (scenario === "restored-proof") candidate().confirmedFollowSource = "restored";
        if (scenario === "not-due") candidate().confirmedFollowAt = new Date().toISOString();
        if (scenario === "warning") data().settings.hasPendingWarning = true;
        if (scenario === "over-session") data().runtime.sessionAttempts = 6;
        if (scenario === "over-daily") data().dailyAttempts[`minha.conta|${new Date().toDateString()}`] = 6;
        assert.equal((await authorize(extra, sender)).ok, false);
        assert.equal(data().runtime.activeToken, "one-use");
        assert.equal(sent.length, 0);
      });
    }

    for (const scenario of ["unfollow-old-client", "unfollow-wrong-action", "unfollow-exact", "follow-legacy", "follow-wrong-selection"] as const) {
      await t.test(`START confere seleção ${scenario}`, async () => {
        const action = scenario.startsWith("follow-") ? "follow" : "unfollow";
        fixture("queued", action);
        data().runtime.mode = "paused";
        const command: any = { type: "START", reviewed: true };
        if (scenario === "unfollow-exact") command.reviewedQueue = [{ id: "candidate-a", action: "unfollow" }];
        if (scenario === "unfollow-wrong-action") command.reviewedQueue = [{ id: "candidate-a", action: "follow" }];
        if (scenario === "follow-wrong-selection") command.reviewedQueue = [{ id: "outro-id", action: "follow" }];
        const response = await route({ type: "COMMAND", workspaceId: "workspace-a", command });
        const allowed = ["unfollow-exact", "follow-legacy"].includes(scenario);
        assert.equal(response.ok, allowed);
        assert.equal(data().runtime.mode, allowed ? "running" : "paused");
        assert.equal(sent.length, 0);
        assert.equal(created, 0);
      });
    }

    await t.test("rede própria abre lista, lê parcial sem salvar e recusa retorno de outra conta/lista", async () => {
      fixture("queued", "follow");
      data().runtime.mode = "paused";
      const before = structuredClone(data().candidates);
      const open = await route({ type: "COMMAND", workspaceId: "workspace-a", command: { type: "OPEN_OWN_RELATIONSHIPS", kind: "followers" } });
      assert.equal(open.ok, true);
      assert.equal(currentUrl, "https://www.instagram.com/minha.conta/followers/");
      assert.equal(created, 1);
      const reading = { account: "minha.conta", kind: "followers", at: new Date().toISOString(), usernames: ["qa.pessoa", "qa.outra"], complete: false };
      delivery = async () => ({ ok: true, data: reading });
      const read = () => route({ type: "READ_OWN_RELATIONSHIPS", workspaceId: "workspace-a", kind: "followers" });
      const result = await read();
      assert.equal(result.ok, true);
      assert.deepEqual(result.data, reading);
      assert.deepEqual(data().candidates, before);
      assert.equal(attemptsToday(data()), 0);
      for (const changes of [{ account: "outra.conta" }, { kind: "following" }, { complete: true }, { usernames: ["qa.pessoa", "qa.pessoa"] }]) {
        delivery = async () => ({ ok: true, data: { ...reading, ...changes } });
        assert.equal((await read()).ok, false);
      }
      currentUrl = "https://www.instagram.com/outra.conta/followers/";
      assert.equal((await read()).ok, false);
      assert.equal((await route({ type: "READ_OWN_RELATIONSHIPS", workspaceId: "another-workspace", kind: "followers" })).ok, false);
      assert.deepEqual(data().candidates, before);
    });

    for (const status of ["following", "requested", "not_following"] as const) {
      await t.test(`conferência de uncertain registra ${status} sem clique, prova ou nova tentativa`, async () => {
        fixture("queued", "follow");
        candidate().stage = "uncertain";
        data().runtime.mode = "paused";
        audit(data(), "attempt", "Tentativa original fictícia", "alvo");
        data().candidates.push({ ...structuredClone(candidate()), id: "candidate-b", username: "qa.outro", stage: "queued" });
        const attempts = attemptsToday(data()), sessionAttempts = data().runtime.sessionAttempts, lastAttempts = structuredClone(data().lastAttempts);
        delivery = async (message) => {
          assert.equal(message.type, "PROFILE_RELATIONSHIP_STATE");
          return { ok: true, data: { account: "minha.conta", username: "alvo", at: new Date().toISOString(), status } };
        };
        const result = await route({ type: "COMMAND", workspaceId: "workspace-a", command: { type: "VERIFY_CANDIDATE_RESULT", id: "candidate-a" } });
        assert.equal(result.ok, true);
        assert.equal(created, 1);
        assert.equal(sent.length, 1);
        assert.equal(sent[0].type, "PROFILE_RELATIONSHIP_STATE");
        assert.equal(candidate().stage, status === "following" ? "followed" : status === "requested" ? "requested" : "uncertain");
        assert.equal(candidate().relationshipObserved?.status, status);
        assert.equal(candidate().relationshipObserved?.source, "instagram");
        assert.equal(candidate().confirmedFollowAt, undefined);
        assert.equal(candidate().confirmedFollowSource, undefined);
        assert.equal(data().candidates[1].stage, "queued");
        assert.equal(data().audit.some((entry) => entry.kind === "relationship_verified"), true);
        assert.equal(data().audit.some((entry) => entry.kind === "followed"), false);
        assert.equal(attemptsToday(data()), attempts);
        assert.equal(data().runtime.sessionAttempts, sessionAttempts);
        assert.deepEqual(data().lastAttempts, lastAttempts);
        assert.equal(data().runtime.mode, "paused");
      });
    }
    await t.test("conferência não abre perfil para queued nem para uncertain-unfollow", async () => {
      fixture("queued", "follow"); data().runtime.mode = "paused";
      const verify = () => route({ type: "COMMAND", workspaceId: "workspace-a", command: { type: "VERIFY_CANDIDATE_RESULT", id: "candidate-a" } });
      assert.equal((await verify()).ok, false);
      candidate().stage = "uncertain"; candidate().queuedAction = "unfollow";
      assert.equal((await verify()).ok, false);
      assert.equal(created, 0);
      assert.equal(sent.length, 0);
    });

    for (const outcome of ["followed", "requested", "already", "unfollowed", "wrong-result-action", "unconsumed-token", "timeout"] as const) {
      await t.test(`resultado ${outcome} mantém prova e orçamento corretos`, async () => {
        const action = outcome === "unfollowed" ? "unfollow" : "follow";
        fixture("queued", action);
        const previousProof = candidate().confirmedFollowAt;
        delivery = async (message) => {
          if (outcome === "timeout") return new Promise(() => {});
          if (outcome !== "already" && outcome !== "unconsumed-token") {
            const response = await authorize({ token: message.token, action });
            assert.equal(response.ok, true);
          }
          return { action: outcome === "wrong-result-action" ? "unfollow" : action, stage: ["wrong-result-action", "unconsumed-token"].includes(outcome) ? "followed" : outcome, message: "Resultado fictício conferido", clickSent: outcome !== "already" };
        };
        alarmListener!({ name: "orbita-queue:workspace-a" });
        await waitFor(() => data().runtime.mode === "paused");
        assert.equal(sent.length, 1);
        assert.equal(sent[0].type, action === "unfollow" ? "UNFOLLOW" : "FOLLOW");
        assert.equal(attemptsToday(data()), 1);
        assert.equal(data().runtime.sessionAttempts, 1);
        assert.equal(data().runtime.activeToken, undefined);
        assert.equal(data().runtime.activeAction, undefined);
        if (outcome === "followed") {
          assert.equal(candidate().confirmedFollowSource, "orbita");
          assert.equal(candidate().confirmedFollowAccount, "minha.conta");
          assert.ok(Number.isFinite(Date.parse(candidate().confirmedFollowAt!)));
        } else assert.equal(candidate().confirmedFollowAt, previousProof);
        const uncertain = ["wrong-result-action", "unconsumed-token", "timeout"].includes(outcome);
        assert.equal(candidate().stage, uncertain ? "uncertain" : outcome);
      });
    }
    for (const scenario of ["protected", "not-due", "restored-proof"] as const) {
      await t.test(`runner revalida ${scenario} antes de abrir o perfil`, async () => {
        fixture("queued", "unfollow");
        if (scenario === "protected") root().accounts[0].relationships = { version: 1, snapshots: [], protections: [{ username: "alvo", enabled: true, reason: "friend", note: "", updatedAt: new Date().toISOString() }] };
        if (scenario === "not-due") candidate().confirmedFollowAt = new Date().toISOString();
        if (scenario === "restored-proof") candidate().confirmedFollowSource = "restored";
        alarmListener!({ name: "orbita-queue:workspace-a" });
        await waitFor(() => data().runtime.mode === "paused");
        assert.equal(sent.length, 0);
        assert.equal(created, 0);
        assert.equal(attemptsToday(data()), 0);
        assert.equal(candidate().stage, "queued");
      });
    }
  } finally {
    globalThis.setTimeout = originalTimer;
    for (const [key, descriptor] of descriptors) {
      if (descriptor) Object.defineProperty(globalThis, key, descriptor);
      else delete (globalThis as any)[key];
    }
  }
});
