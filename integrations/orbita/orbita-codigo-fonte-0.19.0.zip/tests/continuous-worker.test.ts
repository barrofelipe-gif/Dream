import test from "node:test";
import assert from "node:assert/strict";
import { ACCOUNT_STORE_KEY, initialStore, workspace } from "../src/core/accounts.ts";
import { applyCommand, attemptsToday, sourceUrl } from "../src/core/domain.ts";
import { configureContinuousSource } from "../src/core/continuous.ts";
import { continuousWakeAt, nextDayWindowAt, nextWindowAt } from "../src/extension/continuous-schedule.ts";
import type { AccountStore } from "../src/core/types.ts";

test("janela contínua calcula espera diurna, noturna e virada diária sem mexer no ritmo", () => {
  const settings = workspace(initialStore()).data.settings;
  settings.startHour = "09:00"; settings.endHour = "21:00";
  const morning = new Date(2026, 10, 3, 9).getTime();
  assert.equal(nextWindowAt(settings, new Date(2026, 10, 3, 8).getTime()), morning);
  assert.equal(nextWindowAt(settings, morning), morning);
  assert.equal(nextDayWindowAt(settings, morning), new Date(2026, 10, 4, 9).getTime());
  settings.startHour = "21:00"; settings.endHour = "09:00";
  assert.equal(nextWindowAt(settings, new Date(2026, 10, 3, 10).getTime()), new Date(2026, 10, 3, 21).getTime());
  assert.equal(nextDayWindowAt(settings, new Date(2026, 10, 3, 23).getTime()), new Date(2026, 10, 4, 0).getTime());
});

test("worker contínuo conecta leitura, fila, alarmes, pausa e recuperação sem ações reais", async (t) => {
  const originals = new Map(["chrome", "addEventListener"].map((key) => [key, Object.getOwnPropertyDescriptor(globalThis, key)]));
  const saved: Record<string, any> = {}, tabs = new Map<number, any>(), alarms = new Map<string, any>();
  let listener: Function | undefined, onAlarm: Function | undefined, onStartup: Function | undefined;
  let nextTab = 100, steps = 0, follows = 0;
  let stepMode: "normal" | "unavailable" | "hold" | "mismatch" = "normal";
  let releaseStep: ((value: any) => void) | undefined;
  let activateTabAfterStatus: number | undefined;
  const updatedTabs: number[] = [];
  const sender = { id: "fixture-extension", url: "chrome-extension://fixture-extension/index.html" };
  const root = () => saved[ACCOUNT_STORE_KEY] as AccountStore;
  const account = () => workspace(root());
  const state = () => account().data;
  const route = (message: any, actor = sender): Promise<any> => new Promise((resolve) => listener!(message, actor, resolve));
  const command = (cmd: object) => route({ type: "COMMAND", workspaceId: "qa-workspace", command: cmd });
  const flush = async () => { for (let i = 0; i < 120; i++) await Promise.resolve(); };
  const pumpUntil = async (check: () => boolean, limit = 12000) => {
    for (let elapsed = 0; elapsed <= limit; elapsed += 100) {
      await flush(); if (check()) { await flush(); return; }
      t.mock.timers.tick(100);
    }
    assert.fail("A jornada do worker não concluiu dentro do relógio simulado.");
  };
  const fire = () => { alarms.delete("orbita-continuous:qa-workspace"); onAlarm!({ name: "orbita-continuous:qa-workspace" }); };
  const resultFor = (message: any) => ({ ok: true, data: { account: "qa.owner", sourceId: message.campaign.id, runId: message.runId, url: sourceUrl(message.campaign.kind, message.campaign.target), at: new Date().toISOString(), complete: false, phase: "end", candidates: [{ username: message.campaign.id === "source-a" ? "qa.new" : "qa.second" }] } });
  const fixture = (two = false) => {
    const store = initialStore(), item = workspace(store);
    item.id = store.activeId = "qa-workspace"; item.username = "qa.owner"; item.verifiedAt = new Date().toISOString();
    store.sessionUsername = "qa.owner";
    item.data.runtime.account = "qa.owner"; item.data.runtime.connectedAt = item.verifiedAt;
    item.data.settings = { ...item.data.settings, dailyLimit: 5, sessionLimit: 5, intervalMinutes: 5, startHour: "00:00", endHour: "23:59" };
    item.data = applyCommand(item.data, { type: "CREATE_CAMPAIGN", name: "Fonte A fictícia", kind: "followers", target: "qa.reference" });
    item.data.campaigns[0].id = "source-a";
    item.data = configureContinuousSource(item.data, { type: "CONFIGURE_CONTINUOUS_SOURCE", id: "source-a", enabled: true, autoFollow: true, pollMinutes: 15, reviewed: true });
    if (two) {
      item.data = applyCommand(item.data, { type: "CREATE_CAMPAIGN", name: "Fonte B fictícia", kind: "commenters", target: "https://www.instagram.com/p/QApost/" });
      item.data.campaigns[0].id = "source-b";
      item.data = configureContinuousSource(item.data, { type: "CONFIGURE_CONTINUOUS_SOURCE", id: "source-b", enabled: true, autoFollow: true, pollMinutes: 15, reviewed: true });
    }
    saved[ACCOUNT_STORE_KEY] = structuredClone(store);
    tabs.clear(); alarms.clear(); steps = follows = 0; stepMode = "normal"; releaseStep = undefined;
    activateTabAfterStatus = undefined; updatedTabs.length = 0;
    return store;
  };
  const start = async (ids = ["source-a"]) => {
    const reply = await command({ type: "START_CONTINUOUS", sourceIds: ids, reviewed: true });
    assert.equal(reply.ok, true, reply.error);
    assert.ok(alarms.has("orbita-continuous:qa-workspace"));
  };
  try {
    t.mock.timers.enable({ apis: ["Date", "setTimeout"], now: new Date(2026, 10, 3, 12).getTime() });
    Object.defineProperty(globalThis, "chrome", { configurable: true, value: {
      runtime: { id: "fixture-extension", getURL: (path: string) => `chrome-extension://fixture-extension/${path}`, getManifest: () => ({ version: "0.19.0" }), onMessage: { addListener(fn: Function) { listener = fn; } }, onStartup: { addListener(fn: Function) { onStartup = fn; } } },
      storage: { local: { async get(keys: string[]) { return Object.fromEntries(keys.map((key) => [key, structuredClone(saved[key])])); }, async set(values: any) { Object.assign(saved, structuredClone(values)); }, async setAccessLevel() {} } },
      action: { onClicked: { addListener() {} } },
      alarms: { async create(name: string, info: any) { alarms.set(name, info); }, async clear(name: string) { return alarms.delete(name); }, async get(name: string) { return alarms.get(name); }, onAlarm: { addListener(fn: Function) { onAlarm = fn; } } },
      scripting: { async executeScript() { assert.fail("O fixture já tem receptor; não reinjetar para repetir uma etapa."); } },
      tabs: {
        async get(id: number) { if (!tabs.has(id)) throw new Error("No tab with id"); return { ...tabs.get(id), status: "complete" }; },
        async create(options: any) { const tab = { id: ++nextTab, ...options }; tabs.set(tab.id, tab); return tab; },
        async update(id: number, options: any) { updatedTabs.push(id); Object.assign(tabs.get(id), options); return tabs.get(id); },
        async sendMessage(id: number, message: any) {
          if (message.type === "STATUS") {
            const status = { account: "qa.owner", restricted: null, url: tabs.get(id).url, hasDraft: tabs.get(id).hasDraft || false };
            if (activateTabAfterStatus === id) { Object.assign(tabs.get(id), { active: true, hasDraft: true }); activateTabAfterStatus = undefined; }
            return status;
          }
          if (message.type === "STEP_CONTINUOUS_SOURCE") {
            steps++;
            if (stepMode === "hold") return new Promise((resolve) => { releaseStep = resolve; });
            if (stepMode === "mismatch") return { ok: false, accountMismatch: true, error: "Conta trocada no fixture" };
            if (stepMode === "unavailable" && message.campaign.id === "source-a") return { ok: false, unavailable: true, error: "Fonte indisponível no fixture" };
            return resultFor(message);
          }
          if (message.type === "FOLLOW") {
            follows++;
            const authorized = await route({ type: "AUTHORIZE_CLICK", action: "follow", username: message.username, expectedAccount: message.expectedAccount, token: message.token }, { id: "fixture-extension", tab: { id }, url: tabs.get(id).url } as any);
            assert.equal(authorized.ok, true, "a autorização deve continuar vinculada à fonte, conta e candidato");
            return { action: "follow", stage: "followed", message: "Seguindo no fixture", clickSent: true };
          }
          assert.fail(`Mensagem inesperada no fixture: ${message.type}`);
        },
      },
    } });
    Object.defineProperty(globalThis, "addEventListener", { configurable: true, value() {} });
    const modulePath = "../src/extension/background.ts?continuous-worker-fixture";
    await import(modulePath);
    assert.equal((await route({ type: "GET_STATE" })).capabilities.continuousSources, true);

    await t.test("consulta enfileira uma vez, executa automático e mantém agenda para novas consultas", async () => {
      fixture(); await start(); fire();
      await pumpUntil(() => !!state().campaigns[0].continuous?.lastCheckAt && alarms.has("orbita-continuous:qa-workspace"));
      assert.equal(steps, 1); assert.equal(state().candidates[0].stage, "queued"); assert.equal(follows, 0);
      assert.equal(state().campaigns[0].continuous?.lastQueued, 1);
      t.mock.timers.tick(31000); fire();
      await pumpUntil(() => state().candidates[0].stage === "followed" && alarms.has("orbita-continuous:qa-workspace"));
      assert.equal(follows, 1); assert.equal(attemptsToday(state()), 1); assert.equal(state().continuous?.mode, "running");
      state().campaigns[0].continuous!.nextCheckAt = new Date(Date.now() - 1000).toISOString();
      fire(); await pumpUntil(() => steps === 2 && state().campaigns[0].continuous?.lastAdded === 0 && alarms.has("orbita-continuous:qa-workspace"));
      assert.equal(follows, 1); assert.equal(state().candidates.length, 1); assert.equal(attemptsToday(state()), 1);
      assert.equal((await command({ type: "PAUSE_CONTINUOUS" })).ok, true);
    });

    await t.test("fonte indisponível para; outra fonte continua sem insistir na anterior", async () => {
      fixture(true); stepMode = "unavailable"; await start(["source-a", "source-b"]);
      state().campaigns.find((c) => c.id === "source-b")!.continuous!.nextCheckAt = new Date(Date.now() + 1000).toISOString();
      fire();
      await pumpUntil(() => state().campaigns.find((c) => c.id === "source-a")?.continuous?.status === "unavailable" && alarms.has("orbita-continuous:qa-workspace"));
      assert.equal(state().continuous?.mode, "running"); assert.equal(steps, 1);
      t.mock.timers.tick(1000); fire(); await pumpUntil(() => !!state().campaigns.find((c) => c.id === "source-b")?.continuous?.lastCheckAt && alarms.has("orbita-continuous:qa-workspace"));
      assert.equal(steps, 2); assert.equal(state().candidates[0].username, "qa.second");
      assert.equal(state().candidates[0].stage, "queued");
      await command({ type: "PAUSE_CONTINUOUS" });
    });

    await t.test("alarmes simultâneos não sobrepõem scans e pausa invalida resposta tardia", async () => {
      fixture(); stepMode = "hold"; await start(); fire();
      await pumpUntil(() => !!releaseStep);
      fire(); await flush(); assert.equal(steps, 1);
      await command({ type: "PAUSE_CONTINUOUS" });
      releaseStep!({ ok: true, data: { account: "qa.owner", sourceId: "source-a", runId: state().campaigns[0].continuous?.runId, url: "https://www.instagram.com/qa.reference/followers/", at: new Date().toISOString(), phase: "end", complete: false, candidates: [{ username: "qa.late" }] } });
      await flush(); t.mock.timers.tick(1000); await flush();
      assert.equal(state().candidates.length, 0); assert.equal(follows, 0); assert.equal(state().continuous?.mode, "paused");
      fire(); await flush(); assert.equal(steps, 1);
    });

    await t.test("aba ativada durante a conferência de rascunho é preservada antes de navegar", async () => {
      fixture(); await start(); fire();
      await pumpUntil(() => !!state().campaigns[0].continuous?.lastCheckAt && alarms.has("orbita-continuous:qa-workspace"));
      const previous = state().runtime.continuousTabId!;
      activateTabAfterStatus = previous;
      state().campaigns[0].continuous!.nextCheckAt = new Date(Date.now() - 1000).toISOString();
      fire(); await pumpUntil(() => steps === 2 && alarms.has("orbita-continuous:qa-workspace"));
      assert.notEqual(state().runtime.continuousTabId, previous);
      assert.equal(updatedTabs.includes(previous), false);
      assert.equal(tabs.get(previous).hasDraft, true);
      assert.equal(follows, 0);
      await command({ type: "PAUSE_CONTINUOUS" });
    });

    await t.test("troca de ator pausa a rotina inteira, sem clique nem orçamento consumido", async () => {
      fixture(); stepMode = "mismatch"; await start(); fire();
      await pumpUntil(() => state().continuous?.mode === "paused");
      assert.equal(follows, 0); assert.equal(attemptsToday(state()), 0); assert.equal(state().candidates.length, 0);
      assert.equal(alarms.has("orbita-continuous:qa-workspace"), false);
    });

    await t.test("novo dia renova só a sessão antiga; início no mesmo dia não repõe tentativas", async () => {
      fixture(); state().runtime.sessionAttempts = 5;
      state().runtime.sessionStartedAt = new Date().toISOString();
      state().lastAttempts = { "@qa.owner": new Date().toISOString() };
      state().dailyAttempts[`qa.owner|${new Date().toDateString()}`] = 5;
      await start(); fire();
      await pumpUntil(() => state().candidates.length === 1 && alarms.has("orbita-continuous:qa-workspace"));
      assert.equal(follows, 0); assert.equal(state().runtime.sessionAttempts, 5); assert.equal(attemptsToday(state()), 5);
      const previousLedger = structuredClone(state().dailyAttempts), previousInterval = state().settings.intervalMinutes;
      t.mock.timers.tick(86400000); fire();
      await pumpUntil(() => state().candidates[0].stage === "followed" && alarms.has("orbita-continuous:qa-workspace"));
      assert.equal(follows, 1); assert.equal(state().runtime.sessionAttempts, 1); assert.equal(attemptsToday(state()), 1);
      assert.equal(state().settings.intervalMinutes, previousInterval);
      for (const [key, value] of Object.entries(previousLedger)) assert.equal(state().dailyAttempts[key], value);
      await command({ type: "PAUSE_CONTINUOUS" });
    });

    await t.test("primeira ativação renova uma sessão comprovadamente anterior sem esperar outro dia", async () => {
      fixture();
      const yesterday = new Date(Date.now() - 86400000);
      state().runtime.sessionAttempts = 5;
      state().runtime.sessionStartedAt = yesterday.toISOString();
      state().lastAttempts = { "@qa.owner": yesterday.toISOString() };
      state().dailyAttempts[`qa.owner|${yesterday.toDateString()}`] = 5;
      await start(); fire();
      await pumpUntil(() => state().candidates.length === 1 && alarms.has("orbita-continuous:qa-workspace"));
      assert.equal(state().runtime.sessionAttempts, 0);
      assert.equal(attemptsToday(state()), 0);
      t.mock.timers.tick(31000); fire();
      await pumpUntil(() => state().candidates[0].stage === "followed" && alarms.has("orbita-continuous:qa-workspace"));
      assert.equal(follows, 1); assert.equal(state().runtime.sessionAttempts, 1);
      assert.equal(state().dailyAttempts[`qa.owner|${yesterday.toDateString()}`], 5);
      await command({ type: "PAUSE_CONTINUOUS" });
    });

    await t.test("reinício em outro dia agenda renovação agora, sem aguardar a fonte de 24 horas", async () => {
      fixture();
      state().campaigns[0].continuous!.pollMinutes = 1440;
      await start(); fire();
      await pumpUntil(() => state().candidates.length === 1 && alarms.has("orbita-continuous:qa-workspace"));
      const yesterday = new Date();
      state().runtime.sessionAttempts = 5;
      state().runtime.sessionStartedAt = yesterday.toISOString();
      state().lastAttempts = { "@qa.owner": yesterday.toISOString() };
      state().dailyAttempts[`qa.owner|${yesterday.toDateString()}`] = 5;
      t.mock.timers.tick(22 * 3600000);
      const recoveryPath = new URL("../src/extension/account-store.ts?continuous-next-day-alarm", import.meta.url).href;
      await (await import(recoveryPath)).storeReady;
      const alarm = alarms.get("orbita-continuous:qa-workspace");
      assert.ok(alarm.when <= Date.now() + 1000, "o tick precisa renovar o dia antes de aguardar uma fonte ainda futura");
      assert.equal(state().runtime.sessionAttempts, 5, "agendar não pode resetar contadores");
      assert.equal(attemptsToday(state()), 0);
      t.mock.timers.tick(1000); fire();
      await pumpUntil(() => state().candidates[0].stage === "followed" && alarms.has("orbita-continuous:qa-workspace"));
      assert.equal(follows, 1); assert.equal(state().runtime.sessionAttempts, 1);
      await command({ type: "PAUSE_CONTINUOUS" });
    });

    await t.test("reinício recupera leitura sem repetir ação; tentativa interrompida exige revisão", async () => {
      fixture(); await start();
      state().campaigns[0].continuous!.status = "checking"; state().campaigns[0].continuous!.runId = "old-read";
      delete state().campaigns[0].continuous!.nextCheckAt;
      const readRecovery = new URL("../src/extension/account-store.ts?continuous-read-recovery", import.meta.url).href;
      await (await import(readRecovery)).storeReady;
      assert.equal(state().campaigns[0].continuous?.status, "ready");
      assert.equal(state().campaigns[0].continuous?.runId, undefined); assert.ok(alarms.has("orbita-continuous:qa-workspace"));
      assert.equal(follows, 0);
      onStartup!(); await flush(); assert.equal(state().continuous?.mode, "running");
      fire(); await pumpUntil(() => state().candidates.length === 1 && alarms.has("orbita-continuous:qa-workspace"));
      state().candidates[0].stage = "attempting"; state().runtime.mode = "running";
      state().runtime.sessionAttempts = 3;
      state().dailyAttempts[`qa.owner|${new Date().toDateString()}`] = 3;
      const actionRecovery = new URL("../src/extension/account-store.ts?continuous-action-recovery", import.meta.url).href;
      await (await import(actionRecovery)).storeReady;
      assert.equal(state().candidates[0].stage, "uncertain"); assert.equal(state().continuous?.mode, "paused");
      assert.equal(attemptsToday(state()), 3); assert.equal(state().runtime.sessionAttempts, 3);
      assert.equal(continuousWakeAt(account()), undefined); assert.equal(follows, 0);
    });
  } finally {
    releaseStep?.({ ok: false, error: "Fixture encerrado" }); await flush();
    t.mock.timers.reset();
    for (const [key, descriptor] of originals) descriptor ? Object.defineProperty(globalThis, key, descriptor) : Reflect.deleteProperty(globalThis, key);
  }
});
