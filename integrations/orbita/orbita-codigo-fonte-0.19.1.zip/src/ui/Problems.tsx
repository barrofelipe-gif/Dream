import { useState } from "react";
import { Bug, Download, Plus, RefreshCw, Wrench } from "lucide-react";
import type { AccountWorkspace } from "../core/types.ts";
import {
  APP_SCOPE,
  problemAdvice,
  problemText,
  PROBLEM_CATEGORY,
  PROBLEM_STATUS,
  scopedProblems,
} from "../core/problems.ts";
import type {
  Problem,
  ProblemCategory,
  ProblemStatus,
} from "../core/problems.ts";
import {
  changeProblem,
  reportProblem,
  useProblems,
} from "../problems-client.ts";
import { download } from "../core/io.ts";
import { Empty, Field, Modal } from "./components.tsx";
type Snapshot = ReturnType<typeof useProblems>;
const date = (s: string) => new Date(s).toLocaleString("pt-BR");
export function ProblemsPage({
  account,
  snapshot,
}: {
  account: AccountWorkspace;
  snapshot: Snapshot;
}) {
  const { store, storageError, sessionIds, persistedReadable } = snapshot;
  const [filter, setFilter] = useState("active"),
    [search, setSearch] = useState(""),
    [selected, setSelected] = useState<Problem | null>(null),
    [manual, setManual] = useState(false);
  const all = scopedProblems(store, account.id),
    rows = all.filter(
      (p) =>
        (filter === "all" ||
          (filter === "active" && p.status !== "resolved") ||
          p.status === filter) &&
        `${p.message} ${p.operation}`
          .toLowerCase()
          .includes(search.toLowerCase()),
    );
  const [manualText, setManualText] = useState(""),
    [category, setCategory] = useState<ProblemCategory>("interface");
  return (
    <section
      className="problems-page"
      aria-label="Central de problemas"
      data-problem-capture="skip"
    >
      <div className="problems-heading">
        <div>
          <span className="eyebrow">REGISTRAR · INVESTIGAR · CONFERIR</span>
          <h2>Problemas têm acompanhamento.</h2>
          <p>
            Falhas observadas nesta conta e no painel geral, com histórico do
            que foi feito.
          </p>
        </div>
        <div className="metrics-actions">
          <button className="button secondary" onClick={() => setManual(true)}>
            <Plus size={15} />
            Registrar problema
          </button>
          <button
            className="button primary"
            onClick={() =>
              download(
                `orbita-${account.username || "painel"}-diagnostico.json`,
                JSON.stringify(
                  {
                    version: 1,
                    orbitaVersion: "0.19.1",
                    exportedAt: new Date().toISOString(),
                    account: account.username,
                    scope: account.id,
                    persistentHistoryReadable: persistedReadable,
                    exportCoverage: persistedReadable
                      ? "Histórico persistente disponível e registros da sessão"
                      : "Somente registros disponíveis; histórico persistente não pôde ser lido",
                    problems: all,
                    sessionOnlyIds: sessionIds.filter((id) =>
                      all.some((p) => p.id === id),
                    ),
                    pruned: store.pruned,
                    prunedOpen: store.prunedOpen,
                  },
                  null,
                  2,
                ),
                "application/json",
              )
            }
          >
            <Download size={15} />
            {persistedReadable
              ? "Exportar diagnóstico"
              : "Exportar diagnóstico disponível"}
          </button>
        </div>
      </div>
      {storageError ? (
        <div className="notice error" role="alert">
          {storageError}
        </div>
      ) : null}
      {store.pruned ? (
        <p className="problems-retention">
          O limite local resumiu {store.pruned} registros antigos, incluindo{" "}
          {store.prunedOpen} que ainda estavam em acompanhamento. Exporte
          periodicamente para preservar o histórico completo disponível.
        </p>
      ) : null}
      <div className="problems-stats">
        <div>
          <span>Em acompanhamento</span>
          <strong>{all.filter((p) => p.status !== "resolved").length}</strong>
        </div>
        <div>
          <span>Recuperados para observar</span>
          <strong>{all.filter((p) => p.status === "monitoring").length}</strong>
        </div>
        <div>
          <span>Resolvidos pelo usuário</span>
          <strong>{all.filter((p) => p.status === "resolved").length}</strong>
        </div>
      </div>
      <div className="problems-explainer">
        <Wrench size={20} />
        <div>
          <strong>
            Recuperar uma operação e corrigir a causa são etapas diferentes.
          </strong>
          <p>
            A leitura inicial do painel pode ser repetida uma vez após uma falha
            temporária de comunicação. Outras operações exigem revisão. A
            central registra e orienta; mudanças no código precisam ser
            implementadas e verificadas.
          </p>
          <p>
            Avisos do Instagram e ações sem confirmação mantêm os cuidados da
            fila. Marcar um problema como resolvido não libera a execução.
          </p>
        </div>
      </div>
      <div className="problems-filters">
        <Field label="Situação dos problemas">
          <select value={filter} onChange={(e) => setFilter(e.target.value)}>
            <option value="active">Em acompanhamento</option>
            <option value="all">Todos os problemas</option>
            {Object.entries(PROBLEM_STATUS).map(([key, title]) => (
              <option value={key} key={key}>
                {title}
              </option>
            ))}
          </select>
        </Field>
        <Field label="Buscar problema">
          <input
            value={search}
            onChange={(e) => setSearch(e.target.value)}
            placeholder="Mensagem ou operação"
          />
        </Field>
        <button
          className="button secondary"
          onClick={() =>
            window.dispatchEvent(new Event("orbita-problems-change"))
          }
        >
          <RefreshCw size={15} />
          Atualizar lista
        </button>
      </div>
      {rows.length ? (
        <div className="problems-list">
          {rows.map((p) => (
            <article
              className={`problem-card ${p.status}`}
              key={p.id}
              aria-label={`Problema: ${p.message}`}
            >
              <div className="problem-card-heading">
                <span className="problem-category">
                  <Bug size={14} />
                  {PROBLEM_CATEGORY[p.category]}
                </span>
                <span className={`problem-status ${p.status}`}>
                  {PROBLEM_STATUS[p.status]}
                </span>
              </div>
              <h3>{p.message}</h3>
              <p className="problem-context">
                {p.scope === APP_SCOPE
                  ? "Painel geral"
                  : `@${account.username || "conta selecionada"}`}{" "}
                · {p.count}{" "}
                {p.count === 1
                  ? "ocorrência registrada"
                  : "ocorrências registradas"}
                {sessionIds.includes(p.id) ? " · somente nesta sessão" : ""}
              </p>
              <p className="problem-dates">
                Primeira: {date(p.firstAt)} · Mais recente: {date(p.lastAt)}
              </p>
              <div className="problem-guidance">
                <strong>Como encaminhar</strong>
                <p>{problemAdvice(p)}</p>
              </div>
              <details>
                <summary>Histórico e informações para correção</summary>
                <p className="problem-technical">
                  Registro {p.id} · operação {p.operation} · origem {p.source} ·
                  recuperações de leitura: {p.recoveries}
                </p>
                <ol>
                  {[...p.events].reverse().map((event, index) => (
                    <li key={`${event.at}-${index}`}>
                      <span>
                        {date(event.at)} · {PROBLEM_STATUS[event.status]}
                      </span>
                      <p>{event.note}</p>
                    </li>
                  ))}
                </ol>
                <p className="problem-technical">
                  Até 12 eventos recentes neste grupo. A contagem de ocorrências
                  continua acumulando.
                </p>
              </details>
              <div className="problem-card-actions">
                <button
                  className="button secondary"
                  onClick={() => setSelected(p)}
                >
                  Acompanhar problema
                </button>
                {p.category === "interface" || p.category === "connection" ? (
                  <button
                    className="text-link"
                    onClick={() => window.location.reload()}
                  >
                    Reabrir painel
                  </button>
                ) : null}
              </div>
            </article>
          ))}
        </div>
      ) : (
        <Empty
          icon={<Bug size={27} />}
          title="Nenhum problema neste filtro"
          text="Falhas observadas no painel serão registradas aqui. Você também pode descrever um problema manualmente."
        />
      )}
      <p className="problems-privacy">
        Registro local separado dos dados das contas. O diagnóstico inclui
        mensagens resumidas e informações da operação, sem copiar arquivos
        importados, listas ou campos digitados. Links, tokens e campos de
        credenciais reconhecidos são omitidos. Revise o JSON antes de
        compartilhar.
      </p>
      {selected ? (
        <UpdateModal
          problem={all.find((p) => p.id === selected.id) || selected}
          onClose={() => setSelected(null)}
        />
      ) : null}
      {manual ? (
        <Modal
          title="Registrar um problema"
          subtitle="Descreva o que aconteceu, sem senhas ou dados desnecessários."
          onClose={() => setManual(false)}
        >
          <form
            onSubmit={async (e) => {
              e.preventDefault();
              await reportProblem(manualText, {
                scope: account.id,
                operation: "USER_REPORTED",
                source: "manual",
                category,
              });
              setManual(false);
              setManualText("");
            }}
          >
            <Field label="O que aconteceu">
              <textarea
                required
                minLength={10}
                maxLength={600}
                rows={5}
                value={manualText}
                onChange={(e) => setManualText(e.target.value)}
              />
            </Field>
            <Field label="Tipo de problema">
              <select
                value={category}
                onChange={(e) => setCategory(e.target.value as ProblemCategory)}
              >
                {Object.entries(PROBLEM_CATEGORY).map(([key, label]) => (
                  <option key={key} value={key}>
                    {label}
                  </option>
                ))}
              </select>
            </Field>
            <div className="modal-actions">
              <button
                type="button"
                className="button secondary"
                onClick={() => setManual(false)}
              >
                Cancelar
              </button>
              <button className="button primary">Salvar problema</button>
            </div>
          </form>
        </Modal>
      ) : null}
    </section>
  );
}
function UpdateModal({
  problem,
  onClose,
}: {
  problem: Problem;
  onClose: () => void;
}) {
  const [status, setStatus] = useState<ProblemStatus>(
      problem.status === "monitoring" ? "investigating" : problem.status,
    ),
    [note, setNote] = useState(""),
    [error, setError] = useState(""),
    [busy, setBusy] = useState(false);
  return (
    <Modal
      title="Acompanhar problema"
      subtitle="Registre a investigação ou a correção e como ela foi conferida."
      onClose={onClose}
    >
      <form
        onSubmit={async (e) => {
          e.preventDefault();
          setBusy(true);
          setError("");
          try {
            await changeProblem(problem.scope, problem.id, status, note);
            onClose();
          } catch (err) {
            setError(problemText(err));
            void reportProblem(err, {
              scope: problem.scope,
              operation: "UPDATE_PROBLEM",
            });
          } finally {
            setBusy(false);
          }
        }}
      >
        <p className="body-copy">{problem.message}</p>
        <Field label="Nova situação">
          <select
            value={status}
            onChange={(e) => setStatus(e.target.value as ProblemStatus)}
          >
            {Object.entries(PROBLEM_STATUS)
              .filter(([key]) => key !== "monitoring")
              .map(([key, label]) => (
                <option key={key} value={key}>
                  {label}
                </option>
              ))}
          </select>
        </Field>
        <Field label="O que foi feito e como foi conferido">
          <textarea
            rows={5}
            required
            minLength={10}
            maxLength={600}
            value={note}
            onChange={(e) => setNote(e.target.value)}
            placeholder="Ex.: Corrigi o formato do arquivo e a importação terminou sem erro."
          />
        </Field>
        <p className="problems-privacy">
          A situação é informada por você. Resolver este registro não altera
          avisos, tentativas ou autorizações do Instagram.
        </p>
        {error ? (
          <p className="notice error" role="alert">
            {error}
          </p>
        ) : null}
        <div className="modal-actions">
          <button type="button" className="button secondary" onClick={onClose}>
            Cancelar
          </button>
          <button className="button primary" disabled={busy}>
            Salvar acompanhamento
          </button>
        </div>
      </form>
    </Modal>
  );
}
