import { useState } from "react";
import {
  ArrowUpRight,
  Check,
  CircleHelp,
  Download,
  Flag,
  Target,
} from "lucide-react";
import type {
  AccountCommand,
  AccountWorkspace,
  InsightReport,
} from "../core/types.ts";
import type {
  ImprovementMetric,
  ImprovementReview,
  ImprovementSignal,
} from "../core/improvement.ts";
import { MARKET_MODELS, sectorLabel } from "../core/market.ts";
import { COVERAGE_LABELS, localDay } from "../core/insights.ts";
import { download } from "../core/io.ts";
import { Field, Modal } from "./components.tsx";

type Run = (command: AccountCommand, success?: string) => Promise<boolean>;
const number = (value: number) =>
  value !== 0 && Math.abs(value) < 0.01
    ? `${value < 0 ? "−" : ""}<0,01`
    : new Intl.NumberFormat("pt-BR", { maximumFractionDigits: 2 }).format(
        value,
      );
const value = (n: number, unit: ImprovementMetric["unit"]) =>
  `${number(n)}${unit === "percent" ? "%" : unit === "seconds" ? " s" : ""}`;
const date = (v: string) => v.split("-").reverse().join("/");
const basis = {
  previous: "Período anterior",
  history: "Sua média recente",
  sector: "Referência cadastrada do setor",
};
function status(s: ImprovementSignal) {
  if (s.difference === 0) return "No mesmo nível";
  return `${s.difference < 0 ? "Abaixo" : "Acima"} ${s.basis === "previous" ? "do período anterior" : s.basis === "history" ? "da sua referência histórica" : "da referência do setor"}`;
}
function Signal({
  signal: s,
  metric,
}: {
  signal: ImprovementSignal;
  metric: ImprovementMetric;
}) {
  const difference =
    metric.unit === "percent"
      ? `${s.difference > 0 ? "+" : ""}${number(s.difference)} p.p.`
      : s.relative === undefined
        ? `${s.difference > 0 ? "+" : ""}${value(s.difference, metric.unit)}`
        : `${s.relative > 0 ? "+" : ""}${number(s.relative)}%`;
  return (
    <div className={`improvement-signal ${s.tone}`}>
      <span>{basis[s.basis]}</span>
      <strong>
        {value(s.reference, metric.unit)} <small>{difference}</small>
      </strong>
      <p>{status(s)}</p>
    </div>
  );
}
export function ImprovementCenter({
  account,
  report,
  review,
  run,
  busy,
  onExplore,
  onContent,
  onMarket,
}: {
  account: AccountWorkspace;
  report: InsightReport;
  review: ImprovementReview;
  run: Run;
  busy: boolean;
  onExplore: () => void;
  onContent: () => void;
  onMarket: () => void;
}) {
  const [expanded, setExpanded] = useState(false),
    [editing, setEditing] = useState(false);
  const [showStrengths, setShowStrengths] = useState(false);
  const priorities = expanded
    ? review.priorities
    : review.priorities.slice(0, 6);
  const profile = account.market?.profile;
  return (
    <section
      id="improvement-center"
      className="improvement-center"
      aria-label="Plano de melhoria do Instagram"
    >
      <div className="improvement-heading">
        <div>
          <span className="eyebrow">DOS NÚMEROS PARA O PRÓXIMO PASSO</span>
          <h3>Onde melhorar agora</h3>
          <p>
            Vermelho destaca uma diferença desfavorável. Cada quadro mostra a
            base e um teste para o próximo ciclo.
          </p>
        </div>
        <button
          className="button secondary"
          onClick={() =>
            download(
              `orbita-${account.username}-melhorias.json`,
              JSON.stringify(
                {
                  version: 1,
                  orbitaVersion: "0.19.1",
                  account: account.username,
                  report: {
                    start: report.start,
                    end: report.end,
                    coverage: report.coverage,
                  },
                  review,
                  method:
                    "Comparação descritiva; referências do setor informadas manualmente. Não é prova de causa ou de resultado futuro.",
                },
                null,
                2,
              ),
              "application/json",
            )
          }
        >
          <Download size={14} /> Exportar diagnóstico
        </button>
      </div>
      {report.note ? (
        <p className="improvement-report-note">
          Contexto do relatório: {report.note}
        </p>
      ) : null}
      <div className="improvement-overview">
        <article className="improvement-total">
          <Flag size={19} />
          <strong>{review.priorities.length}</strong>
          <span>indicadores para melhorar</span>
        </article>
        <article className="improvement-total good">
          <Check size={19} />
          <strong>{review.strengths.length}</strong>
          <span>indicadores favoráveis</span>
        </article>
        <article className="improvement-total history">
          <Target size={19} />
          <strong>
            {review.historyPeriods >= 3
              ? review.historyPeriods
              : `${review.historyPeriods}/3`}
          </strong>
          <span>
            {review.historyPeriods >= 3
              ? "períodos disponíveis para a base histórica"
              : "períodos · mínimo para uma média"}
          </span>
        </article>
      </div>
      {review.blocked ? (
        <div className="improvement-waiting">
          <CircleHelp size={20} />
          <p>
            <strong>Falta uma base comparável</strong>
            {review.blocked}
          </p>
        </div>
      ) : (
        <>
          <p className="improvement-period">
            Relatório: {date(report.start)} a {date(report.end)} ·{" "}
            {COVERAGE_LABELS[report.coverage]}. Histórico: até 6 períodos
            anteriores de mesma duração, sem sobreposição, nos últimos 180 dias.
            Cada média por indicador exige pelo menos 3 valores disponíveis.
          </p>
          {priorities.length ? (
            <div className="improvement-grid">
              {priorities.map((metric, index) => {
                const reference =
                  metric.signals.find(
                    (s) => s.basis === "sector" && s.tone === "negative",
                  ) ||
                  metric.signals.find(
                    (s) => s.basis === "history" && s.tone === "negative",
                  ) ||
                  metric.signals.find((s) => s.tone === "negative")!;
                return (
                  <article
                    className="improvement-card"
                    key={metric.key}
                    aria-label={`Melhorar: ${metric.label}`}
                  >
                    <div className="improvement-card-heading">
                      <span>
                        <Flag size={14} /> Ponto de atenção {index + 1}
                      </span>
                      <span>Plano sugerido</span>
                    </div>
                    <h4>{metric.label}</h4>
                    <div className="improvement-current">
                      <strong>{value(metric.current, metric.unit)}</strong>
                      <span>no período selecionado</span>
                    </div>
                    <div className="improvement-signals">
                      {metric.signals.map((s) => (
                        <Signal key={s.basis} signal={s} metric={metric} />
                      ))}
                    </div>
                    <div className="improvement-next">
                      <span>O que testar</span>
                      <p>{metric.action.test}</p>
                    </div>
                    <p className="improvement-goal">
                      <Target size={14} /> Referência para buscar:{" "}
                      <strong>{value(reference.reference, metric.unit)}</strong>{" "}
                      · {basis[reference.basis].toLowerCase()}.
                    </p>
                    <p className="improvement-measure">
                      Como medir: registre a mesma métrica ao encerrar outro
                      período de igual duração e cobertura. A referência é um
                      ponto de comparação; recuperação não é garantida.
                    </p>
                    <details>
                      <summary>Investigar e conferir a base</summary>
                      <p>{metric.action.investigate}</p>
                      {metric.signals.map((s) => (
                        <div className="improvement-evidence" key={s.basis}>
                          <strong>{basis[s.basis]}</strong>
                          <p>
                            {s.method} {s.samples}{" "}
                            {s.basis === "sector"
                              ? "contas na amostra informada"
                              : s.samples === 1
                                ? "período"
                                : "períodos"}{" "}
                            · {date(s.start)} a {date(s.end)}.
                          </p>
                          {s.basis === "sector" &&
                          review.market.benchmark?.note ? (
                            <p>{review.market.benchmark.note}</p>
                          ) : null}
                          {s.sourceUrl ? (
                            <a
                              href={s.sourceUrl}
                              target="_blank"
                              rel="noreferrer"
                            >
                              {s.sourceTitle} ↗
                            </a>
                          ) : null}
                        </div>
                      ))}
                    </details>
                    <button className="text-link" onClick={onContent}>
                      Ver conteúdos para o teste <ArrowUpRight size={13} />
                    </button>
                  </article>
                );
              })}
            </div>
          ) : (
            <div className="improvement-waiting">
              <Check size={20} />
              <p>
                <strong>
                  {review.strengths.length || review.stable.length
                    ? "Sem diferença desfavorável nas bases disponíveis"
                    : "Ainda não há comparação suficiente"}
                </strong>
                {review.strengths.length || review.stable.length
                  ? "Indicadores estáveis ou favoráveis nas bases disponíveis. Continue acompanhando o próximo ciclo. Ausência de dado não conta como melhora."
                  : "Registre o período anterior ou pelo menos três períodos históricos comparáveis. Uma referência do setor também precisa de dados e método compatíveis."}
              </p>
            </div>
          )}
          {review.priorities.length > 6 ? (
            <button
              className="button secondary"
              onClick={() => setExpanded(!expanded)}
            >
              {expanded
                ? "Mostrar os primeiros pontos"
                : `Ver todos os ${review.priorities.length} pontos`}
            </button>
          ) : null}
          {review.strengths.length ? (
            <div className="improvement-strengths">
              <h4>
                <Check size={17} /> O que está funcionando nos números
              </h4>
              <p>
                Indicadores favoráveis nas bases disponíveis, sem diferença
                desfavorável em outra base. Isso orienta novos testes; não
                comprova o motivo do resultado.
              </p>
              <div>
                {(showStrengths
                  ? review.strengths
                  : review.strengths.slice(0, 4)
                ).map((metric) => {
                  const s =
                    metric.signals.find(
                      (s) => s.basis === "history" && s.tone === "positive",
                    ) || metric.signals.find((s) => s.tone === "positive")!;
                  return (
                    <article key={metric.key}>
                      <span>{metric.label}</span>
                      <strong>{value(metric.current, metric.unit)}</strong>
                      <small>
                        {status(s)} · {basis[s.basis].toLowerCase()}:{" "}
                        {value(s.reference, metric.unit)}.
                      </small>
                    </article>
                  );
                })}
              </div>
              {review.strengths.length > 4 ? (
                <button
                  className="button secondary small"
                  onClick={() => setShowStrengths(!showStrengths)}
                >
                  {showStrengths
                    ? "Mostrar os primeiros indicadores"
                    : `Ver os ${review.strengths.length} indicadores favoráveis`}
                </button>
              ) : null}
              <button className="text-link" onClick={onExplore}>
                Explorar padrões para repetir como teste{" "}
                <ArrowUpRight size={13} />
              </button>
            </div>
          ) : null}
        </>
      )}
      {review.stable.length ? (
        <details className="improvement-stable">
          <summary>
            {review.stable.length} indicadores no mesmo nível das bases
            disponíveis
          </summary>
          <p>
            {review.stable
              .map(
                (metric) =>
                  `${metric.label}: ${value(metric.current, metric.unit)}`,
              )
              .join(" · ")}
            . Estabilidade é diferente de ausência de comparação.
          </p>
        </details>
      ) : null}
      <div className={`improvement-market ${review.market.status}`}>
        <div>
          <span className="eyebrow">COMPARAÇÃO COM O SETOR</span>
          <h4>
            {review.market.status === "ready"
              ? "Referência compatível para engajamento"
              : review.market.status === "missing"
                ? "Mercado: sem base cadastrada"
                : "Referência cadastrada, comparação suspensa"}
          </h4>
          <p>{review.market.reason}</p>
          {review.market.benchmark ? (
            <p>
              <a
                href={review.market.benchmark.sourceUrl}
                target="_blank"
                rel="noreferrer"
              >
                {review.market.benchmark.sourceTitle} ↗
              </a>{" "}
              · {sectorLabel(review.market.benchmark.sector)} ·{" "}
              {MARKET_MODELS[review.market.benchmark.model]} ·{" "}
              {review.market.benchmark.sampleSize} contas.
            </p>
          ) : null}
        </div>
        <div className="improvement-market-actions">
          <button className="button secondary" onClick={() => setEditing(true)}>
            {account.performanceBenchmark
              ? "Revisar referência"
              : "Informar referência do setor"}
          </button>
          {account.performanceBenchmark ? (
            <button
              className="text-link"
              disabled={busy}
              onClick={() =>
                void run(
                  { type: "REMOVE_PERFORMANCE_BENCHMARK" },
                  "Referência removida desta conta.",
                )
              }
            >
              Remover referência
            </button>
          ) : null}
        </div>
      </div>
      <p className="improvement-footnote">
        Os testes são propostas, não causas comprovadas. O painel não presume
        vendas, bloqueio, mudança de algoritmo ou desempenho de todo o mercado.
      </p>
      {editing ? (
        <BenchmarkModal
          account={account}
          report={report}
          run={run}
          busy={busy}
          onClose={() => setEditing(false)}
          onMarket={() => {
            setEditing(false);
            onMarket();
          }}
        />
      ) : null}
      {!profile ? (
        <p className="improvement-footnote">
          O setor é definido por conta no Radar do setor.
        </p>
      ) : null}
    </section>
  );
}

function BenchmarkModal({
  account,
  report,
  run,
  busy,
  onClose,
  onMarket,
}: {
  account: AccountWorkspace;
  report: InsightReport;
  run: Run;
  busy: boolean;
  onClose: () => void;
  onMarket: () => void;
}) {
  const saved = account.performanceBenchmark,
    profile = account.market?.profile;
  const [form, setForm] = useState({
    value: saved?.value.toString() || "",
    sourceTitle: saved?.sourceTitle || "",
    sourceUrl: saved?.sourceUrl || "",
    start: saved?.start || report.start,
    end: saved?.end || report.end,
    coverage:
      saved?.coverage ||
      (report.coverage === "unknown" ? "organic" : report.coverage),
    sampleSize: saved?.sampleSize.toString() || "",
    note: saved?.note || "",
  });
  const change = (key: keyof typeof form, v: string) =>
    setForm((previous) => ({ ...previous, [key]: v }));
  return (
    <Modal
      title="Referência de engajamento do setor"
      subtitle="Cadastre uma fonte comparável para esta conta. A fonte é informada por você; não há consulta automática."
      onClose={onClose}
    >
      {!profile || profile.model === "unknown" ? (
        <div className="improvement-waiting">
          <CircleHelp size={20} />
          <div>
            <p>
              Defina o setor e o modelo do negócio desta conta no Radar antes de
              usar uma referência.
            </p>
            <button className="button primary" onClick={onMarket}>
              Definir setor no Radar
            </button>
          </div>
        </div>
      ) : (
        <form
          onSubmit={async (e) => {
            e.preventDefault();
            if (
              await run(
                {
                  type: "SAVE_PERFORMANCE_BENCHMARK",
                  data: {
                    ...form,
                    account: account.username,
                    sector: profile.sector,
                    model: profile.model,
                    metric: "interactions_per_reach",
                    value: Number(form.value),
                    sampleSize: Number(form.sampleSize),
                  },
                },
                "Referência do setor salva para esta conta.",
              )
            )
              onClose();
          }}
        >
          <div className="improvement-form-note">
            <strong>
              {sectorLabel(profile.sector)} · {MARKET_MODELS[profile.model]}
            </strong>
            <p>
              Fórmula aceita: interações ÷ alcance × 100, no agregado da conta.
              Não use taxas por seguidores, visualizações ou por post neste
              campo. A comparação exige duração e cobertura iguais; referência
              com mais de 180 dias fica suspensa.
            </p>
          </div>
          <div className="form-grid">
            <Field label="Interações / alcance (%)">
              <input
                required
                type="number"
                min="0"
                max="1000000"
                step="any"
                value={form.value}
                onChange={(e) => change("value", e.target.value)}
              />
            </Field>
            <Field
              label="Contas na amostra"
              hint="Mínimo de 5 contas; isso não garante representatividade."
            >
              <input
                required
                type="number"
                min="5"
                max="10000000"
                step="1"
                value={form.sampleSize}
                onChange={(e) => change("sampleSize", e.target.value)}
              />
            </Field>
            <Field label="Início do período da fonte">
              <input
                required
                type="date"
                min="2020-01-01"
                max={localDay()}
                value={form.start}
                onChange={(e) => change("start", e.target.value)}
              />
            </Field>
            <Field label="Fim do período da fonte">
              <input
                required
                type="date"
                min={form.start}
                max={localDay()}
                value={form.end}
                onChange={(e) => change("end", e.target.value)}
              />
            </Field>
            <Field label="Cobertura da referência">
              <select
                value={form.coverage}
                onChange={(e) => change("coverage", e.target.value)}
              >
                <option value="organic">Orgânico</option>
                <option value="paid">Pago</option>
                <option value="combined">Orgânico e pago</option>
              </select>
            </Field>
          </div>
          <Field label="Nome da fonte">
            <input
              required
              maxLength={150}
              value={form.sourceTitle}
              onChange={(e) => change("sourceTitle", e.target.value)}
              placeholder="Relatório ou estudo que usa essa fórmula"
            />
          </Field>
          <Field label="Link HTTPS da fonte">
            <input
              required
              type="url"
              maxLength={2048}
              value={form.sourceUrl}
              onChange={(e) => change("sourceUrl", e.target.value)}
              placeholder="https://…"
            />
          </Field>
          <Field
            label="Recorte e observações"
            hint="Ex.: porte das contas, país e limitações da amostra."
          >
            <textarea
              maxLength={1000}
              value={form.note}
              onChange={(e) => change("note", e.target.value)}
            />
          </Field>
          <p className="improvement-footnote">
            Referências de mercado podem usar denominadores diferentes. Consulte
            a{" "}
            <a
              href="https://help.rivaliq.com/en/articles/2043672-understanding-engagement-rates"
              target="_blank"
              rel="noreferrer"
            >
              explicação dos métodos de engajamento ↗
            </a>{" "}
            antes de copiar uma taxa. O painel compara a referência declarada;
            não verifica o estudo automaticamente.
          </p>
          <div className="modal-actions">
            <button
              type="button"
              className="button secondary"
              onClick={onClose}
            >
              Cancelar
            </button>
            <button className="button primary" disabled={busy}>
              Salvar referência
            </button>
          </div>
        </form>
      )}
    </Modal>
  );
}
