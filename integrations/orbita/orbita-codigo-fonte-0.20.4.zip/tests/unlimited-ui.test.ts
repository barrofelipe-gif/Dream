import test from "node:test";
import assert from "node:assert/strict";
import { createRequire } from "node:module";
import { runInNewContext } from "node:vm";
import { fileURLToPath } from "node:url";
import { build } from "esbuild";
import { act, createElement } from "react";
import { createRoot } from "react-dom/client";
import { JSDOM } from "jsdom";
import { initialStore, workspace } from "../src/core/accounts.ts";
import { applyCommand } from "../src/core/domain.ts";
import { emptyProblems } from "../src/core/problems.ts";
import type { Command, SpecialCommand } from "../src/core/types.ts";

// UI integration only: native transport is a fictitious capability read and a
// command recorder; no worker, network or Instagram action is present.
const compiled = (
  await build({
    entryPoints: [fileURLToPath(new URL("../src/ui/App.tsx", import.meta.url))],
    bundle: true,
    platform: "node",
    format: "cjs",
    packages: "external",
    loader: { ".css": "empty" },
    write: false,
    plugins: [
      {
        name: "isolated-native",
        setup(build) {
          build.onResolve({ filter: /\/bridge\.ts$/ }, () => ({
            path: "bridge",
            namespace: "qa",
          }));
          build.onResolve({ filter: /\/problems-client\.ts$/ }, () => ({
            path: "problems",
            namespace: "qa",
          }));
          build.onLoad({ filter: /.*/, namespace: "qa" }, ({ path }) => ({
            loader: "js",
            contents:
              path === "bridge"
                ? `
      export const isExtension=true;
      export const useAccountStore=()=>[globalThis.__qa.store,true,null];
      export const dispatch=async(command)=>{globalThis.__qa.commands.push(command);};
      export const dispatchAccount=async()=>{};
      export const readMarketPage=async()=>{throw Error('Not available in isolated QA')};
      export const readOwnRelationships=readMarketPage;
    `
                : `
      export const useProblems=()=>({store:globalThis.__qa.problems,storageError:'',sessionIds:[],persistedReadable:true});
      export const useVisibleProblemCapture=()=>{};
      export const reportProblem=async()=>{};
      export const changeProblem=async()=>{};
    `,
          }));
        },
      },
    ],
  })
).outputFiles[0].text;

async function fixture(t: any, unlimited = true, supported = true) {
  const store = initialStore(),
    account = workspace(store);
  account.username = "qa.unlimited";
  account.verifiedAt = new Date().toISOString();
  account.data.runtime.account = account.username;
  account.data.runtime.connectedAt = account.verifiedAt;
  account.data.settings = {
    ...account.data.settings,
    unlimitedAttempts: unlimited,
    dailyLimit: 5,
    sessionLimit: 5,
    intervalMinutes: 5,
  };
  account.data = applyCommand(account.data, {
    type: "CREATE_PROFILE_CAMPAIGN",
    name: "Fonte fictícia",
    profile: "qa.source",
    postUrl: "https://www.instagram.com/p/QaFixture/",
  });
  account.data = applyCommand(account.data, {
    type: "IMPORT",
    campaignId: account.data.campaigns[0].id,
    url: "https://www.instagram.com/qa.source/followers/",
    candidates: Array.from({ length: 8 }, (_, i) => ({
      username: `qa.person_${i}`,
    })),
  });
  account.data.candidates.forEach((c) => {
    c.stage = "queued";
    c.queueAccount = account.username;
    c.queuedAction = "follow";
  });
  store.sessionUsername = account.username;
  const qa = {
    store,
    problems: emptyProblems(),
    commands: [] as Array<Command | SpecialCommand>,
    supported,
  };
  const dom = new JSDOM('<div id="root"></div>', {
    url: "https://qa.invalid/",
  });
  const originals = new Map<string, PropertyDescriptor | undefined>();
  for (const [key, value] of Object.entries({
    window: dom.window,
    document: dom.window.document,
    HTMLElement: dom.window.HTMLElement,
    Event: dom.window.Event,
    IS_REACT_ACT_ENVIRONMENT: true,
  })) {
    originals.set(key, Object.getOwnPropertyDescriptor(globalThis, key));
    Object.defineProperty(globalThis, key, {
      configurable: true,
      writable: true,
      value,
    });
  }
  dom.window.HTMLDialogElement.prototype.showModal = function () {
    this.setAttribute("open", "");
  };
  dom.window.HTMLDialogElement.prototype.close = function () {
    this.removeAttribute("open");
  };
  const mod = { exports: {} as any };
  const timers = new Set<ReturnType<typeof setTimeout>>();
  const qaTimeout = (fn: () => void, ms: number) => {
    const id = setTimeout(fn, ms);
    timers.add(id);
    return id;
  };
  const sandbox = {
    module: mod,
    exports: mod.exports,
    require: createRequire(import.meta.url),
    console,
    window: dom.window,
    document: dom.window.document,
    HTMLElement: dom.window.HTMLElement,
    Event: dom.window.Event,
    structuredClone,
    crypto,
    URL,
    MutationObserver: dom.window.MutationObserver,
    setTimeout: qaTimeout,
    clearTimeout,
    setInterval,
    clearInterval,
    __qa: qa,
    location: { protocol: "chrome-extension:" },
    chrome: {
      runtime: {
        id: "qa-unlimited",
        sendMessage: async () => ({
          ok: true,
          capabilities: {
            continuousSources: true,
            allDaySchedule: true,
            unlimitedAttempts: qa.supported,
          },
        }),
      },
    },
  };
  runInNewContext(compiled, sandbox);
  const App = mod.exports.default;
  const root = createRoot(dom.window.document.getElementById("root")!);
  t.after(async () => {
    await act(async () => root.unmount());
    for (const id of timers) clearTimeout(id);
    dom.window.close();
    for (const [key, value] of originals) {
      if (value) Object.defineProperty(globalThis, key, value);
      else Reflect.deleteProperty(globalThis, key);
    }
  });
  const render = () => act(async () => root.render(createElement(App)));
  await render();
  const doc = dom.window.document;
  const button = (name: string, scope: ParentNode = doc) => {
    const b = [...scope.querySelectorAll<HTMLButtonElement>("button")].find(
      (b) =>
        b.textContent?.trim() === name ||
        (name === "Fila de ações" && b.textContent?.trim().startsWith(name)),
    );
    assert.ok(b, `Botão ausente: ${name}`);
    return b;
  };
  const click = (node: HTMLElement) => act(async () => node.click());
  const refresh = async () => {
    await click(button("Preferências"));
    await click(button("Conferir recurso sem teto"));
  };
  return { qa, account, root, doc, button, click, render, refresh };
}

test("painel/fila/ritmo sem teto mantêm contadores finitos sem progresso ou razão5/5; START leva prova explícita", async (t) => {
  const f = await fixture(t);
  assert.match(
    f.doc.querySelector(".safety-overview")!.textContent!,
    /sem teto diário ou por lote/,
  );
  assert.doesNotMatch(
    f.doc.querySelector(".safety-overview")!.textContent!,
    /0 de 5|lotes de até 5|Infinity|NaN/,
  );
  await f.click(f.button("Ritmo e cuidados"));
  assert.equal(f.doc.querySelectorAll("progress").length, 0);
  assert.match(
    f.doc.querySelector(".safety-metrics")!.textContent!,
    /sem teto/,
  );
  assert.doesNotMatch(
    f.doc.querySelector(".safety-metrics")!.textContent!,
    /\/ 5|Infinity|NaN|null/,
  );
  await f.click(f.button("Fila de ações"));
  assert.match(
    f.doc.querySelector(".execution-banner")!.textContent!,
    /0 tentativas hoje · sem teto/,
  );
  assert.match(
    f.doc.querySelector(".queue-settings")!.textContent!,
    /Intervalo de 5 min.*Sem teto diário ou por lote/,
  );
  await f.click(f.button("Iniciar fila"));
  assert.match(
    f.doc.querySelector(".start-summary")!.textContent!,
    /Sem teto.*NESTA FILA AGORA8 tentativas/,
  );
  const review = f.doc.querySelector<HTMLInputElement>(".start-review input")!;
  await f.click(review);
  await f.click(f.button("Iniciar lote de até 8"));
  assert.equal(f.qa.commands.length, 1);
  const start = f.qa.commands[0] as Extract<SpecialCommand, { type: "START" }>;
  assert.equal(start.type, "START");
  assert.equal(start.unlimitedAttemptsReviewed, true);
  assert.equal(start.reviewedQueue?.length, 8);
});

test("START manual perde revisão com flip da preferência e não reutiliza token ao voltar", async (t) => {
  const f = await fixture(t, false);
  await f.click(f.button("Fila de ações"));
  await f.click(f.button("Iniciar fila"));
  const review = () =>
    f.doc.querySelector<HTMLInputElement>(".start-review input")!;
  await f.click(review());
  assert.equal(f.button("Iniciar lote de até 5").disabled, false);
  f.account.data.settings.unlimitedAttempts = true;
  await f.render();
  assert.equal(review().checked, false);
  assert.equal(f.button("Iniciar lote de até 8").disabled, true);
  f.account.data.settings.unlimitedAttempts = false;
  await f.render();
  assert.equal(review().checked, false);
  assert.equal(f.button("Iniciar lote de até 5").disabled, true);
  assert.equal(f.qa.commands.length, 0);
});

test("START manual sem capability não inicia flag salva; após suporte exige revisão nova", async (t) => {
  const f = await fixture(t, true, false);
  await f.click(f.button("Fila de ações"));
  await f.click(f.button("Iniciar fila"));
  await f.click(f.doc.querySelector<HTMLInputElement>(".start-review input")!);
  assert.equal(f.button("Iniciar lote de até 8").disabled, true);
  assert.match(
    f.doc.querySelector("dialog")!.textContent!,
    /Sem teto de quantidade está pendente/,
  );
  await f.click(f.button("Iniciar lote de até 8"));
  assert.equal(f.qa.commands.length, 0);
});

function configureWaitingRoutine(account: ReturnType<typeof workspace>) {
  const source = account.data.campaigns[0];
  account.data.settings.allDay = true;
  source.continuous = {
    account: account.username!,
    enabled: true,
    autoFollow: true,
    pollMinutes: 15,
    authorizationId: "qa-source-lease",
    authorizedAt: new Date().toISOString(),
    status: "ready",
    partial: true,
  };
  account.data.continuous = {
    account: account.username!,
    mode: "running",
    sourceIds: [source.id],
    authorizationId: "qa-global-lease",
  };
  account.data.runtime.mode = "paused";
  account.data.runtime.pauseReason =
    "Aguardando o intervalo de 5 minutos entre ações.";
  account.data.runtime.nextRun = Date.now() + 180000;
  const candidate = account.data.candidates[0];
  candidate.continuousSourceId = source.id;
  candidate.continuousAuthorizationId = source.continuous.authorizationId;
  return { source, candidate };
}

test("fila contínua entre ações mostra espera sem apagar motivo ou próximo horário", async (t) => {
  const f = await fixture(t);
  configureWaitingRoutine(f.account);
  await f.render();
  await f.click(f.button("Fila de ações"));
  const banner = f.doc.querySelector(".execution-banner")!;
  assert.equal(
    banner.querySelector("strong")!.textContent,
    "Aguardando próxima ação",
  );
  assert.match(banner.textContent!, /intervalo de 5 minutos/);
  assert.match(banner.textContent!, /Próxima verificação:/);
  assert.equal(f.qa.commands.length, 0);
});

test("reconexão automática só aparece com retry vinculado às autorizações atuais", async (t) => {
  const f = await fixture(t);
  const { source, candidate } = configureWaitingRoutine(f.account);
  f.account.data.continuous!.preparationRetry = {
    account: f.account.username!,
    candidateId: candidate.id,
    username: candidate.username,
    sourceId: source.id,
    authorizationId: "qa-global-lease",
    sourceAuthorizationId: "qa-source-lease",
    failures: 1,
    retryAt: new Date(Date.now() + 60000).toISOString(),
    phase: "aguardando STATUS",
  };
  await f.render();
  await f.click(f.button("Fila de ações"));
  const title = () =>
    f.doc.querySelector(".execution-banner strong")!.textContent;
  assert.equal(title(), "Reconectando automaticamente");
  f.account.data.continuous!.preparationRetry!.authorizationId =
    "qa-stale-lease";
  await f.render();
  assert.equal(title(), "Aguardando próxima ação");
  assert.equal(f.qa.commands.length, 0);
});

test("pausa manual da rotina continua explícita e não promete retomada automática", async (t) => {
  const f = await fixture(t);
  configureWaitingRoutine(f.account);
  f.account.data = applyCommand(f.account.data, { type: "PAUSE_CONTINUOUS" });
  await f.render();
  await f.click(f.button("Fila de ações"));
  assert.equal(
    f.doc.querySelector(".execution-banner strong")!.textContent,
    "Execução pausada",
  );
  assert.equal(f.account.data.continuous!.mode, "paused");
  assert.equal(f.qa.commands.length, 0);
});
