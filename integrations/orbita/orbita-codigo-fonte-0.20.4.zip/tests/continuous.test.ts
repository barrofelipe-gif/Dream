import test from "node:test";
import assert from "node:assert/strict";
import {
  accountBackup,
  accountCommand,
  applyScopedCommand,
  initialStore,
  migrateStore,
  workspace,
} from "../src/core/accounts.ts";
import {
  applyCommand,
  mergeCandidates,
  sourceUrl,
} from "../src/core/domain.ts";
import {
  beginContinuousReading,
  commitContinuousReading,
  configureContinuousSource,
  continuousCandidateEligibility,
  continuousDayKey,
  continuousReview,
  continuousSourceEligibility,
  enabledContinuousSourceIds,
  failContinuousReading,
  nextContinuousCheck,
  pauseContinuous,
  renewContinuousDay,
  startContinuous,
  validateContinuousState,
  continuousPreparationLease,
  continuousPreparationRetry,
  deferContinuousPreparation,
  deferContinuousReading,
} from "../src/core/continuous.ts";
import { continuousWakeAt } from "../src/extension/continuous-schedule.ts";
import type { CandidateInput } from "../src/core/types.ts";
import type { ContinuousReading } from "../src/core/continuous.ts";

function fixture(autoFollow = true) {
  const now = new Date();
  const store = accountCommand(initialStore(), {
    type: "ADD_ACCOUNT",
    username: "qa.owner",
  });
  const a = workspace(store);
  a.verifiedAt = now.toISOString();
  a.data.runtime.connectedAt = now.toISOString();
  for (const target of ["qa.source_a", "qa.source_b"])
    a.data = applyCommand(a.data, {
      type: "CREATE_CAMPAIGN",
      name: target,
      kind: "followers",
      target,
    });
  const [one, two] = a.data.campaigns;
  for (const c of [one, two])
    a.data = configureContinuousSource(
      a.data,
      {
        type: "CONFIGURE_CONTINUOUS_SOURCE",
        id: c.id,
        enabled: true,
        autoFollow,
        reviewed: true,
      },
      now,
    );
  return { store, a, one: a.data.campaigns[0], two: a.data.campaigns[1], now };
}
function start(f: ReturnType<typeof fixture>, ids = [f.one.id, f.two.id]) {
  f.a.data = startContinuous(f.a, ids, true, f.now);
}

test("recuperação pré-reserva persiste leases, cresce com teto de espera e não atrasa outro candidato após cancelamento", () => {
  for (const cancel of ["remove", "configure"] as const) {
    const f = fixture(); f.a.data.settings.allDay = true; start(f);
    scan(f, [{ username: "qa.first" }], "qa-first", f.one.id);
    scan(f, [{ username: "qa.second" }], "qa-second", f.two.id);
    const first = f.a.data.candidates.find((c) => c.username === "qa.first")!;
    const lease = continuousPreparationLease(f.a, first)!;
    f.a.data.runtime.nextRun = f.now.getTime() + 1000;
    const ledger = structuredClone(f.a.data.dailyAttempts), last = structuredClone(f.a.data.lastAttempts);
    for (let failures = 1; failures <= 5; failures++) {
      f.a.data = deferContinuousPreparation(f.a, lease, "STATUS", f.now)!;
      assert.equal(continuousPreparationRetry(f.a)?.failures, failures);
      assert.equal(Date.parse(f.a.data.continuous!.preparationRetry!.retryAt) - f.now.getTime(), [60000, 180000, 600000, 900000, 900000][failures - 1]);
      assert.equal(f.a.data.runtime.nextRun, f.now.getTime() + 1000);
    }
    assert.equal(continuousWakeAt(f.a, f.now.getTime()), f.now.getTime() + 900000);
    if (cancel === "remove") f.a.data = applyCommand(f.a.data, { type: "REMOVE_FROM_QUEUE", ids: [first.id] });
    else f.a.data = configureContinuousSource(f.a.data, { type: "CONFIGURE_CONTINUOUS_SOURCE", id: f.one.id, enabled: false, autoFollow: false }, f.now);
    assert.equal(continuousPreparationRetry(f.a), undefined);
    assert.equal(continuousWakeAt(f.a, f.now.getTime()), f.now.getTime() + 1000);
    assert.deepEqual(f.a.data.dailyAttempts, ledger); assert.deepEqual(f.a.data.lastAttempts, last);
    assert.equal(deferContinuousPreparation(f.a, lease, "STATUS", f.now), undefined);
  }
});

test("a contagem de preparo de um candidato não é herdada por outro candidato elegível", () => {
  const f = fixture(); start(f); scan(f, [{ username: "qa.first" }, { username: "qa.second" }]);
  const first = f.a.data.candidates.find((c) => c.username === "qa.first")!;
  const second = f.a.data.candidates.find((c) => c.username === "qa.second")!;
  const firstLease = continuousPreparationLease(f.a, first)!;
  const secondLease = continuousPreparationLease(f.a, second)!;
  f.a.data = deferContinuousPreparation(f.a, firstLease, "STATUS", f.now)!;
  f.a.data = deferContinuousPreparation(f.a, firstLease, "STATUS", f.now)!;
  assert.equal(f.a.data.continuous!.preparationRetry!.failures, 2);
  f.a.data = deferContinuousPreparation(f.a, secondLease, "STATUS", f.now)!;
  const retry = f.a.data.continuous!.preparationRetry!;
  assert.equal(retry.candidateId, second.id);
  assert.equal(retry.failures, 1);
  assert.equal(Date.parse(retry.retryAt) - f.now.getTime(), 60000);
});

test("recuperação não revive leases de pausa, preferências, troca ou restauração", () => {
  const f = fixture(); start(f); scan(f, [{ username: "qa.first" }]);
  const lease = continuousPreparationLease(f.a, f.a.data.candidates[0])!;
  f.a.data = deferContinuousPreparation(f.a, lease, "STATUS", f.now)!;
  const original = structuredClone(f.a);
  for (const kind of ["pause", "settings", "source", "warning", "switch", "restore", "wrong-lease", "protected"] as const) {
    f.a.data = structuredClone(original.data); delete f.a.relationships;
    if (kind === "pause") f.a.data = pauseContinuous(f.a.data);
    if (kind === "settings") f.a.data = applyCommand(f.a.data, { type: "SETTINGS", settings: f.a.data.settings });
    if (kind === "source") f.a.data = configureContinuousSource(f.a.data, { type: "CONFIGURE_CONTINUOUS_SOURCE", id: f.one.id, enabled: true, autoFollow: true, reviewed: true }, f.now);
    if (kind === "warning") f.a.data = applyCommand(f.a.data, { type: "REPORT_WARNING" });
    if (kind === "switch") f.a.data.runtime.account = "qa.other";
    if (kind === "restore") validateContinuousState(f.a.data, f.a.username, true, f.now);
    if (kind === "wrong-lease") f.a.data.continuous!.authorizationId = "qa-new-authorization";
    if (kind === "protected") f.a.relationships = { version: 1, snapshots: [], protections: [{ username: "qa.first", enabled: true, reason: "friend", note: "", updatedAt: f.now.toISOString() }] };
    assert.equal(continuousPreparationRetry(f.a), undefined, kind);
    const before = structuredClone(f.a.data);
    assert.equal(deferContinuousPreparation(f.a, lease, "STATUS", f.now), undefined, kind);
    assert.deepEqual(f.a.data, before);
  }
});

test("recuperação da fonte exige runId e leases exatos e não revoga a fila já capturada", () => {
  const f = fixture(); start(f); scan(f, [{ username: "qa.first" }]);
  f.a.data.campaigns.find((c) => c.id === f.one.id)!.continuous!.nextCheckAt = f.now.toISOString();
  f.a.data = beginContinuousReading(f.a, f.one.id, "qa-read-timeout", f.now);
  const cfg = f.a.data.campaigns.find((c) => c.id === f.one.id)!.continuous!;
  const queued = structuredClone(f.a.data.candidates), auth = f.a.data.continuous!.authorizationId!;
  assert.equal(deferContinuousReading(f.a, f.one.id, "qa-wrong-run", auth, cfg.authorizationId!, "STEP", f.now), undefined);
  assert.equal(deferContinuousReading(f.a, f.one.id, cfg.runId!, "qa-wrong-lease", cfg.authorizationId!, "STEP", f.now), undefined);
  f.a.data = deferContinuousReading(f.a, f.one.id, cfg.runId!, auth, cfg.authorizationId!, "STEP", f.now)!;
  assert.deepEqual(f.a.data.candidates, queued);
  const retry = f.a.data.campaigns.find((c) => c.id === f.one.id)!.continuous!;
  assert.equal(retry.status, "ready"); assert.equal(retry.runId, undefined); assert.equal(retry.enabled, true);
  assert.equal(Date.parse(retry.nextCheckAt!) - f.now.getTime(), 60000);
  validateContinuousState(f.a.data, f.a.username, true, f.now);
  assert.equal(f.a.data.campaigns.find((c) => c.id === f.one.id)!.continuous!.readRetry, undefined);
  assert.equal(f.a.data.continuous?.mode, "paused");
});
function scan(
  f: ReturnType<typeof fixture>,
  names: CandidateInput[],
  runId = "run-one",
  id = f.one.id,
  now = f.now,
) {
  f.a.data = beginContinuousReading(f.a, id, runId, now);
  const c = f.a.data.campaigns.find((c) => c.id === id)!;
  const reading: ContinuousReading = {
    sourceId: id,
    runId,
    authorizationId: f.a.data.continuous!.authorizationId!,
    account: f.a.username!,
    candidates: names,
    url: sourceUrl(c.kind, c.target),
    at: now.toISOString(),
  };
  const result = commitContinuousReading(f.a, reading, now);
  f.a.data = result.state;
  return { result, reading };
}

test("configurar exige revisão, intervalo válido e conta; não inicia a rotina", () => {
  const f = fixture();
  assert.equal(f.one.continuous?.pollMinutes, 15);
  assert.equal(f.a.data.continuous?.mode, "paused");
  assert.equal(nextContinuousCheck(f.a), undefined);
  for (const pollMinutes of [4, 1441, 5.5])
    assert.throws(() =>
      configureContinuousSource(f.a.data, {
        type: "CONFIGURE_CONTINUOUS_SOURCE",
        id: f.one.id,
        enabled: true,
        autoFollow: true,
        pollMinutes,
        reviewed: true,
      }),
    );
  assert.throws(
    () =>
      configureContinuousSource(f.a.data, {
        type: "CONFIGURE_CONTINUOUS_SOURCE",
        id: f.one.id,
        enabled: true,
        autoFollow: true,
      }),
    /autorize/,
  );
  const before = structuredClone(f.a.data);
  const unsupported = applyCommand(f.a.data, {
    type: "CREATE_CAMPAIGN",
    name: "Hashtag QA",
    kind: "hashtag",
    target: "qa_tag",
  });
  assert.throws(
    () =>
      configureContinuousSource(unsupported, {
        type: "CONFIGURE_CONTINUOUS_SOURCE",
        id: unsupported.campaigns[0].id,
        enabled: true,
        autoFollow: true,
        reviewed: true,
      }),
    /seguidores, comentários ou curtidas/,
  );
  assert.deepEqual(f.a.data, before);
  assert.equal(
    continuousReview({ ...f.a, data: unsupported }).sources.find(
      (c) => c.id === unsupported.campaigns[0].id,
    )?.configurable,
    false,
  );
});

test("START exige revisão e sessão; snapshot limita fontes e nova configuração não inicia escondida", () => {
  const f = fixture();
  assert.throws(() => startContinuous(f.a, [f.one.id], false), /revise/);
  assert.throws(
    () => startContinuous({ ...f.a, verifiedAt: undefined }, [f.one.id], true),
    /Conecte/,
  );
  start(f, [f.one.id]);
  assert.equal(
    continuousSourceEligibility(f.a, f.one.id, f.now).eligible,
    true,
  );
  assert.equal(
    continuousSourceEligibility(f.a, f.two.id, f.now).eligible,
    false,
  );
  const oldGlobal = f.a.data.continuous!.authorizationId;
  f.a.data = configureContinuousSource(
    f.a.data,
    {
      type: "CONFIGURE_CONTINUOUS_SOURCE",
      id: f.two.id,
      enabled: true,
      autoFollow: true,
      reviewed: true,
    },
    f.now,
  );
  assert.equal(f.a.data.continuous?.mode, "running");
  assert.equal(f.a.data.continuous?.authorizationId, oldGlobal);
  assert.deepEqual(f.a.data.continuous?.sourceIds, [f.one.id]);
  assert.equal(
    continuousSourceEligibility(f.a, f.two.id, f.now).eligible,
    false,
  );
  assert.deepEqual(
    enabledContinuousSourceIds(f.a).sort(),
    [f.one.id, f.two.id].sort(),
  );
});

test("somente descobertos no cadastro são autoqueued; dono, referência, cliente e exclusões ficam fora", () => {
  const f = fixture();
  const stages = [
    "new",
    "requested",
    "excluded",
    "unfollowed",
    "followed",
    "already",
    "failed",
  ] as const;
  mergeCandidates(
    f.a.data,
    f.one.id,
    stages.map((stage) => ({ username: `qa.old_${stage}` })),
  );
  stages.forEach((stage, i) => (f.a.data.candidates[i].stage = stage));
  f.a.relationships = {
    version: 1,
    snapshots: [],
    protections: [
      {
        username: "qa.client",
        enabled: true,
        reason: "client",
        note: "QA",
        updatedAt: f.now.toISOString(),
      },
    ],
  };
  f.a.data.settings.exclusions = ["qa.excluded"];
  const oldStages = new Map(
    f.a.data.candidates.map((c) => [c.username, c.stage]),
  );
  start(f);
  const input = [
    ...stages.map((stage) => ({ username: `qa.old_${stage}` })),
    { username: "qa.owner" },
    { username: f.one.target },
    { username: "qa.client" },
    { username: "qa.excluded" },
    { username: "qa.new" },
  ];
  const { result } = scan(f, input);
  assert.equal(result.queued, 1);
  assert.equal(result.added, 5);
  assert.equal(result.partial, true);
  for (const [name, stage] of oldStages)
    assert.equal(
      f.a.data.candidates.find((c) => c.username === name)!.stage,
      stage,
    );
  const candidate = f.a.data.candidates.find((c) => c.username === "qa.new")!;
  assert.equal(candidate.stage, "queued");
  assert.equal(candidate.continuousSourceId, f.one.id);
  assert.equal(candidate.queuedAction, "follow");
  assert.equal(continuousCandidateEligibility(f.a, candidate).eligible, true);
  assert.equal(f.a.data.campaigns[0].continuous?.lastQueued, 1);
  assert.equal(f.a.data.campaigns[0].continuous?.lastLoaded, input.length);
  assert.ok(candidate.sources.some((s) => s.campaignId === f.one.id));
});

test("origem adicional e identidade numérica não transformam antigo em novo", () => {
  const f = fixture();
  mergeCandidates(f.a.data, f.one.id, [
    { username: "qa.previous", platformId: "10001" },
  ]);
  start(f);
  const { result } = scan(f, [
    { username: "qa.renamed", platformId: "10001" },
    { username: "qa.fresh" },
  ]);
  assert.equal(result.added, 1);
  assert.equal(result.queued, 1);
  const second = scan(f, [{ username: "qa.fresh" }], "run-two", f.two.id);
  assert.equal(second.result.added, 0);
  assert.equal(second.result.queued, 0);
  const renamed = f.a.data.candidates.find((c) => c.platformId === "10001")!;
  assert.equal(renamed.stage, "new");
  assert.equal(renamed.continuousSourceId, undefined);
  const fresh = f.a.data.candidates.find((c) => c.username === "qa.fresh")!;
  assert.equal(fresh.continuousSourceId, f.one.id);
  assert.equal(fresh.sources.length, 2);
});

test("commit é atômico, idempotente por runId e rejeita lease, conta, URL ou leitura antiga", () => {
  const f = fixture();
  start(f);
  const { reading } = scan(f, [{ username: "qa.new" }]);
  const before = structuredClone(f.a.data);
  const replay = commitContinuousReading(f.a, reading, f.now);
  assert.equal(replay.replayed, true);
  assert.equal(replay.queued, 0);
  assert.deepEqual(replay.state, before);
  const later = new Date(f.now.getTime() + 16 * 60000);
  f.a.data = beginContinuousReading(f.a, f.one.id, "run-new", later);
  const current: ContinuousReading = {
    ...reading,
    runId: "run-new",
    at: later.toISOString(),
  };
  for (const patch of [
    { account: "qa.other" },
    { authorizationId: "old-lease" },
    { runId: "wrong-run" },
    { url: "https://www.instagram.com/other/followers/" },
    { at: new Date(later.getTime() - 121000).toISOString() },
  ]) {
    const unchanged = structuredClone(f.a.data);
    assert.throws(() =>
      commitContinuousReading(f.a, { ...current, ...patch }, later),
    );
    assert.deepEqual(f.a.data, unchanged);
  }
  const committed = commitContinuousReading(f.a, current, later);
  f.a.data = committed.state;
  assert.throws(
    () => commitContinuousReading(f.a, reading, later),
    /identificação ativa/,
  );
});

test("desativar ou falhar uma fonte revoga só seus queued, preserva provenance e outras fontes", () => {
  const f = fixture();
  start(f);
  scan(f, [{ username: "qa.first" }]);
  scan(f, [{ username: "qa.second" }], "run-two", f.two.id);
  const first = f.a.data.candidates.find((c) => c.username === "qa.first")!;
  first.note = "Nota preservada";
  const provenance = structuredClone(first.sources);
  const later = new Date(f.now.getTime() + 16 * 60000);
  f.a.data = beginContinuousReading(f.a, f.one.id, "run-fail", later);
  f.a.data = failContinuousReading(
    f.a,
    f.one.id,
    "run-fail",
    "Fonte não disponível",
    true,
    later,
  );
  const changed = f.a.data.candidates.find((c) => c.username === "qa.first")!;
  assert.equal(changed.stage, "new");
  assert.equal(changed.note, "Nota preservada");
  assert.deepEqual(changed.sources, provenance);
  assert.equal(changed.continuousSourceId, undefined);
  assert.equal(
    f.a.data.candidates.find((c) => c.username === "qa.second")!.stage,
    "queued",
  );
  assert.equal(f.a.data.continuous?.mode, "running");
  assert.equal(f.a.data.campaigns[0].continuous?.status, "unavailable");
  assert.equal(
    nextContinuousCheck(f.a, later),
    Date.parse(f.a.data.campaigns[1].continuous!.nextCheckAt!),
  );
  const oldAuth = f.a.data.campaigns[0].continuous!.authorizationId;
  f.a.data = configureContinuousSource(
    f.a.data,
    {
      type: "CONFIGURE_CONTINUOUS_SOURCE",
      id: f.one.id,
      enabled: true,
      autoFollow: true,
      reviewed: true,
    },
    later,
  );
  assert.notEqual(f.a.data.campaigns[0].continuous!.authorizationId, oldAuth);
  assert.equal(
    continuousSourceEligibility(f.a, f.one.id, later).eligible,
    false,
  );
});

test("pausa, aviso, troca de conta e resultado incerto impedem retomada escondida", () => {
  const f = fixture();
  start(f);
  f.a.data = beginContinuousReading(f.a, f.one.id, "pending", f.now);
  const reading: ContinuousReading = {
    sourceId: f.one.id,
    runId: "pending",
    authorizationId: f.a.data.continuous!.authorizationId!,
    account: f.a.username!,
    candidates: [{ username: "qa.one" }],
    url: sourceUrl(f.one.kind, f.one.target),
    at: f.now.toISOString(),
  };
  for (const type of ["PAUSE", "PAUSE_CONTINUOUS", "REPORT_WARNING"] as const) {
    const state = applyCommand(f.a.data, { type });
    assert.equal(state.continuous?.mode, "paused");
    assert.equal(state.continuous?.authorizationId, undefined);
    assert.throws(() =>
      commitContinuousReading({ ...f.a, data: state }, reading, f.now),
    );
  }
  f.a.data = pauseContinuous(f.a.data);
  f.a.data = startContinuous(f.a, [f.one.id], true, f.now);
  assert.throws(() => commitContinuousReading(f.a, reading, f.now));
  const switched = accountCommand(f.store, {
    type: "ADD_ACCOUNT",
    username: "qa.other",
  });
  assert.equal(
    switched.accounts.find((a) => a.username === "qa.owner")!.data.continuous
      ?.mode,
    "paused",
  );
  scan(f, [{ username: "qa.new" }], "after-restart");
  f.a.data.candidates[0].stage = "uncertain";
  const migrated = migrateStore(structuredClone(f.store));
  assert.equal(workspace(migrated).data.continuous?.mode, "paused");
});

test("fila manual e unfollow não iniciam escondidos; autorizações inválidas ou proteções barram execução", () => {
  const f = fixture();
  start(f);
  scan(f, [{ username: "qa.new" }]);
  const candidate = f.a.data.candidates[0];
  assert.throws(
    () => applyCommand(f.a.data, { type: "QUEUE", ids: [candidate.id] }),
    /Pause/,
  );
  assert.throws(
    () =>
      accountCommand(f.store, {
        type: "QUEUE_UNFOLLOW",
        account: f.a.username!,
        ids: [candidate.id],
      }),
    /Pause/,
  );
  for (const patch of [
    { queuedAction: "unfollow" },
    { continuousAuthorizationId: "old" },
    { queueAccount: "qa.other" },
    { stage: "requested" },
  ])
    assert.equal(
      continuousCandidateEligibility(f.a, { ...candidate, ...patch } as never)
        .eligible,
      false,
    );
  f.a.relationships = {
    version: 1,
    snapshots: [],
    protections: [
      {
        username: candidate.username,
        enabled: true,
        reason: "important",
        note: "QA",
        updatedAt: f.now.toISOString(),
      },
    ],
  };
  assert.equal(continuousCandidateEligibility(f.a, candidate).eligible, false);
  const manual = {
    ...candidate,
    continuousSourceId: undefined,
    continuousAuthorizationId: undefined,
  };
  assert.throws(
    () =>
      startContinuous(
        { ...f.a, data: { ...f.a.data, candidates: [manual] } },
        [f.one.id],
        true,
        f.now,
      ),
    /fila manual/,
  );
});

test("renovação é uma marca diária monotônica e não altera nenhum contador nem retoma pausa", () => {
  const f = fixture();
  f.a.data.runtime.sessionAttempts = 5;
  f.a.data.runtime.sessionStartedAt = f.now.toISOString();
  f.a.data.dailyAttempts = { "qa.owner|QA": 5 };
  f.a.data.lastAttempts = { "@qa.owner": f.now.toISOString() };
  start(f);
  const before = structuredClone(f.a.data);
  assert.equal(f.a.data.continuous?.dayKey, continuousDayKey(f.now));
  assert.equal(renewContinuousDay(f.a, f.now).renewed, false);
  const tomorrow = new Date(f.now);
  tomorrow.setDate(tomorrow.getDate() + 1);
  const next = renewContinuousDay(f.a, tomorrow);
  assert.equal(next.renewed, true);
  assert.equal(next.state.runtime.sessionAttempts, 5);
  assert.deepEqual(next.state.dailyAttempts, before.dailyAttempts);
  assert.deepEqual(next.state.lastAttempts, before.lastAttempts);
  f.a.data = next.state;
  assert.equal(renewContinuousDay(f.a, tomorrow).renewed, false);
  assert.equal(renewContinuousDay(f.a, f.now).renewed, false);
  f.a.data = pauseContinuous(f.a.data);
  tomorrow.setDate(tomorrow.getDate() + 1);
  assert.equal(renewContinuousDay(f.a, tomorrow).renewed, false);
});

test("reload legítimo preserva fonte/lease; backup e RESTORE revogam execução, fonte e tags", () => {
  const f = fixture();
  start(f);
  scan(f, [{ username: "qa.new" }]);
  const reloaded = migrateStore(structuredClone(f.store));
  assert.equal(workspace(reloaded).data.continuous?.mode, "running");
  assert.equal(
    workspace(reloaded).data.continuous?.authorizationId,
    f.a.data.continuous?.authorizationId,
  );
  const backup = accountBackup(f.a);
  assert.equal(backup.account.data.continuous?.mode, "paused");
  assert.equal(backup.account.data.continuous?.authorizationId, undefined);
  assert.equal(backup.account.data.campaigns[0].continuous?.enabled, false);
  const restored = applyScopedCommand(f.store, f.a.id, {
    type: "RESTORE",
    data: backup,
  });
  const a = workspace(restored);
  assert.equal(a.data.continuous?.mode, "paused");
  assert.deepEqual(a.data.continuous?.sourceIds, []);
  assert.equal(a.data.candidates[0].continuousSourceId, undefined);
  assert.equal(a.data.candidates[0].stage, "uncertain");
  assert.throws(
    () => startContinuous(a, [f.one.id], true),
    /Conecte|incertos|Reative/,
  );
});

test("validação recusa dono, intervalo, calendário, tokens e tags malformados sem reabilitar backup", () => {
  const f = fixture();
  start(f);
  scan(f, [{ username: "qa.new" }]);
  for (const change of [
    (s: any) => (s.continuous.account = "qa.other"),
    (s: any) => (s.continuous.sourceIds = undefined),
    (s: any) => (s.campaigns[0].continuous.account = "qa.other"),
    (s: any) => (s.campaigns[0].continuous.pollMinutes = 1),
    (s: any) =>
      (s.campaigns[0].continuous.lastCheckAt = "2026-02-30T12:00:00Z"),
    (s: any) => (s.candidates[0].continuousAuthorizationId = undefined),
  ]) {
    const state = structuredClone(f.a.data);
    change(state);
    assert.throws(() => validateContinuousState(state, f.a.username));
  }
});

test("pausa central e validação por aviso param também a fila automática sem repor orçamento", () => {
  const f = fixture();
  start(f);
  scan(f, [{ username: "qa.pending" }]);
  f.a.data.runtime.mode = "running";
  f.a.data.runtime.nextRun = f.now.getTime() + 1000;
  f.a.data.runtime.activeToken = "previous-token";
  f.a.data.runtime.activeCandidateId = "previous-candidate";
  f.a.data.runtime.activeAction = "follow";
  f.a.data.runtime.activeExpiresAt = f.now.getTime() + 5000;
  f.a.data.runtime.sessionAttempts = 5;
  f.a.data.dailyAttempts = { "qa.owner|QA": 5 };
  f.a.data.lastAttempts = { "@qa.owner": f.now.toISOString() };
  const before = structuredClone(f.a.data);
  const paused = pauseContinuous(f.a.data);
  assert.equal(paused.runtime.mode, "paused");
  assert.equal(paused.runtime.activeToken, undefined);
  assert.equal(paused.runtime.activeCandidateId, undefined);
  assert.equal(paused.runtime.activeAction, undefined);
  assert.equal(paused.runtime.activeExpiresAt, undefined);
  assert.equal(paused.runtime.nextRun, undefined);
  assert.equal(paused.runtime.sessionAttempts, 5);
  assert.deepEqual(paused.dailyAttempts, before.dailyAttempts);
  assert.deepEqual(paused.lastAttempts, before.lastAttempts);
  f.a.data.settings.hasPendingWarning = true;
  validateContinuousState(f.a.data, f.a.username);
  assert.equal(f.a.data.continuous?.mode, "paused");
  assert.equal(f.a.data.runtime.mode, "paused");
  assert.equal(f.a.data.runtime.activeToken, undefined);
});

test("retirar a última fonte ativa pausa o ciclo; desativar só revoga queued e preserva attempting", () => {
  const f = fixture();
  start(f, [f.one.id]);
  scan(f, [{ username: "qa.pending" }]);
  f.a.data.runtime.mode = "running";
  f.a.data.runtime.sessionAttempts = 3;
  const changed = configureContinuousSource(
    f.a.data,
    {
      type: "CONFIGURE_CONTINUOUS_SOURCE",
      id: f.one.id,
      enabled: false,
      autoFollow: false,
    },
    f.now,
  );
  assert.equal(changed.continuous?.mode, "paused");
  assert.deepEqual(changed.continuous?.sourceIds, []);
  assert.equal(changed.continuous?.authorizationId, undefined);
  assert.equal(changed.runtime.mode, "paused");
  assert.equal(changed.runtime.sessionAttempts, 3);
  assert.equal(changed.candidates[0].stage, "new");
  validateContinuousState(changed, f.a.username);
  const other = fixture();
  start(other);
  scan(other, [{ username: "qa.executing" }]);
  other.a.data.candidates[0].stage = "attempting";
  const later = new Date(other.now.getTime() + 16 * 60000);
  other.a.data = beginContinuousReading(
    other.a,
    other.one.id,
    "failure-with-attempt",
    later,
  );
  const failed = failContinuousReading(
    other.a,
    other.one.id,
    "failure-with-attempt",
    "Fixture de falha",
    false,
    later,
  );
  assert.equal(failed.candidates[0].stage, "attempting");
  assert.ok(failed.candidates[0].continuousAuthorizationId);
});
