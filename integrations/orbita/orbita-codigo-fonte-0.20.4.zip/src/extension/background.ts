import { trustedHostedPage, allowedHostedMessage } from "../core/hosted.ts";
import {
  applyCommand,
  attemptsToday,
  audit,
  insideWindow,
  recoverInterrupted,
  sourceUrl,
  uid,
  normalizeUsername,
} from "../core/domain.ts";
import {
  budgetStopReason,
  pendingWarningReason,
  isUnlimitedAttempts,
  hasDailyBudget,
  hasSessionBudget,
  intervalReadyAt,
  lastAttemptTime,
} from "../core/safety.ts";
import type { AccountWorkspace, AppState, Command, OwnRelationshipReading, SpecialCommand } from "../core/types.ts";
import type { FollowResult } from "./dom.ts";
import { unfollowEligibility } from "../core/prospecting.ts";
import { applyCandidateRelationshipObservation } from "../core/relationship-observation.ts";
import { PageDeadlineError, readPageMessage, withDeadline } from "./page-channel.ts";
import type { PageReadBudget, PageReadMessage } from "./page-channel.ts";
import {
  beginContinuousReading,
  commitContinuousReading,
  continuousCandidateEligibility,
  continuousSourceEligibility,
  failContinuousReading,
  pauseContinuous,
  renewContinuousDay,
  startContinuous,
  continuousPreparationLease,
  continuousPreparationRetry,
  deferContinuousPreparation,
  deferContinuousReading,
} from "../core/continuous.ts";
import type { ContinuousPreparationLease } from "../core/continuous.ts";
import { continuousAlarmName, continuousWakeAt, nextWindowAt } from "./continuous-schedule.ts";
import { marketUrl } from "../core/market.ts";
import { APP_SCOPE } from "../core/problems.ts";
import {
  readProblems,
  recordNativeProblem,
  changeNativeProblem,
  recoverNativeProblem,
  problemStoreFailure,
} from "./problem-store.ts";

import {
  workspace,
  accountCommand,
  bindVerifiedAccount,
  addSnapshot,
  applyScopedCommand,
} from "../core/accounts.ts";
import {
  readStore,
  editStore,
  storeReady as initialized,
  settledStore,
  alarmName,
} from "./account-store.ts";
let runnerActive = false;
let sourceScanActive = false;
let continuousTickActive = false;
class ContinuousCancelled extends Error {}
class ContinuousSourceError extends Error {
  readonly unavailable: boolean;
  constructor(message: string, unavailable = false) { super(message); this.unavailable = unavailable; }
}
const sleep = (ms: number) => new Promise((resolve) => setTimeout(resolve, ms));
const controllers = new Map<string, ReturnType<typeof createController>>();
function controller(id: string) {
  let value = controllers.get(id);
  if (!value) {
    value = createController(id);
    controllers.set(id, value);
  }
  return value;
}
function createController(workspaceId: string) {
  const ALARM = alarmName(workspaceId);
  const CONTINUOUS_ALARM = continuousAlarmName(workspaceId);
  const read = async (): Promise<AppState> =>
    workspace(await readStore(), workspaceId).data;
  const ensureActive = async () => {
    if ((await readStore()).activeId !== workspaceId)
      throw new Error(
        "A conta selecionada mudou. Esta tarefa foi pausada no espaço de origem.",
      );
  };
  const edit = async (
    fn: (state: AppState, account: AccountWorkspace) => AppState | void,
    allowInactive = false,
  ): Promise<AppState> => {
    const root = await editStore((store) => {
      if (!allowInactive && store.activeId !== workspaceId)
        throw new Error(
          "A conta ativa mudou durante a operação. Nenhum dado foi transferido para outra conta.",
        );
      const account = workspace(store, workspaceId);
      account.data = fn(account.data, account) || account.data;
      account.data.runtime.account = account.username;
    });
    return workspace(root, workspaceId).data;
  };
  async function pageMessage(tabId: number, message: PageReadMessage, deadline = Date.now() + 4000, phase = `aguardando ${message.type} do Instagram`, budget?: PageReadBudget): Promise<any> {
    return readPageMessage({
      sendMessage: (id, payload) => chrome.tabs.sendMessage(id, payload),
      inject: (id) => chrome.scripting.executeScript({ target: { tabId: id }, files: ["content.js"], injectImmediately: true }),
    }, tabId, message, deadline, phase, budget);
  }
  const pathOf = (value: string) => {
    const url = new URL(value);
    return url.origin + url.pathname.replace(/\/$/, "");
  };
  async function loaded(tabId: number, expectedUrl: string, deadline = Date.now() + 18000, budget: PageReadBudget = { injectionUsed: false }): Promise<void> {
    let phase = "aguardando carregamento da aba do Instagram";
    while (Date.now() < deadline) {
      await ensureActive();
      const tab = await withDeadline(() => chrome.tabs.get(tabId), deadline, phase);
      if (
        tab.status === "complete" &&
        tab.url &&
        pathOf(tab.url) === pathOf(expectedUrl)
      ) {
          phase = "aguardando STATUS do Instagram";
          const status = await pageMessage(tabId, { type: "STATUS" }, Math.min(deadline, Date.now() + 4000), phase, budget);
          if (!status || typeof status !== "object") throw new Error("STATUS do Instagram não retornou uma resposta válida.");
          if (status.restricted) {
            await pauseWithReason(status.restricted, true);
            throw new Error(status.restricted, { cause: "instagram-warning" });
          }
          if (status.url && pathOf(status.url) === pathOf(expectedUrl)) {
            await withDeadline(() => sleep(700), deadline, "concluindo carregamento do perfil");
            return;
          }
          phase = "aguardando rota confirmada pelo STATUS do Instagram";
      } else {
        phase = tab.status !== "complete" ? "aguardando carregamento da aba do Instagram" : "aguardando rota do perfil esperado";
      }
      if (
        tab.url &&
        /\/(challenge|checkpoint|accounts\/login)\b/.test(
          new URL(tab.url).pathname,
        )
      ) {
        const message =
          "O Instagram pediu login ou verificação. A fila foi pausada.";
        await pauseWithReason(message, true);
        throw new Error(message);
      }
      await withDeadline(() => sleep(400), deadline, phase);
    }
    throw new PageDeadlineError(phase);
  }
  async function session(tabId: number, deadline = Date.now() + 18000, budget: PageReadBudget = { injectionUsed: false }): Promise<{
    account: string | null;
    avatarUrl?: string;
    restricted: string | null;
    url: string;
  }> {
    let result;
    for (let i = 0; i < 6; i++) {
      result = await pageMessage(tabId, { type: "STATUS" }, Math.min(deadline, Date.now() + 4000), "confirmando sessão pelo STATUS do Instagram", budget);
      if (!result || typeof result !== "object") throw new Error("STATUS do Instagram não retornou uma resposta válida para a sessão.");
      if (result.account || result.restricted) return result;
      if (i < 5) await withDeadline(() => sleep(600), deadline, "aguardando identificação da sessão do Instagram");
    }
    return result;
  }
  async function profileTab(url: string, deadline = Date.now() + 18000, budget: PageReadBudget = { injectionUsed: false }): Promise<number> {
    await ensureActive();
    const data = await read();
    let tab: chrome.tabs.Tab | undefined;
    if (data.runtime.connectionTabId) {
      try {
        const previous = await withDeadline(() => chrome.tabs.get(data.runtime.connectionTabId!), deadline, "verificando aba da conexão");
        if (previous.url?.startsWith("https://www.instagram.com/"))
          tab = previous;
      } catch (error) { if (error instanceof PageDeadlineError) throw error; }
    }
    tab = tab?.id
      ? await withDeadline(() => chrome.tabs.update(tab!.id!, { url, active: true }), deadline, "navegando para o perfil da conexão")
      : await withDeadline(() => chrome.tabs.create({ url, active: true }), deadline, "abrindo perfil da conexão");
    if (!tab?.id) throw new Error("Não foi possível abrir o Instagram.");
    const id = tab.id;
    await edit((s) => {
      s.runtime.connectionTabId = id;
    });
    await loaded(id, url, deadline, budget);
    return id;
  }
  async function observeSession(account: string | null) {
    await editStore((store) => {
      store.sessionUsername = account || undefined;
      store.sessionCheckedAt = new Date().toISOString();
    });
  }
  async function connect(): Promise<string> {
    if (runnerActive || (await read()).runtime.mode === "running")
      throw new Error(
        "Pause a execução e aguarde a ação atual antes de conectar uma conta.",
      );
    const account = workspace(await readStore(), workspaceId);
    const url = account.username
      ? "https://www.instagram.com/" + account.username + "/"
      : "https://www.instagram.com/";
    const deadline = Date.now() + 18000, budget = { injectionUsed: false };
    const tabId = await profileTab(url, deadline, budget);
    const status = await session(tabId, deadline, budget);
    await observeSession(status.account);
    if (status.restricted) {
      await pauseWithReason(status.restricted, true);
      throw new Error(status.restricted);
    }
    if (!status.account)
      throw new Error(
        "Entre na conta pelo Instagram e deixe o menu Perfil visível. Depois clique em Conectar sessão novamente.",
      );
    const root = await editStore((store) => {
      const linked = bindVerifiedAccount(
        store,
        workspaceId,
        status.account!,
        status.avatarUrl,
      );
      workspace(linked).data.runtime.connectionTabId = tabId;
      return linked;
    });
    const connected = workspace(root);
    if (account.username && connected.id === workspaceId) {
      try {
        const values = await pageMessage(tabId, {
          type: "PROFILE_METRICS",
          expectedAccount: account.username,
        }, Math.min(deadline, Date.now() + 4000), "lendo contadores do perfil", budget);
        if (values.ok)
          await editStore((store) => {
            if (store.activeId !== workspaceId)
              throw new Error("Conta alterada.");
            addSnapshot(workspace(store, workspaceId), {
              ...values,
              source: "instagram",
            });
          });
        else
          await recordNativeProblem({
            scope: workspaceId,
            operation: "PROFILE_METRICS",
            source: "worker",
            message:
              values?.error ||
              "A sessão foi confirmada, mas os contadores do perfil não puderam ser lidos.",
          });
      } catch (error) {
        await recordNativeProblem({
          scope: workspaceId,
          operation: "PROFILE_METRICS",
          source: "worker",
          message:
            error instanceof Error
              ? error.message
              : "Falha na leitura dos contadores após confirmar a sessão.",
        });
      }
    }
    return (
      "Sessão de @" +
      status.account +
      " verificada. As informações estão no dashboard desta conta."
    );
  }
  async function refreshMetrics(): Promise<string> {
    if (runnerActive || (await read()).runtime.mode === "running")
      throw new Error(
        "Pause a fila antes de atualizar os contadores do perfil.",
      );
    const account = workspace(await readStore(), workspaceId);
    const warning = pendingWarningReason(account.data.settings);
    if (warning) throw new Error(warning);
    if (!account.username)
      throw new Error("Cadastre ou identifique sua conta primeiro.");
    const url = "https://www.instagram.com/" + account.username + "/";
    const deadline = Date.now() + 18000, budget = { injectionUsed: false };
    const tabId = await profileTab(url, deadline, budget);
    const status = await session(tabId, deadline, budget);
    await observeSession(status.account);
    if (status.restricted) {
      await pauseWithReason(status.restricted, true);
      throw new Error(status.restricted);
    }
    if (status.account !== account.username)
      throw new Error(
        "A sessão está em @" +
          (status.account || "não identificada") +
          ". Troque para @" +
          account.username +
          " no Instagram e verifique novamente.",
      );
    const values = await pageMessage(tabId, {
      type: "PROFILE_METRICS",
      expectedAccount: account.username,
    }, Math.min(deadline, Date.now() + 4000), "lendo contadores do perfil", budget);
    if (!values?.ok)
      throw new Error(values?.error || "Os contadores não puderam ser lidos.");
    await editStore((store) => {
      const result = bindVerifiedAccount(
        store,
        workspaceId,
        account.username!,
        status.avatarUrl,
      );
      addSnapshot(workspace(result, workspaceId), {
        ...values,
        source: "instagram",
      });
      return result;
    });
    return (
      "Métricas de @" +
      account.username +
      " atualizadas a partir da interface do Instagram."
    );
  }
  async function openSource(id: string): Promise<void> {
    const state = await read();
    const warning = pendingWarningReason(state.settings);
    if (warning) throw new Error(warning);
    if (state.runtime.mode === "running")
      throw new Error("Pause a fila para abrir uma coleta.");
    const campaign = state.campaigns.find((c) => c.id === id && !c.archived);
    if (!campaign) throw new Error("Campanha não encontrada.");
    const url = sourceUrl(campaign.kind, campaign.target);
    if (!url) throw new Error("Essa campanha recebe uma lista importada.");
    const deadline = Date.now() + 18000, budget = { injectionUsed: false };
    const tab = await withDeadline(() => chrome.tabs.create({ url, active: true }), deadline, "abrindo fonte de coleta");
    if (!tab.id) throw new Error("Não foi possível abrir a fonte.");
    const tabId = tab.id;
    await edit((s) => {
      s.runtime.collectorCampaignId = id;
      s.runtime.collectorTabId = tabId;
      s.runtime.collectorAllowedPaths = [];
      audit(s, "collection", `Fonte aberta para “${campaign.name}”.`);
    });
    if (state.runtime.collectorTabId && state.runtime.collectorTabId !== tabId)
      await withDeadline(() => chrome.tabs.sendMessage(state.runtime.collectorTabId!, { type: "CLOSE_COLLECTOR" }), Math.min(deadline, Date.now() + 4000), "fechando coletor anterior").catch(() => {});
    await loaded(tabId, url, deadline, budget);
    await pageMessage(tabId, { type: "COLLECTOR", campaign, savedCount: state.candidates.filter((candidate) => candidate.sources.some((source) => source.campaignId === campaign.id)).length }, Math.min(deadline, Date.now() + 4000), "abrindo coletor na página", budget);
  }
  async function openOwnRelationships(kind: "followers" | "following"): Promise<string> {
    await ensureActive();
    const account = workspace(await readStore(), workspaceId);
    if (!account.username || !account.verifiedAt) throw new Error("Conecte e verifique esta conta antes de abrir as próprias listas.");
    if (!["followers", "following"].includes(kind)) throw new Error("Escolha Seguidores ou Seguindo.");
    if (runnerActive || account.data.runtime.mode === "running") throw new Error("Pause a fila antes de ler as próprias listas.");
    const warning = pendingWarningReason(account.data.settings);
    if (warning) throw new Error(warning);
    const url = sourceUrl(kind, account.username);
    const deadline = Date.now() + 18000, budget = { injectionUsed: false };
    const tab = await withDeadline(() => chrome.tabs.create({ url, active: true }), deadline, "abrindo lista da própria conta");
    if (!tab.id) throw new Error("Não foi possível abrir a própria lista.");
    const tabId = tab.id;
    await edit((s, current) => {
      if (current.username !== account.username) throw new Error("A conta mudou antes de abrir a lista.");
      s.runtime.relationshipTabId = tabId;
      s.runtime.relationshipKind = kind;
      s.runtime.relationshipAccount = account.username;
    });
    await loaded(tabId, url, deadline, budget);
    const status = await session(tabId, deadline, budget);
    await observeSession(status.account);
    if (status.restricted) { await pauseWithReason(status.restricted, true); throw new Error(status.restricted); }
    if (status.account !== account.username) throw new Error("A sessão do Instagram pertence a outra conta. Nenhuma lista foi lida.");
    return `Lista própria aberta. Abra ${kind === "followers" ? "Seguidores" : "Seguindo"}, role para carregar pessoas e volte ao painel para ler os carregados.`;
  }
  async function ownRelationships(kind: "followers" | "following"): Promise<OwnRelationshipReading> {
    await ensureActive();
    const account = workspace(await readStore(), workspaceId), state = account.data;
    if (!["followers", "following"].includes(kind) || !account.username || !account.verifiedAt || state.runtime.relationshipAccount !== account.username || state.runtime.relationshipKind !== kind || !state.runtime.relationshipTabId)
      throw new Error("Abra esta lista da conta selecionada pelo painel antes de ler.");
    if (runnerActive || state.runtime.mode === "running") throw new Error("Pause a fila antes de ler as próprias listas.");
    const warning = pendingWarningReason(state.settings);
    if (warning) throw new Error(warning);
    const tabId = state.runtime.relationshipTabId;
    const expected = sourceUrl(kind, account.username);
    const deadline = Date.now() + 18000, budget = { injectionUsed: false };
    const tab = await withDeadline(() => chrome.tabs.get(tabId), deadline, "verificando aba da lista própria");
    if (!tab.url || pathOf(tab.url) !== pathOf(expected)) throw new Error("A aba mudou de perfil ou de lista. Reabra a lista pelo painel.");
    const status = await session(tabId, deadline, budget);
    await observeSession(status.account);
    if (status.restricted) { await pauseWithReason(status.restricted, true); throw new Error(status.restricted); }
    if (status.account !== account.username || !status.url || pathOf(status.url) !== pathOf(expected)) throw new Error("A sessão ou a lista aberta não corresponde à conta selecionada.");
    const result = await pageMessage(tabId, { type: "OWN_RELATIONSHIPS", expectedAccount: account.username, kind }, Math.min(deadline, Date.now() + 4000), "lendo perfis carregados da própria lista", budget);
    await ensureActive();
    const current = workspace(await readStore(), workspaceId);
    const reading = result?.data;
    if (!result?.ok) throw new Error(result?.error || "Não foi possível ler os perfis carregados.");
    if (current.username !== account.username || current.data.runtime.relationshipTabId !== tabId || current.data.runtime.relationshipKind !== kind || current.data.runtime.mode === "running" || current.data.settings.hasPendingWarning || reading?.account !== account.username || reading.kind !== kind || reading.complete !== false || !Array.isArray(reading.usernames) || reading.usernames.length > 20000 || reading.usernames.some((name: unknown) => typeof name !== "string" || normalizeUsername(name) !== name || name === account.username) || new Set(reading.usernames).size !== reading.usernames.length || !Number.isFinite(Date.parse(reading.at)) || Math.abs(Date.now() - Date.parse(reading.at)) > 300000)
      throw new Error("A conta, a lista ou o retorno da leitura mudou. Nenhuma medição foi salva.");
    return reading;
  }
  async function verifyCandidateResult(id: string): Promise<string> {
    await ensureActive();
    const account = workspace(await readStore(), workspaceId), state = account.data;
    const candidate = state.candidates.find((candidate) => candidate.id === id);
    if (!account.username || !account.verifiedAt || state.runtime.account !== account.username)
      throw new Error("Conecte e verifique a conta selecionada antes da conferência.");
    if (runnerActive || state.runtime.mode !== "paused" || state.candidates.some((candidate) => candidate.stage === "attempting"))
      throw new Error("Pause a fila e aguarde qualquer ação em andamento antes de conferir.");
    const warning = pendingWarningReason(state.settings);
    if (warning) throw new Error(warning);
    if (!candidate || candidate.stage !== "uncertain" || (candidate.queuedAction || "follow") !== "follow" || candidate.queueAccount !== account.username)
      throw new Error("A conferência sem clique está disponível apenas para seguir com resultado incerto nesta conta.");
    const url = `https://www.instagram.com/${candidate.username}/`;
    const deadline = Date.now() + 18000, budget = { injectionUsed: false };
    // Use a fresh read-only document rather than reusing a possibly invalidated action context.
    const tab = await withDeadline(() => chrome.tabs.create({ url, active: true }), deadline, "abrindo perfil para conferência");
    if (!tab.id) throw new Error("Não foi possível abrir o perfil para conferência.");
    await loaded(tab.id, url, deadline, budget);
    const sessionState = await session(tab.id, deadline, budget);
    await observeSession(sessionState.account);
    if (sessionState.restricted) { await pauseWithReason(sessionState.restricted, true); throw new Error(sessionState.restricted); }
    if (sessionState.account !== account.username || !sessionState.url || pathOf(sessionState.url) !== pathOf(url))
      throw new Error("A sessão ou o perfil aberto não corresponde à conferência solicitada.");
    const result = await pageMessage(tab.id, { type: "PROFILE_RELATIONSHIP_STATE", username: candidate.username, expectedAccount: account.username }, Math.min(deadline, Date.now() + 4000), "conferindo vínculo atual do perfil", budget);
    if (!result?.ok) throw new Error(result?.error || "Não foi possível conferir o estado atual do perfil.");
    await editStore((store) => {
      if (store.activeId !== workspaceId) throw new Error("A conta selecionada mudou durante a conferência.");
      const current = workspace(store, workspaceId);
      if (current.username !== account.username || current.data.candidates.find((c) => c.id === id)?.username !== candidate.username || current.data.settings.hasPendingWarning)
        throw new Error("A conta ou o perfil mudou durante a conferência. Nenhum resultado foi registrado.");
      applyCandidateRelationshipObservation(current, id, result.data);
    });
    return result.data.status === "following"
      ? `Estado Seguindo observado em @${candidate.username}. A fila continua pausada; nenhum clique foi enviado nesta conferência.`
      : result.data.status === "requested"
        ? `Solicitação pendente observada em @${candidate.username}. Nenhum clique foi enviado nesta conferência.`
        : `Botão Seguir observado em @${candidate.username}. O resultado continua em revisão; nenhum clique foi enviado.`;
  }
  async function scheduleContinuous(notBefore = 0): Promise<void> {
    const root = await readStore(), account = workspace(root, workspaceId);
    const authorization = account.data.continuous?.authorizationId;
    const next = root.activeId === workspaceId ? continuousWakeAt(account) : undefined;
    const when = next === undefined ? undefined : Math.max(next, notBefore);
    if (root.activeId === workspaceId) await edit((s) => {
      if (s.continuous?.mode === "running" && s.continuous.authorizationId === authorization && when !== undefined)
        s.continuous.nextRunAt = new Date(when).toISOString();
      else if (s.continuous) delete s.continuous.nextRunAt;
    });
    const current = await readStore();
    const active = workspace(current, workspaceId).data.continuous;
    if (when !== undefined && current.activeId === workspaceId && active?.mode === "running" && active.authorizationId === authorization)
      await chrome.alarms.create(CONTINUOUS_ALARM, { when });
    else await chrome.alarms.clear(CONTINUOUS_ALARM);
  }

  function continuousPageMatches(value: string, campaign: AppState["campaigns"][number]): boolean {
    let url: URL;
    try { url = new URL(value); } catch { return false; }
    if (url.origin !== "https://www.instagram.com") return false;
    if (["followers", "following"].includes(campaign.kind)) {
      const profile = new URL(sourceUrl(campaign.kind, campaign.target)).pathname.split("/")[1];
      return new RegExp(`^/${profile.replace(/[.]/g, "\\.")}/(?:${campaign.kind}/?)?$`, "i").test(url.pathname);
    }
    const code = new URL(sourceUrl(campaign.kind, campaign.target)).pathname.split("/")[2];
    const match = url.pathname.match(/^\/(?:([a-z0-9._]{1,30})\/)?(?:p|reel)\/([\w-]+)(?:\/liked_by)?\/?$/i);
    return !!match && match[2] === code && (!match[1] || !campaign.group || match[1].toLowerCase() === campaign.group.profile);
  }

  async function assertContinuousCycle(id: string, authorizationId: string, sourceAuthorization: string): Promise<void> {
    await ensureActive();
    const state = await read(), source = state.campaigns.find((c) => c.id === id);
    if (state.continuous?.mode !== "running" || state.continuous.authorizationId !== authorizationId ||
        !state.continuous.sourceIds?.includes(id) || !source?.continuous?.enabled || source.archived ||
        source.continuous.authorizationId !== sourceAuthorization || state.settings.hasPendingWarning)
      throw new ContinuousCancelled("A rotina foi pausada ou a autorização da fonte mudou.");
  }

  async function scanContinuousSource(id: string): Promise<void> {
    const original = workspace(await readStore(), workspaceId), campaign = original.data.campaigns.find((c) => c.id === id)!;
    const authorizationId = original.data.continuous!.authorizationId!;
    const sourceAuthorization = campaign.continuous!.authorizationId!;
    const expectedAccount = original.username!, runId = uid();
    let tabId: number | undefined;
    let preparingSourceTabId: number | undefined;
    let began = false;
    try {
      await edit((_s, account) => beginContinuousReading(account, id, runId));
      began = true;
      const deadline = Date.now() + 18000, budget = { injectionUsed: false };
      const expectedUrl = sourceUrl(campaign.kind, campaign.target);
      const openingUrl = ["followers", "following"].includes(campaign.kind)
        ? new URL(expectedUrl).origin + "/" + new URL(expectedUrl).pathname.split("/")[1] + "/" : expectedUrl;
      const existingId = (await read()).runtime.continuousTabId;
      let reusable: chrome.tabs.Tab | undefined;
      await assertContinuousCycle(id, authorizationId, sourceAuthorization);
      if (existingId) {
        preparingSourceTabId = existingId;
        try {
          const previous = await withDeadline(() => chrome.tabs.get(existingId), deadline, "conferindo aba da rotina");
          if (!previous.active && previous.url?.startsWith("https://www.instagram.com/")) {
            const previousState = await pageMessage(existingId, { type: "STATUS" }, Math.min(deadline, Date.now() + 4000), "conferindo rascunhos da aba", budget);
            const latest = await withDeadline(() => chrome.tabs.get(existingId), deadline, "conferindo se a aba está em uso");
            if (previousState?.hasDraft === false && !latest.active && latest.url === previousState.url) reusable = latest;
          }
        } catch (error) {
          if (error instanceof PageDeadlineError) throw error;
          // A closed tab has no reusable document. Never resend a timed-out step.
        }
      }
      const tab = reusable?.id
        ? await withDeadline(() => chrome.tabs.update(reusable!.id!, { url: openingUrl, active: false }), deadline, "abrindo fonte da rotina")
        : await withDeadline(() => chrome.tabs.create({ url: openingUrl, active: false }), deadline, "criando aba da rotina");
      if (!tab?.id) throw new Error("A aba da rotina não pôde ser aberta.");
      tabId = tab.id;
      preparingSourceTabId = tabId;
      await edit((s) => { s.runtime.continuousTabId = tabId; });
      let ready = false;
      let readinessPhase = "aguardando página da fonte";
      while (Date.now() < deadline) {
        await assertContinuousCycle(id, authorizationId, sourceAuthorization);
        const documentTab = await withDeadline(() => chrome.tabs.get(tabId!), deadline, readinessPhase);
        if (documentTab.status === "complete") {
          const status = await pageMessage(tabId, { type: "STATUS" }, Math.min(deadline, Date.now() + 4000), "confirmando sessão da rotina", budget);
          if (status?.restricted) { await pauseWithReason(status.restricted, true, true); throw new ContinuousCancelled(status.restricted); }
          if (status?.account != null && status.account !== expectedAccount) {
            await assertContinuousCycle(id, authorizationId, sourceAuthorization);
            const message = "A sessão do Instagram mudou. Conecte a conta selecionada antes de retomar a rotina.";
            await pauseWithReason(message, false, true);
            await recordNativeProblem({ scope: workspaceId, source: "worker", operation: "CONTINUOUS_SESSION", category: "connection", message });
            throw new ContinuousCancelled("Sessão diferente.");
          }
          if (status?.hasDraft) throw new Error("A aba contém um rascunho. Ele foi preservado; confira a fonte antes de retomar.");
          readinessPhase = status?.account == null ? "aguardando identificação da sessão do Instagram" : "aguardando rota da fonte";
          if (status?.account === expectedAccount && documentTab.url && status.url && continuousPageMatches(documentTab.url, campaign) && continuousPageMatches(status.url, campaign)) { ready = true; break; }
        } else readinessPhase = "aguardando página da fonte";
        await withDeadline(() => sleep(400), deadline, readinessPhase);
      }
      if (!ready) throw new PageDeadlineError(readinessPhase);
      const scanDeadline = Date.now() + 20000;
      const found = new Map<string, import("../core/types.ts").CandidateInput>();
      let observed = false;
      for (let step = 0; step < 16 && Date.now() < scanDeadline; step++) {
        await assertContinuousCycle(id, authorizationId, sourceAuthorization);
        if (!insideWindow(new Date(), (await read()).settings)) break;
        const reply = await pageMessage(tabId, { type: "STEP_CONTINUOUS_SOURCE", campaign, expectedAccount, runId }, Math.min(scanDeadline, Date.now() + 4000), "consultando perfis da fonte", budget);
        if (reply?.platformWarning) { await pauseWithReason(reply.error || "O Instagram pediu verificação.", true, true); throw new ContinuousCancelled("Aviso do Instagram."); }
        if (reply?.accountMismatch) {
          await assertContinuousCycle(id, authorizationId, sourceAuthorization);
          const message = "A sessão do Instagram mudou durante a consulta. Conecte a conta selecionada antes de retomar.";
          await pauseWithReason(message, false, true);
          await recordNativeProblem({ scope: workspaceId, source: "worker", operation: "CONTINUOUS_SESSION", category: "connection", message });
          throw new ContinuousCancelled("Sessão diferente.");
        }
        if (!reply?.ok) throw new ContinuousSourceError(reply?.error || "A leitura da fonte não retornou confirmação.", reply?.unavailable === true);
        const data = reply.data;
        if (!data || data.account !== expectedAccount || data.sourceId !== id || data.runId !== runId || data.url !== expectedUrl || data.complete !== false ||
            !["loading", "ready", "end"].includes(data.phase) || !Array.isArray(data.candidates) || data.candidates.length > 10000 ||
            !Number.isFinite(Date.parse(data.at)) || Math.abs(Date.now() - Date.parse(data.at)) > 120000)
          throw new Error("A resposta da fonte mudou de conta, origem ou consulta. Nenhum perfil desta leitura foi salvo.");
        if (data.phase !== "loading" || data.candidates.length) observed = true;
        for (const person of data.candidates) {
          const username = typeof person?.username === "string" && normalizeUsername(person.username);
          if (username) found.set(username, { ...person, username });
        }
        if (found.size > 10000) throw new Error("A leitura ultrapassou o tamanho de uma transação. A fonte precisa ser revista.");
        if (data.phase === "end") break;
        if (Date.now() + 600 >= scanDeadline) break;
        await withDeadline(() => sleep(600), scanDeadline, "aguardando conteúdo da lista");
      }
      await assertContinuousCycle(id, authorizationId, sourceAuthorization);
      if (!observed) {
        if (!insideWindow(new Date(), (await read()).settings)) {
          await edit((s) => { const c = s.campaigns.find((c) => c.id === id)!; if (c.continuous?.runId === runId) { c.continuous.status = "ready"; delete c.continuous.runId; c.continuous.nextCheckAt = new Date(nextWindowAt(s.settings)).toISOString(); } });
          return;
        }
        throw new Error("A lista não ficou disponível nesta consulta. Confira a fonte antes de reativar.");
      }
      await edit((_s, account) => {
        const result = commitContinuousReading(account, { sourceId: id, runId, authorizationId, account: expectedAccount, url: expectedUrl, at: new Date().toISOString(), candidates: [...found.values()] });
        if (!result.replayed) audit(result.state, "continuous_read", `${result.loaded} perfis lidos · ${result.added} descobertos · ${result.queued} enfileirados. Consulta parcial da fonte “${campaign.name}”.`);
        return result.state;
      });
    } catch (error) {
      if (error instanceof ContinuousCancelled) return;
      const current = await read();
      const currentSource = current.campaigns.find((c) => c.id === id);
      if (!began || current.continuous?.authorizationId !== authorizationId || current.continuous.mode !== "running" || currentSource?.continuous?.authorizationId !== sourceAuthorization) return;
      const message = (error instanceof Error ? error.message : "A consulta da fonte foi interrompida.").slice(0, 500);
      if (error instanceof PageDeadlineError) {
        let deferred = false;
        await edit((_s, account) => {
          const state = deferContinuousReading(account, id, runId, authorizationId, sourceAuthorization, error.phase);
          if (!state) return;
          if (preparingSourceTabId !== undefined && state.runtime.continuousTabId === preparingSourceTabId) delete state.runtime.continuousTabId;
          audit(state, "source_read_retry", "Consulta excedeu o prazo; nova leitura automática agendada sem importar resultados parciais.");
          deferred = true;
          return state;
        });
        if (deferred) await recordNativeProblem({ scope: workspaceId, source: "worker", operation: "CONTINUOUS_SOURCE_RETRY", category: "connection", message });
        else {
          await recordNativeProblem({ scope: workspaceId, source: "worker", operation: "CONTINUOUS_SOURCE_STALE", category: "connection", message: `${message} A recuperação não foi aplicada porque a consulta ou sua autorização mudou.` });
          await schedule(await read());
        }
        return;
      }
      await edit((_s, account) => {
        const state = failContinuousReading(account, id, runId, message, error instanceof ContinuousSourceError && error.unavailable);
        if (tabId && state.runtime.continuousTabId === tabId) delete state.runtime.continuousTabId;
        return state;
      });
      await recordNativeProblem({ scope: workspaceId, source: "worker", operation: "CONTINUOUS_SOURCE", category: "connection", message });
    }
  }

  async function tickContinuous(): Promise<void> {
    if (continuousTickActive) { await scheduleContinuous(Date.now() + 30000); return; }
    continuousTickActive = true;
    try { await runContinuousTick(); }
    finally { continuousTickActive = false; }
  }

  async function runContinuousTick(): Promise<void> {
    await initialized;
    await ensureActive();
    if ((await read()).continuous?.mode !== "running") { await chrome.alarms.clear(CONTINUOUS_ALARM); return; }
    if (runnerActive || sourceScanActive) { await scheduleContinuous(Date.now() + 30000); return; }
    let state = await read();
    if (state.settings.hasPendingWarning || state.candidates.some((c) => c.stage === "uncertain" || c.stage === "attempting")) {
      await pauseWithReason("A rotina precisa de conferência: há um aviso ou resultado sem confirmação. Nenhuma ação será repetida.", false, true); return;
    }
    await edit((s, account) => {
      const result = renewContinuousDay(account);
      const midnight = new Date(); midnight.setHours(0, 0, 0, 0);
      const previous = Math.max(Date.parse(s.runtime.sessionStartedAt || "") || 0, lastAttemptTime(s));
      const previousDaySession = previous > 0 && previous < midnight.getTime();
      if (previousDaySession) result.state.runtime.sessionAttempts = 0;
      // START can initialize dayKey before this first tick. An older session
      // still renews once, proven by its timestamps; today's attempts stay intact.
      if (result.renewed || previousDaySession) {
        result.state.runtime.sessionStartedAt = new Date().toISOString();
      }
      return result.state;
    });
    const account = workspace(await readStore(), workspaceId);
    state = account.data;
    if (!insideWindow(new Date(), state.settings)) {
      await edit((s) => { s.runtime.mode = "paused"; s.runtime.pauseReason = "Rotina contínua aguardando a próxima janela de horário."; });
      await scheduleContinuous(); return;
    }
    const queued = state.candidates.some((c) => continuousCandidateEligibility(account, c).eligible);
    if (queued && !budgetStopReason(state, attemptsToday(state)) && Date.now() >= Math.max(intervalReadyAt(state), state.runtime.nextRun || 0, Date.parse(continuousPreparationRetry(account)?.retryAt || "") || 0)) {
      await edit((s) => { if (s.continuous?.mode === "running") s.runtime.mode = "running"; });
      await runQueue(); return;
    }
    const source = state.campaigns.filter((c) => continuousSourceEligibility(account, c.id).eligible && c.continuous?.status === "ready" && (!c.continuous.nextCheckAt || Date.parse(c.continuous.nextCheckAt) <= Date.now()))
      .sort((a, b) => Date.parse(a.continuous?.nextCheckAt || "1970-01-01") - Date.parse(b.continuous?.nextCheckAt || "1970-01-01"))[0];
    if (source) {
      if (runnerActive || sourceScanActive) { await scheduleContinuous(Date.now() + 30000); return; }
      sourceScanActive = true;
      try { await scanContinuousSource(source.id); }
      finally { sourceScanActive = false; }
    }
    await edit((s, current) => {
      if (s.continuous?.mode !== "running") return;
      if (s.candidates.some((c) => continuousCandidateEligibility(current, c).eligible)) {
        s.runtime.nextRun = Math.max(s.runtime.nextRun || Date.now() + 30000, intervalReadyAt(s));
        s.runtime.pauseReason = budgetStopReason(s, attemptsToday(s)) || "Rotina contínua aguardando a próxima tentativa autorizada.";
      } else s.runtime.pauseReason = "Rotina contínua aguardando novidades nas fontes selecionadas.";
      s.runtime.mode = "paused";
    });
    await scheduleContinuous();
  }

  async function schedule(_state: AppState): Promise<void> {
    const root = await readStore();
    const state = workspace(root, workspaceId).data;
    if (root.activeId === workspaceId && state.continuous?.mode === "running") {
      await chrome.alarms.clear(ALARM);
      await scheduleContinuous();
    } else if (root.activeId === workspaceId && state.runtime.mode === "running")
      await chrome.alarms.create(ALARM, {
        when:
          state.runtime.nextRun ||
          Date.now() + state.settings.intervalMinutes * 60000,
      });
    else await chrome.alarms.clear(ALARM);
    if (state.continuous?.mode !== "running" || root.activeId !== workspaceId) await chrome.alarms.clear(CONTINUOUS_ALARM);
  }
  async function pauseWithReason(
    message: string,
    platformWarning = false,
    stopContinuous = false,
  ): Promise<void> {
    const state = await edit((s) => {
      if (platformWarning) s.settings.hasPendingWarning = true;
      s.runtime.mode = "paused";
      s.runtime.pauseReason = message;
      delete s.runtime.nextRun;
      delete s.runtime.activeToken;
      delete s.runtime.activeAction;
      delete s.runtime.activeCandidateId;
      delete s.runtime.activeExpiresAt;
      audit(s, platformWarning ? "warning" : "pause", message);
      if (platformWarning || stopContinuous) return pauseContinuous(s, message);
    }, true);
    if (platformWarning)
      await recordNativeProblem({
        scope: workspaceId,
        operation: "PLATFORM_WARNING",
        source: "worker",
        category: "platform",
        message,
      });
    await schedule(state);
  }
  async function runQueue(): Promise<void> {
    await initialized;
    if (runnerActive || sourceScanActive) {
      if ((await read()).continuous?.mode === "running") await scheduleContinuous(Date.now() + 30000);
      return;
    }
    runnerActive = true;
    let selectedId: string | undefined;
    let preparingTabId: number | undefined;
    let automatic = false;
    let preparationLease: ContinuousPreparationLease | undefined;
    try {
      await ensureActive();
      const currentAccount = workspace(await readStore(), workspaceId);
      let state = currentAccount.data;
      automatic = state.continuous?.mode === "running";
      if (state.runtime.mode !== "running") return;
      const pendingRetry = automatic && continuousPreparationRetry(currentAccount);
      if (pendingRetry && Date.parse(pendingRetry.retryAt) > Date.now()) {
        await edit((s) => { s.runtime.mode = "paused"; });
        await scheduleContinuous(); return;
      }
      const budgetReason = budgetStopReason(state, attemptsToday(state));
      if (budgetReason) {
        await pauseWithReason(budgetReason);
        return;
      }
      const readyAt = intervalReadyAt(state);
      if (Date.now() < readyAt) {
        state = await edit((s) => {
          if (s.runtime.mode === "running") {
            s.runtime.nextRun = intervalReadyAt(s);
            s.runtime.pauseReason =
              "Aguardando o intervalo entre tentativas. Pausar ou reiniciar não encurta essa espera.";
          }
        });
        await schedule(state);
        return;
      }
      if (!insideWindow(new Date(), state.settings)) {
        await pauseWithReason(
          "Fora da janela de horários configurada. Inicie novamente dentro do horário.",
        );
        return;
      }
      const candidate = state.candidates.find((c) => c.stage === "queued" && (!pendingRetry || c.id === pendingRetry.candidateId) && (!automatic || continuousCandidateEligibility(currentAccount, c).eligible));
      if (!candidate) {
        await pauseWithReason(
          "Fila concluída. Todos os resultados estão no histórico.",
        );
        return;
      }
      if (
        !state.runtime.account ||
        candidate.queueAccount !== state.runtime.account
      ) {
        await pauseWithReason("A fila e a conta conectada não correspondem.");
        return;
      }
      const action = candidate.queuedAction || "follow";
      if (currentAccount.relationships?.protections.some((p) => p.enabled && p.username === candidate.username)) {
        await pauseWithReason("Este perfil está protegido. Nenhum clique foi enviado; revise a fila antes de continuar.");
        return;
      }
      if (action === "unfollow") {
        const eligibility = unfollowEligibility(currentAccount, candidate);
        if (!eligibility.eligible) {
          await pauseWithReason(`Revisão de deixar de seguir interrompida: ${eligibility.reasons.join(" ")} Nenhum clique foi enviado.`);
          return;
        }
      }
      if (
        state.settings.exclusions.includes(candidate.username) ||
        candidate.sources.some((s) => s.url.startsWith("demo:"))
      ) {
        await edit((s) => {
          const c = s.candidates.find((c) => c.id === candidate.id)!;
          c.stage = "excluded";
          audit(
            s,
            "excluded",
            "Perfil de demonstração ou da lista de exclusão retirado da fila.",
            c.username,
          );
        });
        await pauseWithReason(
          "Um perfil não elegível foi retirado da fila. Revise antes de continuar.",
        );
        return;
      }
      const expectedAccount = state.runtime.account;
      if (automatic) preparationLease = continuousPreparationLease(currentAccount, candidate);
      const deadline = Date.now() + 18000, budget = { injectionUsed: false };
      let tab: chrome.tabs.Tab | undefined;
      if (state.runtime.workerTabId) {
        preparingTabId = state.runtime.workerTabId;
        try {
          const existing = await withDeadline(() => chrome.tabs.get(state.runtime.workerTabId!), deadline, "verificando aba de trabalho");
          if (existing.url?.startsWith("https://www.instagram.com/")) {
            if (!automatic || !existing.active) {
              const priorStatus = await pageMessage(existing.id!, { type: "STATUS" }, Math.min(deadline, Date.now() + 4000), "conferindo rascunhos antes da fila", budget);
              const latest = await withDeadline(() => chrome.tabs.get(existing.id!), deadline, "conferindo se a aba da fila está em uso");
              if (priorStatus?.hasDraft === false && (!automatic || !latest.active) && latest.url === priorStatus.url) tab = latest;
            }
          }
        } catch (error) {
          if (error instanceof PageDeadlineError) throw error;
          /* closed */
        }
      }
      const url = `https://www.instagram.com/${candidate.username}/`;
      if (tab?.id)
        tab = await withDeadline(() => chrome.tabs.update(tab!.id!, { url, active: !automatic }), deadline, "navegando para o perfil da fila");
      else tab = await withDeadline(() => chrome.tabs.create({ url, active: !automatic }), deadline, "abrindo perfil da fila");
      if (!tab?.id) throw new Error("Não foi possível abrir o perfil da fila.");
      const tabId = tab.id;
      preparingTabId = tabId;
      await edit((s) => {
        s.runtime.workerTabId = tabId;
      });
      await loaded(tabId, url, deadline, budget);
      const status = await session(tabId, deadline, budget);
      await observeSession(status.account);
      if (status.restricted || status.account !== expectedAccount || !status.url || pathOf(status.url) !== pathOf(url)) {
        await edit((s) => { if (s.runtime.workerTabId === tabId) delete s.runtime.workerTabId; });
        await pauseWithReason(
          status.restricted ||
            "Não foi possível confirmar a conta de execução na página. Nenhuma ação foi enviada.",
          !!status.restricted,
          automatic,
        );
        return;
      }
      const token = uid();
      state = await edit((s, account) => {
        if (s.runtime.mode !== "running") return;
        const c = s.candidates.find((c) => c.id === candidate.id);
        if (
          !c ||
          c.stage !== "queued" ||
          (c.queuedAction || "follow") !== action ||
          c.queueAccount !== expectedAccount ||
          account.username !== expectedAccount ||
          s.runtime.account !== expectedAccount ||
          account.relationships?.protections.some((p) => p.enabled && p.username === c.username) ||
          c.sources.some((source) => source.url.startsWith("demo:")) ||
          (action === "unfollow" && !unfollowEligibility(account, c).eligible) ||
          (automatic && !continuousCandidateEligibility(account, c).eligible) ||
          s.settings.exclusions.includes(c.username) ||
          !insideWindow(new Date(), s.settings) ||
          budgetStopReason(s, attemptsToday(s)) ||
          Date.now() < intervalReadyAt(s)
        )
          return;
        c.stage = "attempting";
        selectedId = c.id;
        s.runtime.activeCandidateId = c.id;
        s.runtime.activeToken = token;
        s.runtime.activeAction = action;
        s.runtime.activeExpiresAt = Date.now() + 10000;
        audit(
          s,
          "attempt",
          `${action === "unfollow" ? "Deixar de seguir" : "Seguir"}: verificação iniciada; o resultado ainda não foi confirmado.`,
          c.username,
        );
      });
      if (state.runtime.activeToken !== token) {
        if (state.runtime.mode === "running")
          await pauseWithReason(
            "As condições da fila mudaram durante a preparação. Revise antes de continuar.",
          );
        return;
      }
      // Mutations use a single delivery. A timeout never reinjects or repeats a click.
      let responseTimer: ReturnType<typeof setTimeout> | undefined;
      let result: FollowResult;
      try {
        result = await Promise.race([
          chrome.tabs.sendMessage(tabId, {
          type: action === "unfollow" ? "UNFOLLOW" : "FOLLOW",
          username: candidate.username,
          expectedAccount,
          token,
          expiresAt: state.runtime.activeExpiresAt,
        }),
          new Promise<FollowResult>((resolve) => {
            responseTimer = setTimeout(() => resolve({
              action,
              stage: "uncertain",
              message: "O retorno da ação expirou. Confira o perfil antes de qualquer nova ação.",
              stop: true,
            }), 12000);
          }),
        ]);
      } finally {
        if (responseTimer) clearTimeout(responseTimer);
      }
      let successful = false;
      state = await edit((s) => {
        const c = s.candidates.find((c) => c.id === candidate.id);
        if (!c || c.stage !== "attempting") return;
        const valid =
          result &&
          result.action === action &&
          typeof result.message === "string" && result.message.length > 0 && result.message.length <= 2000 &&
          s.runtime.activeCandidateId === c.id && s.runtime.activeAction === action &&
          c.queueAccount === expectedAccount && (c.queuedAction || "follow") === action &&
          (action === "unfollow" ? ["unfollowed", "uncertain", "failed"] : ["followed", "requested", "already", "uncertain", "failed"]).includes(result.stage) &&
          (!["followed", "requested", "unfollowed"].includes(result.stage) || (result.clickSent === true && s.runtime.activeToken === undefined));
        c.stage = valid ? result.stage : "uncertain";
        c.lastResult = valid
          ? result.message
          : "Resposta desconhecida. Confira o perfil.";
        c.updatedAt = new Date().toISOString();
        if (valid && action === "follow" && result.stage === "followed") {
          c.confirmedFollowAt = c.updatedAt;
          c.confirmedFollowAccount = expectedAccount;
          c.confirmedFollowSource = "orbita";
        }
        successful = !!valid && ["followed", "requested", "already", "unfollowed"].includes(result.stage);
        if (successful && s.continuous) delete s.continuous.preparationRetry;
        if (s.runtime.account) {
          s.lastAttempts ||= {};
          s.lastAttempts[`@${s.runtime.account}`] = c.updatedAt;
        }
        audit(s, c.stage, c.lastResult, c.username);
        if (result?.platformWarning) {
          s.settings.hasPendingWarning = true;
          audit(s, "warning", c.lastResult, c.username);
        }
        delete s.runtime.activeCandidateId;
        delete s.runtime.activeToken;
        delete s.runtime.activeExpiresAt;
        delete s.runtime.activeAction;
        if (!valid || result.stop || c.stage === "uncertain") {
          s.runtime.mode = "paused";
          s.runtime.pauseReason = c.lastResult;
          delete s.runtime.nextRun;
        } else if (s.runtime.mode === "running") {
          if (!s.candidates.some((candidate) => candidate.stage === "queued")) {
            s.runtime.mode = "paused";
            s.runtime.pauseReason =
              "Fila concluída. Todos os resultados estão no histórico.";
            delete s.runtime.nextRun;
          } else if (budgetStopReason(s, attemptsToday(s))) {
            s.runtime.mode = "paused";
            s.runtime.pauseReason = budgetStopReason(s, attemptsToday(s))!;
            delete s.runtime.nextRun;
          } else {
            s.runtime.nextRun = Date.now() + s.settings.intervalMinutes * 60000;
            s.runtime.pauseReason =
              "Execução em andamento. Você pode pausar a qualquer momento.";
          }
        }
      }, true);
      if (!successful)
        await recordNativeProblem({
          scope: workspaceId,
          operation: "QUEUE_ACTION",
          source: "worker",
          category: result?.platformWarning ? "platform" : "uncertain",
          message:
            result?.message ||
            "Resposta da ação não reconhecida. Confira o perfil antes de repetir.",
        });
      if (automatic && !successful) state = await edit((s) => pauseContinuous(s, result?.message || "Confira o resultado antes de retomar a rotina."), true);
      await schedule(state);
    } catch (error) {
      const reason =
        error instanceof Error
          ? error.message
          : "A comunicação com o Instagram foi interrompida.";
      if (!selectedId && automatic && error instanceof PageDeadlineError && preparationLease) {
        let deferred = false;
        const stale = async (state?: AppState) => {
          await recordNativeProblem({ scope: workspaceId, operation: "QUEUE_PREPARATION_STALE", source: "worker", category: "connection", message: `${reason} A recuperação não foi aplicada porque a conta, a fila ou sua autorização mudou. Nenhum clique foi enviado.` });
          await schedule(state || await read());
        };
        try {
          const state = await edit((s, account) => {
            const next = deferContinuousPreparation(account, preparationLease!, error.phase);
            if (!next) return;
            if (preparingTabId !== undefined && next.runtime.workerTabId === preparingTabId) delete next.runtime.workerTabId;
            audit(next, "preparation_retry", next.runtime.pauseReason, preparationLease!.username);
            deferred = true;
            return next;
          });
          if (deferred) {
            await recordNativeProblem({ scope: workspaceId, operation: "QUEUE_PREPARATION_RETRY", source: "worker", category: "connection", message: `${reason} Nenhuma tentativa reservada; recuperação automática agendada.` });
            await schedule(state);
            return;
          }
          await stale(state);
          return;
        } catch {
          // Account changes can reject the edit before its callback. Preserve the
          // current authorization instead of falling through to a stale pause.
          if ((await readStore()).activeId !== workspaceId) { await stale(); return; }
        }
      }
      const message = selectedId ? reason : `${reason} Nenhum clique foi enviado; a fila foi pausada antes de reservar a tentativa.`;
      await recordNativeProblem({
        scope: workspaceId,
        operation: "QUEUE_FAILURE",
        source: "worker",
        category: selectedId ? "uncertain" : "connection",
        message,
      });
      await edit((s) => {
        if (!selectedId && preparingTabId !== undefined && s.runtime.workerTabId === preparingTabId) delete s.runtime.workerTabId;
        if (selectedId) {
          const c = s.candidates.find((c) => c.id === selectedId);
          if (c?.stage === "attempting") {
            c.stage = "uncertain";
            c.lastResult = message;
            audit(s, "uncertain", message, c.username);
          }
        }
      }, true);
      await pauseWithReason(message, false, automatic);
    } finally {
      runnerActive = false;
    }
  }
  async function start(reviewed: boolean, reviewedQueue?: { id: string; action: "follow" | "unfollow" }[], unlimitedAttemptsReviewed?: boolean): Promise<void> {
    await ensureActive();
    const account = workspace(await readStore(), workspaceId);
    if (account.data.continuous?.mode === "running") throw new Error("Pause a rotina contínua antes de iniciar um lote manual.");
    if (!account.verifiedAt)
      throw new Error(
        "Conecte e verifique a sessão desta conta antes de iniciar.",
      );
    const rootSession = (await readStore()).sessionUsername;
    if (rootSession && rootSession !== account.username)
      throw new Error(
        "A última sessão identificada pertence a outra conta. Conecte a sessão selecionada antes de executar.",
      );
    const state = await edit((s, current) => {
      if (isUnlimitedAttempts(s.settings) && unlimitedAttemptsReviewed !== true)
        throw new Error("Revise explicitamente o modo sem teto de tentativas antes de iniciar. Recarregue o painel para confirmar essa revisão.");
      if (!reviewed)
        throw new Error(
          "Revise a conta e o lote antes de iniciar. Confirme essa revisão na janela de início.",
        );
      const warning = pendingWarningReason(s.settings);
      if (warning) throw new Error(warning);
      if (runnerActive || s.candidates.some((c) => c.stage === "attempting"))
        throw new Error(
          "Aguarde o resultado da ação atual antes de reiniciar.",
        );
      if (!s.runtime.account)
        throw new Error("Conecte a conta antes de iniciar.");
      if (!s.candidates.some((c) => c.stage === "queued"))
        throw new Error("Aprove perfis e adicione-os à fila.");
      const queued = s.candidates.filter((c) => c.stage === "queued");
      if (reviewedQueue !== undefined || queued.some((c) => c.queuedAction === "unfollow")) {
        if (!Array.isArray(reviewedQueue) || reviewedQueue.length !== queued.length ||
          !queued.every((candidate, index) => reviewedQueue[index]?.id === candidate.id && reviewedQueue[index]?.action === (candidate.queuedAction || "follow")))
          throw new Error("A seleção ou o tipo de ação da fila mudou. Revise o lote atualizado antes de iniciar.");
      }
      for (const candidate of queued) {
        if (current.relationships?.protections.some((p) => p.enabled && p.username === candidate.username))
          throw new Error("A fila contém um perfil protegido. Revise a seleção antes de iniciar.");
        if (candidate.queuedAction === "unfollow") {
          const eligibility = unfollowEligibility(current, candidate);
          if (!eligibility.eligible)
            throw new Error(`A revisão de deixar de seguir precisa ser conferida: ${eligibility.reasons[0]}`);
        }
      }
      if (!insideWindow(new Date(), s.settings))
        throw new Error("O horário atual está fora da janela configurada.");
      if (!hasDailyBudget(s.settings, attemptsToday(s)))
        throw new Error("O teto diário de tentativas foi alcançado.");
      s.runtime.sessionAttempts = 0;
      s.runtime.sessionStartedAt = new Date().toISOString();
      s.runtime.mode = "running";
      s.runtime.nextRun = Math.max(Date.now() + 30000, intervalReadyAt(s));
      s.runtime.pauseReason =
        intervalReadyAt(s) > Date.now() + 30000
          ? "Aguardando o intervalo que ainda resta desde a última tentativa."
          : "Preparando o próximo perfil. A primeira verificação acontece em cerca de 30 segundos.";
      audit(
        s,
        "start",
        "Novo lote iniciado; o usuário declarou ter revisado a conta e os candidatos. O intervalo e o consumo diário foram preservados.",
      );
    });
    await schedule(state);
  }
  async function command(
    command: Command | SpecialCommand,
  ): Promise<string | void> {
    await ensureActive();
    if (command.type === "START_CONTINUOUS") {
      if (runnerActive || sourceScanActive) throw new Error("Aguarde a operação atual antes de iniciar a rotina.");
      const root = await readStore(), account = workspace(root, workspaceId);
      if (!account.username || root.sessionUsername !== account.username) throw new Error("Conecte e confira a sessão desta conta antes de ativar a rotina.");
      const state = await edit((_s, current) => {
        const next = startContinuous(current, command.sourceIds, command.reviewed === true, new Date(), command.unlimitedAttemptsReviewed);
        next.runtime.mode = "paused";
        delete next.runtime.nextRun;
        next.runtime.pauseReason = "Rotina autorizada. A próxima consulta respeitará a janela e os limites configurados.";
        audit(next, "continuous_start", "Rotina contínua autorizada para as fontes selecionadas; apenas perfis novos elegíveis podem entrar automaticamente na fila.");
        return next;
      });
      await schedule(state);
      return "Rotina contínua ativada para as fontes selecionadas.";
    }
    if (command.type === "CONNECT") return connect();
    if (command.type === "REFRESH_METRICS") return refreshMetrics();
    if (command.type === "OPEN_SOURCE") return openSource(command.id);
    if (command.type === "OPEN_OWN_RELATIONSHIPS") return openOwnRelationships(command.kind);
    if (command.type === "VERIFY_CANDIDATE_RESULT") return verifyCandidateResult(command.id);
    if (command.type === "START") return start(command.reviewed === true, command.reviewedQueue, command.unlimitedAttemptsReviewed);
    if (command.type === "RESTORE") {
      const current = await read();
      if (runnerActive || current.runtime.mode === "running")
        throw new Error(
          "Pause e aguarde o término da ação atual antes de restaurar.",
        );
    }
    const root = await editStore((store) =>
      applyScopedCommand(store, workspaceId, command),
    );
    await schedule(workspace(root, workspaceId).data);
  }
  async function contentRoute(
    message: any,
    sender: chrome.runtime.MessageSender,
  ): Promise<object> {
    await settledStore();
    const state = await read();
    if (
      message.type === "PLATFORM_WARNING" &&
      sender.id === chrome.runtime.id &&
      sender.tab?.id !== undefined &&
      [state.runtime.workerTabId, state.runtime.collectorTabId, state.runtime.continuousTabId, state.runtime.relationshipTabId].includes(
        sender.tab.id,
      )
    ) {
      await pauseWithReason(
        typeof message.message === "string"
          ? message.message.slice(0, 500)
          : "O Instagram mostrou um aviso. Confira a conta antes de retomar.",
        true,
      );
      return { ok: true };
    }
    if (message.type === "AUTHORIZE_CLICK") {
      let allowed = false;
      await edit((state, account) => {
        const c = state.candidates.find(
          (c) => c.id === state.runtime.activeCandidateId,
        );
        allowed = !!(
          sender.id === chrome.runtime.id &&
          sender.tab?.id === state.runtime.workerTabId &&
          sender.url?.startsWith(`https://www.instagram.com/${c?.username}/`) &&
          state.runtime.mode === "running" &&
          state.runtime.activeToken === message.token &&
          (message.action === "follow" || message.action === "unfollow") &&
          state.runtime.activeAction === message.action &&
          Date.now() < (state.runtime.activeExpiresAt || 0) &&
          c?.stage === "attempting" &&
          c.username === message.username &&
          (c.queuedAction || "follow") === message.action &&
          c.queueAccount === message.expectedAccount &&
          state.runtime.account === message.expectedAccount &&
          account.username === message.expectedAccount &&
          !account.relationships?.protections.some((p) => p.enabled && p.username === c.username) &&
          !c.sources.some((source) => source.url.startsWith("demo:")) &&
          (message.action !== "unfollow" || unfollowEligibility(account, c).eligible) &&
          (state.continuous?.mode !== "running" || continuousCandidateEligibility(account, { ...c, stage: "queued" }).eligible) &&
          !state.settings.hasPendingWarning &&
          hasSessionBudget(state.settings, state.runtime.sessionAttempts || 0, 0) &&
          hasDailyBudget(state.settings, attemptsToday(state), 0) &&
          !state.settings.exclusions.includes(c.username) &&
          insideWindow(new Date(), state.settings)
        );
        // The attempt is already reserved in both counters, so <= permits its last allowed click.
        if (allowed) delete state.runtime.activeToken;
      });
      return { ok: !!allowed };
    }
    if (
      ["CAPTURE", "GET_COLLECTOR", "COLLECTOR_MEDIA"].includes(message.type)
    ) {
      if (message.type === "GET_COLLECTOR") {
        if (sender.tab?.id !== state.runtime.collectorTabId)
          return { ok: false };
        const campaign = state.campaigns.find(
          (c) => c.id === state.runtime.collectorCampaignId && !c.archived,
        );
        return campaign ? { ok: true, campaign, savedCount: state.candidates.filter((candidate) => candidate.sources.some((source) => source.campaignId === campaign.id)).length } : { ok: false };
      }
      if (
        sender.tab?.id !== state.runtime.collectorTabId ||
        message.campaignId !== state.runtime.collectorCampaignId ||
        !sender.url?.startsWith("https://www.instagram.com/")
      )
        throw new Error(
          "Esta aba não é a fonte de coleta ativa. Abra a campanha novamente.",
        );
      const campaign = state.campaigns.find(
        (c) => c.id === message.campaignId && !c.archived,
      );
      if (!campaign) throw new Error("Campanha não encontrada.");
      const warning = pendingWarningReason(state.settings);
      if (warning) throw new Error(warning);
      const actual = new URL(sender.url);
      const expected = new URL(sourceUrl(campaign.kind, campaign.target));
      if (message.type === "COLLECTOR_MEDIA") {
        const destination = new URL(message.url);
        if (
          !["hashtag", "location"].includes(campaign.kind) ||
          !actual.pathname.startsWith(expected.pathname) ||
          destination.origin !== actual.origin ||
          !/^\/(p|reel)\/[\w-]+\/?$/.test(destination.pathname)
        )
          throw new Error("Publicação fora da fonte ativa.");
        await edit((s) => {
          s.runtime.collectorAllowedPaths = [
            ...new Set([
              ...(s.runtime.collectorAllowedPaths || []),
              destination.pathname.replace(/\/$/, ""),
            ]),
          ].slice(-100);
        });
        return { ok: true };
      }
      if (
        ["followers", "following"].includes(campaign.kind) &&
        actual.pathname.replace(/\/$/, "").toLowerCase() !==
          expected.pathname.replace(/\/$/, "").toLowerCase()
      )
        throw new Error(
          "A lista aberta não corresponde à fonte. Reabra Seguidores ou Seguidos da campanha.",
        );
      if (
        ["commenters", "likers"].includes(campaign.kind) &&
        actual.pathname.replace(/\/$/, "") !==
          expected.pathname.replace(/\/$/, "")
      )
        throw new Error("A publicação aberta não corresponde à campanha.");
      if (
        ["hashtag", "location"].includes(campaign.kind) &&
        !actual.pathname.startsWith(expected.pathname) &&
        !state.runtime.collectorAllowedPaths?.includes(
          actual.pathname.replace(/\/$/, ""),
        )
      )
        throw new Error(
          "Abra a publicação a partir da hashtag ou localização da campanha para preservar a origem.",
        );
      const captured = await edit((s) => {
        const current = s.campaigns.find((source) => source.id === campaign.id && !source.archived);
        if (s.runtime.collectorTabId !== sender.tab?.id || s.runtime.collectorCampaignId !== campaign.id || !current || current.kind !== campaign.kind || current.target !== campaign.target || (current.group && message.sourceProfile !== current.group.profile))
          throw new Error("A fonte ativa mudou. Reabra a etapa da campanha antes de capturar; nenhum perfil foi salvo.");
        return applyCommand(s, {
          type: "IMPORT",
          campaignId: campaign.id,
          candidates: message.candidates,
          url: actual.origin + actual.pathname,
        });
      });
      return { ok: true, total: captured.candidates.filter((candidate) => candidate.sources.some((source) => source.campaignId === campaign.id)).length };
    }
    if (
      message.type === "OPEN_DASHBOARD" &&
      sender.id === chrome.runtime.id &&
      sender.tab?.url?.startsWith("https://www.instagram.com/")
    ) {
      await chrome.tabs.create({ url: chrome.runtime.getURL("index.html") });
      return { ok: true };
    }
    throw new Error("Mensagem não autorizada.");
  }

  async function marketPage(url: string, own: boolean) {
    await ensureActive();
    const state = await read();
    if (runnerActive || state.runtime.mode === "running")
      throw new Error("Pause a fila antes de consultar uma referência.");
    const warning = pendingWarningReason(state.settings);
    if (warning) throw new Error(warning);
    const account = workspace(await readStore(), workspaceId);
    if (!account.username) throw new Error("Cadastre sua conta primeiro.");
    const target = own
      ? `https://www.instagram.com/${account.username}/`
      : marketUrl(url, true);
    const deadline = Date.now() + 18000, budget = { injectionUsed: false };
    const tabId = await profileTab(target, deadline, budget);
    const result = await pageMessage(tabId, {
      type: "MARKET_PAGE",
      expectedOwn: own ? account.username : undefined,
    }, Math.min(deadline, Date.now() + 4000), "lendo página de referência", budget);
    await ensureActive();
    if (!result?.ok)
      throw new Error(result?.error || "A página não pôde ser lida.");
    if (result.data?.url !== target)
      throw new Error("A página mudou durante a leitura. Consulte novamente.");
    return result.data;
  }
  return { command, runQueue, contentRoute, marketPage, ownRelationships, tickContinuous, scheduleContinuous };
}
function isDashboard(sender: chrome.runtime.MessageSender): boolean {
  return (
    sender.id === chrome.runtime.id &&
    (!!sender.url?.startsWith(chrome.runtime.getURL("index.html")) ||
      trustedHostedPage(sender.url))
  );
}
async function route(
  message: any,
  sender: chrome.runtime.MessageSender,
): Promise<object> {
  if (trustedHostedPage(sender.url)) {
    if (sender.id !== chrome.runtime.id || sender.tab?.id === undefined)
      throw new Error("Conector não autorizado.");
    if (message?.type === "HOSTED_CONNECT")
      return { ok: true, version: chrome.runtime.getManifest().version };
    if (!allowedHostedMessage(message))
      throw new Error("Operação não disponível no conector do app.");
  }
  // Independent of the account store: diagnostics must survive its startup failure.
  if (isDashboard(sender)) {
    if (message?.type === "GET_PROBLEMS")
      return { ok: true, store: await readProblems() };
    if (message?.type === "REPORT_PROBLEM") {
      const id = await recordNativeProblem({
        ...message.input,
        source: ["dashboard", "visible", "runtime", "manual"].includes(
          message.input?.source,
        )
          ? message.input.source
          : "dashboard",
      });
      return {
        ok: !!id,
        id,
        error: id
          ? undefined
          : problemStoreFailure() ||
            "Não foi possível persistir o diagnóstico.",
      };
    }
    if (message?.type === "UPDATE_PROBLEM") {
      await changeNativeProblem(
        message.scope,
        message.id,
        message.status,
        message.note,
      );
      return { ok: true };
    }
    if (message?.type === "RECOVER_PROBLEM") {
      await recoverNativeProblem(message.scope, message.id);
      return { ok: true };
    }
  }
  await initialized;
  await settledStore();
  let root = await readStore();
  if (message.type === "GET_STATE" && isDashboard(sender))
    return { ok: true, store: root, state: workspace(root).data, capabilities: { continuousSources: true, allDaySchedule: true, unlimitedAttempts: true, autoRecovery: true } };
  if (message.type === "READ_MARKET_PAGE" && isDashboard(sender)) {
    if (
      message.workspaceId !== root.activeId ||
      typeof message.own !== "boolean" ||
      (!message.own && typeof message.url !== "string")
    )
      throw new Error("Conta ou link inválido para a leitura.");
    const data = await controller(root.activeId).marketPage(
      message.url,
      message.own,
    );
    return { ok: true, data };
  }
  if (message.type === "READ_OWN_RELATIONSHIPS" && isDashboard(sender)) {
    if (message.workspaceId !== root.activeId || !["followers", "following"].includes(message.kind))
      throw new Error("A conta ativa ou a lista solicitada mudou.");
    return { ok: true, data: await controller(root.activeId).ownRelationships(message.kind) };
  }
  if (message.type === "ACCOUNT_COMMAND" && isDashboard(sender)) {
    if (!message.command || message.expectedActiveId !== root.activeId)
      throw new Error("A conta ativa mudou. Aguarde a atualização do painel.");
    root = await editStore((store) => {
      if (store.activeId !== message.expectedActiveId)
        throw new Error("A conta ativa mudou durante a operação.");
      return accountCommand(store, message.command);
    });
    for (const account of root.accounts)
      if (account.data.runtime.mode !== "running")
        await chrome.alarms.clear(alarmName(account.id));
    for (const account of root.accounts) if (account.data.continuous?.mode !== "running" || account.id !== root.activeId)
      await chrome.alarms.clear(continuousAlarmName(account.id));
    await controller(root.activeId).scheduleContinuous();
    return { ok: true };
  }
  if (message.type === "COMMAND" && isDashboard(sender)) {
    if (!message.command || typeof message.command.type !== "string")
      throw new Error("Comando inválido.");
    if (message.workspaceId !== root.activeId)
      throw new Error(
        "A conta ativa mudou. Recarregue o painel antes de executar esta ação.",
      );
    const notice = await controller(root.activeId).command(message.command);
    return { ok: true, notice };
  }
  if (
    message.type === "OPEN_DASHBOARD" &&
    sender.id === chrome.runtime.id &&
    sender.tab?.url?.startsWith("https://www.instagram.com/")
  ) {
    await chrome.tabs.create({ url: chrome.runtime.getURL("index.html") });
    return { ok: true };
  }
  const owner = root.accounts.find(
    (a) =>
      sender.tab?.id !== undefined &&
      [a.data.runtime.workerTabId, a.data.runtime.collectorTabId,
        ...(message.type === "PLATFORM_WARNING" ? [a.data.runtime.continuousTabId, a.data.runtime.relationshipTabId] : []),
      ].includes(
        sender.tab.id,
      ),
  );
  if (owner && owner.id === root.activeId)
    return controller(owner.id).contentRoute(message, sender);
  if (message.type === "GET_COLLECTOR") return { ok: false };
  throw new Error(
    "Esta aba pertence a outra conta ou coleta. Selecione a conta correspondente e reabra a fonte.",
  );
}
chrome.runtime.onMessage.addListener((message, sender, respond) => {
  void route(message, sender)
    .then(respond)
    .catch(async (error) => {
      const diagnosticMessage = [
        "GET_PROBLEMS",
        "REPORT_PROBLEM",
        "UPDATE_PROBLEM",
        "RECOVER_PROBLEM",
      ].includes(message?.type);
      const problemId =
        isDashboard(sender) && !diagnosticMessage
          ? await recordNativeProblem({
              scope:
                message?.workspaceId || message?.expectedActiveId || APP_SCOPE,
              operation:
                message?.type === "GET_STATE"
                  ? "LOAD_STATE"
                  : message?.type === "ACCOUNT_COMMAND"
                    ? `ACCOUNT_${String(message.command?.type || "INVALID").slice(0, 60)}`
                    : message?.type === "COMMAND"
                      ? `COMMAND_${String(message.command?.type || "INVALID").slice(0, 60)}`
                      : message?.type === "READ_OWN_RELATIONSHIPS" ? "READ_OWN_RELATIONSHIPS" : "READ_MARKET_PAGE",
              source: "worker",
              category: message?.type === "GET_STATE" ? "storage" : undefined,
              message:
                error instanceof Error ? error.message : "Falha inesperada.",
            })
          : undefined;
      respond({
        ok: false,
        error: error instanceof Error ? error.message : "Falha inesperada.",
        problemId,
      });
    });
  return true;
});
chrome.alarms.onAlarm.addListener((alarm) => {
  if (alarm.name.startsWith("orbita-continuous:")) {
    const id = alarm.name.slice("orbita-continuous:".length);
    void initialized.then(async () => {
      const root = await readStore();
      if (root.activeId !== id || workspace(root, id).data.continuous?.mode !== "running") { await chrome.alarms.clear(alarm.name); return; }
      try { await controller(id).tickContinuous(); }
      catch (error) {
        const message = error instanceof Error ? error.message : "A rotina contínua foi interrompida.";
        await editStore((store) => { const account = workspace(store, id); account.data = pauseContinuous(account.data, message); account.data.runtime.mode = "paused"; delete account.data.runtime.nextRun; });
        await chrome.alarms.clear(alarm.name);
        await recordNativeProblem({ scope: id, source: "worker", operation: "CONTINUOUS_FAILURE", category: "connection", message });
      }
    });
    return;
  }
  if (alarm.name.startsWith("orbita-queue:"))
    void initialized.then(() =>
      controller(alarm.name.slice("orbita-queue:".length)).runQueue(),
    );
});
chrome.runtime.onStartup.addListener(() => {
  void initialized.then(async () => {
    const store = await editStore((store) => {
      for (const account of store.accounts)
        if (account.data.continuous?.mode !== "running" || account.data.candidates.some((c) => c.stage === "attempting" || c.stage === "uncertain") || account.data.settings.hasPendingWarning)
          account.data = recoverInterrupted(account.data);
    });
    for (const account of store.accounts)
      await chrome.alarms.clear(alarmName(account.id));
    for (const account of store.accounts) await chrome.alarms.clear(continuousAlarmName(account.id));
    await controller(store.activeId).scheduleContinuous();
  });
});
chrome.action.onClicked.addListener(() => {
  void chrome.tabs.create({ url: chrome.runtime.getURL("index.html") });
});
globalThis.addEventListener("unhandledrejection", (event) => {
  void recordNativeProblem({
    scope: APP_SCOPE,
    operation: "WORKER_UNHANDLED",
    source: "worker",
    message:
      event.reason instanceof Error
        ? event.reason.message
        : "Falha inesperada no serviço da extensão.",
  });
});
