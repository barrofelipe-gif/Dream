import type {
  AccountWorkspace,
  AppState,
  Campaign,
  Candidate,
  CandidateInput,
  Command,
  ContinuousPreparationRetry,
} from "./types.ts";
import { isUnlimitedAttempts } from "./safety.ts";
import {
  cleanInput,
  mergeCandidates,
  normalizeUsername,
  sourceUrl,
  uid,
} from "./domain.ts";

export const DEFAULT_CONTINUOUS_POLL_MINUTES = 15;
export const CONTINUOUS_SOURCE_KINDS = [
  "followers",
  "commenters",
  "likers",
] as const;
const supported = (campaign: Campaign) =>
  (CONTINUOUS_SOURCE_KINDS as readonly string[]).includes(campaign.kind);
type ConfigureCommand = Extract<
  Command,
  { type: "CONFIGURE_CONTINUOUS_SOURCE" }
>;
export interface ContinuousReading {
  sourceId: string;
  runId: string;
  authorizationId: string;
  account: string;
  candidates: CandidateInput[];
  url: string;
  at: string;
}
function fail(message: string): never {
  throw new Error(message);
}
const token = (v: unknown): v is string =>
  typeof v === "string" && v.length > 0 && v.length <= 150;
function stamp(v: unknown, future = true, now = new Date()): string {
  if (
    typeof v !== "string" ||
    !/^\d{4}-\d{2}-\d{2}T\d{2}:\d{2}(?::\d{2}(?:\.\d{1,3})?)?(?:Z|[+-]\d{2}:\d{2})$/.test(
      v,
    ) ||
    !Number.isFinite(Date.parse(v)) ||
    Number(v.slice(11, 13)) > 23 ||
    Number(v.slice(14, 16)) > 59 ||
    Number(v.slice(17, 19) || 0) > 59 ||
    new Date(v.slice(0, 10)).toISOString().slice(0, 10) !== v.slice(0, 10) ||
    (!future && Date.parse(v) > now.getTime() + 1000)
  )
    fail("Data inválida na rotina contínua.");
  return new Date(v).toISOString();
}
export function continuousDayKey(now = new Date()): string {
  if (!Number.isFinite(now.getTime()))
    fail("Data inválida para a rotina contínua.");
  return `${now.getFullYear()}-${String(now.getMonth() + 1).padStart(2, "0")}-${String(now.getDate()).padStart(2, "0")}`;
}
function owner(state: AppState, expected?: string): string {
  const name = expected || state.runtime.account;
  if (
    !name ||
    normalizeUsername(name) !== name ||
    state.runtime.account !== name
  )
    fail("Vincule a rotina à conta selecionada e confira a sessão.");
  return name;
}
function source(state: AppState, id: string): Campaign {
  const campaign = state.campaigns.find((c) => c.id === id);
  if (!campaign || campaign.archived || !supported(campaign))
    fail(
      "A rotina contínua aceita fontes ativas de seguidores, comentários ou curtidas.",
    );
  sourceUrl(campaign.kind, campaign.target);
  return campaign;
}
function revokeQueued(state: AppState, id: string): void {
  for (const c of state.candidates)
    if (c.stage === "queued" && c.continuousSourceId === id) {
      c.stage = "new";
      delete c.queueAccount;
      delete c.queuedAction;
      delete c.continuousSourceId;
      delete c.continuousAuthorizationId;
    }
}
function invalidateCheck(campaign: Campaign): void {
  if (!campaign.continuous) return;
  delete campaign.continuous.runId;
  delete campaign.continuous.nextCheckAt;
  if (campaign.continuous.status === "checking")
    campaign.continuous.status = "ready";
}
/** Reload preserves legitimate native state. Explicit restore always revokes execution. */
export function validateContinuousState(
  state: AppState,
  expected?: string,
  restored = false,
  now = new Date(),
): void {
  const hasData =
    !!state.continuous ||
    state.campaigns.some((c) => c.continuous) ||
    state.candidates.some(
      (c) =>
        c.continuousSourceId !== undefined ||
        c.continuousAuthorizationId !== undefined,
    );
  if (!hasData) return;
  const name = expected || state.runtime.account;
  if (!name || normalizeUsername(name) !== name)
    fail("A rotina contínua precisa pertencer a uma conta identificada.");
  if (state.runtime.account !== undefined && state.runtime.account !== name)
    fail("A conta da rotina contínua não corresponde ao espaço selecionado.");
  for (const c of state.campaigns)
    if (c.continuous !== undefined) {
      const cfg = c.continuous;
      if (
        !cfg ||
        cfg.account !== name ||
        typeof cfg.enabled !== "boolean" ||
        typeof cfg.autoFollow !== "boolean" ||
        !Number.isInteger(cfg.pollMinutes) ||
        cfg.pollMinutes < 5 ||
        cfg.pollMinutes > 1440 ||
        !["ready", "checking", "unavailable", "error"].includes(cfg.status) ||
        (cfg.reason !== undefined &&
          (typeof cfg.reason !== "string" || cfg.reason.length > 500)) ||
        (cfg.partial !== undefined && cfg.partial !== true)
      )
        fail(
          "Configuração de fonte contínua inválida ou pertencente a outra conta.",
        );
      if (!supported(c) && cfg.enabled)
        fail("Este tipo de fonte não aceita a rotina contínua nesta versão.");
      for (const key of [
        "authorizationId",
        "runId",
        "lastCommittedRunId",
      ] as const)
        if (cfg[key] !== undefined && !token(cfg[key]))
          fail("Identificação inválida na rotina contínua.");
      for (const key of ["authorizedAt", "lastCheckAt", "nextCheckAt"] as const)
        if (cfg[key] !== undefined)
          cfg[key] = stamp(cfg[key], key === "nextCheckAt", now);
      for (const key of ["lastLoaded", "lastAdded", "lastQueued"] as const)
        if (
          cfg[key] !== undefined &&
          (!Number.isSafeInteger(cfg[key]) || cfg[key]! < 0)
        )
          fail("Contagem inválida na rotina contínua.");
      if (cfg.enabled && (!token(cfg.authorizationId) || !cfg.authorizedAt))
        fail("A fonte habilitada precisa de autorização explícita.");
      if (cfg.readRetry !== undefined) {
        const retry = cfg.readRetry;
        if (!retry || !token(retry.authorizationId) || !token(retry.sourceAuthorizationId) ||
            !Number.isSafeInteger(retry.failures) || retry.failures < 1 ||
            typeof retry.phase !== "string" || !retry.phase || retry.phase.length > 180)
          fail("Recuperação de leitura inválida na rotina contínua.");
        retry.retryAt = stamp(retry.retryAt, true, now);
      }
      if (restored) {
        cfg.enabled = false;
        cfg.status = "ready";
        cfg.reason =
          "Histórico restaurado. Configure e autorize novamente esta fonte.";
        delete cfg.authorizationId;
        delete cfg.authorizedAt;
        delete cfg.readRetry;
        invalidateCheck(c);
      }
    }
  if (state.continuous !== undefined) {
    const cfg = state.continuous;
    if (
      !cfg ||
      cfg.account !== name ||
      !["running", "paused"].includes(cfg.mode) ||
      (cfg.pauseReason !== undefined &&
        (typeof cfg.pauseReason !== "string" ||
          cfg.pauseReason.length > 500)) ||
      (cfg.dayKey !== undefined &&
        (!/^\d{4}-\d{2}-\d{2}$/.test(cfg.dayKey) ||
          !Number.isFinite(Date.parse(cfg.dayKey)) ||
          new Date(cfg.dayKey).toISOString().slice(0, 10) !== cfg.dayKey)) ||
      !Array.isArray(cfg.sourceIds) ||
      cfg.sourceIds.some(
        (id) => !token(id) || !state.campaigns.some((c) => c.id === id),
      ) ||
      new Set(cfg.sourceIds).size !== cfg.sourceIds.length ||
      (cfg.authorizationId !== undefined && !token(cfg.authorizationId))
    )
      fail("Estado global da rotina contínua inválido.");
    for (const key of ["startedAt", "nextRunAt"] as const)
      if (cfg[key] !== undefined)
        cfg[key] = stamp(cfg[key], key === "nextRunAt", now);
    if (
      cfg.mode === "running" &&
      (!cfg.sourceIds?.length || !token(cfg.authorizationId))
    )
      fail("A execução contínua exige fontes e autorização da sessão.");
    if (restored) {
      cfg.mode = "paused";
      cfg.sourceIds = [];
      cfg.pauseReason = "Backup restaurado: execução contínua desativada.";
      delete cfg.authorizationId;
      delete cfg.nextRunAt;
      delete cfg.preparationRetry;
    }
    const retry = cfg.preparationRetry;
    if (retry !== undefined) {
      if (!retry || retry.account !== name ||
          normalizeUsername(retry.username) !== retry.username ||
          ![retry.candidateId, retry.sourceId, retry.authorizationId, retry.sourceAuthorizationId].every(token) ||
          !Number.isSafeInteger(retry.failures) || retry.failures < 1 ||
          typeof retry.phase !== "string" || !retry.phase || retry.phase.length > 180)
        fail("Recuperação de preparo inválida na rotina contínua.");
      retry.retryAt = stamp(retry.retryAt, true, now);
    }
  }
  for (const c of state.candidates) {
    if (
      c.continuousSourceId !== undefined ||
      c.continuousAuthorizationId !== undefined
    ) {
      if (
        !token(c.continuousSourceId) ||
        !token(c.continuousAuthorizationId) ||
        !state.campaigns.some((source) => source.id === c.continuousSourceId)
      )
        fail("Autorização contínua inválida no perfil.");
      if (restored) {
        delete c.continuousSourceId;
        delete c.continuousAuthorizationId;
      }
    }
  }
  if (
    !restored &&
    state.continuous?.mode === "running" &&
    (state.settings.hasPendingWarning ||
      state.candidates.some((c) => c.stage === "uncertain"))
  )
    Object.assign(
      state,
      pauseContinuous(
        state,
        "A rotina foi pausada por aviso ou resultado incerto.",
      ),
    );
}

export function configureContinuousSource(
  original: AppState,
  command: ConfigureCommand,
  now = new Date(),
): AppState {
  const state = structuredClone(original),
    name = owner(state),
    campaign = source(state, command.id);
  const poll = command.pollMinutes ?? DEFAULT_CONTINUOUS_POLL_MINUTES;
  if (
    typeof command.enabled !== "boolean" ||
    typeof command.autoFollow !== "boolean" ||
    !Number.isInteger(poll) ||
    poll < 5 ||
    poll > 1440
  )
    fail(
      "Informe o intervalo inteiro entre 5 e 1.440 minutos e as opções da fonte.",
    );
  if (command.enabled && command.reviewed !== true)
    fail("Revise e autorize explicitamente esta fonte antes de habilitá-la.");
  if (state.candidates.some((c) => c.stage === "attempting"))
    fail("Aguarde a ação em andamento antes de alterar a rotina.");
  const previous = campaign.continuous;
  if (previous && previous.account !== name)
    fail("A configuração existente pertence a outra conta.");
  if (state.continuous?.preparationRetry?.sourceId === campaign.id)
    delete state.continuous.preparationRetry;
  revokeQueued(state, campaign.id);
  campaign.continuous = {
    ...previous,
    account: name,
    enabled: command.enabled,
    autoFollow: command.autoFollow,
    pollMinutes: poll,
    status: "ready",
    partial: true,
    reason: command.enabled
      ? "Fonte configurada. Inicie explicitamente a rotina para usá-la."
      : "Fonte desativada por você.",
  };
  delete campaign.continuous.readRetry;
  invalidateCheck(campaign);
  if (command.enabled) {
    campaign.continuous.authorizationId = uid();
    campaign.continuous.authorizedAt = now.toISOString();
    campaign.continuous.nextCheckAt = now.toISOString();
  } else {
    delete campaign.continuous.authorizationId;
    delete campaign.continuous.authorizedAt;
  }
  state.continuous ||= {
    account: name,
    mode: "paused",
    sourceIds: [],
    pauseReason: "Configure as fontes e inicie após revisar.",
  };
  state.continuous.sourceIds =
    state.continuous.sourceIds?.filter((id) => id !== campaign.id) || [];
  delete state.continuous.nextRunAt;
  if (state.continuous.mode === "running" && !state.continuous.sourceIds.length)
    return pauseContinuous(
      state,
      "O conjunto ativo ficou vazio. Revise as fontes e inicie novamente.",
    );
  return state;
}
export function pauseContinuous(
  original: AppState,
  reason = "Rotina contínua pausada por você.",
): AppState {
  const state = structuredClone(original);
  const wasRunning = state.continuous?.mode === "running";
  if (state.continuous) {
    state.continuous.mode = "paused";
    state.continuous.pauseReason = reason.slice(0, 500);
    delete state.continuous.authorizationId;
    delete state.continuous.nextRunAt;
    delete state.continuous.preparationRetry;
  }
  if (wasRunning) {
    state.runtime.mode = "paused";
    state.runtime.pauseReason = reason.slice(0, 500);
    delete state.runtime.nextRun;
    delete state.runtime.activeToken;
    delete state.runtime.activeAction;
    delete state.runtime.activeCandidateId;
    delete state.runtime.activeExpiresAt;
  }
  for (const campaign of state.campaigns)
    if (campaign.continuous) {
      if (campaign.continuous.status === "checking") invalidateCheck(campaign);
      delete campaign.continuous.readRetry;
    }
  delete state.runtime.continuousTabId;
  return state;
}
export function enabledContinuousSourceIds(
  account: AccountWorkspace,
): string[] {
  return account.data.campaigns
    .filter(
      (c) =>
        !c.archived &&
        supported(c) &&
        c.continuous?.enabled &&
        c.continuous.account === account.username,
    )
    .map((c) => c.id);
}
function globalReasons(account: AccountWorkspace): string[] {
  const state = account.data,
    name = account.username;
  const reasons: string[] = [];
  if (
    !name ||
    state.runtime.account !== name ||
    state.continuous?.account !== name
  )
    reasons.push(
      "A conta da rotina e da sessão precisa corresponder à selecionada.",
    );
  if (
    state.continuous?.mode !== "running" ||
    !token(state.continuous.authorizationId)
  )
    reasons.push("Inicie explicitamente a rotina após revisar suas fontes.");
  if (state.settings.hasPendingWarning)
    reasons.push("Há um aviso da conta pendente de conferência.");
  if (state.candidates.some((c) => c.stage === "uncertain"))
    reasons.push("Confira o resultado incerto antes de continuar.");
  return reasons;
}
export function continuousSourceEligibility(
  account: AccountWorkspace,
  id: string,
  now = new Date(),
) {
  const reasons = globalReasons(account),
    c = account.data.campaigns.find((c) => c.id === id),
    cfg = c?.continuous;
  if (
    !c ||
    c.archived ||
    !supported(c) ||
    !cfg?.enabled ||
    cfg.account !== account.username ||
    !token(cfg.authorizationId)
  )
    reasons.push("A fonte não está habilitada e autorizada para esta conta.");
  if (!account.data.continuous?.sourceIds?.includes(id))
    reasons.push(
      "A fonte não está no conjunto revisado neste início da rotina.",
    );
  if (cfg && ["unavailable", "error", "checking"].includes(cfg.status))
    reasons.push(
      cfg.reason ||
        "Esta fonte aguarda reativação ou uma leitura já em andamento.",
    );
  if (cfg?.nextCheckAt && Date.parse(cfg.nextCheckAt) > now.getTime())
    reasons.push("Aguarde a próxima consulta desta fonte.");
  return { eligible: reasons.length === 0, reasons };
}
function sourceProfile(c: Campaign): string | undefined {
  if (c.group?.profile) return normalizeUsername(c.group.profile) || undefined;
  if (["followers", "following"].includes(c.kind))
    return sourceUrl(c.kind, c.target).split("/")[3];
}
export function continuousCandidateEligibility(
  account: AccountWorkspace,
  candidate: Candidate,
) {
  const reasons = globalReasons(account),
    id = candidate.continuousSourceId;
  const c = account.data.campaigns.find((c) => c.id === id),
    cfg = c?.continuous;
  if (
    !id ||
    !c ||
    c.archived ||
    !supported(c) ||
    !cfg?.enabled ||
    !cfg.autoFollow ||
    cfg.account !== account.username ||
    cfg.authorizationId !== candidate.continuousAuthorizationId ||
    !token(candidate.continuousAuthorizationId) ||
    !account.data.continuous?.sourceIds?.includes(id) ||
    ["unavailable", "error"].includes(cfg.status)
  )
    reasons.push(
      "Este perfil não possui autorização ativa de seguir nesta fonte.",
    );
  if (
    candidate.stage !== "queued" ||
    candidate.queuedAction !== "follow" ||
    candidate.queueAccount !== account.username
  )
    reasons.push(
      "Somente perfis novos enfileirados para seguir pela rotina podem executar.",
    );
  if (
    normalizeUsername(candidate.username) !== candidate.username ||
    candidate.username === account.username ||
    candidate.username === (c && sourceProfile(c))
  )
    reasons.push(
      "A própria conta e o perfil de referência ficam fora do seguimento automático.",
    );
  if (!candidate.sources.some((s) => s.campaignId === id))
    reasons.push(
      "A proveniência deste perfil não corresponde à fonte autorizada.",
    );
  if (account.data.settings.exclusions.includes(candidate.username))
    reasons.push("Este perfil está excluído.");
  if (
    account.relationships?.protections.some(
      (p) => p.enabled && p.username === candidate.username,
    )
  )
    reasons.push(
      "Este perfil está protegido e não será seguido automaticamente.",
    );
  if (candidate.sources.some((s) => s.url.startsWith("demo:")))
    reasons.push("Dados de demonstração não entram na execução real.");
  return { eligible: reasons.length === 0, reasons };
}
export type ContinuousPreparationLease = Omit<ContinuousPreparationRetry, "failures" | "retryAt" | "phase">;
export function continuousPreparationLease(account: AccountWorkspace, candidate: Candidate): ContinuousPreparationLease | undefined {
  if (!continuousCandidateEligibility(account, candidate).eligible) return;
  return { account: account.username!, candidateId: candidate.id, username: candidate.username,
    sourceId: candidate.continuousSourceId!, authorizationId: account.data.continuous!.authorizationId!,
    sourceAuthorizationId: candidate.continuousAuthorizationId! };
}
const samePreparation = (a: ContinuousPreparationLease, b: ContinuousPreparationLease) =>
  (["account", "candidateId", "username", "sourceId", "authorizationId", "sourceAuthorizationId"] as const).every((key) => a[key] === b[key]);
function preparationLeaseCurrent(account: AccountWorkspace, lease: ContinuousPreparationLease): boolean {
  const state = account.data, candidate = state.candidates.find((c) => c.id === lease.candidateId);
  const current = candidate && continuousPreparationLease(account, candidate);
  return !!current && samePreparation(current, lease) && !state.runtime.activeToken && !state.runtime.activeCandidateId &&
    !state.candidates.some((c) => c.stage === "attempting" || c.stage === "uncertain");
}
/** A stale retry never delays a different candidate, account, or authorization. */
export function continuousPreparationRetry(account: AccountWorkspace): ContinuousPreparationRetry | undefined {
  const retry = account.data.continuous?.preparationRetry;
  return retry && preparationLeaseCurrent(account, retry) ? retry : undefined;
}
const retryDelay = (failures: number): number => [60000, 180000, 600000, 900000][Math.min(failures - 1, 3)];
/** Only the worker may call this after a typed deadline and before reserving an attempt. */
export function deferContinuousPreparation(account: AccountWorkspace, lease: ContinuousPreparationLease, phase: string, now = new Date()): AppState | undefined {
  if (!preparationLeaseCurrent(account, lease)) return;
  const state = structuredClone(account.data), saved = continuousPreparationRetry(account);
  const previous = saved && samePreparation(saved, lease) ? saved : undefined;
  const failures = Math.min(Number.MAX_SAFE_INTEGER, (previous?.failures || 0) + 1);
  const backoff = retryDelay(failures);
  const retryAt = new Date(now.getTime() + backoff).toISOString();
  state.continuous!.preparationRetry = { ...lease, failures, retryAt, phase: phase.slice(0, 180) };
  state.runtime.mode = "paused";
  const time = new Date(retryAt).toLocaleTimeString("pt-BR", { hour: "2-digit", minute: "2-digit" });
  state.runtime.pauseReason = `O preparo do perfil demorou. Nenhum clique foi enviado e nenhuma tentativa foi reservada. Retomada automática a partir de ${time}, respeitando os controles da conta.`;
  return state;
}
export function deferContinuousReading(account: AccountWorkspace, id: string, runId: string, authorizationId: string, sourceAuthorizationId: string, phase: string, now = new Date()): AppState | undefined {
  const state = structuredClone(account.data), cfg = state.campaigns.find((c) => c.id === id && !c.archived)?.continuous;
  if (globalReasons(account).length || account.data.runtime.account !== account.username ||
      state.continuous?.authorizationId !== authorizationId || !state.continuous.sourceIds.includes(id) ||
      !cfg?.enabled || cfg.account !== account.username || cfg.authorizationId !== sourceAuthorizationId ||
      cfg.runId !== runId || cfg.status !== "checking" || state.candidates.some((c) => c.stage === "attempting")) return;
  const previous = cfg.readRetry?.authorizationId === authorizationId && cfg.readRetry.sourceAuthorizationId === sourceAuthorizationId ? cfg.readRetry : undefined;
  const failures = Math.min(Number.MAX_SAFE_INTEGER, (previous?.failures || 0) + 1);
  const retryAt = new Date(now.getTime() + retryDelay(failures)).toISOString();
  cfg.readRetry = { authorizationId, sourceAuthorizationId, failures, retryAt, phase: phase.slice(0, 180) };
  cfg.status = "ready"; delete cfg.runId;
  cfg.nextCheckAt = retryAt;
  const time = new Date(retryAt).toLocaleTimeString("pt-BR", { hour: "2-digit", minute: "2-digit" });
  cfg.reason = `A consulta demorou. Nova leitura automática a partir de ${time}; nenhuma leitura parcial foi salva.`;
  return state;
}
export function startContinuous(
  account: AccountWorkspace,
  sourceIds: string[],
  reviewed: boolean | undefined,
  now = new Date(),
  unlimitedAttemptsReviewed?: boolean,
): AppState {
  const state = structuredClone(account.data),
    name = owner(state, account.username);
  if (isUnlimitedAttempts(state.settings) && unlimitedAttemptsReviewed !== true)
    fail("Revise explicitamente o modo sem teto de tentativas antes de iniciar. Recarregue o painel para confirmar essa revisão.");
  if (
    reviewed !== true ||
    !Array.isArray(sourceIds) ||
    !sourceIds.length ||
    new Set(sourceIds).size !== sourceIds.length ||
    sourceIds.some((id) => !token(id))
  )
    fail("Selecione e revise explicitamente as fontes antes de iniciar.");
  if (!account.verifiedAt || !state.runtime.connectedAt)
    fail("Conecte e confira a conta antes de iniciar a rotina contínua.");
  stamp(account.verifiedAt, false, now);
  stamp(state.runtime.connectedAt, false, now);
  if (
    state.settings.hasPendingWarning ||
    state.candidates.some((c) => ["uncertain", "attempting"].includes(c.stage))
  )
    fail(
      "Confira avisos, resultados incertos e ações em andamento antes de iniciar.",
    );
  for (const id of sourceIds) {
    const c = source(state, id),
      cfg = c.continuous;
    if (
      !cfg?.enabled ||
      cfg.account !== name ||
      !token(cfg.authorizationId) ||
      ["error", "unavailable", "checking"].includes(cfg.status)
    )
      fail("Reative e autorize cada fonte selecionada antes de iniciar.");
  }
  const cycle = {
    account: name,
    mode: "running" as const,
    sourceIds: [...sourceIds],
    authorizationId: uid(),
    startedAt: now.toISOString(),
    dayKey: state.continuous?.dayKey || continuousDayKey(now),
  };
  state.continuous = cycle;
  const probe = { ...account, data: state };
  for (const c of state.candidates.filter((c) => c.stage === "queued"))
    if (!continuousCandidateEligibility(probe, c).eligible)
      fail(
        "Pause e revise a fila manual ou incompatível antes de iniciar a rotina contínua.",
      );
  for (const id of sourceIds) {
    const cfg = state.campaigns.find((c) => c.id === id)!.continuous!;
    delete cfg.readRetry;
    cfg.nextCheckAt = now.toISOString();
    cfg.reason = "Pronta para consultar os perfis disponíveis.";
  }
  return state;
}
export function beginContinuousReading(
  account: AccountWorkspace,
  id: string,
  runId: string,
  now = new Date(),
): AppState {
  const result = continuousSourceEligibility(account, id, now);
  if (!token(runId) || !result.eligible)
    fail(
      result.reasons.join(" ") || "Identificação inválida para esta consulta.",
    );
  const state = structuredClone(account.data),
    cfg = state.campaigns.find((c) => c.id === id)!.continuous!;
  if (cfg.lastCommittedRunId === runId)
    fail("Esta consulta já foi concluída. Use uma nova identificação.");
  cfg.runId = runId;
  cfg.status = "checking";
  cfg.reason = "Lendo os perfis disponíveis nesta fonte.";
  delete cfg.nextCheckAt;
  return state;
}
function canonicalUrl(raw: string): string {
  const url = new URL(raw);
  if (
    url.protocol !== "https:" ||
    !["instagram.com", "www.instagram.com"].includes(url.hostname) ||
    url.port ||
    url.username ||
    url.password ||
    url.search ||
    url.hash
  )
    fail("A consulta precisa usar o link exato da fonte revisada.");
  return `https://www.instagram.com${url.pathname.replace(/\/+$/, "")}/`;
}
export function commitContinuousReading(
  account: AccountWorkspace,
  reading: ContinuousReading,
  now = new Date(),
) {
  const state = structuredClone(account.data),
    name = owner(state, account.username),
    campaign = source(state, reading.sourceId),
    cfg = campaign.continuous;
  if (
    reading.account !== name ||
    !cfg ||
    cfg.account !== name ||
    !token(reading.runId) ||
    !token(reading.authorizationId) ||
    state.continuous?.authorizationId !== reading.authorizationId ||
    state.continuous.mode !== "running" ||
    !state.continuous.sourceIds?.includes(campaign.id) ||
    !cfg.enabled ||
    !token(cfg.authorizationId)
  )
    fail("A conta, a fonte ou a autorização desta consulta mudou.");
  if (cfg.lastCommittedRunId === reading.runId)
    return {
      state,
      added: 0,
      merged: 0,
      invalid: 0,
      queued: 0,
      loaded: 0,
      replayed: true,
      partial: true as const,
    };
  if (cfg.status !== "checking" || cfg.runId !== reading.runId)
    fail(
      "A consulta perdeu sua identificação ativa. Nenhuma leitura antiga será aplicada.",
    );
  const at = stamp(reading.at, false, now);
  if (
    now.getTime() - Date.parse(at) > 120000 ||
    !Array.isArray(reading.candidates) ||
    reading.candidates.length > 20000 ||
    canonicalUrl(reading.url) !==
      canonicalUrl(sourceUrl(campaign.kind, campaign.target))
  )
    fail(
      "A leitura está antiga, excede o limite ou não pertence ao link exato desta fonte.",
    );
  if (globalReasons({ ...account, data: state }).length)
    fail(
      "A rotina foi pausada ou exige conferência antes de aplicar esta leitura.",
    );
  const previous = new Set(state.candidates.map((c) => c.id));
  const result = mergeCandidates(
    state,
    campaign.id,
    reading.candidates,
    reading.url,
  );
  let queued = 0;
  if (cfg.autoFollow)
    for (const candidate of state.candidates)
      if (!previous.has(candidate.id) && candidate.stage === "new") {
        const probe: Candidate = {
          ...candidate,
          stage: "queued",
          queuedAction: "follow",
          queueAccount: name,
          continuousSourceId: campaign.id,
          continuousAuthorizationId: cfg.authorizationId,
        };
        if (
          continuousCandidateEligibility({ ...account, data: state }, probe)
            .eligible
        ) {
          Object.assign(candidate, probe);
          queued++;
        }
      }
  const loaded = new Set(
    reading.candidates
      .map(cleanInput)
      .filter(Boolean)
      .map((c) => c!.username),
  ).size;
  cfg.lastLoaded = loaded;
  cfg.lastAdded = result.added;
  cfg.lastQueued = queued;
  cfg.partial = true;
  cfg.lastCheckAt = at;
  cfg.nextCheckAt = new Date(
    now.getTime() + cfg.pollMinutes * 60000,
  ).toISOString();
  cfg.status = "ready";
  cfg.lastCommittedRunId = reading.runId;
  delete cfg.readRetry;
  cfg.reason = `${loaded} perfis lidos, ${result.added} descobertos nesta consulta e ${queued} enfileirados. A leitura pode ser parcial.`;
  return {
    state,
    ...result,
    queued,
    loaded,
    replayed: false,
    partial: true as const,
  };
}
function markFailure(
  original: AppState,
  id: string,
  reason: string,
  unavailable: boolean,
  now: Date,
): AppState {
  if (typeof reason !== "string" || !reason.trim() || reason.length > 500)
    fail("Informe um motivo de até 500 caracteres para esta fonte.");
  const state = structuredClone(original),
    campaign = source(state, id),
    cfg = campaign.continuous;
  if (!cfg) fail("A fonte ainda não possui uma configuração contínua.");
  if (cfg.account !== owner(state)) fail("A fonte pertence a outra conta.");
  revokeQueued(state, id);
  invalidateCheck(campaign);
  cfg.status = unavailable ? "unavailable" : "error";
  delete cfg.readRetry;
  cfg.reason = reason.trim();
  cfg.lastCheckAt = now.toISOString();
  return state;
}
export function failContinuousReading(
  account: AccountWorkspace,
  id: string,
  runId: string,
  reason: string,
  unavailable = false,
  now = new Date(),
): AppState {
  owner(account.data, account.username);
  const cfg = source(account.data, id).continuous;
  if (
    !cfg ||
    cfg.account !== account.username ||
    cfg.runId !== runId ||
    cfg.status !== "checking"
  )
    fail("Esta consulta já perdeu a identificação ativa.");
  return markFailure(account.data, id, reason, unavailable, now);
}
export function setContinuousSourceUnavailable(
  state: AppState,
  id: string,
  reason: string,
  now = new Date(),
): AppState {
  owner(state);
  return markFailure(state, id, reason, true, now);
}
export function renewContinuousDay(
  account: AccountWorkspace,
  now = new Date(),
) {
  const state = structuredClone(account.data),
    key = continuousDayKey(now);
  if (
    state.continuous?.mode !== "running" ||
    state.continuous.account !== account.username ||
    (state.continuous.dayKey !== undefined && state.continuous.dayKey >= key)
  )
    return { state, renewed: false };
  state.continuous.dayKey = key;
  return { state, renewed: true };
}
export function nextContinuousCheck(
  account: AccountWorkspace,
  now = new Date(),
): number | undefined {
  if (globalReasons(account).length) return;
  const times = account.data.campaigns
    .filter(
      (c) =>
        !c.archived &&
        supported(c) &&
        c.continuous?.enabled &&
        token(c.continuous.authorizationId) &&
        c.continuous.account === account.username &&
        account.data.continuous?.sourceIds?.includes(c.id) &&
        c.continuous.status === "ready",
    )
    .map((c) =>
      c.continuous?.nextCheckAt
        ? Date.parse(c.continuous.nextCheckAt)
        : now.getTime(),
    )
    .filter(Number.isFinite);
  return times.length ? Math.min(...times) : undefined;
}
export function continuousReview(account: AccountWorkspace, now = new Date()) {
  const state = account.data;
  return {
    mode: state.continuous?.mode || "paused",
    reason: state.continuous?.pauseReason || state.runtime.pauseReason,
    nextRunAt: state.continuous?.nextRunAt,
    enabledSourceIds: enabledContinuousSourceIds(account),
    nextCheckAt: nextContinuousCheck(account, now),
    sources: state.campaigns
      .filter((c) => !c.archived && c.kind !== "import")
      .map((c) => ({
        id: c.id,
        name: c.name,
        kind: c.kind,
        target: c.target,
        pollMinutes: DEFAULT_CONTINUOUS_POLL_MINUTES,
        enabled: false,
        autoFollow: false,
        status: "ready" as const,
        ...c.continuous,
        configured: !!c.continuous,
        configurable: supported(c),
        configurationReason: supported(c)
          ? undefined
          : "Nesta versão, a rotina contínua aceita seguidores, comentários e curtidas.",
        active: state.continuous?.sourceIds?.includes(c.id) || false,
        startable: !!(
          supported(c) &&
          c.continuous?.enabled &&
          token(c.continuous.authorizationId) &&
          c.continuous.status === "ready"
        ),
        partial: true as const,
        ...continuousSourceEligibility(account, c.id, now),
      })),
  };
}
