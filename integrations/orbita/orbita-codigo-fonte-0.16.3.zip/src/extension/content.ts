import {
  collectLoaded,
  detectAccount,
  pageRestriction,
  profileControls,
  readOwnProfileMetrics,
  sessionProfilePhoto,
} from "./dom.ts";
import type { FollowResult } from "./dom.ts";
import type { Campaign } from "../core/types.ts";
import { sourceUrl } from "../core/domain.ts";
import { readMarketPage } from "./market-dom.ts";

const marker = "__orbita_content_v1__";
const globalState = globalThis as typeof globalThis & { [marker]?: boolean };
if (!globalState[marker]) {
  globalState[marker] = true;
  let host: HTMLElement | null = null;
  let observer: MutationObserver | undefined;
  let collecting = false;
  let sent = new Map<string, string>();
  const captureIdentity = (candidate: { name?: string; avatarUrl?: string }) =>
    JSON.stringify([candidate.name || "", candidate.avatarUrl || ""]);
  let activeCampaign: Campaign | undefined;
  let scheduled: ReturnType<typeof setTimeout> | undefined;
  const wait = (ms: number) =>
    new Promise((resolve) => setTimeout(resolve, ms));

  async function capture(shadow: ShadowRoot): Promise<void> {
    const status = shadow.querySelector("#status")!;
    if (!activeCampaign || collecting) return;
    const campaign = activeCampaign;
    const restricted = pageRestriction(document, location.pathname);
    if (restricted) {
      status.textContent = restricted;
      observer?.disconnect();
      void chrome.runtime
        .sendMessage({ type: "PLATFORM_WARNING", message: restricted })
        .catch(() => {});
      return;
    }
    try {
      const result = collectLoaded(
        document,
        campaign.kind,
        campaign.target,
        detectAccount(document) || undefined,
      );
      const fresh = result.candidates.filter(
        (c) => sent.get(c.username) !== captureIdentity(c),
      );
      if (!fresh.length) {
        status.textContent = `${sent.size} perfis capturados. Role a lista para carregar mais.`;
        return;
      }
      collecting = true;
      const response = await chrome.runtime.sendMessage({
        type: "CAPTURE",
        campaignId: campaign.id,
        candidates: fresh,
        url: location.href,
      });
      if (!response?.ok)
        throw new Error(response?.error || "A captura não foi salva.");
      fresh.forEach((c) => sent.set(c.username, captureIdentity(c)));
      status.textContent = `${sent.size} perfis capturados e salvos. Captura parcial; role para carregar mais.`;
    } catch (error) {
      status.textContent =
        error instanceof Error ? error.message : "Falha ao capturar.";
    } finally {
      collecting = false;
    }
  }
  function showCollector(campaign: Campaign): void {
    observer?.disconnect();
    if (scheduled) clearTimeout(scheduled);
    host?.remove();
    activeCampaign = campaign;
    sent = new Map();
    host = document.createElement("div");
    host.id = "orbita-collector";
    document.body.append(host);
    const shadow = host.attachShadow({ mode: "open" });
    shadow.innerHTML = `<style>:host{all:initial}.box{position:fixed;right:24px;bottom:24px;width:330px;z-index:2147483647;background:#fff;color:#173d36;padding:22px;border-radius:20px;box-shadow:0 12px 70px #0004;font:14px/1.5 system-ui;border:1px solid #d8e0d5}h3{font-size:19px;margin:0 0 5px}p{margin:8px 0;color:#52655e}button{font:600 13px system-ui;padding:11px 14px;border:0;border-radius:10px;cursor:pointer;background:#d8f576;color:#173d36}button.secondary{background:#edf2e9}.actions{display:flex;gap:8px;margin:16px 0 12px}.close{float:right;background:transparent;padding:0 4px;font-size:20px}.meta{font-size:11px;color:#6c7d73}label{display:flex;align-items:center;gap:6px;margin-top:12px}</style><section class="box"><button class="close" aria-label="Fechar coletor">×</button><div class="meta">ÓRBITA · COLETA ACOMPANHADA</div><h3></h3><p id="status">Abra a lista correspondente. A captura lê apenas o conteúdo carregado, sem acessar perfis privados.</p><div class="actions"><button id="capture">Capturar carregados</button><button id="dashboard" class="secondary">Ver painel ↗</button></div><label><input id="watch" type="checkbox"> Capturar enquanto eu rolo</label><p class="meta">A coleta pode ser parcial. Uma captura não segue ninguém.</p></section>`;
    shadow.querySelector("h3")!.textContent = campaign.name;
    shadow.querySelector(".close")!.addEventListener("click", () => {
      observer?.disconnect();
      if (scheduled) clearTimeout(scheduled);
      host?.remove();
    });
    shadow
      .querySelector("#capture")!
      .addEventListener("click", () => void capture(shadow));
    shadow
      .querySelector("#dashboard")!
      .addEventListener(
        "click",
        () => void chrome.runtime.sendMessage({ type: "OPEN_DASHBOARD" }),
      );
    shadow.querySelector("#watch")!.addEventListener("change", (event) => {
      if (!(event.target as HTMLInputElement).checked) {
        observer?.disconnect();
        return;
      }
      void capture(shadow);
      observer = new MutationObserver(() => {
        if (!scheduled)
          scheduled = setTimeout(() => {
            scheduled = undefined;
            void capture(shadow);
          }, 1500);
      });
      observer.observe(document.body, {
        childList: true,
        subtree: true,
        attributes: true,
        attributeFilter: ["src", "srcset"],
      });
    });
  }
  async function follow(
    username: string,
    expectedAccount: string,
    token: string,
  ): Promise<FollowResult> {
    const restricted = pageRestriction(document, location.pathname);
    if (restricted)
      return {
        stage: "failed",
        message: restricted,
        stop: true,
        platformWarning: true,
      };
    if (detectAccount(document) !== expectedAccount)
      return {
        stage: "failed",
        message:
          "A conta da sessão não pôde ser confirmada ou foi trocada. Nenhum clique foi enviado.",
        stop: true,
      };
    const controls = profileControls(document, location.pathname, username);
    if (controls.error)
      return { stage: "failed", message: controls.error, stop: true };
    if (controls.state)
      return {
        stage: "already",
        message:
          controls.state === "requested"
            ? "Já havia uma solicitação pendente."
            : "O perfil já estava sendo seguido.",
      };
    const authorization = await chrome.runtime.sendMessage({
      type: "AUTHORIZE_CLICK",
      username,
      expectedAccount,
      token,
    });
    if (!authorization?.ok)
      return {
        stage: "failed",
        message:
          "A execução foi pausada ou perdeu a autorização. Nenhum clique foi enviado.",
        stop: true,
      };
    // Recheck the DOM after the asynchronous authorization to avoid clicking a replaced control.
    if (
      pageRestriction(document, location.pathname) ||
      detectAccount(document) !== expectedAccount
    )
      return {
        stage: "failed",
        message: "A sessão mudou antes do clique.",
        stop: true,
      };
    const current = profileControls(document, location.pathname, username);
    if (!current.follow || current.follow !== controls.follow)
      return {
        stage: "failed",
        message:
          "O botão mudou durante a verificação. Nenhum clique foi enviado.",
        stop: true,
      };
    current.follow.click();
    let lastState = "",
      stable = 0;
    for (let i = 0; i < 20; i++) {
      await wait(300);
      const blocked = pageRestriction(document, location.pathname);
      if (blocked)
        return {
          stage: "uncertain",
          message: blocked,
          stop: true,
          platformWarning: true,
        };
      const result = profileControls(document, location.pathname, username);
      if (result.state) {
        stable = result.state === lastState ? stable + 1 : 1;
        lastState = result.state;
        if (stable >= 4)
          return {
            stage: result.state,
            message:
              result.state === "requested"
                ? "Solicitação confirmada pelo botão do Instagram."
                : "Estado Seguindo confirmado pelo botão do Instagram.",
          };
      } else {
        stable = 0;
        lastState = "";
      }
    }
    return {
      stage: "uncertain",
      message:
        "Clique enviado, mas o resultado não foi confirmado. Confira no Instagram; não haverá repetição automática.",
      stop: true,
    };
  }
  chrome.runtime.onMessage.addListener((message, sender, respond) => {
    if (sender.id !== chrome.runtime.id) return false;
    if (message.type === "STATUS") {
      respond({
        account: detectAccount(document),
        avatarUrl: sessionProfilePhoto(document, location.pathname),
        restricted: pageRestriction(document, location.pathname),
        url: location.href,
      });
      return false;
    }
    if (message.type === "COLLECTOR") {
      showCollector(message.campaign);
      respond({ ok: true });
      return false;
    }
    if (message.type === "MARKET_PAGE") {
      try {
        respond({
          ok: true,
          data: readMarketPage(document, location.href, message.expectedOwn),
        });
      } catch (error) {
        respond({
          ok: false,
          error:
            error instanceof Error
              ? error.message
              : "Não foi possível ler a página.",
        });
      }
      return false;
    }
    if (message.type === "PROFILE_METRICS") {
      try {
        respond({
          ok: true,
          ...readOwnProfileMetrics(
            document,
            location.pathname,
            message.expectedAccount,
          ),
        });
      } catch (error) {
        respond({
          ok: false,
          error:
            error instanceof Error
              ? error.message
              : "Não foi possível ler as métricas.",
        });
      }
      return false;
    }
    if (message.type === "FOLLOW") {
      void follow(message.username, message.expectedAccount, message.token)
        .then(respond)
        .catch(() =>
          respond({
            stage: "uncertain",
            message: "A comunicação foi interrompida. Verifique o perfil.",
            stop: true,
          }),
        );
      return true;
    }
    return false;
  });
  document.addEventListener(
    "click",
    (event) => {
      if (
        !activeCampaign ||
        !["hashtag", "location"].includes(activeCampaign.kind)
      )
        return;
      const expected = new URL(
        sourceUrl(activeCampaign.kind, activeCampaign.target),
      );
      if (!location.pathname.startsWith(expected.pathname)) return;
      const anchor = (event.target as Element)?.closest<HTMLAnchorElement>(
        "a[href]",
      );
      if (
        !anchor ||
        !/^\/(p|reel)\/[\w-]+\/?$/.test(new URL(anchor.href).pathname)
      )
        return;
      void chrome.runtime
        .sendMessage({
          type: "COLLECTOR_MEDIA",
          campaignId: activeCampaign.id,
          url: anchor.href,
        })
        .catch(() => {});
    },
    true,
  );
  void chrome.runtime
    .sendMessage({ type: "GET_COLLECTOR" })
    .then((result) => {
      if (result?.ok && result.campaign) showCollector(result.campaign);
    })
    .catch(() => {});
}
