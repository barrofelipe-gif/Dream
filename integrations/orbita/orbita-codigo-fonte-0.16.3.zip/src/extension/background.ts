import { trustedHostedPage, allowedHostedMessage } from "../core/hosted.ts";
import {
  applyCommand,
  attemptsToday,
  audit,
  insideWindow,
  recoverInterrupted,
  sourceUrl,
  uid,
} from "../core/domain.ts";
import {
  budgetStopReason,
  pendingWarningReason,
  sessionLimit,
  intervalReadyAt,
} from "../core/safety.ts";
import type { AppState, Command, SpecialCommand } from "../core/types.ts";
import type { FollowResult } from "./dom.ts";
import { marketUrl } from "../core/market.ts";
import { APP_SCOPE } from "../core/problems.ts";
import {
  readProblems,
  recordNativeProblem,
  changeNativeProblem,
  recoverNativeProblem,
  problemStoreFailure,
} from "./problem-store.ts";

import {
  workspace,
  accountCommand,
  bindVerifiedAccount,
  addSnapshot,
  applyScopedCommand,
} from "../core/accounts.ts";
import {
  readStore,
  editStore,
  storeReady as initialized,
  settledStore,
  alarmName,
} from "./account-store.ts";
let runnerActive = false;
const sleep = (ms: number) => new Promise((resolve) => setTimeout(resolve, ms));
const controllers = new Map<string, ReturnType<typeof createController>>();
function controller(id: string) {
  let value = controllers.get(id);
  if (!value) {
    value = createController(id);
    controllers.set(id, value);
  }
  return value;
}
function createController(workspaceId: string) {
  const ALARM = alarmName(workspaceId);
  const read = async (): Promise<AppState> =>
    workspace(await readStore(), workspaceId).data;
  const ensureActive = async () => {
    if ((await readStore()).activeId !== workspaceId)
      throw new Error(
        "A conta selecionada mudou. Esta tarefa foi pausada no espaço de origem.",
      );
  };
  const edit = async (
    fn: (state: AppState) => AppState | void,
    allowInactive = false,
  ): Promise<AppState> => {
    const root = await editStore((store) => {
      if (!allowInactive && store.activeId !== workspaceId)
        throw new Error(
          "A conta ativa mudou durante a operação. Nenhum dado foi transferido para outra conta.",
        );
      const account = workspace(store, workspaceId);
      account.data = fn(account.data) || account.data;
      account.data.runtime.account = account.username;
    });
    return workspace(root, workspaceId).data;
  };
  async function pageMessage(tabId: number, message: object): Promise<any> {
    try {
      return await chrome.tabs.sendMessage(tabId, message);
    } catch {
      await chrome.scripting.executeScript({
        target: { tabId },
        files: ["content.js"],
      });
      return chrome.tabs.sendMessage(tabId, message);
    }
  }
  const pathOf = (value: string) => {
    const url = new URL(value);
    return url.origin + url.pathname.replace(/\/$/, "");
  };
  async function loaded(tabId: number, expectedUrl: string): Promise<void> {
    const deadline = Date.now() + 18000;
    while (Date.now() < deadline) {
      await ensureActive();
      const tab = await chrome.tabs.get(tabId);
      if (
        tab.status === "complete" &&
        tab.url &&
        pathOf(tab.url) === pathOf(expectedUrl)
      ) {
        try {
          const status = await pageMessage(tabId, { type: "STATUS" });
          if (status.restricted) {
            await pauseWithReason(status.restricted, true);
            throw new Error(status.restricted, { cause: "instagram-warning" });
          }
          if (status.url && pathOf(status.url) === pathOf(expectedUrl)) {
            await sleep(700);
            return;
          }
        } catch (error) {
          if (error instanceof Error && error.cause === "instagram-warning")
            throw error;
          /* document may still be replacing */
        }
      }
      if (
        tab.url &&
        /\/(challenge|checkpoint|accounts\/login)\b/.test(
          new URL(tab.url).pathname,
        )
      ) {
        const message =
          "O Instagram pediu login ou verificação. A fila foi pausada.";
        await pauseWithReason(message, true);
        throw new Error(message);
      }
      await sleep(400);
    }
    throw new Error("O Instagram demorou para abrir. A execução foi pausada.");
  }
  async function session(tabId: number): Promise<{
    account: string | null;
    avatarUrl?: string;
    restricted: string | null;
    url: string;
  }> {
    let result;
    for (let i = 0; i < 6; i++) {
      result = await pageMessage(tabId, { type: "STATUS" });
      if (result.account || result.restricted) return result;
      await sleep(600);
    }
    return result;
  }
  async function profileTab(url: string): Promise<number> {
    await ensureActive();
    const data = await read();
    let tab: chrome.tabs.Tab | undefined;
    if (data.runtime.connectionTabId) {
      try {
        const previous = await chrome.tabs.get(data.runtime.connectionTabId);
        if (previous.url?.startsWith("https://www.instagram.com/"))
          tab = previous;
      } catch {}
    }
    tab = tab?.id
      ? await chrome.tabs.update(tab.id, { url, active: true })
      : await chrome.tabs.create({ url, active: true });
    if (!tab?.id) throw new Error("Não foi possível abrir o Instagram.");
    const id = tab.id;
    await edit((s) => {
      s.runtime.connectionTabId = id;
    });
    await loaded(id, url);
    return id;
  }
  async function observeSession(account: string | null) {
    await editStore((store) => {
      store.sessionUsername = account || undefined;
      store.sessionCheckedAt = new Date().toISOString();
    });
  }
  async function connect(): Promise<string> {
    if (runnerActive || (await read()).runtime.mode === "running")
      throw new Error(
        "Pause a execução e aguarde a ação atual antes de conectar uma conta.",
      );
    const account = workspace(await readStore(), workspaceId);
    const url = account.username
      ? "https://www.instagram.com/" + account.username + "/"
      : "https://www.instagram.com/";
    const tabId = await profileTab(url);
    const status = await session(tabId);
    await observeSession(status.account);
    if (status.restricted) {
      await pauseWithReason(status.restricted, true);
      throw new Error(status.restricted);
    }
    if (!status.account)
      throw new Error(
        "Entre na conta pelo Instagram e deixe o menu Perfil visível. Depois clique em Conectar sessão novamente.",
      );
    const root = await editStore((store) => {
      const linked = bindVerifiedAccount(
        store,
        workspaceId,
        status.account!,
        status.avatarUrl,
      );
      workspace(linked).data.runtime.connectionTabId = tabId;
      return linked;
    });
    const connected = workspace(root);
    if (account.username && connected.id === workspaceId) {
      try {
        const values = await pageMessage(tabId, {
          type: "PROFILE_METRICS",
          expectedAccount: account.username,
        });
        if (values.ok)
          await editStore((store) => {
            if (store.activeId !== workspaceId)
              throw new Error("Conta alterada.");
            addSnapshot(workspace(store, workspaceId), {
              ...values,
              source: "instagram",
            });
          });
        else
          await recordNativeProblem({
            scope: workspaceId,
            operation: "PROFILE_METRICS",
            source: "worker",
            message:
              values?.error ||
              "A sessão foi confirmada, mas os contadores do perfil não puderam ser lidos.",
          });
      } catch (error) {
        await recordNativeProblem({
          scope: workspaceId,
          operation: "PROFILE_METRICS",
          source: "worker",
          message:
            error instanceof Error
              ? error.message
              : "Falha na leitura dos contadores após confirmar a sessão.",
        });
      }
    }
    return (
      "Sessão de @" +
      status.account +
      " verificada. As informações estão no dashboard desta conta."
    );
  }
  async function refreshMetrics(): Promise<string> {
    if (runnerActive || (await read()).runtime.mode === "running")
      throw new Error(
        "Pause a fila antes de atualizar os contadores do perfil.",
      );
    const account = workspace(await readStore(), workspaceId);
    const warning = pendingWarningReason(account.data.settings);
    if (warning) throw new Error(warning);
    if (!account.username)
      throw new Error("Cadastre ou identifique sua conta primeiro.");
    const url = "https://www.instagram.com/" + account.username + "/";
    const tabId = await profileTab(url);
    const status = await session(tabId);
    await observeSession(status.account);
    if (status.restricted) {
      await pauseWithReason(status.restricted, true);
      throw new Error(status.restricted);
    }
    if (status.account !== account.username)
      throw new Error(
        "A sessão está em @" +
          (status.account || "não identificada") +
          ". Troque para @" +
          account.username +
          " no Instagram e verifique novamente.",
      );
    const values = await pageMessage(tabId, {
      type: "PROFILE_METRICS",
      expectedAccount: account.username,
    });
    if (!values?.ok)
      throw new Error(values?.error || "Os contadores não puderam ser lidos.");
    await editStore((store) => {
      const result = bindVerifiedAccount(
        store,
        workspaceId,
        account.username!,
        status.avatarUrl,
      );
      addSnapshot(workspace(result, workspaceId), {
        ...values,
        source: "instagram",
      });
      return result;
    });
    return (
      "Métricas de @" +
      account.username +
      " atualizadas a partir da interface do Instagram."
    );
  }
  async function openSource(id: string): Promise<void> {
    const state = await read();
    const warning = pendingWarningReason(state.settings);
    if (warning) throw new Error(warning);
    if (state.runtime.mode === "running")
      throw new Error("Pause a fila para abrir uma coleta.");
    const campaign = state.campaigns.find((c) => c.id === id && !c.archived);
    if (!campaign) throw new Error("Campanha não encontrada.");
    const url = sourceUrl(campaign.kind, campaign.target);
    if (!url) throw new Error("Essa campanha recebe uma lista importada.");
    const tab = await chrome.tabs.create({ url, active: true });
    if (!tab.id) throw new Error("Não foi possível abrir a fonte.");
    const tabId = tab.id;
    await edit((s) => {
      s.runtime.collectorCampaignId = id;
      s.runtime.collectorTabId = tabId;
      s.runtime.collectorAllowedPaths = [];
      audit(s, "collection", `Fonte aberta para “${campaign.name}”.`);
    });
    await loaded(tabId, url);
    await pageMessage(tabId, { type: "COLLECTOR", campaign });
  }
  async function schedule(_state: AppState): Promise<void> {
    const root = await readStore();
    const state = workspace(root, workspaceId).data;
    if (root.activeId === workspaceId && state.runtime.mode === "running")
      await chrome.alarms.create(ALARM, {
        when:
          state.runtime.nextRun ||
          Date.now() + state.settings.intervalMinutes * 60000,
      });
    else await chrome.alarms.clear(ALARM);
  }
  async function pauseWithReason(
    message: string,
    platformWarning = false,
  ): Promise<void> {
    const state = await edit((s) => {
      if (platformWarning) s.settings.hasPendingWarning = true;
      s.runtime.mode = "paused";
      s.runtime.pauseReason = message;
      delete s.runtime.nextRun;
      delete s.runtime.activeToken;
      audit(s, platformWarning ? "warning" : "pause", message);
    }, true);
    if (platformWarning)
      await recordNativeProblem({
        scope: workspaceId,
        operation: "PLATFORM_WARNING",
        source: "worker",
        category: "platform",
        message,
      });
    await schedule(state);
  }
  async function runQueue(): Promise<void> {
    await initialized;
    if (runnerActive) return;
    runnerActive = true;
    let selectedId: string | undefined;
    try {
      await ensureActive();
      let state = await read();
      if (state.runtime.mode !== "running") return;
      const budgetReason = budgetStopReason(state, attemptsToday(state));
      if (budgetReason) {
        await pauseWithReason(budgetReason);
        return;
      }
      const readyAt = intervalReadyAt(state);
      if (Date.now() < readyAt) {
        state = await edit((s) => {
          if (s.runtime.mode === "running") {
            s.runtime.nextRun = intervalReadyAt(s);
            s.runtime.pauseReason =
              "Aguardando o intervalo entre tentativas. Pausar ou reiniciar não encurta essa espera.";
          }
        });
        await schedule(state);
        return;
      }
      if (!insideWindow(new Date(), state.settings)) {
        await pauseWithReason(
          "Fora da janela de horários configurada. Inicie novamente dentro do horário.",
        );
        return;
      }
      const candidate = state.candidates.find((c) => c.stage === "queued");
      if (!candidate) {
        await pauseWithReason(
          "Fila concluída. Todos os resultados estão no histórico.",
        );
        return;
      }
      if (
        !state.runtime.account ||
        candidate.queueAccount !== state.runtime.account
      ) {
        await pauseWithReason("A fila e a conta conectada não correspondem.");
        return;
      }
      if (
        state.settings.exclusions.includes(candidate.username) ||
        candidate.sources.some((s) => s.url.startsWith("demo:"))
      ) {
        await edit((s) => {
          const c = s.candidates.find((c) => c.id === candidate.id)!;
          c.stage = "excluded";
          audit(
            s,
            "excluded",
            "Perfil de demonstração ou da lista de exclusão retirado da fila.",
            c.username,
          );
        });
        await pauseWithReason(
          "Um perfil não elegível foi retirado da fila. Revise antes de continuar.",
        );
        return;
      }
      const expectedAccount = state.runtime.account;
      let tab: chrome.tabs.Tab | undefined;
      if (state.runtime.workerTabId) {
        try {
          const existing = await chrome.tabs.get(state.runtime.workerTabId);
          if (existing.url?.startsWith("https://www.instagram.com/"))
            tab = existing;
        } catch {
          /* closed */
        }
      }
      const url = `https://www.instagram.com/${candidate.username}/`;
      if (tab?.id)
        tab = await chrome.tabs.update(tab.id, { url, active: true });
      else tab = await chrome.tabs.create({ url, active: true });
      if (!tab?.id) throw new Error("Não foi possível abrir o perfil da fila.");
      const tabId = tab.id;
      await edit((s) => {
        s.runtime.workerTabId = tabId;
      });
      await loaded(tabId, url);
      const status = await session(tabId);
      await observeSession(status.account);
      if (status.restricted || status.account !== expectedAccount) {
        await pauseWithReason(
          status.restricted ||
            "Não foi possível confirmar a conta de execução na página. Nenhuma ação foi enviada.",
          !!status.restricted,
        );
        return;
      }
      const token = uid();
      state = await edit((s) => {
        if (s.runtime.mode !== "running") return;
        const c = s.candidates.find((c) => c.id === candidate.id);
        if (
          !c ||
          c.stage !== "queued" ||
          s.settings.exclusions.includes(c.username) ||
          !insideWindow(new Date(), s.settings) ||
          budgetStopReason(s, attemptsToday(s)) ||
          Date.now() < intervalReadyAt(s)
        )
          return;
        c.stage = "attempting";
        selectedId = c.id;
        s.runtime.activeCandidateId = c.id;
        s.runtime.activeToken = token;
        s.runtime.activeExpiresAt = Date.now() + 10000;
        audit(
          s,
          "attempt",
          "Verificação iniciada; o resultado ainda não foi confirmado.",
          c.username,
        );
      });
      if (state.runtime.activeToken !== token) {
        if (state.runtime.mode === "running")
          await pauseWithReason(
            "As condições da fila mudaram durante a preparação. Revise antes de continuar.",
          );
        return;
      }
      // A timed-out reply is always uncertain; never repeat FOLLOW automatically.
      const result: FollowResult = await Promise.race([
        chrome.tabs.sendMessage(tabId, {
          type: "FOLLOW",
          username: candidate.username,
          expectedAccount,
          token,
        }),
        sleep(12000).then((): FollowResult => ({
          stage: "uncertain",
          message:
            "O retorno da ação expirou. Confira o perfil antes de qualquer nova ação.",
          stop: true,
        })),
      ]);
      state = await edit((s) => {
        const c = s.candidates.find((c) => c.id === candidate.id);
        if (!c) return;
        const valid =
          result &&
          ["followed", "requested", "already", "uncertain", "failed"].includes(
            result.stage,
          );
        c.stage = valid ? result.stage : "uncertain";
        c.lastResult = valid
          ? result.message
          : "Resposta desconhecida. Confira o perfil.";
        c.updatedAt = new Date().toISOString();
        if (s.runtime.account) {
          s.lastAttempts ||= {};
          s.lastAttempts[`@${s.runtime.account}`] = c.updatedAt;
        }
        audit(s, c.stage, c.lastResult, c.username);
        if (result?.platformWarning) {
          s.settings.hasPendingWarning = true;
          audit(s, "warning", c.lastResult, c.username);
        }
        delete s.runtime.activeCandidateId;
        delete s.runtime.activeToken;
        delete s.runtime.activeExpiresAt;
        if (!valid || result.stop || c.stage === "uncertain") {
          s.runtime.mode = "paused";
          s.runtime.pauseReason = c.lastResult;
          delete s.runtime.nextRun;
        } else if (s.runtime.mode === "running") {
          if (!s.candidates.some((candidate) => candidate.stage === "queued")) {
            s.runtime.mode = "paused";
            s.runtime.pauseReason =
              "Fila concluída. Todos os resultados estão no histórico.";
            delete s.runtime.nextRun;
          } else if (budgetStopReason(s, attemptsToday(s))) {
            s.runtime.mode = "paused";
            s.runtime.pauseReason = budgetStopReason(s, attemptsToday(s))!;
            delete s.runtime.nextRun;
          } else {
            s.runtime.nextRun = Date.now() + s.settings.intervalMinutes * 60000;
            s.runtime.pauseReason =
              "Execução em andamento. Você pode pausar a qualquer momento.";
          }
        }
      }, true);
      if (
        !result ||
        !["followed", "requested", "already"].includes(result.stage)
      )
        await recordNativeProblem({
          scope: workspaceId,
          operation: "QUEUE_ACTION",
          source: "worker",
          category: result?.platformWarning ? "platform" : "uncertain",
          message:
            result?.message ||
            "Resposta da ação não reconhecida. Confira o perfil antes de repetir.",
        });
      await schedule(state);
    } catch (error) {
      const message =
        error instanceof Error
          ? error.message
          : "A comunicação com o Instagram foi interrompida.";
      await recordNativeProblem({
        scope: workspaceId,
        operation: "QUEUE_FAILURE",
        source: "worker",
        category: "uncertain",
        message,
      });
      await edit((s) => {
        if (selectedId) {
          const c = s.candidates.find((c) => c.id === selectedId);
          if (c?.stage === "attempting") {
            c.stage = "uncertain";
            c.lastResult = message;
            audit(s, "uncertain", message, c.username);
          }
        }
      }, true);
      await pauseWithReason(message);
    } finally {
      runnerActive = false;
    }
  }
  async function start(reviewed: boolean): Promise<void> {
    await ensureActive();
    const account = workspace(await readStore(), workspaceId);
    if (!account.verifiedAt)
      throw new Error(
        "Conecte e verifique a sessão desta conta antes de iniciar.",
      );
    const rootSession = (await readStore()).sessionUsername;
    if (rootSession && rootSession !== account.username)
      throw new Error(
        "A última sessão identificada pertence a outra conta. Conecte a sessão selecionada antes de executar.",
      );
    const state = await edit((s) => {
      if (!reviewed)
        throw new Error(
          "Revise a conta e o lote antes de iniciar. Confirme essa revisão na janela de início.",
        );
      const warning = pendingWarningReason(s.settings);
      if (warning) throw new Error(warning);
      if (runnerActive || s.candidates.some((c) => c.stage === "attempting"))
        throw new Error(
          "Aguarde o resultado da ação atual antes de reiniciar.",
        );
      if (!s.runtime.account)
        throw new Error("Conecte a conta antes de iniciar.");
      if (!s.candidates.some((c) => c.stage === "queued"))
        throw new Error("Aprove perfis e adicione-os à fila.");
      if (!insideWindow(new Date(), s.settings))
        throw new Error("O horário atual está fora da janela configurada.");
      if (attemptsToday(s) >= s.settings.dailyLimit)
        throw new Error("O teto diário de tentativas foi alcançado.");
      s.runtime.sessionAttempts = 0;
      s.runtime.sessionStartedAt = new Date().toISOString();
      s.runtime.mode = "running";
      s.runtime.nextRun = Math.max(Date.now() + 30000, intervalReadyAt(s));
      s.runtime.pauseReason =
        intervalReadyAt(s) > Date.now() + 30000
          ? "Aguardando o intervalo que ainda resta desde a última tentativa."
          : "Preparando o próximo perfil. A primeira verificação acontece em cerca de 30 segundos.";
      audit(
        s,
        "start",
        "Novo lote iniciado; o usuário declarou ter revisado a conta e os candidatos. O intervalo e o consumo diário foram preservados.",
      );
    });
    await schedule(state);
  }
  async function command(
    command: Command | SpecialCommand,
  ): Promise<string | void> {
    await ensureActive();
    if (command.type === "CONNECT") return connect();
    if (command.type === "REFRESH_METRICS") return refreshMetrics();
    if (command.type === "OPEN_SOURCE") return openSource(command.id);
    if (command.type === "START") return start(command.reviewed === true);
    if (command.type === "RESTORE") {
      const current = await read();
      if (runnerActive || current.runtime.mode === "running")
        throw new Error(
          "Pause e aguarde o término da ação atual antes de restaurar.",
        );
    }
    const root = await editStore((store) =>
      applyScopedCommand(store, workspaceId, command),
    );
    await schedule(workspace(root, workspaceId).data);
  }
  async function contentRoute(
    message: any,
    sender: chrome.runtime.MessageSender,
  ): Promise<object> {
    await settledStore();
    const state = await read();
    if (
      message.type === "PLATFORM_WARNING" &&
      sender.id === chrome.runtime.id &&
      sender.tab?.id !== undefined &&
      [state.runtime.workerTabId, state.runtime.collectorTabId].includes(
        sender.tab.id,
      )
    ) {
      await pauseWithReason(
        typeof message.message === "string"
          ? message.message.slice(0, 500)
          : "O Instagram mostrou um aviso. Confira a conta antes de retomar.",
        true,
      );
      return { ok: true };
    }
    if (message.type === "AUTHORIZE_CLICK") {
      let allowed = false;
      await edit((state) => {
        const c = state.candidates.find(
          (c) => c.id === state.runtime.activeCandidateId,
        );
        allowed = !!(
          sender.id === chrome.runtime.id &&
          sender.tab?.id === state.runtime.workerTabId &&
          sender.url?.startsWith(`https://www.instagram.com/${c?.username}/`) &&
          state.runtime.mode === "running" &&
          state.runtime.activeToken === message.token &&
          Date.now() < (state.runtime.activeExpiresAt || 0) &&
          c?.stage === "attempting" &&
          c.username === message.username &&
          c.queueAccount === message.expectedAccount &&
          state.runtime.account === message.expectedAccount &&
          !state.settings.hasPendingWarning &&
          (state.runtime.sessionAttempts || 0) <=
            sessionLimit(state.settings) &&
          attemptsToday(state) <= state.settings.dailyLimit &&
          !state.settings.exclusions.includes(c.username) &&
          insideWindow(new Date(), state.settings)
        );
        // The attempt is already reserved in both counters, so <= permits its last allowed click.
        if (allowed) delete state.runtime.activeToken;
      });
      return { ok: !!allowed };
    }
    if (
      ["CAPTURE", "GET_COLLECTOR", "COLLECTOR_MEDIA"].includes(message.type)
    ) {
      if (message.type === "GET_COLLECTOR") {
        if (sender.tab?.id !== state.runtime.collectorTabId)
          return { ok: false };
        const campaign = state.campaigns.find(
          (c) => c.id === state.runtime.collectorCampaignId && !c.archived,
        );
        return campaign ? { ok: true, campaign } : { ok: false };
      }
      if (
        sender.tab?.id !== state.runtime.collectorTabId ||
        message.campaignId !== state.runtime.collectorCampaignId ||
        !sender.url?.startsWith("https://www.instagram.com/")
      )
        throw new Error(
          "Esta aba não é a fonte de coleta ativa. Abra a campanha novamente.",
        );
      const campaign = state.campaigns.find(
        (c) => c.id === message.campaignId && !c.archived,
      );
      if (!campaign) throw new Error("Campanha não encontrada.");
      const warning = pendingWarningReason(state.settings);
      if (warning) throw new Error(warning);
      const actual = new URL(sender.url);
      const expected = new URL(sourceUrl(campaign.kind, campaign.target));
      if (message.type === "COLLECTOR_MEDIA") {
        const destination = new URL(message.url);
        if (
          !["hashtag", "location"].includes(campaign.kind) ||
          !actual.pathname.startsWith(expected.pathname) ||
          destination.origin !== actual.origin ||
          !/^\/(p|reel)\/[\w-]+\/?$/.test(destination.pathname)
        )
          throw new Error("Publicação fora da fonte ativa.");
        await edit((s) => {
          s.runtime.collectorAllowedPaths = [
            ...new Set([
              ...(s.runtime.collectorAllowedPaths || []),
              destination.pathname.replace(/\/$/, ""),
            ]),
          ].slice(-100);
        });
        return { ok: true };
      }
      if (
        ["followers", "following"].includes(campaign.kind) &&
        actual.pathname.replace(/\/$/, "").toLowerCase() !==
          expected.pathname.replace(/\/$/, "").toLowerCase()
      )
        throw new Error(
          "A lista aberta não corresponde à fonte. Reabra Seguidores ou Seguidos da campanha.",
        );
      if (
        ["commenters", "likers"].includes(campaign.kind) &&
        actual.pathname.replace(/\/$/, "") !==
          expected.pathname.replace(/\/$/, "")
      )
        throw new Error("A publicação aberta não corresponde à campanha.");
      if (
        ["hashtag", "location"].includes(campaign.kind) &&
        !actual.pathname.startsWith(expected.pathname) &&
        !state.runtime.collectorAllowedPaths?.includes(
          actual.pathname.replace(/\/$/, ""),
        )
      )
        throw new Error(
          "Abra a publicação a partir da hashtag ou localização da campanha para preservar a origem.",
        );
      await edit((s) =>
        applyCommand(s, {
          type: "IMPORT",
          campaignId: campaign.id,
          candidates: message.candidates,
          url: actual.origin + actual.pathname,
        }),
      );
      return { ok: true };
    }
    if (
      message.type === "OPEN_DASHBOARD" &&
      sender.id === chrome.runtime.id &&
      sender.tab?.url?.startsWith("https://www.instagram.com/")
    ) {
      await chrome.tabs.create({ url: chrome.runtime.getURL("index.html") });
      return { ok: true };
    }
    throw new Error("Mensagem não autorizada.");
  }

  async function marketPage(url: string, own: boolean) {
    await ensureActive();
    const state = await read();
    if (runnerActive || state.runtime.mode === "running")
      throw new Error("Pause a fila antes de consultar uma referência.");
    const warning = pendingWarningReason(state.settings);
    if (warning) throw new Error(warning);
    const account = workspace(await readStore(), workspaceId);
    if (!account.username) throw new Error("Cadastre sua conta primeiro.");
    const target = own
      ? `https://www.instagram.com/${account.username}/`
      : marketUrl(url, true);
    const tabId = await profileTab(target);
    const result = await pageMessage(tabId, {
      type: "MARKET_PAGE",
      expectedOwn: own ? account.username : undefined,
    });
    await ensureActive();
    if (!result?.ok)
      throw new Error(result?.error || "A página não pôde ser lida.");
    if (result.data?.url !== target)
      throw new Error("A página mudou durante a leitura. Consulte novamente.");
    return result.data;
  }
  return { command, runQueue, contentRoute, marketPage };
}
function isDashboard(sender: chrome.runtime.MessageSender): boolean {
  return (
    sender.id === chrome.runtime.id &&
    (!!sender.url?.startsWith(chrome.runtime.getURL("index.html")) ||
      trustedHostedPage(sender.url))
  );
}
async function route(
  message: any,
  sender: chrome.runtime.MessageSender,
): Promise<object> {
  if (trustedHostedPage(sender.url)) {
    if (sender.id !== chrome.runtime.id || sender.tab?.id === undefined)
      throw new Error("Conector não autorizado.");
    if (message?.type === "HOSTED_CONNECT")
      return { ok: true, version: chrome.runtime.getManifest().version };
    if (!allowedHostedMessage(message))
      throw new Error("Operação não disponível no conector do app.");
  }
  // Independent of the account store: diagnostics must survive its startup failure.
  if (isDashboard(sender)) {
    if (message?.type === "GET_PROBLEMS")
      return { ok: true, store: await readProblems() };
    if (message?.type === "REPORT_PROBLEM") {
      const id = await recordNativeProblem({
        ...message.input,
        source: ["dashboard", "visible", "runtime", "manual"].includes(
          message.input?.source,
        )
          ? message.input.source
          : "dashboard",
      });
      return {
        ok: !!id,
        id,
        error: id
          ? undefined
          : problemStoreFailure() ||
            "Não foi possível persistir o diagnóstico.",
      };
    }
    if (message?.type === "UPDATE_PROBLEM") {
      await changeNativeProblem(
        message.scope,
        message.id,
        message.status,
        message.note,
      );
      return { ok: true };
    }
    if (message?.type === "RECOVER_PROBLEM") {
      await recoverNativeProblem(message.scope, message.id);
      return { ok: true };
    }
  }
  await initialized;
  await settledStore();
  let root = await readStore();
  if (message.type === "GET_STATE" && isDashboard(sender))
    return { ok: true, store: root, state: workspace(root).data };
  if (message.type === "READ_MARKET_PAGE" && isDashboard(sender)) {
    if (
      message.workspaceId !== root.activeId ||
      typeof message.own !== "boolean" ||
      (!message.own && typeof message.url !== "string")
    )
      throw new Error("Conta ou link inválido para a leitura.");
    const data = await controller(root.activeId).marketPage(
      message.url,
      message.own,
    );
    return { ok: true, data };
  }
  if (message.type === "ACCOUNT_COMMAND" && isDashboard(sender)) {
    if (!message.command || message.expectedActiveId !== root.activeId)
      throw new Error("A conta ativa mudou. Aguarde a atualização do painel.");
    root = await editStore((store) => {
      if (store.activeId !== message.expectedActiveId)
        throw new Error("A conta ativa mudou durante a operação.");
      return accountCommand(store, message.command);
    });
    for (const account of root.accounts)
      if (account.data.runtime.mode !== "running")
        await chrome.alarms.clear(alarmName(account.id));
    return { ok: true };
  }
  if (message.type === "COMMAND" && isDashboard(sender)) {
    if (!message.command || typeof message.command.type !== "string")
      throw new Error("Comando inválido.");
    if (message.workspaceId !== root.activeId)
      throw new Error(
        "A conta ativa mudou. Recarregue o painel antes de executar esta ação.",
      );
    const notice = await controller(root.activeId).command(message.command);
    return { ok: true, notice };
  }
  if (
    message.type === "OPEN_DASHBOARD" &&
    sender.id === chrome.runtime.id &&
    sender.tab?.url?.startsWith("https://www.instagram.com/")
  ) {
    await chrome.tabs.create({ url: chrome.runtime.getURL("index.html") });
    return { ok: true };
  }
  const owner = root.accounts.find(
    (a) =>
      sender.tab?.id !== undefined &&
      [a.data.runtime.workerTabId, a.data.runtime.collectorTabId].includes(
        sender.tab.id,
      ),
  );
  if (owner && owner.id === root.activeId)
    return controller(owner.id).contentRoute(message, sender);
  if (message.type === "GET_COLLECTOR") return { ok: false };
  throw new Error(
    "Esta aba pertence a outra conta ou coleta. Selecione a conta correspondente e reabra a fonte.",
  );
}
chrome.runtime.onMessage.addListener((message, sender, respond) => {
  void route(message, sender)
    .then(respond)
    .catch(async (error) => {
      const diagnosticMessage = [
        "GET_PROBLEMS",
        "REPORT_PROBLEM",
        "UPDATE_PROBLEM",
        "RECOVER_PROBLEM",
      ].includes(message?.type);
      const problemId =
        isDashboard(sender) && !diagnosticMessage
          ? await recordNativeProblem({
              scope:
                message?.workspaceId || message?.expectedActiveId || APP_SCOPE,
              operation:
                message?.type === "GET_STATE"
                  ? "LOAD_STATE"
                  : message?.type === "ACCOUNT_COMMAND"
                    ? `ACCOUNT_${String(message.command?.type || "INVALID").slice(0, 60)}`
                    : message?.type === "COMMAND"
                      ? `COMMAND_${String(message.command?.type || "INVALID").slice(0, 60)}`
                      : "READ_MARKET_PAGE",
              source: "worker",
              category: message?.type === "GET_STATE" ? "storage" : undefined,
              message:
                error instanceof Error ? error.message : "Falha inesperada.",
            })
          : undefined;
      respond({
        ok: false,
        error: error instanceof Error ? error.message : "Falha inesperada.",
        problemId,
      });
    });
  return true;
});
chrome.alarms.onAlarm.addListener((alarm) => {
  if (alarm.name.startsWith("orbita-queue:"))
    void initialized.then(() =>
      controller(alarm.name.slice("orbita-queue:".length)).runQueue(),
    );
});
chrome.runtime.onStartup.addListener(() => {
  void initialized.then(async () => {
    const store = await editStore((store) => {
      for (const account of store.accounts)
        account.data = recoverInterrupted(account.data);
    });
    for (const account of store.accounts)
      await chrome.alarms.clear(alarmName(account.id));
  });
});
chrome.action.onClicked.addListener(() => {
  void chrome.tabs.create({ url: chrome.runtime.getURL("index.html") });
});
globalThis.addEventListener("unhandledrejection", (event) => {
  void recordNativeProblem({
    scope: APP_SCOPE,
    operation: "WORKER_UNHANDLED",
    source: "worker",
    message:
      event.reason instanceof Error
        ? event.reason.message
        : "Falha inesperada no serviço da extensão.",
  });
});
