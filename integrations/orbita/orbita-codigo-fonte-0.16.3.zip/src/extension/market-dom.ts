import { marketUrl } from "../core/market.ts";
import {
  detectAccount,
  exactCount,
  pageRestriction,
  usernameFromHref,
} from "./dom.ts";
import type { MarketPageReading } from "../core/types.ts";

export function readMarketPage(
  doc: Document,
  url: string,
  expectedOwn?: string,
): MarketPageReading {
  const clean = marketUrl(url, true),
    path = new URL(clean).pathname,
    blocked = pageRestriction(doc, path);
  if (blocked) throw new Error(blocked);
  const kind = /^\/reel\//.test(path)
    ? "reel"
    : /^\/p\//.test(path)
      ? "post"
      : "profile";
  if (
    expectedOwn &&
    (kind !== "profile" ||
      usernameFromHref(path) !== expectedOwn ||
      detectAccount(doc) !== expectedOwn)
  )
    throw new Error(
      "A sessão e o perfil precisam corresponder à conta selecionada.",
    );
  let scope: Element | null = doc.querySelector("main header");
  if (kind !== "profile") {
    const articles = new Set(
      [...doc.querySelectorAll<HTMLAnchorElement>("a[href]")]
        .filter((a) => {
          try {
            return (
              !!a.querySelector("time") &&
              marketUrl(new URL(a.getAttribute("href")!, clean).href, true) ===
                clean
            );
          } catch {
            return false;
          }
        })
        .map((a) => a.closest("article"))
        .filter((a): a is HTMLElement => !!a),
    );
    if (articles.size !== 1)
      throw new Error(
        "A publicação não pôde ser confirmada por um link de data único no conteúdo carregado. Registre a referência manualmente.",
      );
    scope = [...articles][0];
    if (scope.querySelector("article"))
      throw new Error(
        "A página mistura publicações; registre a referência manualmente.",
      );
  }
  if (!scope)
    throw new Error(
      "A página não mostrou um cabeçalho ou publicação reconhecível. Abra no Instagram e registre a referência manualmente.",
    );
  const rendered = (scope as HTMLElement).innerText;
  const text =
    typeof rendered === "string" ? rendered : scope.textContent || "";
  if (!text.trim())
    throw new Error("O texto da página ainda não está disponível.");
  if (
    /(?:esta conta [ée] privada|this account is private|conte[uú]do indispon[ií]vel|content unavailable)/i.test(
      text,
    )
  )
    throw new Error("O conteúdo está privado ou indisponível; não foi lido.");
  if (
    kind === "profile" &&
    ![...scope.querySelectorAll("h1,h2")].some(
      (h) => h.textContent?.trim().toLowerCase() === usernameFromHref(path),
    )
  )
    throw new Error("Não foi possível confirmar o perfil no cabeçalho.");
  const metrics: MarketPageReading["metrics"] = {};
  if (kind !== "profile") {
    const labels = {
      views: /^(\d+(?:[., \u00a0]\d{3})*)\s+(?:visualizaç[õo]es|views)$/i,
      likes: /^(\d+(?:[., \u00a0]\d{3})*)\s+(?:curtidas|likes)$/i,
      comments:
        /^(?:ver todos os |view all )?(\d+(?:[., \u00a0]\d{3})*)\s+(?:coment[áa]rios|comments)$/i,
    };
    const lines = text.split(/[\r\n]+/).map((s) => s.trim());
    for (const [key, re] of Object.entries(labels)) {
      const values = new Set(
        lines
          .map((s) => s.match(re)?.[1])
          .filter((s): s is string => !!s)
          .map((s) =>
            new Set(
              s.match(/[., \u00a0]/g)?.map((c) => (c === "\u00a0" ? " " : c)),
            ).size > 1
              ? undefined
              : exactCount(s),
          )
          .filter((n): n is number => n !== undefined),
      );
      if (values.size === 1)
        metrics[key as keyof typeof metrics] = [...values][0];
    }
  }
  const creator = kind === "profile" ? usernameFromHref(path) || "" : "";
  return {
    url: clean,
    kind,
    creator,
    text: text.slice(0, 2200),
    metrics,
    observedAt: new Date().toISOString(),
  };
}
