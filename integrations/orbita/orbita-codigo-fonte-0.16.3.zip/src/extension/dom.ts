import { normalizeUsername } from "../core/domain.ts";
import type { CandidateInput, SourceKind } from "../core/types.ts";
import { profilePhotoUrl } from "../core/photos.ts";

const avatarLabel = (image: HTMLImageElement) =>
  /profile picture|foto (?:do|de) perfil/i.test(image.alt);
function imageSource(image: HTMLImageElement): string | undefined {
  const direct =
    profilePhotoUrl(image.currentSrc) ||
    profilePhotoUrl(image.getAttribute("src"));
  if (direct) return direct;
  for (const candidate of (image.getAttribute("srcset") || "").split(
    /,\s*(?=https:\/\/)/,
  )) {
    const match = candidate.trim().match(/^(\S+)(?:\s+\d+(?:\.\d+)?[wx])?$/);
    const url = match && profilePhotoUrl(match[1]);
    if (url) return url;
  }
  return undefined;
}
function uniquePhoto(images: HTMLImageElement[]): string | undefined {
  const urls = images.map(imageSource).filter((url): url is string => !!url);
  const identities = new Set(
    urls.map((value) => {
      const url = new URL(value);
      return url.origin + url.pathname;
    }),
  );
  return identities.size === 1 ? urls[0] : undefined;
}
function imageUrl(root: Element): string | undefined {
  const images = [...root.querySelectorAll<HTMLImageElement>("img")];
  const labelled = images.filter(avatarLabel);
  return uniquePhoto(labelled.length ? labelled : images);
}
function isProfileNavigation(link: HTMLAnchorElement): boolean {
  return (
    /^(perfil|profile)$/i.test((link.textContent || "").trim()) ||
    /^(perfil|profile)$/i.test(
      (link.getAttribute("aria-label") || "").trim(),
    ) ||
    !!link.querySelector('[aria-label="Perfil"], [aria-label="Profile"]')
  );
}
export function sessionProfilePhoto(
  doc: Document,
  pathname: string,
): string | undefined {
  const account = detectAccount(doc);
  if (!account) return undefined;
  // Only the signed-in profile link or its confirmed profile header may supply this photo.
  for (const link of doc.querySelectorAll<HTMLAnchorElement>("a[href]")) {
    if (link.closest('main, article, [role="dialog"]')) continue;
    if (usernameFromHref(link.getAttribute("href") || "") !== account) continue;
    if (!isProfileNavigation(link)) continue;
    const photo = imageUrl(link);
    if (photo) return photo;
  }
  if (usernameFromHref(pathname) !== account) return undefined;
  const header = doc.querySelector("main header, article header");
  if (
    !header ||
    ![...header.querySelectorAll("h1,h2")].some(
      (h) => h.textContent?.trim().toLowerCase() === account,
    )
  )
    return undefined;
  // Require an avatar label, rather than using any picture in the header.
  return uniquePhoto(
    [...header.querySelectorAll<HTMLImageElement>("img[alt]")].filter(
      avatarLabel,
    ),
  );
}

export function exactCount(text: string): number | undefined {
  const value = text.trim().replace(/\u00a0/g, " ");
  if (!/^\d+(?:[., ]\d{3})*$/.test(value)) return undefined;
  const number = Number(value.replace(/[., ]/g, ""));
  return Number.isSafeInteger(number) && number >= 0 ? number : undefined;
}
type ProfileMetricKey = "followers" | "following" | "posts";
function compactProfileCounters(header: Element, expected: string) {
  const groups = new Map<Element, Record<ProfileMetricKey, Element>>();
  const readGroup = (group: Element) => {
    const blocked = group.closest(
      'nav, article, button, [role="button"], [role="dialog"]',
    );
    if ((blocked && header.contains(blocked)) || group.children.length !== 3)
      return;
    const nodes: Partial<Record<ProfileMetricKey, Element>> = {};
    for (const row of group.children) {
      const text = (row.textContent || "").replace(/\s+/g, " ").trim();
      const match = text.match(
        /^\d[\d., ]*(?:mil|mi|bi|[kmb])?\s+(posts|publicaç[õo]es|followers|seguidores|following|seguindo|seguidos)$/i,
      );
      if (!match) return;
      const kind: ProfileMetricKey = /posts|publicaç/i.test(match[1])
        ? "posts"
        : /followers|seguidores/i.test(match[1])
          ? "followers"
          : "following";
      if (nodes[kind]) return;
      const links = [...row.querySelectorAll<HTMLAnchorElement>("a[href]")];
      if (row.matches("a[href]")) links.unshift(row as HTMLAnchorElement);
      if (kind !== "posts" && links.length !== 1) return;
      for (const link of links) {
        const raw = (link.getAttribute("href") || "").trim();
        if (raw === "#") continue;
        let href: URL;
        try {
          href = new URL(raw, "https://www.instagram.com");
        } catch {
          return;
        }
        if (
          href.origin !== "https://www.instagram.com" ||
          (href.pathname !== `/${expected}/` &&
            href.pathname !== `/${expected}/${kind}/`)
        )
          return;
      }
      nodes[kind] = row;
    }
    if (nodes.followers && nodes.following && nodes.posts)
      return nodes as Record<ProfileMetricKey, Element>;
  };
  for (const heading of header.querySelectorAll("h1,h2")) {
    if (heading.textContent?.trim().toLowerCase() !== expected) continue;
    for (
      let root = heading.parentElement;
      root && header.contains(root);
      root = root.parentElement
    ) {
      const local = [...root.children].flatMap((group) => {
        const nodes = readGroup(group);
        return nodes ? [{ group, nodes }] : [];
      });
      if (local.length > 1) return;
      if (local.length === 1) {
        groups.set(local[0].group, local[0].nodes);
        break;
      }
      if (root === header) break;
    }
  }
  return groups.size === 1 ? [...groups.values()][0] : undefined;
}
export function readOwnProfileMetrics(
  doc: Document,
  pathname: string,
  expected: string,
) {
  if (
    detectAccount(doc) !== expected ||
    usernameFromHref(pathname) !== expected
  )
    throw new Error(
      "O perfil e a sessão não correspondem à conta selecionada.",
    );
  const header = doc.querySelector("main header, article header");
  if (
    !header ||
    ![...header.querySelectorAll("h1, h2")].some(
      (h) => h.textContent?.trim().toLowerCase() === expected,
    )
  )
    throw new Error("Não foi possível confirmar o cabeçalho do seu perfil.");
  const result: { followers?: number; following?: number; posts?: number } = {};
  const readNode = (node: Element) => {
    const exact = [...node.querySelectorAll("[title]")]
      .map((el) => exactCount(el.getAttribute("title") || ""))
      .find((n) => n !== undefined);
    if (exact !== undefined) return exact;
    const match = (node.textContent || "")
      .trim()
      .match(
        /^(\d+(?:[., \u00a0]\d{3})*)\s+(?:followers|seguidores|following|seguindo|seguidos|posts|publicaç[õo]es)\b/i,
      );
    return match ? exactCount(match[1]) : undefined;
  };
  // Current Instagram profiles use a compact DIV/SPAN group and JS links (#).
  // Bind those links to the local profile heading, never to the entire header/bio.
  const compact = compactProfileCounters(header, expected);
  if (compact)
    return {
      followers: readNode(compact.followers),
      following: readNode(compact.following),
      posts: readNode(compact.posts),
    };
  for (const link of header.querySelectorAll<HTMLAnchorElement>("a[href]")) {
    const href = new URL(
      link.getAttribute("href")!,
      "https://www.instagram.com",
    );
    if (href.origin !== "https://www.instagram.com") continue;
    if (href.pathname === `/${expected}/followers/`)
      result.followers = readNode(link);
    if (href.pathname === `/${expected}/following/`)
      result.following = readNode(link);
  }
  for (const node of header.querySelectorAll("li"))
    if (/\b(posts|publicaç[õo]es)\b/i.test(node.textContent || ""))
      result.posts = readNode(node);
  return result;
}

export function usernameFromHref(href: string): string | null {
  try {
    const url = new URL(href, "https://www.instagram.com");
    if (!["instagram.com", "www.instagram.com"].includes(url.hostname))
      return null;
    const match = url.pathname.match(/^\/([a-z0-9._]{1,30})\/?$/i);
    return match ? normalizeUsername(match[1]) : null;
  } catch {
    return null;
  }
}
export function detectAccount(doc: Document): string | null {
  // Only the application's own Profile navigation link identifies the signed-in account.
  const accounts = new Set<string>();
  for (const a of doc.querySelectorAll<HTMLAnchorElement>("a[href]")) {
    if (a.closest('main, article, [role="dialog"]')) continue;
    if (!isProfileNavigation(a)) continue;
    const user = usernameFromHref(a.getAttribute("href") || "");
    if (user) accounts.add(user);
  }
  return accounts.size === 1 ? [...accounts][0] : null;
}
export function pageRestriction(
  doc: Document,
  pathname: string,
): string | null {
  if (
    /\/(challenge|checkpoint|accounts\/login|accounts\/suspended|accounts\/disabled)\b/.test(
      pathname,
    )
  )
    return "O Instagram pediu login ou verificação. Resolva diretamente no Instagram.";
  const text = [...doc.querySelectorAll('[role="dialog"], [role="alert"]')]
    .map((el) => el.textContent)
    .join(" ")
    .toLocaleLowerCase();
  if (
    /ação bloqueada|action blocked|tente novamente mais tarde|try again later|we restrict certain activity|restringimos determinadas atividades|confirme que você é humano|confirm you.re human/.test(
      text,
    )
  )
    return "O Instagram mostrou uma restrição. A execução foi interrompida.";
  return null;
}
function modernCommentRows(doc: Document, target: string) {
  let source: RegExpMatchArray | null = null;
  try {
    const url = new URL(target, "https://www.instagram.com");
    if (url.origin === "https://www.instagram.com")
      source = url.pathname.match(/^\/(?:p|reel)\/([\w-]+)\/?$/);
  } catch {}
  if (!source) return;
  const code = source[1];
  const anchors = [
    ...doc.querySelectorAll<HTMLAnchorElement>(
      'main a[href], [role="main"] a[href], article a[href]',
    ),
  ].filter((a) => !a.closest("nav,aside"));
  const path = (anchor: HTMLAnchorElement) => {
    try {
      const url = new URL(
        anchor.getAttribute("href") || "",
        "https://www.instagram.com",
      );
      return url.origin === "https://www.instagram.com" ? url.pathname : "";
    } catch {
      return "";
    }
  };
  const hasTime = (anchor: HTMLAnchorElement) =>
    [...anchor.querySelectorAll("time[datetime]")].some((t) =>
      Number.isFinite(Date.parse(t.getAttribute("datetime") || "")),
    );
  const commentId = (anchor: HTMLAnchorElement) => {
    const match = path(anchor).match(/^\/(?:p|reel)\/([\w-]+)\/c\/(\d+)\/?$/);
    return match?.[1] === code ? match[2] : null;
  };
  const authors = new Set<string>();
  for (const anchor of anchors) {
    const match = path(anchor).match(
      /^\/([a-z0-9._]{1,30})\/(?:p|reel)\/([\w-]+)\/?$/i,
    );
    if (match?.[2] === code && hasTime(anchor)) {
      const owner = normalizeUsername(match[1]);
      if (owner) authors.add(owner);
    }
  }
  if (authors.size !== 1)
    throw new Error(
      "Não foi possível confirmar o autor desta publicação pelo link de origem. Nenhum comentário foi capturado.",
    );
  const ids = (root: Element) =>
    new Set(
      [...root.querySelectorAll<HTMLAnchorElement>("a[href]")]
        .map(commentId)
        .filter(Boolean),
    );
  const rows = new Map<HTMLAnchorElement, Element>();
  for (const permalink of anchors.filter((a) => commentId(a) && hasTime(a))) {
    const scope = permalink.closest('main,[role="main"],article');
    if (!scope) continue;
    for (
      let identity = permalink.parentElement;
      identity && scope.contains(identity);
      identity = identity.parentElement
    ) {
      if (ids(identity).size !== 1) break;
      const names = [
        ...identity.querySelectorAll<HTMLAnchorElement>("a[href]"),
      ].filter((a) => {
        const user = usernameFromHref(a.getAttribute("href") || "");
        return (
          !!user && normalizeUsername((a.textContent || "").trim()) === user
        );
      });
      const users = new Set(
        names.map((a) => usernameFromHref(a.getAttribute("href") || "")),
      );
      if (users.size > 1) break;
      if (names.length) {
        for (
          let row: Element | null = identity;
          row && scope.contains(row);
          row = row.parentElement
        ) {
          if (ids(row).size !== 1) break;
          const reply = [
            ...row.querySelectorAll('button,[role="button"]'),
          ].some((b) =>
            /^(responder|reply)$/i.test((b.textContent || "").trim()),
          );
          const like = [...row.querySelectorAll("svg[aria-label]")].some((s) =>
            /^(curtir|descurtir|like|unlike)$/i.test(
              s.getAttribute("aria-label") || "",
            ),
          );
          if (reply && like) {
            const parent = row.parentElement;
            if (
              parent &&
              scope.contains(parent) &&
              ids(parent).size === 1 &&
              parent.querySelector("a[href] img")
            )
              row = parent;
            rows.set(names[0], row);
            break;
          }
          if (row === scope) break;
        }
        break;
      }
      if (identity === scope) break;
    }
  }
  return { rows, authors };
}
export function collectLoaded(
  doc: Document,
  kind: SourceKind,
  sourceTarget: string,
  ownAccount?: string,
): { candidates: CandidateInput[]; message: string } {
  let links: HTMLAnchorElement[] = [];
  let commentRows = new Map<HTMLAnchorElement, Element>();
  let modernAuthors: Set<string> | undefined;
  if (["followers", "following", "likers"].includes(kind)) {
    const dialogs = [...doc.querySelectorAll('[role="dialog"]')];
    const sourceDialogs =
      kind === "likers"
        ? dialogs.filter((dialog) =>
            [...dialog.querySelectorAll('h1,h2,h3,[role="heading"]')].some(
              (h) =>
                h.closest('[role="dialog"]') === dialog &&
                /^(curtidas|likes)$/i.test((h.textContent || "").trim()),
            ),
          )
        : dialogs;
    if (sourceDialogs.length !== 1)
      throw new Error(
        kind === "likers"
          ? "Abra apenas a lista Curtidas da publicação e capture novamente."
          : "Abra apenas a lista de seguidores ou seguidos no Instagram e capture novamente.",
      );
    const rows = [...sourceDialogs[0].querySelectorAll("a[href]")];
    links = rows as HTMLAnchorElement[];
  } else if (kind === "commenters") {
    // Restrict to comment-list rows, never suggested accounts or the sidebar.
    const rows = [...doc.querySelectorAll("main ul li, article ul li")];
    links = rows
      .map((row) => row.querySelector<HTMLAnchorElement>("a[href]"))
      .filter((a): a is HTMLAnchorElement => !!a);
    if (!links.length) {
      const modern = modernCommentRows(doc, sourceTarget);
      if (modern) {
        commentRows = modern.rows;
        modernAuthors = modern.authors;
        links = [...commentRows.keys()];
      }
    }
    if (!links.length)
      throw new Error(
        "Nenhuma linha de comentário reconhecida. Abra os comentários da publicação e tente novamente.",
      );
  } else if (kind === "hashtag" || kind === "location") {
    links = [
      ...doc.querySelectorAll<HTMLAnchorElement>(
        "article header a[href], main article h2 a[href]",
      ),
    ];
    if (!links.length)
      throw new Error(
        "Abra uma publicação encontrada nessa fonte. A coleta lê os autores dos posts carregados, não identifica perfis pelas miniaturas.",
      );
  } else throw new Error("Essa fonte usa importação de arquivo ou texto.");
  const sourceAccount = ["followers", "following"].includes(kind)
    ? sourceTarget
        .replace(/^@/, "")
        .toLowerCase()
        .split("/")
        .filter(Boolean)
        .at(-1)
    : null;
  const candidates = new Map<string, CandidateInput>();
  const authors = new Set(
    kind === "commenters"
      ? [
          ...doc.querySelectorAll<HTMLAnchorElement>(
            "article header a[href], main header a[href]",
          ),
        ]
          .map((a) => usernameFromHref(a.getAttribute("href") || ""))
          .filter(Boolean)
      : [],
  );
  for (const author of modernAuthors || []) authors.add(author);
  for (const link of links) {
    const username = usernameFromHref(link.getAttribute("href") || "");
    if (
      !username ||
      username === ownAccount ||
      username === sourceAccount ||
      authors.has(username)
    )
      continue;
    const text = (link.textContent || "").trim();
    // Names and counts are intentionally left unknown unless independently available.
    const name =
      text && text.toLowerCase() !== username ? text.slice(0, 150) : "";
    const photoLinks =
      kind === "commenters"
        ? [
            ...((
              commentRows.get(link) || link.closest("li")
            )?.querySelectorAll<HTMLAnchorElement>("a[href]") || []),
          ].filter(
            (a) => usernameFromHref(a.getAttribute("href") || "") === username,
          )
        : [link];
    const avatarUrl = photoLinks.map(imageUrl).find(Boolean);
    if (!candidates.has(username)) candidates.set(username, { username, name });
    else if (!candidates.get(username)!.name && name)
      candidates.get(username)!.name = name;
    if (avatarUrl && !candidates.get(username)!.avatarUrl)
      candidates.get(username)!.avatarUrl = avatarUrl;
  }
  return {
    candidates: [...candidates.values()],
    message:
      "Captura parcial: apenas os perfis já carregados nesta página. Role a lista e capture novamente.",
  };
}
export type FollowResult = {
  stage: "followed" | "requested" | "already" | "uncertain" | "failed";
  message: string;
  stop?: boolean;
  platformWarning?: boolean;
};
export function profileControls(
  doc: Document,
  pathname: string,
  username: string,
): { follow?: HTMLElement; state?: "followed" | "requested"; error?: string } {
  if (usernameFromHref(pathname) !== username)
    return { error: "O perfil aberto não corresponde ao candidato da fila." };
  const header = doc.querySelector("main header, article header");
  if (!header)
    return {
      error: "Cabeçalho do perfil não reconhecido. Nenhuma ação foi enviada.",
    };
  const headings = [...header.querySelectorAll("h1, h2")].map((el) =>
    (el.textContent || "").trim().toLowerCase(),
  );
  if (!headings.includes(username))
    return {
      error: "Não foi possível confirmar a identidade do perfil no cabeçalho.",
    };
  const buttons = [
    ...header.querySelectorAll<HTMLElement>('button, [role="button"]'),
  ];
  const label = (el: HTMLElement) =>
    (el.textContent || "").trim().toLocaleLowerCase();
  if (buttons.some((b) => /^(seguindo|following)$/.test(label(b))))
    return { state: "followed" };
  if (buttons.some((b) => /^(solicitado|requested)$/.test(label(b))))
    return { state: "requested" };
  const follow = buttons.filter(
    (b) =>
      /^(seguir|follow|seguir de volta|follow back)$/.test(label(b)) &&
      !b.hasAttribute("disabled") &&
      b.getAttribute("aria-disabled") !== "true",
  );
  return follow.length === 1
    ? { follow: follow[0] }
    : {
        error:
          "Botão Seguir não reconhecido de forma única. Nenhuma ação foi enviada.",
      };
}
