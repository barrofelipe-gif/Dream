import { allowedHostedMessage, trustedHostedPage } from "../core/hosted.ts";
import { hostedSessionMatches } from "../core/hosted-session.ts";

if (trustedHostedPage(location.href)) {
  const expectedScope = document
    .querySelector('meta[name="orbita-user"]')
    ?.getAttribute("content");
  let connected = false,
    pending = 0;
  const expired = () =>
    new Error(
      "O prazo da solicitação encerrou antes da autorização. A solicitação não foi enviada à extensão.",
    );
  const session = async (expiresAt: number) => {
    if (!expectedScope || !/^[a-f0-9]{32}$/.test(expectedScope))
      throw new Error(
        "Não foi possível identificar o usuário do painel. Entre novamente no app.",
      );
    const controller = new AbortController();
    let timer: ReturnType<typeof setTimeout> | undefined;
    const deadline = new Promise<never>((_resolve, reject) => {
      timer = setTimeout(
        () => {
          reject(expired());
          controller.abort();
        },
        Math.max(0, expiresAt - Date.now()),
      );
    });
    try {
      await Promise.race([
        (async () => {
          const response = await fetch("/api/growth/orbita/session", {
            credentials: "same-origin",
            cache: "no-store",
            redirect: "error",
            signal: controller.signal,
          });
          if (!response.ok)
            throw new Error(
              "Entre novamente no app com um usuário administrador para conectar a extensão.",
            );
          const data = await response.json();
          if (data?.ready !== true)
            throw new Error("A sessão do app não está disponível.");
          if (!hostedSessionMatches(data, expectedScope))
            throw new Error(
              "O usuário da sessão do app mudou. Reabra o painel antes de conectar ou executar uma operação.",
            );
        })(),
        deadline,
      ]);
    } finally {
      if (timer !== undefined) clearTimeout(timer);
    }
  };
  window.addEventListener("message", async (event) => {
    const request = event.data;
    if (
      event.source !== window ||
      event.origin !== location.origin ||
      request?.channel !== "orbita-extension-request" ||
      typeof request.id !== "string" ||
      request.id.length > 80
    )
      return;
    if (pending >= 30) {
      window.postMessage(
        {
          channel: "orbita-extension-response",
          id: request.id,
          transportError:
            "O conector está ocupado. Esta solicitação não foi enviada à extensão. Aguarde as operações pendentes e confira seus resultados antes de tentar novamente.",
        },
        location.origin,
      );
      return;
    }
    if (
      request.message?.type !== "HOSTED_CONNECT" &&
      (!connected || !allowedHostedMessage(request.message))
    )
      return;
    pending++;
    try {
      const budget = request.message?.type === "HOSTED_CONNECT" ? 6000 : 45000;
      const expiresAt =
        typeof request.expiresAt === "number" &&
        Number.isFinite(request.expiresAt)
          ? Math.min(request.expiresAt, Date.now() + budget)
          : Date.now() + budget;
      if (expiresAt <= Date.now()) throw expired();
      await session(expiresAt);
      // Authorization is read-only. Never start a mutation whose sender has
      // already timed out while waiting for that authorization.
      if (expiresAt <= Date.now()) throw expired();
      let result;
      if (request.message.type === "HOSTED_CONNECT") {
        // Only establishes transport. Never starts a queue or changes an account.
        result = await chrome.runtime.sendMessage({ type: "HOSTED_CONNECT" });
        connected = result?.ok === true;
      } else result = await chrome.runtime.sendMessage(request.message);
      window.postMessage(
        { channel: "orbita-extension-response", id: request.id, result },
        location.origin,
      );
      if (
        result?.ok &&
        [
          "COMMAND",
          "ACCOUNT_COMMAND",
          "REPORT_PROBLEM",
          "UPDATE_PROBLEM",
          "RECOVER_PROBLEM",
        ].includes(request.message.type)
      ) {
        const keys = request.message.type.endsWith("PROBLEM")
          ? ["orbita-problems-v1"]
          : ["orbita-accounts-v2", "orbita-problems-v1"];
        window.postMessage(
          { channel: "orbita-extension-changed", keys },
          location.origin,
        );
      }
    } catch (error) {
      window.postMessage(
        {
          channel: "orbita-extension-response",
          id: request.id,
          transportError:
            error instanceof Error ? error.message : "Conexão indisponível.",
        },
        location.origin,
      );
    } finally {
      pending--;
    }
  });
}
