import {
  PROBLEMS_KEY,
  problemText,
  recordProblem,
  recoverProblem,
  updateProblem,
  validateProblems,
} from "../core/problems.ts";
import type {
  ProblemInput,
  ProblemStatus,
  ProblemStore,
} from "../core/problems.ts";
let transaction: Promise<unknown> = Promise.resolve();
let failure = "";
export const problemStoreFailure = () => failure;
export const readProblems = async () => {
  await transaction;
  const saved = await chrome.storage.local.get(PROBLEMS_KEY);
  return validateProblems(saved[PROBLEMS_KEY]);
};
function edit(fn: (store: ProblemStore) => ProblemStore) {
  const next = transaction.then(async () => {
    const saved = await chrome.storage.local.get(PROBLEMS_KEY),
      result = fn(validateProblems(saved[PROBLEMS_KEY]));
    await chrome.storage.local.set({ [PROBLEMS_KEY]: result });
    return result;
  });
  transaction = next.catch(() => {});
  return next;
}
export async function recordNativeProblem(
  input: ProblemInput,
): Promise<string | undefined> {
  try {
    let id: string | undefined;
    await edit((s) => {
      const result = recordProblem(s, input);
      id = result.id;
      return result.store;
    });
    failure = "";
    return id;
  } catch (cause) {
    failure = problemText(cause);
    return undefined;
  }
}
export async function changeNativeProblem(
  scope: string,
  id: string,
  status: ProblemStatus,
  note: string,
) {
  await edit((s) => updateProblem(s, scope, id, status, note));
}
export async function recoverNativeProblem(scope: string, id: string) {
  await edit((s) => recoverProblem(s, scope, id));
}
