import {
  ACCOUNT_STORE_KEY,
  migrateStore,
  workspace,
} from "../core/accounts.ts";
import {
  STORAGE_KEY,
  recoverInterrupted,
  validateSettings,
} from "../core/domain.ts";
import type { AccountStore } from "../core/types.ts";

let transaction: Promise<unknown> = Promise.resolve();
export const alarmName = (id: string) => `orbita-queue:${id}`;
export async function readStore(): Promise<AccountStore> {
  const saved = await chrome.storage.local.get([
    ACCOUNT_STORE_KEY,
    STORAGE_KEY,
  ]);
  return migrateStore(saved[ACCOUNT_STORE_KEY], saved[STORAGE_KEY]);
}
export async function settledStore() {
  await transaction;
}
export function editStore(
  fn: (store: AccountStore) => AccountStore | void,
): Promise<AccountStore> {
  const next = transaction.then(async () => {
    const store = await readStore();
    const result = fn(store) || store;
    await chrome.storage.local.set({ [ACCOUNT_STORE_KEY]: result });
    return result;
  });
  transaction = next.catch(() => {});
  return next;
}
export const storeReady = (async () => {
  await chrome.storage.local.setAccessLevel({
    accessLevel: "TRUSTED_CONTEXTS",
  });
  const store = await readStore();
  for (const account of store.accounts) {
    if (account.data.candidates.some((c) => c.stage === "attempting"))
      account.data = recoverInterrupted(account.data);
    if (account.data.settings.sessionLimit === undefined) {
      account.data.settings = validateSettings(account.data.settings);
      account.data = recoverInterrupted(account.data);
    }
    account.data.runtime.account = account.username;
    if (
      account.id !== store.activeId &&
      account.data.runtime.mode === "running"
    )
      account.data = recoverInterrupted(account.data);
  }
  await chrome.storage.local.set({ [ACCOUNT_STORE_KEY]: store });
  await chrome.alarms.clear("orbita-queue");
  const active = workspace(store);
  if (
    active.data.runtime.mode === "running" &&
    !(await chrome.alarms.get(alarmName(active.id)))
  )
    await chrome.alarms.create(alarmName(active.id), {
      when: Math.max(Date.now() + 1000, active.data.runtime.nextRun || 0),
    });
})();
