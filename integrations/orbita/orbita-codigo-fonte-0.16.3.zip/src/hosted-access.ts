import { trustedHostedPage } from "./core/hosted.ts";
import { hostedSessionMatches } from "./core/hosted-session.ts";

export async function verifyHostedActor(signal?: AbortSignal): Promise<void> {
  if (typeof location === "undefined" || !trustedHostedPage(location.href))
    return;
  const scope = document
    .querySelector('meta[name="orbita-user"]')
    ?.getAttribute("content");
  const deadline = AbortSignal.timeout(10000);
  const requestSignal = signal ? AbortSignal.any([signal, deadline]) : deadline;
  try {
    const response = await fetch("/api/growth/orbita/session", {
      credentials: "same-origin",
      cache: "no-store",
      redirect: "manual",
      signal: requestSignal,
    });
    if (
      !response.ok ||
      response.type === "opaqueredirect" ||
      !hostedSessionMatches(await response.json(), scope)
    )
      throw new Error(
        "O usuário do app mudou ou a sessão expirou. Reabra a Órbita antes de salvar dados.",
      );
    if (requestSignal.aborted)
      throw new Error("Operação cancelada antes de salvar dados.");
  } catch (error) {
    if (!signal?.aborted)
      window.dispatchEvent(
        new CustomEvent("orbita-transport-error", {
          detail: "Sessão do app indisponível.",
        }),
      );
    throw error;
  }
}
