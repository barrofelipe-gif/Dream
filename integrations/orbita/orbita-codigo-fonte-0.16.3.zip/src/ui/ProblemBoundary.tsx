import { Component } from "react";
import type { ErrorInfo, ReactNode } from "react";
import { APP_SCOPE, problemText } from "../core/problems.ts";
import { reportProblem, useProblems } from "../problems-client.ts";
import { ProblemsPage } from "./Problems.tsx";
import { initialStore, workspace } from "../core/accounts.ts";

export class ProblemBoundary extends Component<
  { children: ReactNode },
  { error: string | null }
> {
  state: { error: string | null } = { error: null };
  static getDerivedStateFromError(error: unknown) {
    return { error: problemText(error) };
  }
  componentDidCatch(error: Error, _info: ErrorInfo) {
    void reportProblem(error, {
      scope: APP_SCOPE,
      operation: "UI_RENDER",
      source: "runtime",
      category: "interface",
    });
  }
  render() {
    return this.state.error ? (
      <BoundaryFallback message={this.state.error} />
    ) : (
      this.props.children
    );
  }
}
function BoundaryFallback({ message }: { message: string }) {
  const snapshot = useProblems(),
    account = {
      ...workspace(initialStore()),
      id: APP_SCOPE,
      label: "Painel geral",
    };
  return (
    <main className="problem-fallback" data-problem-capture="skip">
      <h1>O painel encontrou uma falha.</h1>
      <p>
        O diagnóstico fica disponível abaixo. Reabra o painel para tentar
        carregar novamente.
      </p>
      <p className="notice error" role="alert">
        {message}
      </p>
      <button
        className="button primary"
        onClick={() => window.location.reload()}
      >
        Reabrir painel
      </button>
      <ProblemsPage account={account} snapshot={snapshot} />
    </main>
  );
}
