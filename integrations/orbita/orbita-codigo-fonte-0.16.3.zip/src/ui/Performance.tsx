import {
  CircleCheck,
  CircleHelp,
  TrendingDown,
  TrendingUp,
} from "lucide-react";
import { performanceReview, recoveryTest } from "../core/performance.ts";
import type { PerformanceComparison } from "../core/performance.ts";
import type { InsightReport } from "../core/types.ts";

const decimal = (n: number) =>
  new Intl.NumberFormat("pt-BR", { maximumFractionDigits: 2 }).format(n);
const amount = (n: number) =>
  n !== 0 && Math.abs(n) < 0.01 ? `${n < 0 ? "−" : ""}<0,01` : decimal(n);
const signed = (n: number) => `${n > 0 ? "+" : ""}${amount(n)}`;
const period = (r: InsightReport) =>
  `${r.start.split("-").reverse().join("/")} a ${r.end.split("-").reverse().join("/")}`;
function reading(n: number, unit: PerformanceComparison["unit"]) {
  return `${amount(n)}${unit === "percent" ? "%" : unit === "seconds" ? " s" : ""}`;
}
export function PerformanceAlerts({
  report,
  reports,
  onExplore,
  onContent,
}: {
  report: InsightReport;
  reports: InsightReport[];
  onExplore: () => void;
  onContent: () => void;
}) {
  const review = performanceReview(report, reports);
  return (
    <section className="performance-review" aria-label="Alertas de desempenho">
      <div className="performance-heading">
        <div>
          <span className="eyebrow">ACOMPANHAR E AJUSTAR</span>
          <h3>O que precisa de atenção</h3>
        </div>
        {review.status === "ready" ? (
          <span
            className={`performance-count ${review.alerts.length ? "attention" : ""}`}
          >
            {review.alerts.length
              ? `${review.alerts.length} ${review.alerts.length === 1 ? "sinal de piora" : "sinais de piora"}`
              : review.comparisons.length
                ? "Sem piora observada"
                : "Sem base de métricas"}
          </span>
        ) : null}
      </div>
      {review.status === "waiting" ? (
        <div className="performance-empty">
          <CircleHelp size={20} />
          <p>
            <strong>Comparação ainda indisponível</strong>
            {review.reason}
          </p>
        </div>
      ) : (
        <>
          <p className="performance-period">
            Atual: <strong>{period(report)}</strong> · Anterior:{" "}
            <strong>{period(review.previous!)}</strong>
          </p>
          <p className="performance-rule">
            Destacamos toda piora, inclusive pequena. Uma oscilação isolada não
            explica a causa. Confirme se os relatórios estão completos e medem
            as mesmas coisas.
          </p>
          {review.alerts.length ? (
            <div className="performance-grid">
              {review.alerts.map((c) => {
                const plan = recoveryTest(c.key);
                return (
                  <article
                    className="performance-card"
                    key={c.key}
                    aria-label={`Alerta: ${c.label}`}
                  >
                    <div className="performance-card-top">
                      <span>
                        {c.difference < 0 ? (
                          <TrendingDown size={18} />
                        ) : (
                          <TrendingUp size={18} />
                        )}
                        {c.difference < 0 ? "Em queda" : "Em alta"}
                      </span>
                      <span>Investigar</span>
                    </div>
                    <h4>{c.label}</h4>
                    <strong className="performance-delta">
                      {c.unit === "percent"
                        ? `${signed(c.difference)} p.p.`
                        : c.relative === undefined
                          ? `${signed(c.difference)}${c.unit === "seconds" ? " s" : ""}`
                          : `${signed(c.relative)}%`}
                    </strong>
                    <p className="performance-values">
                      {reading(c.before, c.unit)}{" "}
                      <span aria-label="para">→</span>{" "}
                      {reading(c.current, c.unit)}
                      {c.unit !== "percent" && c.relative !== undefined ? (
                        <small>
                          Diferença: {signed(c.difference)}
                          {c.unit === "seconds" ? " s" : ""}
                        </small>
                      ) : null}
                      {c.before === 0 ? (
                        <small>Base zero: sem variação percentual.</small>
                      ) : null}
                    </p>
                    {c.key === "engagement_rate" ? (
                      <p className="performance-definition">
                        Interações ÷ alcance × 100. Pode superar 100%; não
                        representa pessoas únicas.
                      </p>
                    ) : null}
                    <details>
                      <summary>O que verificar e testar</summary>
                      <div>
                        <strong>Verifique</strong>
                        <p>{plan.investigate}</p>
                        <strong>Próximo teste</strong>
                        <p>{plan.test}</p>
                        <p className="performance-target">
                          Referência para acompanhar:{" "}
                          {reading(c.before, c.unit)} no período anterior.
                          Recuperação não é garantida; mantenha a medição
                          comparável.
                        </p>
                      </div>
                    </details>
                  </article>
                );
              })}
            </div>
          ) : (
            <div className="performance-empty">
              <CircleCheck size={21} />
              <p>
                <strong>
                  {review.comparisons.length
                    ? `Nenhuma piora nas ${review.comparisons.length} métricas comparáveis`
                    : "Nenhuma métrica comparável disponível"}
                </strong>
                {review.comparisons.length
                  ? "Valores estáveis ou favoráveis neste recorte. Continue acompanhando o próximo ciclo; dados ausentes não foram considerados melhora."
                  : "Registre as mesmas métricas nos dois períodos. Um campo ausente não é zero."}
              </p>
            </div>
          )}
          {review.observations.length ? (
            <div className="performance-context">
              <h4>O que os números mostram</h4>
              <ul>
                {review.observations.map((text) => (
                  <li key={text}>{text}</li>
                ))}
              </ul>
              <p>
                São observações, não causas comprovadas. Os dados não permitem
                concluir bloqueio ou mudança do algoritmo.
              </p>
            </div>
          ) : null}
          <div className="performance-actions">
            <button className="button secondary" onClick={onContent}>
              Ver publicações do período
            </button>
            <button className="text-link" onClick={onExplore}>
              Abrir Aprendizados →
            </button>
            <span>Reavalie no próximo período de mesma duração.</span>
          </div>
          <details className="performance-coverage">
            <summary>
              {review.comparisons.length} métricas comparadas ·{" "}
              {review.missing.length} sem dados comparáveis
            </summary>
            <p>
              Comparadas:{" "}
              {review.comparisons.map((c) => c.label).join(", ") || "nenhuma"}.
            </p>
            <p>
              Sem dados nos dois períodos:{" "}
              {review.missing.join(", ") || "nenhuma"}.
            </p>
            <p>
              Quantidade publicada e navegação bruta dos Stories têm direção
              ambígua e servem de contexto. Outras métricas do arquivo continuam
              em Todas as métricas.
            </p>
          </details>
        </>
      )}
    </section>
  );
}
