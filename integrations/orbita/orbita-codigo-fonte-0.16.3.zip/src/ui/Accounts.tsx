import { useState } from "react";
import {
  ArrowRight,
  Camera,
  Check,
  Clock3,
  Download,
  Link2,
  Minus,
  Plus,
  RefreshCw,
  ShieldCheck,
  TrendingDown,
  TrendingUp,
  UsersRound,
} from "lucide-react";
import type {
  AccountCommand,
  AccountType,
  AccountStore,
  AccountWorkspace,
  Command,
  SpecialCommand,
} from "../core/types.ts";
import { profileMetrics } from "../core/metrics.ts";
import {
  ACCOUNT_TYPE_LABELS,
  accountTypeGuide,
} from "../core/account-types.ts";
import { InsightsDashboard } from "./Insights.tsx";
import { download } from "../core/io.ts";
import { isExtension } from "../bridge.ts";
import { Avatar, date, Empty, Field, Modal, number } from "./components.tsx";

type Run = (
  command: Command | SpecialCommand,
  success?: string,
) => Promise<boolean>;
export type RunAccount = (
  command: AccountCommand,
  success?: string,
) => Promise<boolean>;
function AccountTypeSelect({
  account,
  run,
  busy,
}: {
  account: AccountWorkspace;
  run: RunAccount;
  busy: boolean;
}) {
  return (
    <label className="account-type-select">
      <span>Tipo no Instagram · informado</span>
      <select
        aria-label={`Tipo de conta de @${account.username || "perfil"}`}
        disabled={busy || !account.username}
        value={account.accountType || "unknown"}
        onChange={(e) =>
          void run(
            {
              type: "SET_ACCOUNT_TYPE",
              id: account.id,
              accountType: e.target.value as AccountType,
            },
            "Tipo informado salvo nesta conta.",
          )
        }
      >
        {Object.entries(ACCOUNT_TYPE_LABELS).map(([key, label]) => (
          <option key={key} value={key}>
            {label}
          </option>
        ))}
      </select>
    </label>
  );
}
export function AccountSelector({
  store,
  run,
  onManage,
}: {
  store: AccountStore;
  run: RunAccount;
  onManage: () => void;
}) {
  const selected = store.accounts.find((a) => a.id === store.activeId);
  return (
    <div className="account-switcher">
      <label>
        <span className="sr-only">Conta selecionada</span>
        {selected?.username ? (
          <Avatar
            username={selected.username}
            name={selected.label}
            src={selected.avatarUrl || ""}
          />
        ) : (
          <Camera size={16} />
        )}
        <select
          aria-label="Conta selecionada"
          value={store.activeId}
          onChange={(e) =>
            void run({ type: "SELECT_ACCOUNT", id: e.target.value })
          }
        >
          {store.accounts.map((a) => (
            <option key={a.id} value={a.id}>
              {a.username
                ? a.label === a.username
                  ? `@${a.username}`
                  : `${a.label} · @${a.username}`
                : a.label}
            </option>
          ))}
        </select>
      </label>
      <button
        className="icon-button"
        aria-label="Gerenciar contas"
        onClick={onManage}
      >
        <UsersRound size={18} />
      </button>
    </div>
  );
}
export function AccountSession({
  store,
  account,
  run,
  busy,
}: {
  store: AccountStore;
  account: AccountWorkspace;
  run: Run;
  busy: boolean;
}) {
  const mismatch = !!(
    account.username &&
    store.sessionUsername &&
    store.sessionUsername !== account.username
  );
  return (
    <section className={`account-session ${mismatch ? "mismatch" : ""}`}>
      <span className="connection-mark">
        <Camera size={19} />
      </span>
      <div>
        <strong>
          {account.username
            ? `Espaço de @${account.username}`
            : "Seu primeiro espaço de conta"}
        </strong>
        <p>
          {!isExtension
            ? "Prévia local: cadastre contas e explore os dashboards. A conexão com o Instagram funciona na extensão."
            : mismatch
              ? `A última sessão identificada foi @${store.sessionUsername}. Troque para @${account.username} no Instagram e conecte novamente antes de executar.`
              : account.verifiedAt
                ? `Última verificação: ${date(account.verifiedAt)}. Cada execução confere novamente a conta da sessão.`
                : "Cadastro pronto. Entre na conta correspondente no Instagram e verifique a sessão aqui."}
        </p>
      </div>
      <button
        className="button secondary"
        disabled={busy}
        onClick={() =>
          void run({ type: "CONNECT" }, "Sessão da conta identificada.")
        }
      >
        <Link2 size={15} />
        {account.verifiedAt ? "Verificar sessão" : "Conectar sessão"}
      </button>
    </section>
  );
}
export function AccountsPage({
  store,
  run,
  busy,
  onAdd,
  onOpen,
}: {
  store: AccountStore;
  run: RunAccount;
  busy: boolean;
  onAdd: () => void;
  onOpen: () => void;
}) {
  const registered = store.accounts.filter((a) => a.username).length;
  return (
    <>
      <div className="accounts-intro">
        <div>
          <strong>
            {registered}{" "}
            {registered === 1 ? "conta cadastrada" : "contas cadastradas"}
          </strong>
          <p>
            Cada conta tem suas campanhas, público, fila, limites e medições. A
            troca no painel pausa a execução anterior.
          </p>
        </div>
        <button className="button primary" onClick={onAdd}>
          <Plus size={16} />
          Adicionar conta
        </button>
      </div>
      <div className="account-cards">
        {store.accounts.map((a) => {
          const followers = a.snapshots.findLast(
            (s) => s.followers !== undefined,
          )?.followers;
          return (
            <section
              className={`panel account-card ${a.id === store.activeId ? "selected" : ""}`}
              key={a.id}
            >
              <div className="account-card-head">
                <Avatar
                  username={a.username || "local"}
                  name={a.label}
                  src={a.avatarUrl || ""}
                  large
                />
                <span
                  className={`account-status ${a.id === store.activeId ? "active" : ""}`}
                >
                  {a.id === store.activeId ? "Selecionada" : "Espaço separado"}
                </span>
              </div>
              <h2>{a.label}</h2>
              <p className="account-handle">
                {a.username
                  ? `@${a.username}`
                  : "Ainda não vinculada ao Instagram"}
              </p>
              {!a.avatarUrl ? (
                <p className="account-photo-hint">
                  A foto aparece quando estiver disponível na conexão com o
                  Instagram.
                </p>
              ) : null}
              <AccountTypeSelect account={a} run={run} busy={busy} />
              <div className="account-card-stats">
                <div>
                  <strong>{number(followers)}</strong>
                  <span>seguidores</span>
                </div>
                <div>
                  <strong>
                    {a.data.campaigns.filter((c) => !c.archived).length}
                  </strong>
                  <span>campanhas</span>
                </div>
                <div>
                  <strong>{a.data.candidates.length}</strong>
                  <span>perfis salvos</span>
                </div>
              </div>
              <div className="account-card-info">
                <Clock3 size={14} />
                {a.verifiedAt
                  ? `Verificada em ${date(a.verifiedAt)}`
                  : "Sessão ainda não verificada"}
              </div>
              {a.data.settings.hasPendingWarning ? (
                <div className="account-warning">
                  <ShieldCheck size={14} />
                  Aviso pendente nesta conta
                </div>
              ) : null}
              <button
                className="button secondary full"
                onClick={async () => {
                  if (await run({ type: "SELECT_ACCOUNT", id: a.id })) onOpen();
                }}
              >
                Abrir dashboard <ArrowRight size={15} />
              </button>
            </section>
          );
        })}
      </div>
      <div className="hint">
        <ShieldCheck size={17} />
        <span>
          Você cadastra várias contas no mesmo painel. A execução acontece em
          uma conta por vez, usando a conta ativa no Instagram deste navegador.
          Adicionar uma conta não transfere a senha nem cria uma sessão de login
          independente.
        </span>
      </div>
    </>
  );
}
export function AddAccountModal({
  run,
  busy,
  onClose,
}: {
  run: RunAccount;
  busy: boolean;
  onClose: () => void;
}) {
  const [username, setUsername] = useState(""),
    [label, setLabel] = useState(""),
    [accountType, setAccountType] = useState<AccountType>("unknown");
  return (
    <Modal
      title="Adicionar conta do Instagram"
      subtitle="Crie um espaço separado para esta conta."
      onClose={onClose}
    >
      <form
        onSubmit={async (e) => {
          e.preventDefault();
          if (await run({ type: "ADD_ACCOUNT", username, label, accountType }))
            onClose();
        }}
      >
        <Field label="@perfil que você gerencia">
          <input
            autoFocus
            required
            value={username}
            onChange={(e) => setUsername(e.target.value)}
            placeholder="@minha.marca"
            maxLength={31}
          />
        </Field>
        <Field
          label="Nome para identificar no painel"
          hint="Opcional. Ex.: Loja principal, Marca pessoal, Cliente A."
        >
          <input
            value={label}
            onChange={(e) => setLabel(e.target.value)}
            placeholder="Minha marca"
            maxLength={100}
          />
        </Field>
        <Field
          label="Tipo de conta no Instagram"
          hint="Informe o tipo que já está configurado no Instagram. Você pode ajustar esta informação depois."
        >
          <select
            value={accountType}
            onChange={(e) => setAccountType(e.target.value as AccountType)}
          >
            {Object.entries(ACCOUNT_TYPE_LABELS).map(([key, label]) => (
              <option key={key} value={key}>
                {label}
              </option>
            ))}
          </select>
        </Field>
        <div className="hint">
          <ShieldCheck size={17} />
          <span>
            O cadastro guarda o nome da conta. Para conectar, entre nela pelo
            próprio Instagram e clique em Conectar sessão. Nenhuma senha é
            solicitada aqui. A foto disponível é lida nessa conexão; cadastrar
            só o @ ainda pode mostrar as iniciais.
          </span>
        </div>
        <div className="modal-actions">
          <button type="button" className="button secondary" onClick={onClose}>
            Cancelar
          </button>
          <button className="button primary" disabled={busy}>
            <Plus size={16} />
            Criar espaço da conta
          </button>
        </div>
      </form>
    </Modal>
  );
}
export function SnapshotModal({
  account,
  run,
  busy,
  onClose,
}: {
  account: AccountWorkspace;
  run: RunAccount;
  busy: boolean;
  onClose: () => void;
}) {
  const today = new Date();
  const todayText = `${today.getFullYear()}-${String(today.getMonth() + 1).padStart(2, "0")}-${String(today.getDate()).padStart(2, "0")}`;
  const [values, setValues] = useState({
    followers: "",
    following: "",
    posts: "",
    day: todayText,
  });
  return (
    <Modal
      title={`Medição manual · @${account.username || "conta"}`}
      subtitle="Registre os contadores observados no seu perfil. Eles serão identificados como manuais."
      onClose={onClose}
    >
      <form
        onSubmit={async (e) => {
          e.preventDefault();
          const optional = (value: string) =>
            value === "" ? undefined : Number(value);
          if (
            await run(
              {
                type: "RECORD_SNAPSHOT",
                followers: optional(values.followers),
                following: optional(values.following),
                posts: optional(values.posts),
                at:
                  values.day === todayText
                    ? new Date().toISOString()
                    : new Date(`${values.day}T12:00:00`).toISOString(),
              },
              "Medição manual salva nesta conta.",
            )
          )
            onClose();
        }}
      >
        <div className="form-grid">
          {(["followers", "following", "posts"] as const).map((key) => (
            <Field
              label={
                {
                  followers: "Seguidores",
                  following: "Seguindo",
                  posts: "Publicações",
                }[key]
              }
              key={key}
            >
              <input
                type="number"
                min="0"
                step="1"
                placeholder="Não informado"
                value={values[key]}
                onChange={(e) =>
                  setValues({ ...values, [key]: e.target.value })
                }
              />
            </Field>
          ))}
          <Field label="Data da medição">
            <input
              type="date"
              required
              max={todayText}
              value={values.day}
              onChange={(e) => setValues({ ...values, day: e.target.value })}
            />
          </Field>
        </div>
        <div className="modal-actions">
          <button type="button" className="button secondary" onClick={onClose}>
            Cancelar
          </button>
          <button className="button primary" disabled={busy}>
            <Check size={16} />
            Salvar medição manual
          </button>
        </div>
      </form>
    </Modal>
  );
}
export function AccountDashboard({
  account,
  run,
  runAccount,
  busy,
  onManual,
  onMarket,
}: {
  account: AccountWorkspace;
  run: Run;
  runAccount: RunAccount;
  busy: boolean;
  onManual: () => void;
  onMarket: () => void;
}) {
  const [period, setPeriod] = useState(7);
  const metrics = profileMetrics(account, period);
  const type = accountTypeGuide(account.accountType);
  return (
    <section className="account-dashboard">
      <div className="metrics-heading">
        <div className="account-profile-heading">
          {account.username ? (
            <Avatar
              username={account.username}
              name={account.label}
              src={account.avatarUrl || ""}
              large
            />
          ) : null}
          <div>
            <span className="eyebrow">DASHBOARD DA CONTA</span>
            <h2>
              {account.username
                ? `@${account.username}`
                : "Seu perfil no Instagram"}
            </h2>
            <p>
              Contadores do perfil e atividade da Órbita, com origens separadas.
            </p>
          </div>
        </div>
        <div className="metrics-actions">
          <select
            aria-label="Período das medições do perfil e atividade da Órbita"
            title="Este período controla as medições do perfil e a atividade da Órbita. Insights usa o relatório selecionado abaixo."
            value={period}
            onChange={(e) => setPeriod(Number(e.target.value))}
          >
            <option value={7}>Últimos 7 dias</option>
            <option value={30}>Últimos 30 dias</option>
          </select>
          <button
            className="button secondary"
            onClick={onManual}
            disabled={!account.username}
          >
            <Plus size={15} />
            Medição manual
          </button>
          <button
            className="button primary"
            disabled={busy || !account.username}
            onClick={() =>
              void run(
                { type: "REFRESH_METRICS" },
                "Métricas lidas no perfil desta conta.",
              )
            }
          >
            <RefreshCw size={15} />
            Atualizar métricas
          </button>
        </div>
      </div>
      <section
        className="account-type-guide"
        aria-label="Tipo e disponibilidade desta conta"
      >
        <div>
          <strong>{type.label}</strong>
          <span>Tipo informado manualmente</span>
          <p>{type.guidance}</p>
        </div>
        <AccountTypeSelect account={account} run={runAccount} busy={busy} />
      </section>
      <div className="profile-metric-grid">
        {(["followers", "following", "posts"] as const).map((key) => (
          <div className={`profile-metric-card profile-${key}`} key={key}>
            <span>
              <span>
                {
                  {
                    followers: "Seguidores do perfil",
                    following: "Contas que segue",
                    posts: "Publicações",
                  }[key]
                }
              </span>
              <span className="profile-metric-symbol" aria-hidden="true">
                {key === "followers" ? (
                  <UsersRound size={19} />
                ) : key === "following" ? (
                  <Link2 size={19} />
                ) : (
                  <Camera size={19} />
                )}
              </span>
            </span>
            <strong>{number(metrics[key].value)}</strong>
            <small>
              {metrics[key].snapshot
                ? `${metrics[key].snapshot!.source === "manual" ? "Medição manual" : "Leitura no Instagram"} · ${date(metrics[key].snapshot!.at)}`
                : "Sem medição. Nenhum valor estimado."}
            </small>
          </div>
        ))}
        <div
          className="profile-metric-card growth"
          data-trend={
            metrics.growth !== undefined && metrics.growth < 0
              ? "negative"
              : "other"
          }
        >
          <span>
            <span>Variação de seguidores · {period} dias</span>
            <span className="profile-metric-symbol" aria-hidden="true">
              {metrics.growth === undefined || metrics.growth === 0 ? (
                <Minus size={19} />
              ) : metrics.growth < 0 ? (
                <TrendingDown size={19} />
              ) : (
                <TrendingUp size={19} />
              )}
            </span>
          </span>
          <strong>
            {metrics.growth === undefined
              ? "—"
              : `${metrics.growth > 0 ? "+" : ""}${number(metrics.growth)}`}
          </strong>
          <small>
            {metrics.growth === undefined
              ? "Registre duas medições para comparar."
              : `${date(metrics.growthFrom!)} → ${date(metrics.growthTo!)}. Não prova efeito das ações.`}
          </small>
        </div>
      </div>
      <InsightsDashboard
        account={account}
        run={runAccount}
        busy={busy}
        onMarket={onMarket}
      />
      <div className="metrics-chart-grid">
        <section className="panel metric-chart">
          <div className="panel-heading">
            <div>
              <h2>
                <TrendingUp size={18} />
                Seguidores ao longo do tempo
              </h2>
              <p>{account.snapshots.length} medições salvas nesta conta.</p>
            </div>
            <button
              className="icon-button"
              aria-label="Exportar medições desta conta"
              onClick={() =>
                download(
                  `orbita-${account.username || "conta"}-metricas.json`,
                  JSON.stringify(
                    { account: account.username, snapshots: account.snapshots },
                    null,
                    2,
                  ),
                  "application/json",
                )
              }
            >
              <Download size={16} />
            </button>
          </div>
          <FollowerChart measurements={metrics.history} />
        </section>
        <section className="panel metric-chart">
          <div className="panel-heading">
            <div>
              <h2>
                <Link2 size={18} />
                Atividade da Órbita
              </h2>
              <p>Tentativas por dia · somente desta conta.</p>
            </div>
          </div>
          <div className="activity-totals">
            <div>
              <strong>{metrics.attempts}</strong>
              <span>tentativas</span>
            </div>
            <div>
              <strong>{metrics.confirmed}</strong>
              <span>Seguindo confirmado</span>
            </div>
            <div>
              <strong>{metrics.requested}</strong>
              <span>solicitações enviadas</span>
            </div>
          </div>
          <div
            className="daily-chart"
            aria-label={`Histórico de ${metrics.attempts} tentativas no período`}
          >
            {metrics.trend.map((day) => (
              <div
                className="daily-column"
                key={day.day}
                title={`${day.label}: ${day.attempts} tentativas, ${day.confirmed} confirmações`}
              >
                <span className="daily-bar-track">
                  <span
                    style={{
                      height: `${day.attempts ? Math.max(4, (day.attempts / Math.max(1, ...metrics.trend.map((d) => d.attempts))) * 100) : 0}%`,
                    }}
                  />
                </span>
                <small>
                  {period === 7 || metrics.trend.indexOf(day) % 5 === 0
                    ? day.label.slice(0, 2)
                    : ""}
                </small>
              </div>
            ))}
          </div>
          <p className="metrics-footnote">
            Confirmações e solicitações vêm dos eventos salvos; não representam
            pessoas que passaram a seguir você.
          </p>
        </section>
      </div>
      {account.snapshots.length ? (
        <details className="panel metric-history">
          <summary>Histórico e origem das medições</summary>
          <div className="table-scroll">
            <table>
              <thead>
                <tr>
                  <th>DATA</th>
                  <th>SEGUIDORES</th>
                  <th>SEGUINDO</th>
                  <th>PUBLICAÇÕES</th>
                  <th>ORIGEM</th>
                </tr>
              </thead>
              <tbody>
                {[...account.snapshots]
                  .reverse()
                  .slice(0, 30)
                  .map((s) => (
                    <tr key={s.id}>
                      <td>{date(s.at)}</td>
                      <td>{number(s.followers)}</td>
                      <td>{number(s.following)}</td>
                      <td>{number(s.posts)}</td>
                      <td>
                        {s.source === "manual"
                          ? "Registro manual"
                          : "Interface do Instagram"}
                      </td>
                    </tr>
                  ))}
              </tbody>
            </table>
          </div>
        </details>
      ) : (
        <p className="metrics-footnote">
          As métricas ficam vazias até uma leitura ou registro manual. Contagens
          abreviadas, como “1,2 mil”, não são convertidas em números exatos.
        </p>
      )}
    </section>
  );
}
function FollowerChart({
  measurements,
}: {
  measurements: {
    id: string;
    at: string;
    followers?: number;
    source: string;
  }[];
}) {
  if (measurements.length < 2)
    return (
      <Empty
        icon={<TrendingUp size={25} />}
        title="Uma evolução começa com duas medições"
        text="Atualize os contadores do perfil ou registre medições manuais para acompanhar a evolução."
      />
    );
  const values = measurements.map((s) => s.followers!);
  const low = Math.max(
    0,
    Math.min(...values) -
      Math.max(1, (Math.max(...values) - Math.min(...values)) * 0.15),
  );
  const high =
    Math.max(...values) +
    Math.max(1, (Math.max(...values) - Math.min(...values)) * 0.15);
  const first = Date.parse(measurements[0].at),
    last = Date.parse(measurements.at(-1)!.at);
  const points = measurements.map((s) => ({
    ...s,
    x: 52 + ((Date.parse(s.at) - first) / Math.max(1, last - first)) * 438,
    y: 166 - ((s.followers! - low) / (high - low)) * 136,
  }));
  return (
    <svg
      className="followers-chart"
      viewBox="0 0 520 210"
      role="img"
      aria-label={`Evolução de ${values[0]} para ${values.at(-1)} seguidores em ${measurements.length} medições`}
    >
      {[0, 0.5, 1].map((t) => (
        <g key={t}>
          <line
            x1="52"
            x2="490"
            y1={30 + t * 136}
            y2={30 + t * 136}
            stroke="#e9eedf"
            strokeDasharray="4 5"
          />
          <text x="43" y={34 + t * 136} textAnchor="end">
            {number(Math.round(high - t * (high - low)))}
          </text>
        </g>
      ))}
      <polyline
        points={points.map((p) => `${p.x},${p.y}`).join(" ")}
        fill="none"
        stroke="#7e9f51"
        strokeWidth="2.5"
      />
      {points.map((p) => (
        <circle
          key={p.id}
          cx={p.x}
          cy={p.y}
          r="3.5"
          fill="#7e9f51"
          stroke="white"
          strokeWidth="2"
        >
          <title>{`${date(p.at)} · ${p.followers} seguidores · ${p.source === "manual" ? "manual" : "Instagram"}`}</title>
        </circle>
      ))}
      <text x="52" y="196">
        {date(measurements[0].at)}
      </text>
      <text x="490" y="196" textAnchor="end">
        {date(measurements.at(-1)!.at)}
      </text>
    </svg>
  );
}
