import {
  CalendarClock,
  ClipboardCheck,
  MessageCircle,
  Plus,
} from "lucide-react";
import type { ContentKind, InsightReport } from "../core/types.ts";
import { CONTENT_LABELS } from "../core/insights.ts";
import { GROWTH_OBJECTIVES } from "../core/growth.ts";
import type { GrowthObjective } from "../core/growth.ts";
import { contentGuidance } from "../core/guidance.ts";
import type { EvidenceGroup } from "../core/guidance.ts";
import { Field } from "./components.tsx";

const number = (n?: number) =>
  n === undefined
    ? "—"
    : new Intl.NumberFormat("pt-BR", { maximumFractionDigits: 2 }).format(n);
const evidence = (g: EvidenceGroup) =>
  `${g.n} publicações em ${g.dates} dias · mediana ${number(g.value)} · contraste ${number(g.reference)} em ${g.otherN} publicações`;
function EvidenceTable({
  rows,
  label,
}: {
  rows: EvidenceGroup[];
  label: string;
}) {
  return rows.length ? (
    <div className="table-scroll">
      <table aria-label={label}>
        <thead>
          <tr>
            <th>GRUPO</th>
            <th>PUBLICAÇÕES / DIAS</th>
            <th>MEDIANA</th>
            <th>OUTROS GRUPOS</th>
            <th>LEITURA</th>
          </tr>
        </thead>
        <tbody>
          {rows.map((g) => (
            <tr key={g.key}>
              <td>{g.label}</td>
              <td>
                {g.n} / {g.dates}
              </td>
              <td>{number(g.value)}</td>
              <td>
                {number(g.reference)} · n={g.otherN}
              </td>
              <td>
                {g.qualified ? "Comparável para teste" : "Ainda exploratório"}
              </td>
            </tr>
          ))}
        </tbody>
      </table>
    </div>
  ) : (
    <p className="insights-note">
      Sem dados classificados e com taxa calculável neste recorte.
    </p>
  );
}
export function GuidancePanel({
  report,
  objective,
  window,
  format,
  timeZone,
  onTimeZone,
  onRecord,
}: {
  report: InsightReport;
  objective: GrowthObjective;
  window: number | "all";
  format: ContentKind | "all";
  timeZone: string;
  onTimeZone: (zone: string) => void;
  onRecord: () => void;
}) {
  const result = contentGuidance(report, {
    objective,
    window,
    format,
    timeZone,
  });
  const storyWinner = result.mediaBest || result.stickerBest;
  const zones = [
    ...new Set([
      timeZone,
      "America/Sao_Paulo",
      "America/Manaus",
      "America/Rio_Branco",
      "Europe/Lisbon",
      "UTC",
    ]),
  ];
  const windowText =
    window === "all"
      ? "uma janela fixa (por exemplo, primeiras 24h para Stories)"
      : `as primeiras ${window} horas`;
  return (
    <section
      className="guidance-panel"
      aria-label="Direção para conteúdo e horários"
    >
      <div className="growth-heading">
        <div>
          <span className="eyebrow">DO RESULTADO À PRÓXIMA PUBLICAÇÃO</span>
          <h3>O que fazer agora</h3>
          <p>
            @{report.account} ·{" "}
            {format === "all"
              ? "selecione um formato para os horários"
              : CONTENT_LABELS[format]}{" "}
            · {GROWTH_OBJECTIVES[result.metric]}
          </p>
        </div>
        <button className="button secondary" onClick={onRecord}>
          <Plus size={15} />
          Registrar resultado
        </button>
      </div>
      {report.note ? <p className="insights-note">{report.note}</p> : null}
      <div className="guidance-cards">
        <article>
          <CalendarClock size={21} />
          <span>Faixa de horário para testar</span>
          <h4>
            {result.hourBest?.label || "Ainda sem indicação personalizada"}
          </h4>
          {result.hourBest ? (
            <>
              <p>{evidence(result.hourBest)}.</p>
              <p>
                Teste essa faixa novamente, mantendo formato e tema semelhantes.
                É uma associação observada; não garante o próximo resultado.
              </p>
            </>
          ) : (
            <p>
              {format === "all"
                ? "Escolha Story, Reel ou outro formato no filtro acima."
                : "Para indicar uma faixa, precisamos de 3 publicações nela e 3 em outras faixas, em pelo menos 2 datas de cada lado, com a mesma janela e cobertura conhecida."}
            </p>
          )}
          <Field label="Fuso para analisar horários">
            <select
              value={timeZone}
              onChange={(e) => onTimeZone(e.target.value)}
            >
              {zones.map((z) => (
                <option key={z} value={z}>
                  {z}
                </option>
              ))}
            </select>
          </Field>
          {result.dayBest ? (
            <p>
              <strong>Dia observado: {result.dayBest.label}.</strong>{" "}
              {evidence(result.dayBest)}. Dia e faixa foram analisados
              separadamente; não comprovam uma combinação entre eles.
            </p>
          ) : (
            <p className="insights-note">
              Dia da semana: ainda sem contraste suficiente. Um pico de público
              ativo, sozinho, não demonstra qual conteúdo funciona melhor.
            </p>
          )}
        </article>
        <article>
          <MessageCircle size={21} />
          <span>Foto, vídeo ou caixinha?</span>
          <h4>
            {storyWinner
              ? `${storyWinner.label}: um sinal para repetir`
              : "Vamos testar os Stories"}
          </h4>
          {storyWinner ? (
            <p>
              {evidence(storyWinner)}. O objetivo usado é{" "}
              {GROWTH_OBJECTIVES[result.metric].toLocaleLowerCase("pt-BR")}.
            </p>
          ) : (
            <p>
              Registre foto/vídeo e figurinha separadamente. Uma foto pode ter
              caixinha. Compare foto com vídeo mantendo a figurinha; depois
              compare com e sem caixinha mantendo a mídia.
            </p>
          )}
          <p>
            {result.stories} Stories com taxa calculável ·{" "}
            {result.missingStoryMedia} sem mídia informada ·{" "}
            {result.missingStorySticker} sem figurinha informada.
          </p>
          {result.mediaBest && result.stickerBest ? (
            <p>
              <strong>Figurinha observada: {result.stickerBest.label}.</strong>{" "}
              {evidence(result.stickerBest)}. Mídia e figurinha foram comparadas
              separadamente; teste uma mudança por vez.
            </p>
          ) : null}
          <p className="insights-note">
            Respostas à caixinha, respostas por mensagem e toques em figurinhas
            são resultados diferentes. Não somamos esses campos para inventar
            interações.
          </p>
        </article>
      </div>
      <div className="guidance-recipe">
        <div className="growth-section-heading">
          <ClipboardCheck size={19} />
          <h3>Seu roteiro para o próximo teste</h3>
        </div>
        <ol>
          <li>
            <strong>Escolha uma mudança.</strong>{" "}
            {storyWinner
              ? `Repita ${storyWinner.label.toLocaleLowerCase("pt-BR")} em uma nova publicação. Mantenha horário, tema e os outros elementos semelhantes; compare com a alternativa.`
              : format === "story" || format === "all"
                ? "Comece por 3 Stories de foto e 3 de vídeo, em pelo menos 2 dias por grupo, mantendo tema e figurinha semelhantes. Depois teste a caixinha em outro ciclo."
                : `Compare duas aberturas de ${CONTENT_LABELS[format]}, com 3 publicações em cada grupo e tema semelhante.`}
          </li>
          <li>
            <strong>Teste o horário em outro ciclo.</strong>{" "}
            {result.hourBest
              ? `Use ${result.hourBest.label} como faixa candidata e compare com outra faixa. Não mude o tipo de conteúdo ao mesmo tempo.`
              : "Se ainda não há histórico, 12h–14h e 18h–20h são duas faixas iniciais de teste, sem evidência de que sejam as melhores para você. Distribua 3 publicações semelhantes em cada uma, em pelo menos 2 datas por faixa."}{" "}
            Fuso: {timeZone}.
          </li>
          <li>
            <strong>Meça e volte ao painel.</strong> Registre {windowText},
            alcance e o resultado escolhido acima. Para Stories, informe
            respostas e respostas à caixinha somente quando realmente
            conhecidas. Não preencha campos desconhecidos com zero.
          </li>
          <li>
            <strong>Continue a prospecção com revisão.</strong> Em Campanhas,
            escolha um perfil de referência ou uma publicação com comentários
            relevantes. Revise os candidatos em Seu público e respeite o saldo
            em Ritmo e cuidados. Estar numa lista ou ser seguido não significa
            virar cliente.
          </li>
        </ol>
      </div>
      <details className="growth-group-details">
        <summary>
          Ver a base da orientação: horários, dias e tipos de Story
        </summary>
        <div className="guidance-evidence">
          <h4>Faixas de publicação · {timeZone}</h4>
          <EvidenceTable
            rows={result.hourGroups}
            label="Resultados por faixa de horário"
          />
          <h4>Dias da semana · análise separada</h4>
          <EvidenceTable
            rows={result.dayGroups}
            label="Resultados por dia da semana"
          />
          <h4>Mídia dos Stories</h4>
          <EvidenceTable
            rows={result.mediaGroups}
            label="Foto e vídeo nos Stories"
          />
          <h4>Figurinhas nos Stories</h4>
          <EvidenceTable
            rows={result.stickerGroups}
            label="Figurinhas nos Stories"
          />
        </div>
      </details>
      <p className="insights-note">
        {result.reasons.join(" ")} Usamos medianas por publicação do relatório
        selecionado. Faixas têm 2 horas; não identificamos o melhor minuto. Os
        mínimos são controles do produto, não significância estatística. Tema,
        posição na sequência, promoção e público podem explicar diferenças. O
        roteiro orienta testes manuais; não agenda nem publica.
      </p>
    </section>
  );
}
