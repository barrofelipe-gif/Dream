import type { ContentKind, InsightContent, InsightReport } from "./types.ts";
import { CONTENT_LABELS } from "./insights.ts";

export type GrowthObjective =
  | "follows"
  | "followersPer1000"
  | "engagementRate"
  | "savesPer1000"
  | "sharesPer1000"
  | "repliesPer1000"
  | "questionAnswersPer1000";
export const GROWTH_OBJECTIVES: Record<GrowthObjective, string> = {
  follows: "Seguidores atribuídos · total",
  followersPer1000: "Seguidores por mil alcançadas",
  engagementRate: "Interações / alcance · %",
  savesPer1000: "Salvamentos por mil alcançadas",
  sharesPer1000: "Compartilhamentos por mil alcançadas",
  repliesPer1000: "Respostas por mil alcançadas",
  questionAnswersPer1000: "Respostas à caixinha por mil alcançadas · manual",
};
export const GROWTH_DIMENSIONS = {
  format: "Formato",
  theme: "Tema",
  hook: "Tipo de abertura",
  cta: "Chamada para ação",
} as const;
export function contentPerformance(content: InsightContent) {
  const m = content.metrics;
  const read = (key: string): number | undefined =>
    Object.hasOwn(m, key) ? m[key] : undefined;
  const reach = read("reach");
  const ratio = (key: string, multiplier: number) => {
    const value = read(key);
    return reach !== undefined && reach > 0 && value !== undefined
      ? (value / reach) * multiplier
      : undefined;
  };
  return {
    content,
    follows: read("follows"),
    reach,
    interactions: read("total_interactions"),
    engagementRate: ratio("total_interactions", 100),
    followersPer1000: ratio("follows", 1000),
    savesPer1000: ratio("saves", 1000),
    sharesPer1000: ratio("shares", 1000),
    repliesPer1000: ratio("replies", 1000),
    questionAnswersPer1000: ratio("question_answers", 1000),
  };
}
export type ContentPerformance = ReturnType<typeof contentPerformance>;
export function median(values: number[]): number | undefined {
  if (!values.length) return undefined;
  const sorted = [...values].sort((a, b) => a - b),
    middle = Math.floor(sorted.length / 2);
  return sorted.length % 2
    ? sorted[middle]
    : (sorted[middle - 1] + sorted[middle]) / 2;
}
const normalize = (s: string) =>
  s
    .normalize("NFD")
    .replace(/[\u0300-\u036f]/g, "")
    .trim()
    .toLocaleLowerCase("pt-BR")
    .replace(/\s+/g, " ");
const publishedInReport = (c: InsightContent, r: InsightReport) =>
  !!c.publishedAt &&
  c.publishedAt.slice(0, 10) >= r.start &&
  c.publishedAt.slice(0, 10) <= r.end;
function windowCounts(
  report: InsightReport,
  format: ContentKind | "all" = "all",
): Map<number, number> {
  const counts = new Map<number, number>();
  if (report.contentWindow === "lifetime") return counts;
  for (const c of report.content)
    if (
      c.observationHours &&
      publishedInReport(c, report) &&
      (format === "all" || c.kind === format)
    )
      counts.set(c.observationHours, (counts.get(c.observationHours) || 0) + 1);
  return counts;
}
export const growthWindows = (
  report: InsightReport,
  format: ContentKind | "all" = "all",
) => [...windowCounts(report, format).keys()].sort((a, b) => a - b);
export const defaultGrowthWindow = (
  report: InsightReport,
  format: ContentKind | "all" = "all",
): number | "all" =>
  [...windowCounts(report, format)].sort(
    (a, b) => b[1] - a[1] || a[0] - b[0],
  )[0]?.[0] || "all";
export function growthAnalysis(
  report: InsightReport,
  options: {
    objective: GrowthObjective;
    window: "all" | number;
    format?: ContentKind | "all";
  },
) {
  const all = report.content.map(contentPerformance);
  const formatted = all.filter(
    (row) =>
      !options.format ||
      options.format === "all" ||
      row.content.kind === options.format,
  );
  const availableWindows = growthWindows(report, options.format || "all");
  const cohort = formatted.filter(
    (row) =>
      options.window === "all" ||
      (report.contentWindow === "period" &&
        row.content.observationHours === options.window &&
        publishedInReport(row.content, report)),
  );
  const ranking = cohort
    .filter((row) => row[options.objective] !== undefined)
    .sort(
      (a, b) =>
        b[options.objective]! - a[options.objective]! ||
        (b.reach || 0) - (a.reach || 0) ||
        a.content.id.localeCompare(b.content.id),
    );
  const patternObjective =
    options.objective === "follows" ? "followersPer1000" : options.objective;
  const eligible = cohort.filter((row) => row[patternObjective] !== undefined);
  const reasons: string[] = [];
  if (report.contentWindow === "lifetime")
    reasons.push(
      "Valores de vida inteira são exploratórios. Para comparar primeiras horas, registre um recorte de período com a janela realmente medida.",
    );
  if (options.window === "all")
    reasons.push(
      "Escolha uma janela comum, como as primeiras 48 horas, para gerar hipóteses comparáveis.",
    );
  if (report.coverage === "unknown")
    reasons.push("Informe a cobertura do relatório: orgânico, pago ou ambos.");
  if (eligible.length < 6)
    reasons.push(
      `Há ${eligible.length} publicações com os dados necessários neste recorte. As hipóteses exigem pelo menos 3 no grupo e 3 fora dele.`,
    );
  const groups: {
    dimension: keyof typeof GROWTH_DIMENSIONS;
    label: string;
    n: number;
    otherN: number;
    value: number;
    reference: number | undefined;
    difference: number | undefined;
    qualified: boolean;
    best: InsightContent;
  }[] = [];
  for (const dimension of Object.keys(
    GROWTH_DIMENSIONS,
  ) as (keyof typeof GROWTH_DIMENSIONS)[]) {
    const labeled = eligible.filter(
      (row) => dimension === "format" || !!row.content[dimension]?.trim(),
    );
    const labels = new Map<string, string>();
    for (const row of labeled) {
      const label =
        dimension === "format"
          ? CONTENT_LABELS[row.content.kind]
          : row.content[dimension];
      if (label) labels.set(normalize(label), label);
    }
    for (const [key, label] of labels) {
      const inGroup = (row: ContentPerformance) =>
        normalize(
          dimension === "format"
            ? CONTENT_LABELS[row.content.kind]
            : row.content[dimension] || "",
        ) === key;
      const members = labeled.filter(inGroup),
        others = labeled.filter((row) => !inGroup(row));
      const value = median(members.map((row) => row[patternObjective]!))!,
        reference = median(others.map((row) => row[patternObjective]!));
      const qualified =
        !reasons.length && members.length >= 3 && others.length >= 3;
      const best = [...members].sort(
        (a, b) => b[patternObjective]! - a[patternObjective]!,
      )[0].content;
      groups.push({
        dimension,
        label,
        n: members.length,
        otherN: others.length,
        value,
        reference,
        difference: reference === undefined ? undefined : value - reference,
        qualified,
        best,
      });
    }
  }
  const hypotheses = groups
    .filter(
      (g) =>
        g.qualified &&
        g.reference !== undefined &&
        g.value > g.reference &&
        g.value > 0,
    )
    .sort((a, b) => b.difference! - a.difference! || b.n - a.n)
    .slice(0, 3);
  const metadataGaps = (["theme", "hook", "cta"] as const).map((key) => ({
    dimension: key,
    missing: eligible.filter((row) => !row.content[key]?.trim()).length,
    total: eligible.length,
  }));
  return {
    all,
    availableWindows,
    cohort,
    ranking,
    patternObjective,
    groups,
    hypotheses,
    reasons,
    metadataGaps,
    coverage: {
      publications: report.content.length,
      attributedFollowers: all.filter((r) => r.follows !== undefined).length,
      positiveReach: all.filter((r) => r.reach !== undefined && r.reach > 0)
        .length,
      standardWindow: all.filter(
        (r) =>
          report.contentWindow === "period" &&
          r.content.observationHours !== undefined &&
          publishedInReport(r.content, report),
      ).length,
    },
    medians: {
      engagement: median(
        cohort.flatMap((r) =>
          r.engagementRate === undefined ? [] : [r.engagementRate],
        ),
      ),
      followers: median(
        cohort.flatMap((r) =>
          r.followersPer1000 === undefined ? [] : [r.followersPer1000],
        ),
      ),
    },
  };
}
