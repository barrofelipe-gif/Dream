import { normalizeUsername, uid } from "./domain.ts";
import { csvRows } from "./io.ts";
import type {
  RelationshipBook,
  RelationshipSnapshot,
  RelationshipProtection,
} from "./types.ts";

export const RELATIONSHIP_LIMITS = {
  perList: 20000,
  snapshots: 24,
  totalEntries: 200000,
  protections: 5000,
};
export const PROTECTION_REASONS = {
  friend: "Amigo(a)",
  family: "Família",
  important: "Perfil importante",
  client: "Cliente / contato",
  other: "Outro motivo",
} as const;
const fail = (message: string): never => {
  throw new Error(message);
};
const object = (value: unknown): Record<string, unknown> =>
  value && typeof value === "object" && !Array.isArray(value)
    ? (value as Record<string, unknown>)
    : fail("Os dados das relações devem conter objetos válidos.");
export function relationshipUsername(value: unknown): string {
  if (typeof value !== "string")
    fail("Use @perfis ou links de perfil válidos nas listas.");
  let text = (value as string).trim();
  if (/^https?:\/\//i.test(text)) {
    let url: URL;
    try {
      url = new URL(text);
    } catch {
      return fail("Link de perfil inválido na lista.");
    }
    const parts = url.pathname.split("/").filter(Boolean);
    if (parts[0] === "_u") parts.shift();
    if (
      url.protocol !== "https:" ||
      !["instagram.com", "www.instagram.com"].includes(url.hostname) ||
      url.port ||
      url.username ||
      url.password ||
      parts.length !== 1
    )
      fail(
        "Use apenas links completos de perfis do Instagram, sem rotas de publicações.",
      );
    text = parts[0];
  }
  return (
    normalizeUsername(text) ||
    fail("Há um @perfil inválido na lista. Nenhuma linha foi ignorada.")
  );
}
export function relationshipNames(input: unknown): string[] {
  if (!Array.isArray(input) || input.length > RELATIONSHIP_LIMITS.perList)
    fail("Cada lista deve conter até 20.000 perfis.");
  return [...new Set((input as unknown[]).map(relationshipUsername))].sort();
}
function instant(value: unknown, label: string, tolerance = 0): string {
  if (
    typeof value !== "string" ||
    !/^\d{4}-\d{2}-\d{2}T\d{2}:\d{2}(?::\d{2}(?:\.\d{1,3})?)?(?:Z|[+-]\d{2}:\d{2})$/.test(
      value,
    ) ||
    !Number.isFinite(Date.parse(value)) ||
    Number(value.slice(11, 13)) > 23 ||
    Number(value.slice(14, 16)) > 59 ||
    new Date(value.slice(0, 10)).toISOString().slice(0, 10) !==
      value.slice(0, 10) ||
    Date.parse(value) > Date.now() + tolerance
  )
    fail(`${label}: informe data e hora válidas com fuso, sem datas futuras.`);
  return new Date(value as string).toISOString();
}
export function validateRelationshipSnapshot(
  input: unknown,
  account: string,
  preserve = false,
): RelationshipSnapshot {
  const raw = object(input);
  if (
    !account ||
    raw.account !== account ||
    normalizeUsername(account) !== account
  )
    fail(`Esta medição deve pertencer a @${account || "conta selecionada"}.`);
  if (!["manual", "file"].includes(String(raw.source)))
    fail("Origem da medição de relações inválida.");
  if (
    typeof raw.followersComplete !== "boolean" ||
    typeof raw.followingComplete !== "boolean"
  )
    fail("Informe explicitamente se cada lista está completa ou parcial.");
  const followers = relationshipNames(raw.followers),
    following = relationshipNames(raw.following);
  if (followers.includes(account) || following.includes(account))
    fail(
      "Sua própria conta não deve estar nas listas de seguidores ou seguidos. Confira a conta e os arquivos.",
    );
  if (
    preserve &&
    (typeof raw.id !== "string" || !raw.id.trim() || raw.id.length > 150)
  )
    fail("Identificador da medição de relações inválido.");
  if (
    raw.note !== undefined &&
    (typeof raw.note !== "string" || raw.note.length > 500)
  )
    fail("A observação deve ter até 500 caracteres.");
  return {
    id: preserve ? (raw.id as string) : uid(),
    account,
    at: instant(raw.at, "Data da medição"),
    recordedAt: preserve
      ? instant(raw.recordedAt, "Data de registro", 60000)
      : new Date().toISOString(),
    source: raw.source as RelationshipSnapshot["source"],
    followers,
    following,
    followersComplete: raw.followersComplete as boolean,
    followingComplete: raw.followingComplete as boolean,
    note: ((raw.note as string) || "").trim(),
  };
}
export function emptyRelationships(): RelationshipBook {
  return { version: 1, snapshots: [], protections: [] };
}
const fingerprint = (s: RelationshipSnapshot) =>
  JSON.stringify([
    s.at,
    s.followers,
    s.following,
    s.followersComplete,
    s.followingComplete,
  ]);
function capacity(book: RelationshipBook) {
  if (
    book.snapshots.length > RELATIONSHIP_LIMITS.snapshots ||
    book.snapshots.reduce(
      (n, s) => n + s.followers.length + s.following.length,
      0,
    ) > RELATIONSHIP_LIMITS.totalEntries
  )
    fail(
      "O histórico comporta 24 medições e 200.000 entradas de relações por conta. Exporte um backup antes de remover medições antigas.",
    );
  if (book.protections.length > RELATIONSHIP_LIMITS.protections)
    fail("Esta conta chegou ao limite de 5.000 registros de proteção.");
}
export function validateRelationships(
  input: unknown,
  account: string,
): RelationshipBook {
  if (!account || normalizeUsername(account) !== account)
    fail("O histórico de relações precisa de uma conta identificada.");
  const raw = object(input);
  if (
    raw.version !== 1 ||
    !Array.isArray(raw.snapshots) ||
    !Array.isArray(raw.protections) ||
    raw.snapshots.length > 24 ||
    raw.protections.length > 5000
  )
    fail(
      "Histórico de relações inválido. Os dados existentes foram preservados.",
    );
  const snapshots = (raw.snapshots as unknown[]).map((s) =>
    validateRelationshipSnapshot(s, account, true),
  );
  if (
    new Set(snapshots.map((s) => s.id)).size !== snapshots.length ||
    new Set(snapshots.map((s) => s.at)).size !== snapshots.length
  )
    fail(
      "Há medições de relações duplicadas ou conflitantes no mesmo instante.",
    );
  const protections = (raw.protections as unknown[]).map((value) => {
    const p = object(value),
      username = relationshipUsername(p.username);
    if (
      typeof p.enabled !== "boolean" ||
      !Object.hasOwn(PROTECTION_REASONS, String(p.reason)) ||
      typeof p.note !== "string" ||
      p.note.length > 500
    )
      fail("Um registro de proteção é inválido.");
    return {
      username,
      enabled: p.enabled,
      reason: p.reason,
      note: p.note,
      updatedAt: instant(p.updatedAt, "Data da proteção", 60000),
    } as RelationshipProtection;
  });
  if (new Set(protections.map((p) => p.username)).size !== protections.length)
    fail("Há proteções duplicadas para o mesmo perfil.");
  const book: RelationshipBook = {
    version: 1,
    snapshots: snapshots.sort((a, b) => a.at.localeCompare(b.at)),
    protections,
  };
  capacity(book);
  return book;
}
export function addRelationshipSnapshot(
  book: RelationshipBook | undefined,
  input: unknown,
  account: string,
): RelationshipBook {
  const next = structuredClone(book || emptyRelationships()),
    snapshot = validateRelationshipSnapshot(input, account);
  const existing = next.snapshots.find((s) => s.at === snapshot.at);
  if (existing) {
    if (fingerprint(existing) === fingerprint(snapshot)) return next;
    fail(
      "Já existe uma medição diferente nesse instante. Confira a data do novo levantamento.",
    );
  }
  next.snapshots.push(snapshot);
  next.snapshots.sort((a, b) => a.at.localeCompare(b.at));
  capacity(next);
  return next;
}
export function mergeRelationships(
  current: RelationshipBook | undefined,
  input: unknown,
  account: string,
): RelationshipBook {
  const incoming = validateRelationships(input, account),
    next = structuredClone(current || emptyRelationships());
  for (const s of incoming.snapshots) {
    const existing = next.snapshots.find((old) => old.at === s.at);
    if (existing) {
      if (fingerprint(existing) !== fingerprint(s))
        fail(
          "O backup tem uma medição de relações conflitante no mesmo instante. Nenhum dado foi restaurado.",
        );
      continue;
    }
    if (next.snapshots.some((old) => old.id === s.id)) s.id = uid();
    next.snapshots.push(s);
  }
  for (const p of incoming.protections) {
    const i = next.protections.findIndex((old) => old.username === p.username);
    if (i < 0) next.protections.push(p);
    else if (p.updatedAt > next.protections[i].updatedAt)
      next.protections[i] = p;
  }
  next.snapshots.sort((a, b) => a.at.localeCompare(b.at));
  capacity(next);
  return next;
}
export function setRelationshipProtection(
  book: RelationshipBook | undefined,
  username: string,
  enabled: boolean,
  reason: string = "other",
  note = "",
): RelationshipBook {
  const next = structuredClone(book || emptyRelationships()),
    name = relationshipUsername(username);
  if (
    !Object.hasOwn(PROTECTION_REASONS, reason) ||
    typeof note !== "string" ||
    note.length > 500
  )
    fail("Escolha um motivo válido e uma observação de até 500 caracteres.");
  const index = next.protections.findIndex((p) => p.username === name),
    prior = next.protections[index];
  const value: RelationshipProtection = {
    username: name,
    enabled,
    reason: enabled
      ? (reason as RelationshipProtection["reason"])
      : prior?.reason || "other",
    note: enabled ? note.trim() : prior?.note || "",
    updatedAt: new Date().toISOString(),
  };
  if (index < 0) next.protections.push(value);
  else next.protections[index] = value;
  capacity(next);
  return next;
}

export function parseRelationshipList(
  text: string,
  kind: "followers" | "following",
  account: string,
  filename = "",
) {
  if (text.length > 5_000_000) fail("Use até 5 MB por arquivo de relações.");
  const cleaned = text.replace(/^\uFEFF/, "").trim();
  if (!cleaned)
    fail(
      "A lista está vazia. Para declarar uma lista sem perfis, informe explicitamente [] em JSON.",
    );
  if (/\.json$/i.test(filename) && !/^[\[{]/.test(cleaned))
    fail(
      "O arquivo JSON precisa conter uma lista ou objeto JSON de relações válido.",
    );
  let rows: unknown[],
    format = "text";
  if (/^[\[{]/.test(cleaned)) {
    let root: unknown;
    try {
      root = JSON.parse(cleaned);
    } catch {
      return fail("JSON de relações inválido. Nenhum perfil foi ignorado.");
    }
    if (!Array.isArray(root)) {
      let raw = object(root);
      if (raw.type === "orbita-connections-snapshot")
        raw = object(raw.snapshot);
      if (raw.account !== undefined) {
        if (raw.account !== account)
          fail(`O arquivo deve pertencer a @${account}.`);
        rows = raw[kind] as unknown[];
        format = "orbita-json";
      } else {
        const key =
          kind === "followers"
            ? "relationships_followers"
            : "relationships_following";
        if (!Object.hasOwn(raw, key))
          fail(
            "O arquivo não corresponde à lista escolhida. Use seguidores no primeiro campo e seguidos no segundo.",
          );
        rows = raw[key] as unknown[];
        format = "instagram-json";
      }
    } else {
      rows = root;
      format = "json";
    }
    if (!Array.isArray(rows) || rows.length > RELATIONSHIP_LIMITS.perList)
      fail("A lista JSON deve conter até 20.000 perfis.");
    const basename = filename.split(/[\\/]/).at(-1) || "";
    if (
      (/^following(?:_\d+)?\.json$/i.test(basename) && kind !== "following") ||
      (/^followers(?:_\d+)?\.json$/i.test(basename) && kind !== "followers")
    )
      fail("Os arquivos de seguidores e seguidos estão trocados.");
    rows = rows.map((value, index) => {
      if (typeof value === "string") return relationshipUsername(value);
      const row = object(value);
      if (!Array.isArray(row.string_list_data))
        fail(`Registro ${index + 1}: formato de perfil não reconhecido.`);
      const names: string[] = [];
      if (kind === "following" && row.title)
        names.push(relationshipUsername(row.title));
      for (const v of row.string_list_data as unknown[]) {
        const data = object(v);
        if (data.value) names.push(relationshipUsername(data.value));
        if (data.href) names.push(relationshipUsername(data.href));
      }
      if (!names.length || new Set(names).size !== 1)
        fail(`Registro ${index + 1}: nome e link ausentes ou conflitantes.`);
      return names[0];
    });
  } else {
    if (/^\s*</.test(cleaned))
      fail(
        "Use os arquivos JSON de conexões, ou TXT/CSV com @perfis. HTML e ZIP não são aceitos.",
      );
    const parsed = csvRows(cleaned);
    if (parsed.some((r) => r.length !== 1))
      fail("O TXT/CSV deve ter uma coluna username, com um @perfil por linha.");
    if (/\.csv$/i.test(filename)) {
      if (parsed[0]?.[0].trim().toLowerCase() !== "username")
        fail(
          "O arquivo CSV deve começar com o cabeçalho username. Para uma lista sem cabeçalho, use TXT ou cole o texto.",
        );
      parsed.shift();
    }
    rows = parsed.map((r) => r[0]);
  }
  const names = relationshipNames(rows);
  return { names, duplicates: rows.length - names.length, format };
}
export function relationshipAnalysis(
  book: RelationshipBook | undefined,
  selectedId?: string,
  baselineId?: string,
) {
  const snapshots = book?.snapshots || [],
    current = snapshots.find((s) => s.id === selectedId) || snapshots.at(-1);
  const older = snapshots.filter(
    (s) => current && s.at < current.at && s.followersComplete,
  );
  const previous = baselineId
    ? older.find((s) => s.id === baselineId)
    : older.at(-1);
  const followers = new Set(current?.followers),
    previousFollowers = new Set(previous?.followers);
  const comparable = !!current?.followersComplete && !!previous;
  return {
    current,
    previous,
    older,
    comparable,
    notFollowingBack: current?.followersComplete
      ? current.following.filter((n) => !followers.has(n))
      : undefined,
    mutual: current?.following.filter((n) => followers.has(n)) || [],
    lost: comparable
      ? previous!.followers.filter((n) => !followers.has(n))
      : undefined,
    gained: comparable
      ? current!.followers.filter((n) => !previousFollowers.has(n))
      : undefined,
    protections: book?.protections.filter((p) => p.enabled) || [],
  };
}
