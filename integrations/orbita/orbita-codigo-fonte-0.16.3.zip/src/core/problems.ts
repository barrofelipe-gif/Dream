export const PROBLEMS_KEY = "orbita-problems-v1";
export const APP_SCOPE = "app";
export const PROBLEM_LIMIT = 1000;
export type ProblemStatus =
  "open" | "investigating" | "monitoring" | "resolved";
export type ProblemCategory =
  | "validation"
  | "connection"
  | "storage"
  | "platform"
  | "uncertain"
  | "interface";
export type ProblemSource =
  "dashboard" | "worker" | "visible" | "runtime" | "manual";
export interface ProblemEvent {
  at: string;
  status: ProblemStatus;
  kind: "reported" | "status" | "recovered";
  note: string;
}
export interface Problem {
  id: string;
  scope: string;
  operation: string;
  category: ProblemCategory;
  source: ProblemSource;
  message: string;
  status: ProblemStatus;
  count: number;
  recoveries: number;
  firstAt: string;
  lastAt: string;
  updatedAt: string;
  events: ProblemEvent[];
}
export interface ProblemStore {
  version: 1;
  entries: Problem[];
  pruned: number;
  prunedOpen: number;
}
export interface ProblemInput {
  scope: string;
  operation: string;
  source: ProblemSource;
  message: string;
  category?: ProblemCategory;
}
export const PROBLEM_STATUS = {
  open: "Em aberto",
  investigating: "Em análise",
  monitoring: "Recuperado · observar",
  resolved: "Resolvido pelo usuário",
} as const;
export const PROBLEM_CATEGORY = {
  validation: "Dados e formato",
  connection: "Comunicação",
  storage: "Armazenamento",
  platform: "Aviso do Instagram",
  uncertain: "Ação sem confirmação",
  interface: "Interface",
} as const;
export const emptyProblems = (): ProblemStore => ({
  version: 1,
  entries: [],
  pruned: 0,
  prunedOpen: 0,
});
function fail(s: string): never {
  throw new Error(s);
}
export function problemScope(scope: unknown): string {
  return typeof scope === "string" && /^[a-zA-Z0-9_-]{1,100}$/.test(scope)
    ? scope
    : fail("Identificação inválida para o registro de problemas.");
}
export function problemText(input: unknown): string {
  let text =
    input instanceof SyntaxError
      ? "Não foi possível interpretar um arquivo ou registro. Confira o formato dos dados."
      : input instanceof Error
        ? input.message
        : typeof input === "string"
          ? input
          : "Falha sem mensagem reconhecível.";
  if (/unexpected (?:token|end)|not valid json|json at position/i.test(text))
    text =
      "Não foi possível interpretar um arquivo ou registro. Confira o formato dos dados.";
  return (
    text
      .replace(
        /^(?:Error|OrbitaResponseError|TypeError|RangeError|SyntaxError):\s*/i,
        "",
      )
      .replace(/https?:\/\/[^\s<>]+/gi, "[link omitido]")
      .replace(/\bBearer\s+[^\s,;]+/gi, "Bearer [omitido]")
      .replace(
        /(["']?(?:access[_-]?token|refresh[_-]?token|authorization|password|passwd|senha|cookie|sessionid|secret|api[_-]?key|token)["']?\s*[:=]\s*)(?:"[^"]*"|'[^']*'|[^\s,;}]+)/gi,
        "$1[omitido]",
      )
      .replace(
        /\beyJ[A-Za-z0-9_-]+\.[A-Za-z0-9_-]+\.[A-Za-z0-9_-]+\b/g,
        "[credencial omitida]",
      )
      .replace(/[\u0000-\u001f]+/g, " ")
      .replace(/\s+/g, " ")
      .trim()
      .slice(0, 600) || "Falha sem mensagem reconhecível."
  );
}
export function problemCategory(message: string): ProblemCategory {
  if (
    /sem confirma|incert|retorno.*expir|uncertain|confira o perfil antes/i.test(
      message,
    )
  )
    return "uncertain";
  if (
    /quota|storage|armazen|cadastro.*inválid|registro.*inválid|falha ao carregar/i.test(
      message,
    )
  )
    return "storage";
  if (
    /instagram.*(?:login|verifica|aviso)|aviso.*pendente|bloquead|challenge|checkpoint/i.test(
      message,
    )
  )
    return "platform";
  if (
    /connection|receiving end|message port|port closed|comunica|conexão|demorou|timeout|network|sessão|sessao/i.test(
      message,
    )
  )
    return "connection";
  if (
    /informe|inválid|formato|arquivo|relatório|pertenc|limite|excede|repetid|dados/i.test(
      message,
    )
  )
    return "validation";
  return "interface";
}
const time = (v: unknown) =>
  typeof v === "string" &&
  /^\d{4}-\d{2}-\d{2}T/.test(v) &&
  Number.isFinite(Date.parse(v))
    ? new Date(v).toISOString()
    : fail("Data inválida no registro de problemas.");
const counter = (n: unknown, min = 0) =>
  typeof n === "number" && Number.isSafeInteger(n) && n >= min
    ? n
    : fail("Contador inválido no registro de problemas.");
const status = (v: unknown): ProblemStatus =>
  typeof v === "string" && Object.hasOwn(PROBLEM_STATUS, v)
    ? (v as ProblemStatus)
    : fail("Situação inválida do problema.");
export function validateProblems(input: unknown): ProblemStore {
  if (input === undefined || input === null) return emptyProblems();
  const r = input as ProblemStore;
  if (
    r.version !== 1 ||
    !Array.isArray(r.entries) ||
    r.entries.length > PROBLEM_LIMIT
  )
    fail(
      "Registro de problemas inválido. Exporte os dados antes de tentar reparar o armazenamento.",
    );
  const ids = new Set<string>();
  const entries = r.entries.map((p) => {
    if (
      !p ||
      typeof p.id !== "string" ||
      !p.id ||
      p.id.length > 100 ||
      ids.has(p.id) ||
      !Object.hasOwn(PROBLEM_CATEGORY, p.category) ||
      !["dashboard", "worker", "visible", "runtime", "manual"].includes(
        p.source,
      ) ||
      !Array.isArray(p.events) ||
      p.events.length > 12
    )
      fail("Há um problema inválido no histórico local.");
    ids.add(p.id);
    const firstAt = time(p.firstAt),
      lastAt = time(p.lastAt),
      updatedAt = time(p.updatedAt);
    if (firstAt > lastAt || updatedAt < firstAt)
      fail("Ordem de datas inválida no histórico de problemas.");
    return {
      id: p.id,
      category: p.category,
      source: p.source,
      scope: problemScope(p.scope),
      operation: problemText(p.operation).slice(0, 80),
      message: problemText(p.message),
      status: status(p.status),
      count: counter(p.count, 1),
      recoveries: counter(p.recoveries),
      firstAt,
      lastAt,
      updatedAt,
      events: p.events.map((e) => ({
        at: time(e.at),
        status: status(e.status),
        kind: ["reported", "status", "recovered"].includes(e.kind)
          ? e.kind
          : fail("Evento inválido no problema."),
        note: problemText(e.note),
      })),
    };
  });
  return {
    version: 1,
    entries,
    pruned: counter(r.pruned),
    prunedOpen: counter(r.prunedOpen),
  };
}
export function recordProblem(
  store: ProblemStore,
  input: ProblemInput,
  now = new Date().toISOString(),
): { store: ProblemStore; id: string } {
  const result = structuredClone(store),
    at = time(now),
    scope = problemScope(input.scope),
    message = problemText(input.message),
    operation = problemText(input.operation).slice(0, 80),
    category = input.category || problemCategory(message);
  if (
    !Object.hasOwn(PROBLEM_CATEGORY, category) ||
    !["dashboard", "worker", "visible", "runtime", "manual"].includes(
      input.source,
    )
  )
    fail("Origem inválida para registrar o problema.");
  let p = result.entries.find(
    (e) =>
      e.scope === scope &&
      e.operation === operation &&
      e.category === category &&
      e.message === message,
  );
  if (p) {
    p.count = Math.min(Number.MAX_SAFE_INTEGER, p.count + 1);
    p.lastAt = at;
    p.updatedAt = at;
    p.status = "open";
    p.source = input.source;
    p.events.push({
      at,
      status: "open",
      kind: "reported",
      note: "Nova ocorrência registrada; requer acompanhamento.",
    });
    p.events = p.events.slice(-12);
  } else {
    p = {
      id: crypto.randomUUID(),
      scope,
      operation,
      category,
      source: input.source,
      message,
      status: "open",
      count: 1,
      recoveries: 0,
      firstAt: at,
      lastAt: at,
      updatedAt: at,
      events: [
        { at, status: "open", kind: "reported", note: "Problema registrado." },
      ],
    };
    if (result.entries.length >= PROBLEM_LIMIT) {
      const oldest = [...result.entries].sort(
        (a, b) =>
          (a.status === "resolved" ? 0 : 1) -
            (b.status === "resolved" ? 0 : 1) ||
          a.updatedAt.localeCompare(b.updatedAt),
      )[0];
      result.entries = result.entries.filter((e) => e.id !== oldest.id);
      result.pruned++;
      if (oldest.status !== "resolved") result.prunedOpen++;
    }
    result.entries.push(p);
  }
  return { store: result, id: p.id };
}
export function updateProblem(
  store: ProblemStore,
  scope: string,
  id: string,
  next: ProblemStatus,
  note: string,
  now = new Date().toISOString(),
): ProblemStore {
  const result = structuredClone(store),
    p = result.entries.find(
      (e) => e.id === id && e.scope === problemScope(scope),
    );
  if (!p) fail("Problema não encontrado neste espaço de conta.");
  const checked = status(next),
    text = problemText(note),
    at = time(now);
  if (text.length < 10)
    fail(
      "Descreva o acompanhamento ou a correção e a conferência, com pelo menos 10 caracteres.",
    );
  if (checked === "monitoring")
    fail(
      "Recuperação automática é registrada somente após uma leitura bem-sucedida.",
    );
  p.status = checked;
  p.updatedAt = at;
  p.events = [
    ...p.events,
    {
      at,
      status: checked,
      kind: "status" as const,
      note: `Registro manual: ${text}`,
    },
  ].slice(-12);
  return result;
}
export function recoverProblem(
  store: ProblemStore,
  scope: string,
  id: string,
  now = new Date().toISOString(),
): ProblemStore {
  const result = structuredClone(store),
    p = result.entries.find(
      (e) => e.id === id && e.scope === problemScope(scope),
    );
  if (!p) return result;
  if (p.operation !== "LOAD_STATE" || p.category !== "connection")
    fail("Somente a leitura inicial de estado admite recuperação automática.");
  if (p.status === "monitoring" || p.recoveries >= p.count) return result;
  const at = time(now);
  p.status = "monitoring";
  p.updatedAt = at;
  p.recoveries = Math.min(Number.MAX_SAFE_INTEGER, p.recoveries + 1);
  p.events = [
    ...p.events,
    {
      at,
      status: "monitoring" as const,
      kind: "recovered" as const,
      note: "A leitura de estado respondeu na segunda tentativa. A causa ainda não foi considerada corrigida.",
    },
  ].slice(-12);
  return result;
}
export function scopedProblems(store: ProblemStore, scope: string) {
  const selected = problemScope(scope);
  return store.entries
    .filter((e) => e.scope === selected || e.scope === APP_SCOPE)
    .sort((a, b) => b.lastAt.localeCompare(a.lastAt));
}
export function problemAdvice(p: Pick<Problem, "category">) {
  return {
    validation:
      "Confira o formato e os campos indicados. Ajuste a entrada e envie novamente; a central não altera seus dados automaticamente.",
    connection:
      "Confira a sessão e a conexão. Reabra o painel se necessário. Somente a leitura inicial de estado admite uma segunda tentativa automática.",
    storage:
      "Preserve seus backups e exporte o diagnóstico. Não removemos nem zeramos o cadastro para tentar recuperar o painel.",
    platform:
      "Resolva o aviso diretamente no Instagram. O registro do problema não libera a fila nem remove o aviso pendente.",
    uncertain:
      "Confira o resultado no próprio perfil antes de decidir uma nova ação. Não repetimos seguir, solicitações ou mensagens automaticamente.",
    interface:
      "Reabra o painel. Se a falha continuar, exporte o diagnóstico para reproduzir e corrigir o código.",
  }[p.category];
}
