import type { AccountType } from "./types.ts";

export const ACCOUNT_TYPE_LABELS: Record<AccountType, string> = {
  unknown: "Tipo não informado",
  personal: "Pessoal",
  business: "Profissional · comercial",
  creator: "Profissional · criador",
};
export function checkedAccountType(value: unknown): AccountType {
  if (value === undefined) return "unknown";
  if (typeof value === "string" && Object.hasOwn(ACCOUNT_TYPE_LABELS, value))
    return value as AccountType;
  throw new Error(
    "Tipo de conta inválido. Escolha pessoal, comercial, criador ou não informado.",
  );
}
export function accountTypeGuide(value?: AccountType) {
  const type = checkedAccountType(value);
  const professional = type === "business" || type === "creator";
  const guidance =
    type === "personal"
      ? "Contadores do perfil e relatórios locais disponíveis. Se o Instagram mostrar Insights nesta conta, você pode registrá-los ou importá-los. A sincronização pela API oficial exige uma conta profissional."
      : professional
        ? "Tipo profissional informado por você. Os Insights disponíveis dependem da conta e das permissões da Meta. A sincronização automática ainda não está implementada."
        : "Informe o tipo desta conta para ver a orientação correspondente. Os contadores do perfil e os relatórios locais continuam disponíveis.";
  return { type, label: ACCOUNT_TYPE_LABELS[type], professional, guidance };
}
