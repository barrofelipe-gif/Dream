import type { AccountWorkspace, ProfileSnapshot } from "./types.ts";

export function profileMetrics(
  account: AccountWorkspace,
  days: number,
  now = new Date(),
) {
  if (![7, 30].includes(days))
    throw new Error("Escolha um período de 7 ou 30 dias.");
  const start = new Date(now);
  start.setHours(0, 0, 0, 0);
  start.setDate(start.getDate() - days + 1);
  const boundary = start.getTime();
  const snapshots = account.snapshots
    .filter((s) => Date.parse(s.at) <= now.getTime())
    .sort((a, b) => Date.parse(a.at) - Date.parse(b.at));
  const latest = snapshots.at(-1);
  const measurements = snapshots.filter((s) => s.followers !== undefined);
  const previous =
    measurements.filter((s) => Date.parse(s.at) < boundary).at(-1) ||
    measurements.find((s) => Date.parse(s.at) >= boundary);
  const lastFollowers = measurements.at(-1);
  const growth =
    previous &&
    lastFollowers &&
    Date.parse(lastFollowers.at) >= boundary &&
    previous.id !== lastFollowers.id
      ? lastFollowers.followers! - previous.followers!
      : undefined;
  const events = account.data.audit.filter(
    (a) =>
      Date.parse(a.at) >= boundary &&
      Date.parse(a.at) <= now.getTime() &&
      !!account.username &&
      a.account === account.username,
  );
  const trend = Array.from({ length: days }, (_, index) => {
    const date = new Date(now);
    date.setHours(12, 0, 0, 0);
    date.setDate(date.getDate() - days + index + 1);
    const key = date.toDateString();
    const attempts = account.username
      ? Math.max(
          account.data.dailyAttempts[`${account.username}|${key}`] || 0,
          events.filter(
            (a) =>
              a.kind === "attempt" &&
              a.account === account.username &&
              new Date(a.at).toDateString() === key,
          ).length,
        )
      : 0;
    return {
      day: date.toISOString(),
      label: new Intl.DateTimeFormat("pt-BR", {
        day: "2-digit",
        month: "2-digit",
      }).format(date),
      attempts,
      confirmed: events.filter(
        (a) => a.kind === "followed" && new Date(a.at).toDateString() === key,
      ).length,
    };
  });
  const latestKnown = (
    key: "followers" | "following" | "posts",
  ): { value: number | undefined; snapshot?: ProfileSnapshot } => {
    const snapshot = snapshots.filter((s) => s[key] !== undefined).at(-1);
    return { value: snapshot?.[key], snapshot };
  };
  return {
    latest,
    followers: latestKnown("followers"),
    following: latestKnown("following"),
    posts: latestKnown("posts"),
    growth,
    growthFrom: previous?.at,
    growthTo: lastFollowers?.at,
    history: measurements.filter((s) => Date.parse(s.at) >= boundary),
    trend,
    attempts: trend.reduce((sum, d) => sum + d.attempts, 0),
    confirmed: events.filter((a) => a.kind === "followed").length,
    requested: events.filter((a) => a.kind === "requested").length,
    uncertain: events.filter((a) => a.kind === "uncertain").length,
  };
}
