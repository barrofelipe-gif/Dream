export type SourceKind =
  | "followers"
  | "following"
  | "commenters"
  | "likers"
  | "hashtag"
  | "location"
  | "import";
export type Stage =
  | "new"
  | "approved"
  | "queued"
  | "attempting"
  | "followed"
  | "requested"
  | "already"
  | "uncertain"
  | "failed"
  | "excluded";
export interface Campaign {
  id: string;
  name: string;
  kind: SourceKind;
  target: string;
  createdAt: string;
  archived: boolean;
}
export interface Provenance {
  campaignId: string;
  url: string;
  at: string;
}
export interface Candidate {
  id: string;
  username: string;
  avatarUrl?: string;
  platformId?: string;
  name: string;
  bio?: string;
  followers?: number;
  following?: number;
  posts?: number;
  isPrivate?: boolean;
  sources: Provenance[];
  stage: Stage;
  createdAt: string;
  updatedAt: string;
  note: string;
  queueAccount?: string;
  lastResult?: string;
}
export interface CandidateInput {
  username: string;
  avatarUrl?: string;
  platformId?: string;
  name?: string;
  bio?: string;
  followers?: number;
  following?: number;
  posts?: number;
  isPrivate?: boolean;
}
export interface Audit {
  id: string;
  at: string;
  kind: string;
  message: string;
  username?: string;
  account?: string;
}
export interface Settings {
  dailyLimit: number;
  intervalMinutes: number;
  sessionLimit?: number;
  hasPendingWarning?: boolean;
  startHour: string;
  endHour: string;
  exclusions: string[];
}
export interface Filters {
  query: string;
  campaignId: string;
  stage: string;
  minFollowers: string;
  maxFollowers: string;
  bio: string;
  publicOnly: boolean;
  requireKnown: boolean;
}
export interface Runtime {
  mode: "paused" | "running";
  account?: string;
  connectedAt?: string;
  connectionTabId?: number;
  pauseReason: string;
  nextRun?: number;
  workerTabId?: number;
  collectorTabId?: number;
  collectorCampaignId?: string;
  activeToken?: string;
  activeCandidateId?: string;
  activeExpiresAt?: number;
  collectorAllowedPaths?: string[];
  sessionAttempts?: number;
  sessionStartedAt?: string;
}
export interface AppState {
  version: 1;
  campaigns: Campaign[];
  candidates: Candidate[];
  audit: Audit[];
  settings: Settings;
  runtime: Runtime;
  dailyAttempts: Record<string, number>;
  lastAttempts?: Record<string, string>;
}
export type Command =
  | { type: "CREATE_CAMPAIGN"; name: string; kind: SourceKind; target: string }
  | { type: "ARCHIVE_CAMPAIGN"; id: string }
  | {
      type: "IMPORT";
      campaignId: string;
      candidates: CandidateInput[];
      url?: string;
    }
  | { type: "APPROVE"; ids: string[] }
  | { type: "QUEUE"; ids: string[] }
  | { type: "EXCLUDE"; ids: string[] }
  | { type: "REMOVE_FROM_QUEUE"; ids: string[] }
  | { type: "RETURN_TO_REVIEW"; id: string }
  | { type: "NOTE"; id: string; note: string }
  | { type: "SETTINGS"; settings: Settings }
  | { type: "APPLY_STARTER" }
  | { type: "REPORT_WARNING" }
  | { type: "PAUSE" }
  | { type: "DEMO" }
  | { type: "RESTORE"; data: unknown };
export type SpecialCommand =
  | { type: "CONNECT" }
  | { type: "REFRESH_METRICS" }
  | { type: "OPEN_SOURCE"; id: string }
  | { type: "START"; reviewed?: boolean };

export interface ProfileSnapshot {
  id: string;
  at: string;
  followers?: number;
  following?: number;
  posts?: number;
  source: "instagram" | "manual";
}
export type AccountType = "unknown" | "personal" | "business" | "creator";
export interface AccountWorkspace {
  id: string;
  username?: string;
  avatarUrl?: string;
  label: string;
  accountType?: AccountType;
  createdAt: string;
  verifiedAt?: string;
  snapshots: ProfileSnapshot[];
  insights?: InsightReport[];
  relationships?: RelationshipBook;
  acquisition?: AcquisitionBook;
  market?: MarketBook;
  performanceBenchmark?: PerformanceBenchmark;
  data: AppState;
}
export type AcquisitionChannel = "organic" | "paid" | "prospecting" | "unknown";
export type OriginEvidence = "manual" | "self_report" | "tracking";
export interface FollowerOrigin {
  username: string;
  channel: AcquisitionChannel;
  sourceLabel: string;
  campaignId?: string;
  evidence: OriginEvidence;
  note: string;
  updatedAt: string;
}
export interface ChannelResult {
  id: string;
  start: string;
  end: string;
  channel: "organic" | "paid";
  name: string;
  followers: number;
  attributionWindow: string;
  note: string;
  recordedAt: string;
}
export interface AcquisitionBook {
  version: 1;
  account: string;
  assignments: FollowerOrigin[];
  reports: ChannelResult[];
}
export interface RelationshipSnapshot {
  id: string;
  account: string;
  at: string;
  recordedAt: string;
  source: "manual" | "file";
  followers: string[];
  following: string[];
  followersComplete: boolean;
  followingComplete: boolean;
  note: string;
}
export type ProtectionReason =
  "friend" | "family" | "important" | "client" | "other";
export interface RelationshipProtection {
  username: string;
  reason: ProtectionReason;
  note: string;
  enabled: boolean;
  updatedAt: string;
}
export interface RelationshipBook {
  version: 1;
  snapshots: RelationshipSnapshot[];
  protections: RelationshipProtection[];
}
export type ContentKind = "post" | "carousel" | "reel" | "story" | "live";
export type StoryMedia = "photo" | "video";
export type StorySticker =
  "none" | "question_box" | "poll" | "quiz" | "slider" | "link" | "other";
export interface InsightContent {
  id: string;
  kind: ContentKind;
  title: string;
  url?: string;
  publishedAt?: string;
  observationHours?: number;
  theme?: string;
  hook?: string;
  cta?: string;
  storyMedia?: StoryMedia;
  storySticker?: StorySticker;
  metrics: Record<string, number>;
}
export interface InsightAudience {
  audience: "followers" | "reached" | "engaged";
  dimension:
    "country" | "city" | "age" | "gender" | "hour" | "day" | "follower_status";
  unit: "count" | "percent";
  values: { label: string; value: number }[];
}
export interface InsightReport {
  id: string;
  account: string;
  start: string;
  end: string;
  recordedAt: string;
  source: "manual" | "file";
  coverage: "organic" | "paid" | "combined" | "unknown";
  contentWindow: "period" | "lifetime";
  note: string;
  metrics: Record<string, number>;
  content: InsightContent[];
  audience: InsightAudience[];
}
export type MarketModel = "wholesale" | "retail" | "both" | "unknown";
export type MarketPattern =
  "demo" | "mix" | "backstage" | "faq" | "proof" | "launch" | "other";
export interface MarketProfile {
  sector: string;
  model: MarketModel;
  audience: string;
  bio: string;
  updatedAt: string;
}
export interface PerformanceBenchmark {
  account: string;
  sector: string;
  model: Exclude<MarketModel, "unknown">;
  metric: "interactions_per_reach";
  value: number;
  coverage: Exclude<InsightReport["coverage"], "unknown">;
  start: string;
  end: string;
  sampleSize: number;
  sourceTitle: string;
  sourceUrl: string;
  note: string;
  updatedAt: string;
}
export interface MarketReference {
  id: string;
  url: string;
  creator: string;
  sector: string;
  model: MarketModel;
  kind: ContentKind | "ad" | "article";
  pattern: MarketPattern;
  title: string;
  hook: string;
  cta: string;
  note: string;
  distribution: "organic" | "paid" | "unknown";
  publishedAt?: string;
  observedAt: string;
  windowHours?: number;
  metrics: { views?: number; likes?: number; comments?: number };
  source: "manual" | "file" | "instagram";
  archived: boolean;
  updatedAt: string;
}
export interface MarketExperiment {
  id: string;
  referenceId: string;
  title: string;
  hypothesis: string;
  recipe: string;
  cta: string;
  goal: "views" | "total_interactions" | "follows";
  windowHours: number;
  status: "idea" | "testing" | "measured";
  ownUrl: string;
  note: string;
  updatedAt: string;
}
export interface MarketBook {
  version: 1;
  account: string;
  profile?: MarketProfile;
  references: MarketReference[];
  experiments: MarketExperiment[];
}
export interface MarketPageReading {
  url: string;
  kind: "profile" | "post" | "reel";
  creator: string;
  text: string;
  metrics: MarketReference["metrics"];
  observedAt: string;
}
export interface AccountStore {
  version: 2;
  activeId: string;
  accounts: AccountWorkspace[];
  sessionUsername?: string;
  sessionCheckedAt?: string;
}
export type AccountCommand =
  | { type: "SAVE_PERFORMANCE_BENCHMARK"; data: unknown }
  | { type: "REMOVE_PERFORMANCE_BENCHMARK" }
  | { type: "SET_MARKET_PROFILE"; data: unknown }
  | { type: "SAVE_MARKET_REFERENCES"; data: unknown }
  | { type: "ARCHIVE_MARKET_REFERENCE"; id: string; archived: boolean }
  | { type: "SAVE_MARKET_EXPERIMENT"; data: unknown }
  | {
      type: "ADD_ACCOUNT";
      username: string;
      label?: string;
      accountType?: AccountType;
    }
  | { type: "SELECT_ACCOUNT"; id: string }
  | { type: "RENAME_ACCOUNT"; id: string; label: string }
  | { type: "SET_ACCOUNT_TYPE"; id: string; accountType: AccountType }
  | { type: "IMPORT_INSIGHTS"; data: unknown }
  | { type: "RECORD_INSIGHTS"; data: unknown }
  | { type: "REMOVE_INSIGHT_REPORT"; id: string }
  | { type: "RECORD_RELATIONSHIPS"; data: unknown }
  | { type: "SET_FOLLOWER_ORIGIN"; data: unknown }
  | { type: "IMPORT_FOLLOWER_ORIGINS"; data: unknown }
  | { type: "RECORD_CHANNEL_RESULT"; data: unknown }
  | { type: "REMOVE_CHANNEL_RESULT"; id: string }
  | { type: "REMOVE_RELATIONSHIP_SNAPSHOT"; id: string }
  | {
      type: "PROTECT_RELATIONSHIP";
      username: string;
      reason: ProtectionReason;
      note: string;
    }
  | { type: "UNPROTECT_RELATIONSHIP"; username: string }
  | {
      type: "RECORD_SNAPSHOT";
      followers?: number;
      following?: number;
      posts?: number;
      at?: string;
    };
export const SOURCE_LABELS: Record<SourceKind, string> = {
  followers: "Seguidores de um perfil",
  following: "Seguidos de um perfil",
  commenters: "Comentários de uma publicação",
  likers: "Curtidas de uma publicação",
  hashtag: "Hashtag",
  location: "Localização",
  import: "Lista importada",
};
export const STAGE_LABELS: Record<Stage, string> = {
  new: "Para revisar",
  approved: "Aprovado",
  queued: "Na fila",
  attempting: "Em execução",
  followed: "Seguindo",
  requested: "Solicitado",
  already: "Já seguia",
  uncertain: "Revisar resultado",
  failed: "Não realizado",
  excluded: "Excluído",
};
