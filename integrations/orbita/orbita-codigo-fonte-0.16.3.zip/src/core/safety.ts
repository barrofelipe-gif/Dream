import type { AppState, Settings } from "./types.ts";

// Product defaults for a small, reviewable pilot, not Instagram-approved limits.
export const STARTER = {
  dailyLimit: 5,
  sessionLimit: 5,
  intervalMinutes: 15,
} as const;
export const sessionLimit = (settings: Settings): number =>
  settings.sessionLimit ?? STARTER.sessionLimit;
export function lastAttemptTime(state: AppState): number {
  const account = state.runtime.account;
  if (!account) return 0;
  const stored = Date.parse(state.lastAttempts?.[`@${account}`] || "") || 0;
  return state.audit.reduce(
    (latest, a) =>
      a.kind === "attempt" && a.account === account
        ? Math.max(latest, Date.parse(a.at) || 0)
        : latest,
    stored,
  );
}
export const intervalReadyAt = (state: AppState): number => {
  const last = lastAttemptTime(state);
  return last ? last + state.settings.intervalMinutes * 60000 : 0;
};
export const pendingWarningReason = (settings: Settings): string | null =>
  settings.hasPendingWarning
    ? "Há um aviso ou pedido de verificação pendente. Confira a conta no Instagram e só libere a execução nas Preferências depois que a situação estiver resolvida."
    : null;
export function budgetStopReason(
  state: AppState,
  dailyUsed: number,
): string | null {
  return (
    pendingWarningReason(state.settings) ||
    (dailyUsed >= state.settings.dailyLimit
      ? "O teto diário de tentativas foi alcançado. A Órbita não aumenta esse teto automaticamente."
      : null) ||
    ((state.runtime.sessionAttempts || 0) >= sessionLimit(state.settings)
      ? `Lote encerrado após ${state.runtime.sessionAttempts} tentativas. Confira os resultados e a conta antes de iniciar outro lote.`
      : null)
  );
}
export interface GuidanceNotice {
  id: string;
  severity: "info" | "attention" | "stop";
  title: string;
  text: string;
}
export function safetyAssessment(state: AppState, dailyUsed: number) {
  const limit = sessionLimit(state.settings);
  const remaining = Math.max(0, state.settings.dailyLimit - dailyUsed);
  const queued = state.candidates.filter((c) =>
    ["queued", "attempting"].includes(c.stage),
  ).length;
  const sources = state.campaigns.filter(
    (c) => !c.archived && c.kind !== "import",
  ).length;
  const sessionUsed = state.runtime.sessionAttempts || 0;
  const remainingSession =
    state.runtime.mode === "running" ? Math.max(0, limit - sessionUsed) : limit;
  const nextBatch = state.settings.hasPendingWarning
    ? 0
    : Math.min(queued, remaining, remainingSession);
  const expanded =
    state.settings.dailyLimit > STARTER.dailyLimit ||
    limit > STARTER.sessionLimit ||
    state.settings.intervalMinutes < STARTER.intervalMinutes;
  const notices: GuidanceNotice[] = [];
  if (state.settings.hasPendingWarning)
    notices.push({
      id: "warning",
      severity: "stop",
      title: "Interrompa e confira o Instagram",
      text: "Existe um aviso ou pedido de verificação marcado como pendente. Não insista, não execute outra ferramenta para continuar e não use um prazo fixo como garantia de liberação.",
    });
  if (dailyUsed >= state.settings.dailyLimit)
    notices.push({
      id: "daily",
      severity: "stop",
      title: "Teto de hoje atingido",
      text: `${dailyUsed} tentativas registradas pela Órbita. A mudança de dia no contador não comprova que a conta está liberada ou sem restrições.`,
    });
  else if (
    dailyUsed > 0 &&
    remaining <= Math.max(1, Math.floor(state.settings.dailyLimit * 0.2))
  )
    notices.push({
      id: "near",
      severity: "attention",
      title: "Você está perto do teto escolhido",
      text: `Restam ${remaining} tentativas hoje. Conte também as ações que você faz pelo celular ou por outras ferramentas; a Órbita não consegue medi-las.`,
    });
  if (expanded)
    notices.push({
      id: "pace",
      severity: "attention",
      title: "Seu ritmo está acima do começo guiado",
      text: `Você configurou ${state.settings.dailyLimit}/dia, lotes de ${limit} e intervalo de ${state.settings.intervalMinutes} min. Isso permite mais volume ou menos pausa que o piloto de 5/dia, lotes de 5 e 15 min. Esses valores são escolhas do aplicativo, não faixas de risco comprovadas.`,
    });
  if (queued > remaining)
    notices.push({
      id: "backlog",
      severity: "info",
      title: "Uma fila grande não será executada de uma vez",
      text: `Há ${queued} perfis na fila e espaço para até ${remaining} tentativas hoje. O restante aguarda; adicionar perfis não aumenta o teto diário.`,
    });
  if (sources > 1)
    notices.push({
      id: "sources",
      severity: "info",
      title: `${sources} fontes de coleta ativas`,
      text: "Comece com 1 perfil de referência para avaliar a qualidade. Mais fontes podem exigir mais consultas e rolagens, mas não aumentam o limite de seguir. Não há um número de fontes que garanta ausência de restrições.",
    });
  return {
    dailyUsed,
    remaining,
    queued,
    sources,
    sessionUsed,
    sessionLimit: limit,
    nextBatch,
    expanded,
    notices,
    label: state.settings.hasPendingWarning
      ? "Conferência necessária"
      : expanded
        ? "Reveja o ritmo configurado"
        : "Começo guiado configurado",
  };
}
