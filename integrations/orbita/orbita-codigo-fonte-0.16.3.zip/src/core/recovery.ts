export const transientReadError = (error: unknown) =>
  !(error instanceof Error && error.name === "OrbitaResponseError") &&
  /receiving end|could not establish connection|message port|port closed|context invalidated|networkerror|timed? ?out|timeout/i.test(
    error instanceof Error ? error.message : String(error),
  );
// Deliberately excludes every mutation and every Instagram page/action request.
export async function recoverStateRead<T>(
  operation: string,
  request: () => Promise<T>,
  hooks: {
    report: (error: unknown) => Promise<string | undefined>;
    recovered: (id: string) => Promise<void>;
  },
  wait: (ms: number) => Promise<void> = (ms) =>
    new Promise((resolve) => setTimeout(resolve, ms)),
): Promise<T> {
  if (operation !== "GET_STATE")
    throw new Error("A recuperação automática só aceita leitura de estado.");
  try {
    return await request();
  } catch (first) {
    let id: string | undefined;
    try {
      id = await hooks.report(first);
    } catch {
      /* Diagnostics cannot mask the operation. */
    }
    if (!transientReadError(first)) throw first;
    await wait(250);
    let value: T;
    try {
      value = await request();
    } catch (second) {
      try {
        await hooks.report(second);
      } catch {
        /* Preserve the actual operation error. */
      }
      throw second;
    }
    if (id)
      try {
        await hooks.recovered(id);
      } catch {
        /* A successful read remains successful. */
      }
    return value;
  }
}
