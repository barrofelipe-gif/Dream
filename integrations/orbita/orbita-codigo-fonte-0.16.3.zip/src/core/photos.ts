// Keep the image URL seen in the page; never guess an endpoint from a username.
export function profilePhotoUrl(value: unknown): string | undefined {
  if (typeof value !== "string" || value.length > 4096) return undefined;
  try {
    const url = new URL(value.trim());
    if (
      url.protocol !== "https:" ||
      url.username ||
      url.password ||
      (url.port && url.port !== "443") ||
      !["cdninstagram.com", "fbcdn.net"].some(
        (host) => url.hostname === host || url.hostname.endsWith(`.${host}`),
      )
    )
      return undefined;
    url.hash = "";
    return url.href;
  } catch {
    return undefined;
  }
}
