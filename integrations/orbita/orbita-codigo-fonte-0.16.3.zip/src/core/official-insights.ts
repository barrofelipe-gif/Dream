import { normalizeUsername } from "./domain.ts";
import { localDay, validateInsightReport } from "./insights.ts";
import { hostedSessionMatches } from "./hosted-session.ts";
import type { InsightReport } from "./types.ts";

export interface OfficialAccountChoice {
  id: string;
  username: string;
  loja: string;
}
export interface OfficialInsightResult {
  reports: InsightReport[];
  warnings: string[];
  source: {
    username: string;
    loja: string;
    lastCollectedAt: string | null;
    daysAvailable: number;
    daysExpected: number;
    contentAvailable: number;
    readOnly: true;
  };
}
const object = (value: unknown): Record<string, unknown> => {
  if (!value || typeof value !== "object" || Array.isArray(value))
    throw new Error("A resposta de métricas do app não é válida.");
  return value as Record<string, unknown>;
};
export function officialRange(start: string, end: string, today = localDay()) {
  for (const value of [start, end]) {
    if (
      !/^\d{4}-\d{2}-\d{2}$/.test(value) ||
      !Number.isFinite(Date.parse(`${value}T12:00:00Z`)) ||
      new Date(`${value}T12:00:00Z`).toISOString().slice(0, 10) !== value
    )
      throw new Error("Informe datas válidas para consultar as métricas.");
  }
  if (
    start > end ||
    end >= today ||
    (Date.parse(end) - Date.parse(start)) / 86400000 >= 90
  )
    throw new Error(
      "Escolha um período encerrado, com até 90 dias. O dia atual ainda não está completo.",
    );
}
export function officialChoices(
  value: unknown,
  username: string,
): OfficialAccountChoice[] {
  if (!Array.isArray(value)) return [];
  return value.slice(0, 20).flatMap((raw) => {
    if (!raw || typeof raw !== "object") return [];
    const item = raw as Record<string, unknown>;
    if (
      typeof item.id !== "string" ||
      !item.id ||
      item.id.length > 150 ||
      typeof item.username !== "string" ||
      normalizeUsername(item.username) !== username ||
      typeof item.loja !== "string" ||
      item.loja.length > 80
    )
      return [];
    return [{ id: item.id, username, loja: item.loja }];
  });
}
export function officialInsightResult(
  value: unknown,
  username: string,
  start: string,
  end: string,
  userScope: string | null | undefined,
): OfficialInsightResult {
  const data = object(value);
  if (
    !hostedSessionMatches({ ready: true, userScope: data.userScope }, userScope)
  )
    throw new Error(
      "O usuário do app mudou. Reabra a Órbita antes de importar métricas.",
    );
  const source = object(data.source);
  if (
    source.type !== "app-official-collection" ||
    source.readOnly !== true ||
    source.username !== username ||
    typeof source.loja !== "string" ||
    source.loja.length > 80
  )
    throw new Error(
      "A origem das métricas não corresponde à conta selecionada.",
    );
  if (!Array.isArray(data.reports) || data.reports.length > 120)
    throw new Error("A resposta excede a quantidade de relatórios permitida.");
  const reports = data.reports.map((raw) => {
    const report = validateInsightReport(raw, username, "file");
    if (report.start !== start || report.end !== end)
      throw new Error(
        "O app retornou métricas de outro período. Nenhum relatório foi importado.",
      );
    return report;
  });
  const count = (key: string) => {
    const n = source[key];
    if (typeof n !== "number" || !Number.isSafeInteger(n) || n < 0)
      throw new Error("O resumo da coleta está incompleto.");
    return n;
  };
  const last = source.lastCollectedAt;
  if (
    last !== null &&
    (typeof last !== "string" || !Number.isFinite(Date.parse(last)))
  )
    throw new Error("A data da coleta do app não é válida.");
  return {
    reports,
    warnings: Array.isArray(data.warnings)
      ? data.warnings
          .filter((w): w is string => typeof w === "string")
          .slice(0, 30)
          .map((w) => w.slice(0, 700))
      : [],
    source: {
      username,
      loja: source.loja,
      lastCollectedAt: last as string | null,
      daysAvailable: count("daysAvailable"),
      daysExpected: count("daysExpected"),
      contentAvailable: count("contentAvailable"),
      readOnly: true,
    },
  };
}
