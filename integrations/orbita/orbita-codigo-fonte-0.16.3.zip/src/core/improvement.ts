import {
  INSIGHT_METRICS,
  insightSummary,
  localDay,
  metricSpec,
} from "./insights.ts";
import {
  performanceReview,
  performanceTone,
  recoveryTest,
} from "./performance.ts";
import { marketUrl } from "./market.ts";
import type {
  AccountWorkspace,
  InsightReport,
  PerformanceBenchmark,
} from "./types.ts";

const DAY = 86400000;
const days = (r: { start: string; end: string }) =>
  (Date.parse(r.end) - Date.parse(r.start)) / DAY + 1;
const plain = (text: string) =>
  text
    .normalize("NFD")
    .replace(/[\u0300-\u036f]/g, "")
    .trim()
    .toLowerCase();
const delta = (a: number, b: number) =>
  Math.abs(a - b) <= Number.EPSILON * Math.max(1, a, b) * 8 ? 0 : a - b;
const amount = (r: InsightReport, key: string) =>
  key === "engagement_rate" ? insightSummary(r, []).rate : r.metrics[key];
const label = (key: string) =>
  key === "engagement_rate"
    ? "Engajamento · interações / alcance"
    : metricSpec(key)!.label;
const keys = [
  "engagement_rate",
  ...INSIGHT_METRICS.filter((m) => performanceTone(m.key, 1) !== "neutral").map(
    (m) => m.key,
  ),
];

function fail(message: string): never {
  throw new Error(message);
}
function date(value: unknown): string {
  if (
    typeof value !== "string" ||
    !/^\d{4}-\d{2}-\d{2}$/.test(value) ||
    !Number.isFinite(Date.parse(value)) ||
    new Date(value).toISOString().slice(0, 10) !== value ||
    value < "2020-01-01" ||
    value > localDay()
  )
    fail("Use datas reais, de 2020 até hoje, para a referência.");
  return value;
}
export function validatePerformanceBenchmark(
  input: unknown,
  account: string,
): PerformanceBenchmark {
  if (!input || typeof input !== "object" || Array.isArray(input))
    fail("Informe uma referência do setor válida.");
  const raw = input as Record<string, unknown>;
  if (!account || raw.account !== account)
    fail("A referência precisa pertencer à conta selecionada.");
  const text = (key: string, max: number, required = true) => {
    const value = raw[key];
    if (
      typeof value !== "string" ||
      value.length > max ||
      (required && !value.trim())
    )
      fail("Preencha setor, fonte e textos dentro dos limites informados.");
    return value.trim();
  };
  const sector = text("sector", 80),
    sourceTitle = text("sourceTitle", 150),
    note = text("note", 1000, false);
  if (
    typeof raw.model !== "string" ||
    !["wholesale", "retail", "both"].includes(raw.model)
  )
    fail("Informe o modelo do negócio antes da comparação com o setor.");
  if (raw.metric !== "interactions_per_reach")
    fail(
      "A referência aceita somente interações divididas pelo alcance. Taxas por seguidores ou visualizações não são equivalentes.",
    );
  if (
    typeof raw.coverage !== "string" ||
    !["organic", "paid", "combined"].includes(raw.coverage)
  )
    fail("Informe a cobertura da referência: orgânico, pago ou ambos.");
  if (
    typeof raw.value !== "number" ||
    !Number.isFinite(raw.value) ||
    raw.value < 0 ||
    raw.value > 1e6
  )
    fail("Informe uma taxa de referência válida, a partir de zero.");
  if (
    !Number.isSafeInteger(raw.sampleSize) ||
    (raw.sampleSize as number) < 5 ||
    (raw.sampleSize as number) > 1e7
  )
    fail(
      "Informe uma amostra de pelo menos 5 contas. Esse mínimo não garante representatividade.",
    );
  const start = date(raw.start),
    end = date(raw.end);
  if (start > end) fail("O início da referência deve vir antes do fim.");
  const updatedAt = raw.updatedAt;
  if (
    typeof updatedAt !== "string" ||
    !Number.isFinite(Date.parse(updatedAt)) ||
    Date.parse(updatedAt) > Date.now() + 60000
  )
    fail("Data de registro da referência inválida.");
  return {
    account,
    sector,
    sourceTitle,
    note,
    model: raw.model as PerformanceBenchmark["model"],
    metric: "interactions_per_reach",
    value: raw.value,
    coverage: raw.coverage as PerformanceBenchmark["coverage"],
    start,
    end,
    sampleSize: raw.sampleSize as number,
    sourceUrl: marketUrl(text("sourceUrl", 2048)),
    updatedAt: new Date(updatedAt).toISOString(),
  };
}
export function savePerformanceBenchmark(
  account: AccountWorkspace,
  input: unknown,
): void {
  const raw =
    input && typeof input === "object"
      ? (input as Record<string, unknown>)
      : {};
  const benchmark = validatePerformanceBenchmark(
    { ...raw, updatedAt: new Date().toISOString() },
    account.username || "",
  );
  const profile = account.market?.profile;
  if (
    !profile ||
    plain(profile.sector) !== plain(benchmark.sector) ||
    profile.model !== benchmark.model
  )
    fail("Defina no Radar o mesmo setor e modelo informados na referência.");
  account.performanceBenchmark = benchmark;
}

export interface ImprovementSignal {
  basis: "previous" | "history" | "sector";
  reference: number;
  difference: number;
  relative?: number;
  tone: ReturnType<typeof performanceTone>;
  samples: number;
  start: string;
  end: string;
  method: string;
  sourceUrl?: string;
  sourceTitle?: string;
}
export interface ImprovementMetric {
  key: string;
  label: string;
  unit: "count" | "percent" | "seconds";
  current: number;
  signals: ImprovementSignal[];
  action: ReturnType<typeof recoveryTest>;
}
export interface ImprovementReview {
  blocked?: string;
  priorities: ImprovementMetric[];
  strengths: ImprovementMetric[];
  stable: ImprovementMetric[];
  historyPeriods: number;
  historyStart?: string;
  historyEnd?: string;
  market: {
    status: "missing" | "incompatible" | "ready";
    reason: string;
    benchmark?: PerformanceBenchmark;
  };
}

export function improvementReview(
  account: AccountWorkspace,
  report: InsightReport,
  today = localDay(),
): ImprovementReview {
  const previous = performanceReview(report, account.insights || [], today);
  const result: ImprovementReview = {
    priorities: [],
    strengths: [],
    stable: [],
    historyPeriods: 0,
    market: {
      status: "missing",
      reason:
        "Cadastre uma referência do seu setor com fonte e a mesma fórmula. Nenhum número de mercado foi presumido.",
    },
  };
  if (report.account !== account.username) {
    result.blocked = "O relatório não pertence à conta selecionada.";
    return result;
  }
  if (
    report.end >= today ||
    report.coverage === "unknown" ||
    report.contentWindow !== "period"
  ) {
    result.blocked =
      previous.reason ||
      "Use um período encerrado, com cobertura conhecida e valores do período.";
    return result;
  }

  // Latest revision per interval; choose at most six disjoint, equally long periods.
  const revisions = new Map<string, InsightReport>();
  for (const r of account.insights || []) {
    if (
      r.account !== report.account ||
      r.coverage !== report.coverage ||
      r.contentWindow !== "period" ||
      r.end >= report.start ||
      days(r) !== days(report) ||
      Date.parse(report.start) - Date.parse(r.end) > 180 * DAY
    )
      continue;
    const id = r.start + "/" + r.end,
      existing = revisions.get(id);
    if (
      !existing ||
      r.recordedAt > existing.recordedAt ||
      (r.recordedAt === existing.recordedAt && r.id > existing.id)
    )
      revisions.set(id, r);
  }
  const history: InsightReport[] = [];
  let boundary = report.start;
  for (const r of [...revisions.values()].sort(
    (a, b) => b.end.localeCompare(a.end) || b.start.localeCompare(a.start),
  )) {
    if (r.end >= boundary) continue;
    history.push(r);
    boundary = r.start;
    if (history.length === 6) break;
  }
  result.historyPeriods = history.length;
  result.historyStart = history.at(-1)?.start;
  result.historyEnd = history[0]?.end;

  const saved = account.performanceBenchmark;
  if (saved) {
    const profile = account.market?.profile;
    let reason = "";
    if (saved.account !== report.account)
      reason = "A referência não pertence à conta selecionada.";
    else if (
      !profile ||
      plain(saved.sector) !== plain(profile.sector) ||
      saved.model !== profile.model
    )
      reason =
        "A referência foi cadastrada para outro setor ou modelo. Revise o Radar ou substitua a fonte.";
    else if (saved.coverage !== report.coverage)
      reason =
        "A referência e o relatório têm coberturas diferentes (orgânico, pago ou ambos).";
    else if (days(saved) !== days(report))
      reason =
        "A referência e o relatório precisam medir intervalos com a mesma duração.";
    else if (saved.end >= today || saved.end > report.end)
      reason =
        "A referência é de um período ainda aberto ou posterior ao relatório selecionado.";
    else if (Date.parse(report.end) - Date.parse(saved.end) > 180 * DAY)
      reason =
        "A referência está mais de 180 dias atrás do relatório; atualize a fonte.";
    else if (amount(report, "engagement_rate") === undefined)
      reason =
        "Faltam interações e alcance maior que zero para calcular a taxa desta conta.";
    result.market = {
      status: reason ? "incompatible" : "ready",
      reason:
        reason ||
        "Referência cadastrada do setor, com fórmula e recorte declarados. Não é uma média de todo o mercado nem uma fonte verificada automaticamente.",
      benchmark: saved,
    };
  }

  for (const key of keys) {
    const current = amount(report, key);
    if (current === undefined) continue;
    const signals: ImprovementSignal[] = [];
    const signal = (
      reference: number,
      base: Omit<
        ImprovementSignal,
        "reference" | "difference" | "relative" | "tone"
      >,
    ) => {
      const difference = delta(current, reference);
      signals.push({
        ...base,
        reference,
        difference,
        relative: reference > 0 ? (difference / reference) * 100 : undefined,
        tone: performanceTone(key, difference),
      });
    };
    const prior = previous.comparisons.find((c) => c.key === key);
    if (prior && previous.previous)
      signal(prior.before, {
        basis: "previous",
        samples: 1,
        start: previous.previous.start,
        end: previous.previous.end,
        method:
          "Mesmo período imediatamente anterior: conta, duração e cobertura iguais.",
      });
    if (key === "engagement_rate") {
      const valid = history.filter(
        (r) =>
          r.metrics.reach > 0 && r.metrics.total_interactions !== undefined,
      );
      if (valid.length >= 3) {
        const reach = valid.reduce((sum, r) => sum + r.metrics.reach, 0),
          interactions = valid.reduce(
            (sum, r) => sum + r.metrics.total_interactions,
            0,
          );
        signal((interactions / reach) * 100, {
          basis: "history",
          samples: valid.length,
          start: valid.at(-1)!.start,
          end: valid[0].end,
          method:
            "Taxa histórica ponderada: soma de interações ÷ soma de alcance nos períodos. Não é a média simples das taxas.",
        });
      }
    } else if (metricSpec(key)?.unit === "count") {
      const valid = history.filter((r) => r.metrics[key] !== undefined);
      if (valid.length >= 3)
        signal(
          valid.reduce((sum, r) => sum + r.metrics[key], 0) / valid.length,
          {
            basis: "history",
            samples: valid.length,
            start: valid.at(-1)!.start,
            end: valid[0].end,
            method:
              "Média dos totais de períodos de mesma duração, conta e cobertura, sem sobreposição. Ausências não são zero.",
          },
        );
    }
    if (key === "engagement_rate" && saved && result.market.status === "ready")
      signal(saved.value, {
        basis: "sector",
        samples: saved.sampleSize,
        start: saved.start,
        end: saved.end,
        method:
          "Taxa informada: interações ÷ alcance × 100, no agregado da conta. Amostra e metodologia declaradas no cadastro.",
        sourceUrl: saved.sourceUrl,
        sourceTitle: saved.sourceTitle,
      });
    const metric: ImprovementMetric = {
      key,
      label: label(key),
      unit: key === "engagement_rate" ? "percent" : metricSpec(key)!.unit,
      current,
      signals,
      action: recoveryTest(key),
    };
    if (signals.some((s) => s.tone === "negative"))
      result.priorities.push(metric);
    else if (signals.some((s) => s.tone === "positive"))
      result.strengths.push(metric);
    else if (signals.length) result.stable.push(metric);
  }
  const order = [
    "engagement_rate",
    "total_interactions",
    "reach",
    "follows",
    "accounts_engaged",
    "profile_visits",
    "profile_links_taps",
  ];
  result.priorities.sort(
    (a, b) =>
      (order.indexOf(a.key) < 0 ? 100 : order.indexOf(a.key)) -
      (order.indexOf(b.key) < 0 ? 100 : order.indexOf(b.key)),
  );
  return result;
}
