import type { ContentKind, InsightReport } from "./types.ts";
import { STORY_MEDIA_LABELS, STORY_STICKER_LABELS } from "./insights.ts";
import { growthAnalysis, median } from "./growth.ts";
import type { ContentPerformance, GrowthObjective } from "./growth.ts";

export const WEEKDAYS = [
  "Domingo",
  "Segunda-feira",
  "Terça-feira",
  "Quarta-feira",
  "Quinta-feira",
  "Sexta-feira",
  "Sábado",
];
export function publicationClock(iso: string, timeZone: string) {
  const parts = new Intl.DateTimeFormat("en-CA", {
    timeZone,
    year: "numeric",
    month: "2-digit",
    day: "2-digit",
    hour: "2-digit",
    hourCycle: "h23",
  }).formatToParts(new Date(iso));
  const read = (key: string) => parts.find((p) => p.type === key)!.value;
  const date = `${read("year")}-${read("month")}-${read("day")}`;
  return {
    date,
    hour: Number(read("hour")),
    weekday: new Date(`${date}T12:00:00Z`).getUTCDay(),
  };
}
export interface EvidenceGroup {
  key: string;
  label: string;
  n: number;
  otherN: number;
  dates: number;
  otherDates: number;
  value: number;
  reference?: number;
  qualified: boolean;
}
export function contentGuidance(
  report: InsightReport,
  options: {
    objective: GrowthObjective;
    window: number | "all";
    format: ContentKind | "all";
    timeZone: string;
  },
) {
  // Validate the selected zone even for an empty report. Never silently change time zones.
  new Intl.DateTimeFormat("en", { timeZone: options.timeZone });
  const analysis = growthAnalysis(report, options);
  const metric = analysis.patternObjective;
  const eligible = analysis.cohort.filter((row) => row[metric] !== undefined);
  const clock = new Map(
    eligible
      .filter((r) => r.content.publishedAt)
      .map((row) => [
        row.content.id,
        publicationClock(row.content.publishedAt!, options.timeZone),
      ]),
  );
  const baseAllowed = !analysis.reasons.length;
  const dates = (rows: ContentPerformance[]) =>
    new Set(
      rows.flatMap((r) => {
        const c = clock.get(r.content.id);
        return c ? [c.date] : [];
      }),
    ).size;
  function groups(
    rows: ContentPerformance[],
    keyOf: (r: ContentPerformance) => string | undefined,
    labelOf: (key: string) => string,
    allowed: boolean,
  ): EvidenceGroup[] {
    const known = rows.filter((r) => keyOf(r) !== undefined);
    return [...new Set(known.map((r) => keyOf(r)!))]
      .map((key) => {
        const members = known.filter((r) => keyOf(r) === key),
          others = known.filter((r) => keyOf(r) !== key);
        return {
          key,
          label: labelOf(key),
          n: members.length,
          otherN: others.length,
          dates: dates(members),
          otherDates: dates(others),
          value: median(members.map((r) => r[metric]!))!,
          reference: median(others.map((r) => r[metric]!)),
          qualified:
            allowed &&
            members.length >= 3 &&
            others.length >= 3 &&
            dates(members) >= 2 &&
            dates(others) >= 2,
        };
      })
      .sort(
        (a, b) => b.value - a.value || b.n - a.n || a.key.localeCompare(b.key),
      );
  }
  const hourGroups = groups(
    eligible,
    (r) => {
      const c = clock.get(r.content.id);
      return c ? String(Math.floor(c.hour / 2) * 2) : undefined;
    },
    (key) =>
      `${key.padStart(2, "0")}h–${String(Number(key) + 2).padStart(2, "0")}h`,
    baseAllowed && options.format !== "all",
  );
  const dayGroups = groups(
    eligible,
    (r) => {
      const c = clock.get(r.content.id);
      return c ? String(c.weekday) : undefined;
    },
    (key) => WEEKDAYS[Number(key)],
    baseAllowed && options.format !== "all",
  );
  const stories = eligible.filter((r) => r.content.kind === "story");
  const mediaGroups = groups(
    stories,
    (r) => r.content.storyMedia,
    (key) => STORY_MEDIA_LABELS[key as keyof typeof STORY_MEDIA_LABELS],
    baseAllowed,
  );
  const stickerGroups = groups(
    stories,
    (r) => r.content.storySticker,
    (key) => STORY_STICKER_LABELS[key as keyof typeof STORY_STICKER_LABELS],
    baseAllowed,
  );
  const winner = (items: EvidenceGroup[]) =>
    items.find(
      (g) =>
        g.qualified &&
        g.reference !== undefined &&
        g.value > g.reference &&
        g.value > 0,
    );
  return {
    metric,
    eligible: eligible.length,
    stories: stories.length,
    missingStoryMedia: stories.filter((r) => !r.content.storyMedia).length,
    missingStorySticker: stories.filter((r) => !r.content.storySticker).length,
    missingTimestamp: eligible.filter((r) => !r.content.publishedAt).length,
    hourGroups,
    dayGroups,
    mediaGroups,
    stickerGroups,
    hourBest: winner(hourGroups),
    dayBest: winner(dayGroups),
    mediaBest: winner(mediaGroups),
    stickerBest: winner(stickerGroups),
    reasons: [
      ...analysis.reasons,
      ...(options.format === "all"
        ? [
            "Escolha um formato para orientar horários sem misturar Stories, Reels e feed.",
          ]
        : []),
    ],
  };
}
