import { uid } from "./domain.ts";
import { csvRows } from "./io.ts";
import { relationshipAnalysis, relationshipUsername } from "./relationships.ts";
import { localDay } from "./insights.ts";
import type {
  AccountWorkspace,
  AcquisitionBook,
  AcquisitionChannel,
  ChannelResult,
  FollowerOrigin,
} from "./types.ts";

export const ACQUISITION_CHANNELS = {
  organic: "Orgânico",
  paid: "Anúncio",
  prospecting: "Prospecção",
  unknown: "Origem desconhecida",
} as const;
export const ORIGIN_EVIDENCE = {
  manual: "Classificação manual",
  self_report: "Pessoa informou",
  tracking: "Registro de atendimento/rastreamento",
} as const;
function fail(message: string): never {
  throw new Error(message);
}
const object = (value: unknown): Record<string, unknown> =>
  value && typeof value === "object" && !Array.isArray(value)
    ? (value as Record<string, unknown>)
    : fail("Os dados de origem devem conter objetos válidos.");
const text = (value: unknown, max: number, label: string, required = false) => {
  if (value === undefined && !required) return "";
  if (
    typeof value !== "string" ||
    value.length > max ||
    (required && !value.trim())
  )
    fail(
      `${label}: informe um texto ${required ? "não vazio " : ""}de até ${max} caracteres.`,
    );
  return (value as string).trim();
};
function recorded(value: unknown) {
  if (
    typeof value !== "string" ||
    !/^\d{4}-\d{2}-\d{2}T\d{2}:\d{2}(?::\d{2}(?:\.\d{1,3})?)?(?:Z|[+-]\d{2}:\d{2})$/.test(
      value,
    ) ||
    !Number.isFinite(Date.parse(value)) ||
    Number(value.slice(11, 13)) > 23 ||
    Number(value.slice(14, 16)) > 59 ||
    new Date(value.slice(0, 10)).toISOString().slice(0, 10) !==
      value.slice(0, 10) ||
    Date.parse(value) > Date.now() + 60000
  )
    fail("Data de registro da origem inválida.");
  return new Date(value as string).toISOString();
}
const owner = (raw: Record<string, unknown>, account: string) => {
  if (!account || raw.account !== account)
    fail(
      `Os dados de origem devem pertencer a @${account || "conta selecionada"}.`,
    );
};
export const emptyAcquisition = (account: string): AcquisitionBook => ({
  version: 1,
  account,
  assignments: [],
  reports: [],
});
export function validateFollowerOrigin(
  input: unknown,
  account: AccountWorkspace,
  preserve = false,
): FollowerOrigin {
  const raw = object(input);
  if (!preserve) owner(raw, account.username || "");
  const username = relationshipUsername(raw.username);
  if (username === account.username)
    fail("Informe o perfil de um seguidor, não a sua própria conta.");
  if (
    !Object.hasOwn(ACQUISITION_CHANNELS, String(raw.channel)) ||
    !Object.hasOwn(ORIGIN_EVIDENCE, String(raw.evidence))
  )
    fail("Escolha um canal e um tipo de evidência válidos.");
  const channel = raw.channel as AcquisitionChannel;
  let sourceLabel = text(
      raw.sourceLabel,
      150,
      "Descrição da origem",
      channel !== "unknown",
    ),
    campaignId =
      raw.campaignId === undefined || raw.campaignId === ""
        ? undefined
        : text(raw.campaignId, 150, "Campanha");
  if (campaignId && channel !== "prospecting")
    fail(
      "Uma campanha de prospecção só pode ser vinculada ao canal Prospecção.",
    );
  if (
    campaignId &&
    !preserve &&
    !account.data.campaigns.some((c) => c.id === campaignId)
  )
    fail("A campanha de prospecção não pertence a esta conta.");
  if (channel === "unknown") {
    sourceLabel = "";
    campaignId = undefined;
  }
  return {
    username,
    channel,
    sourceLabel,
    campaignId,
    evidence: raw.evidence as FollowerOrigin["evidence"],
    note: text(raw.note, 500, "Observação"),
    updatedAt: preserve ? recorded(raw.updatedAt) : new Date().toISOString(),
  };
}
function day(value: unknown): string {
  if (
    typeof value !== "string" ||
    !/^\d{4}-\d{2}-\d{2}$/.test(value) ||
    !Number.isFinite(Date.parse(value)) ||
    new Date(value).toISOString().slice(0, 10) !== value ||
    value > localDay()
  )
    fail("Use datas válidas no formato AAAA-MM-DD, sem datas futuras.");
  return value as string;
}
export function validateChannelResult(
  input: unknown,
  account: string,
  preserve = false,
): ChannelResult {
  const raw = object(input);
  if (!preserve) owner(raw, account);
  const start = day(raw.start),
    end = day(raw.end);
  if (start > end || (Date.parse(end) - Date.parse(start)) / 86400000 > 365)
    fail("Confira o período do resultado: início até fim, em até 366 dias.");
  if (
    !["organic", "paid"].includes(String(raw.channel)) ||
    typeof raw.followers !== "number" ||
    !Number.isSafeInteger(raw.followers) ||
    raw.followers < 0
  )
    fail(
      "Informe um canal orgânico ou pago e a contagem observada de seguidores atribuídos.",
    );
  if (
    preserve &&
    (typeof raw.id !== "string" || !raw.id.trim() || raw.id.length > 150)
  )
    fail("Identificador do resultado agregado inválido.");
  return {
    id: preserve ? (raw.id as string) : uid(),
    start,
    end,
    channel: raw.channel as ChannelResult["channel"],
    name: text(raw.name, 150, "Nome da campanha/conteúdo", true),
    followers: raw.followers as number,
    attributionWindow: text(
      raw.attributionWindow,
      150,
      "Janela/regra do relatório",
      true,
    ),
    note: text(raw.note, 500, "Observação"),
    recordedAt: preserve ? recorded(raw.recordedAt) : new Date().toISOString(),
  };
}
function capacity(book: AcquisitionBook) {
  if (book.assignments.length > 20000 || book.reports.length > 120)
    fail(
      "Esta conta comporta 20.000 classificações de origem e 120 resultados agregados. Exporte o backup antes de organizar o histórico.",
    );
}
export function validateAcquisition(
  input: unknown,
  account: AccountWorkspace,
): AcquisitionBook {
  const raw = object(input);
  owner(raw, account.username || "");
  if (
    raw.version !== 1 ||
    !Array.isArray(raw.assignments) ||
    !Array.isArray(raw.reports) ||
    raw.assignments.length > 20000 ||
    raw.reports.length > 120
  )
    fail("Histórico de origens inválido.");
  const assignments = (raw.assignments as unknown[]).map((row) =>
    validateFollowerOrigin(row, account, true),
  );
  const reports = (raw.reports as unknown[]).map((row) =>
    validateChannelResult(row, account.username || "", true),
  );
  if (
    new Set(assignments.map((row) => row.username)).size !==
      assignments.length ||
    new Set(reports.map((row) => row.id)).size !== reports.length
  )
    fail("Há classificações ou resultados duplicados no histórico de origens.");
  return { version: 1, account: account.username!, assignments, reports };
}
export function setFollowerOrigins(
  account: AccountWorkspace,
  input: unknown,
): AcquisitionBook {
  if (!account.username) fail("Cadastre uma conta antes de informar origens.");
  const rows = Array.isArray(input) ? input : [input];
  if (!rows.length || rows.length > 20000)
    fail("Informe entre 1 e 20.000 classificações por vez.");
  const values = rows.map((row) => validateFollowerOrigin(row, account));
  if (new Set(values.map((row) => row.username)).size !== values.length)
    fail("O mesmo @perfil aparece mais de uma vez na importação de origens.");
  const next = structuredClone(
      account.acquisition || emptyAcquisition(account.username),
    ),
    map = new Map(next.assignments.map((row) => [row.username, row]));
  for (const row of values) map.set(row.username, row);
  next.assignments = [...map.values()].sort((a, b) =>
    a.username.localeCompare(b.username),
  );
  capacity(next);
  return next;
}
const reportFingerprint = (row: ChannelResult) =>
  JSON.stringify([
    row.start,
    row.end,
    row.channel,
    row.name,
    row.followers,
    row.attributionWindow,
    row.note,
  ]);
export function addChannelResult(
  account: AccountWorkspace,
  input: unknown,
): AcquisitionBook {
  if (!account.username)
    fail("Cadastre uma conta antes de informar resultados.");
  const row = validateChannelResult(input, account.username),
    next = structuredClone(
      account.acquisition || emptyAcquisition(account.username),
    );
  if (
    !next.reports.some(
      (old) => reportFingerprint(old) === reportFingerprint(row),
    )
  )
    next.reports.push(row);
  capacity(next);
  return next;
}
export function mergeAcquisition(
  account: AccountWorkspace,
  input: unknown,
): AcquisitionBook {
  const incoming = validateAcquisition(input, account),
    next = structuredClone(
      account.acquisition || emptyAcquisition(account.username!),
    );
  const map = new Map(next.assignments.map((row) => [row.username, row]));
  for (const row of incoming.assignments) {
    const old = map.get(row.username);
    if (!old || row.updatedAt > old.updatedAt) map.set(row.username, row);
  }
  next.assignments = [...map.values()];
  for (const row of incoming.reports) {
    if (
      next.reports.some(
        (old) => reportFingerprint(old) === reportFingerprint(row),
      )
    )
      continue;
    if (next.reports.some((old) => old.id === row.id)) row.id = uid();
    next.reports.push(row);
  }
  capacity(next);
  return next;
}
export function parseFollowerOrigins(contents: string): unknown {
  if (contents.length > 5_000_000)
    fail("Use um arquivo de origens com até 5 MB.");
  const cleaned = contents.replace(/^\uFEFF/, "").trim();
  if (/^[\[{]/.test(cleaned)) {
    let value: unknown;
    try {
      value = JSON.parse(cleaned);
    } catch {
      return fail("JSON de origens inválido.");
    }
    if (Array.isArray(value)) return value;
    const raw = object(value);
    if (!Array.isArray(raw.assignments))
      fail("Use um JSON com account e assignments.");
    return raw.assignments.map((row) => {
      const item = object(row);
      if (item.account !== undefined && item.account !== raw.account)
        fail("O JSON contém contas diferentes nas classificações de origem.");
      return { ...item, account: raw.account };
    });
  }
  const rows = csvRows(cleaned),
    header = rows.shift()?.map((v) => v.trim().toLowerCase());
  if (
    !header ||
    ["account", "username", "channel", "source_label", "evidence"].some(
      (key) => !header.includes(key),
    ) ||
    new Set(header).size !== header.length
  )
    fail(
      "Use o modelo CSV de origens da Órbita. Um relatório agregado de anúncios não identifica @perfis.",
    );
  if (rows.length > 20000) fail("Importe até 20.000 classificações por vez.");
  return rows.map((row) => {
    if (row.length !== header.length)
      fail("Confira a quantidade de colunas do CSV de origens.");
    const get = (key: string) => row[header.indexOf(key)]?.trim() || "";
    return {
      account: get("account"),
      username: get("username"),
      channel: get("channel"),
      sourceLabel: get("source_label"),
      evidence: get("evidence"),
      campaignId: get("campaign_id") || undefined,
      note: get("note"),
    };
  });
}

export interface ProspectAssociation {
  campaignId: string;
  name: string;
  kind: string;
  target: string;
  capturedAt: string;
  timing: "before_interval" | "within_interval" | "before_snapshot";
}
export function followerAcquisition(
  account: AccountWorkspace,
  options: {
    snapshotId?: string;
    baselineId?: string;
    scope: "new" | "current";
  },
) {
  const history = relationshipAnalysis(
    account.relationships,
    options.snapshotId,
    options.baselineId,
  );
  const current = history.current,
    baseline = history.previous;
  const cohort = options.scope === "new" ? history.gained : current?.followers;
  const origins = new Map(
    account.acquisition?.assignments.map((row) => [row.username, row]),
  );
  const candidates = new Map(
    account.data.candidates.map((row) => [row.username, row]),
  );
  const campaigns = new Map(account.data.campaigns.map((row) => [row.id, row]));
  const previousNames = new Set(baseline?.followers);
  const upper = current ? Date.parse(current.at) : 0;
  const events = new Map<
    string,
    { kind: "followed" | "requested"; at: string }
  >();
  for (const event of account.data.audit) {
    if (
      event.account !== account.username ||
      !event.username ||
      !["followed", "requested"].includes(event.kind) ||
      !Number.isFinite(Date.parse(event.at)) ||
      Date.parse(event.at) > upper
    )
      continue;
    const old = events.get(event.username);
    if (!old || Date.parse(event.at) > Date.parse(old.at))
      events.set(event.username, {
        kind: event.kind as "followed" | "requested",
        at: event.at,
      });
  }
  const rows = (cohort || []).map((username) => {
    const associations = new Map<string, ProspectAssociation>();
    for (const source of candidates.get(username)?.sources || []) {
      const campaign = campaigns.get(source.campaignId),
        time = Date.parse(source.at);
      if (
        !campaign ||
        !Number.isFinite(time) ||
        time > upper ||
        !Number.isFinite(Date.parse(campaign.createdAt)) ||
        Date.parse(campaign.createdAt) > upper
      )
        continue;
      const old = associations.get(campaign.id);
      if (old && Date.parse(old.capturedAt) <= time) continue;
      associations.set(campaign.id, {
        campaignId: campaign.id,
        name: campaign.name,
        kind: campaign.kind,
        target: campaign.target,
        capturedAt: source.at,
        timing: baseline
          ? time <= Date.parse(baseline.at)
            ? "before_interval"
            : "within_interval"
          : "before_snapshot",
      });
    }
    return {
      username,
      origin: origins.get(username),
      associations: [...associations.values()],
      outboundAction: events.get(username),
      alreadyInBaseline: baseline ? previousNames.has(username) : undefined,
    };
  });
  const counts: Record<AcquisitionChannel, number> = {
    organic: 0,
    paid: 0,
    prospecting: 0,
    unknown: 0,
  };
  const sourceMap = new Map<
    string,
    {
      campaignId: string;
      name: string;
      target: string;
      matches: number;
      informed: number;
    }
  >();
  for (const row of rows) {
    counts[row.origin?.channel || "unknown"]++;
    for (const a of row.associations) {
      const source = sourceMap.get(a.campaignId) || {
        campaignId: a.campaignId,
        name: a.name,
        target: a.target,
        matches: 0,
        informed: 0,
      };
      source.matches++;
      sourceMap.set(a.campaignId, source);
    }
    if (row.origin?.channel === "prospecting" && row.origin.campaignId) {
      const c = campaigns.get(row.origin.campaignId);
      const source = sourceMap.get(row.origin.campaignId) || {
        campaignId: row.origin.campaignId,
        name: row.origin.sourceLabel,
        target: c?.target || "",
        matches: 0,
        informed: 0,
      };
      source.informed++;
      sourceMap.set(source.campaignId, source);
    }
  }
  return {
    ...history,
    rows,
    available: cohort !== undefined,
    scope: options.scope,
    counts,
    associated: rows.filter((row) => row.associations.length > 0).length,
    sources: [...sourceMap.values()].sort(
      (a, b) => b.matches - a.matches || a.name.localeCompare(b.name),
    ),
  };
}
