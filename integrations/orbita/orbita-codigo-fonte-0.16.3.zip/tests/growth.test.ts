import test from "node:test";
import assert from "node:assert/strict";
import {
  contentPerformance,
  defaultGrowthWindow,
  growthAnalysis,
  median,
} from "../src/core/growth.ts";
import {
  contentRevision,
  mergeInsightReports,
  parseInsightFile,
  validateInsightReport,
} from "../src/core/insights.ts";
import {
  accountCommand,
  initialStore,
  workspace,
} from "../src/core/accounts.ts";
import type { InsightContent, InsightReport } from "../src/core/types.ts";
function item(i: number): InsightContent {
  return {
    id: `p${i}`,
    kind: i < 3 ? "reel" : "post",
    title: `Publicação ${i}`,
    publishedAt: `2026-10-${String(10 + i).padStart(2, "0")}T12:00:00Z`,
    observationHours: 48,
    theme: i < 3 ? "Dicas" : "Oferta",
    hook: i < 3 ? "Lista" : "Produto",
    cta: i < 3 ? "Seguir" : "Comprar",
    metrics: {
      reach: 1000,
      views: 1500,
      follows: [40, 30, 35, 5, 6, 4][i],
      total_interactions: [50, 60, 55, 200, 250, 220][i],
      saves: 10,
      shares: 5,
    },
  };
}
function report(
  content: InsightContent[] = Array.from({ length: 6 }, (_, i) => item(i)),
): InsightReport {
  return validateInsightReport(
    {
      account: "qa.alpha",
      start: "2026-10-01",
      end: "2026-10-31",
      coverage: "organic",
      metrics: { follows: 5000 },
      content,
    },
    "qa.alpha",
    "file",
  );
}
const options = { objective: "followersPer1000" as const, window: 48 };
test("seguidores por publicação nunca são inferidos do total da conta", () => {
  const r = report([
    { ...item(0), metrics: { reach: 1000, total_interactions: 50 } },
  ]);
  const a = growthAnalysis(r, options);
  assert.equal(a.all[0].follows, undefined);
  assert.equal(a.all[0].followersPer1000, undefined);
  assert.equal(a.ranking.length, 0);
  assert.equal(a.coverage.attributedFollowers, 0);
});
test("taxas distinguem zero, ausente e alcance zero", () => {
  const zero = contentPerformance({
    ...item(0),
    metrics: { reach: 100, follows: 0, total_interactions: 0 },
  });
  assert.equal(zero.followersPer1000, 0);
  assert.equal(zero.engagementRate, 0);
  for (const reach of [0, undefined]) {
    const p = contentPerformance({
      ...item(0),
      metrics: {
        ...(reach === undefined ? {} : { reach }),
        follows: 5,
        total_interactions: 5,
      },
    });
    assert.equal(p.followersPer1000, undefined);
    assert.equal(p.engagementRate, undefined);
  }
  assert.equal(
    contentPerformance({
      ...item(0),
      metrics: { reach: 100, likes: 10, comments: 5 },
    }).engagementRate,
    undefined,
  );
});
test("objetivo absoluto e eficiência por alcance produzem rankings diferentes", () => {
  const r = report([
    { ...item(0), metrics: { reach: 10000, follows: 50 } },
    { ...item(1), metrics: { reach: 1000, follows: 20 } },
  ]);
  assert.equal(
    growthAnalysis(r, { ...options, objective: "follows" }).ranking[0].content
      .id,
    "p0",
  );
  assert.equal(growthAnalysis(r, options).ranking[0].content.id, "p1");
});
test("engajamento alto não é usado como substituto de seguidores atribuídos", () => {
  const r = report();
  assert.equal(
    growthAnalysis(r, { ...options, objective: "engagementRate" }).ranking[0]
      .content.id,
    "p4",
  );
  assert.equal(growthAnalysis(r, options).ranking[0].content.id, "p0");
});
test("hipóteses usam medianas de grupos com três publicações e três de contraste", () => {
  const a = growthAnalysis(report(), options);
  const reel = a.groups.find(
    (g) => g.dimension === "format" && g.label === "Reel",
  )!;
  assert.equal(reel.n, 3);
  assert.equal(reel.otherN, 3);
  assert.equal(reel.value, 35);
  assert.equal(reel.reference, 5);
  assert.ok(reel.qualified);
  assert.ok(a.hypotheses.some((p) => p.label === "Reel"));
  assert.equal(a.patternObjective, "followersPer1000");
  assert.equal(
    growthAnalysis(report(), { ...options, objective: "follows" })
      .patternObjective,
    "followersPer1000",
  );
});
test("amostra pequena, cobertura desconhecida e janelas misturadas não geram hipóteses", () => {
  assert.equal(
    growthAnalysis(
      report([item(0), item(1), item(3), item(4), item(5)]),
      options,
    ).hypotheses.length,
    0,
  );
  assert.equal(
    growthAnalysis({ ...report(), coverage: "unknown" }, options).hypotheses
      .length,
    0,
  );
  assert.equal(
    growthAnalysis(report(), { ...options, window: "all" }).hypotheses.length,
    0,
  );
});
test("metadados ausentes não são tratados como temas ou chamadas diferentes", () => {
  const r = report(
    Array.from({ length: 6 }, (_, i) =>
      i < 3
        ? item(i)
        : { ...item(i), theme: undefined, hook: undefined, cta: undefined },
    ),
  );
  const a = growthAnalysis(r, options);
  assert.equal(
    a.groups.find((g) => g.dimension === "theme" && g.label === "Dicas")
      ?.otherN,
    0,
  );
  assert.equal(
    a.hypotheses.some((p) => p.dimension === "theme"),
    false,
  );
});
test("normaliza rótulos sem adivinhar categorias pelo texto da publicação", () => {
  const r = report(
    Array.from({ length: 6 }, (_, i) => ({
      ...item(i),
      theme: i < 3 ? ["DÍCAS", "dicas", " Dicas "][i] : "Oferta",
    })),
  );
  assert.equal(
    growthAnalysis(r, options).groups.filter((g) => g.dimension === "theme")
      .length,
    2,
  );
  const missing = report([
    { ...item(0), theme: undefined, title: "Dicas de conteúdo" },
  ]);
  assert.equal(
    growthAnalysis(missing, options).groups.some(
      (g) => g.dimension === "theme",
    ),
    false,
  );
});
test("janela automática respeita formato e data, sem misturar 24h com 48h", () => {
  const r = report([
    { ...item(0), observationHours: 24 },
    { ...item(1), observationHours: 24 },
    item(3),
    { ...item(4), publishedAt: "2026-09-01T12:00:00Z" },
  ]);
  assert.equal(defaultGrowthWindow(r), 24);
  assert.equal(defaultGrowthWindow(r, "post"), 48);
  assert.equal(growthAnalysis(r, { ...options, window: 24 }).cohort.length, 2);
  assert.equal(growthAnalysis(r, options).cohort.length, 1);
});
test("resultados de versões e contas diferentes não são combinados", () => {
  const a = report();
  const b = {
    ...report(),
    account: "qa.beta",
    content: [{ ...item(0), metrics: { reach: 1, follows: 999 } }],
  };
  const result = growthAnalysis(a, options);
  assert.equal(result.ranking[0].follows, 40);
  assert.equal(growthAnalysis(b, options).ranking[0].follows, 999);
  assert.equal(result.coverage.publications, 6);
});
test("mediana não é dominada por uma única publicação extrema", () => {
  assert.equal(median([1, 2, 10000]), 2);
  assert.equal(median([1, 2, 3, 10000]), 2.5);
  assert.equal(median([]), undefined);
});
test("valida janela completa, calendário real, tipos e fuso explícito da publicação", () => {
  for (const c of [
    { ...item(0), publishedAt: "2026-10-01" },
    { ...item(0), publishedAt: "2026-02-30T12:00:00Z" },
    { ...item(0), publishedAt: "2099-01-01T12:00:00Z" },
    { ...item(0), publishedAt: undefined },
    { ...item(0), observationHours: 0 },
    { ...item(0), observationHours: 1.2 },
    { ...item(0), observationHours: 8761 },
    { ...item(0), publishedAt: "2026-10-31T23:00:00Z" },
    { ...item(0), theme: [] as unknown as string },
  ])
    assert.throws(() => report([c]));
  const c = {
    ...item(0),
    publishedAt: "2026-10-30T23:00:00-03:00",
    observationHours: 24,
  };
  const r = report([c]);
  assert.equal(r.content[0].publishedAt, c.publishedAt);
  assert.equal(
    validateInsightReport(r, "qa.alpha", "file", true).content[0]
      .observationHours,
    24,
  );
});
test("metadados de publicação sobrevivem ao CSV e conflitos são rejeitados", () => {
  const header =
    "account,start,end,coverage,scope,content_id,metric,value,published_at,observation_hours,theme,hook,cta\n";
  const row =
    "qa.alpha,2026-10-01,2026-10-31,organic,reel,p1,follows,12,2026-10-10T12:00:00Z,48,Dicas,Lista,Seguir";
  const r = validateInsightReport(
    (parseInsightFile(header + row) as unknown[])[0],
    "qa.alpha",
    "file",
  );
  assert.equal(r.content[0].theme, "Dicas");
  assert.equal(r.content[0].observationHours, 48);
  assert.equal(r.content[0].metrics.follows, 12);
  assert.throws(
    () =>
      parseInsightFile(
        header +
          row +
          "\n" +
          row
            .replace("follows,12", "reach,500")
            .replace("48,Dicas", "24,Dicas"),
      ),
    /conflitante/,
  );
});
test("edição cria versão, preserva original e não altera totais da conta", () => {
  const base = report();
  const original = structuredClone(base);
  const edited = {
    ...base.content[0],
    metrics: { ...base.content[0].metrics, follows: 75 },
  };
  const revision = contentRevision(base, "qa.alpha", base, edited);
  assert.equal(revision.source, "manual");
  assert.equal(
    revision.content.find((c) => c.id === edited.id)?.metrics.follows,
    75,
  );
  assert.deepEqual(revision.metrics, base.metrics);
  assert.deepEqual(base, original);
  const account = workspace(
    accountCommand(initialStore(), {
      type: "ADD_ACCOUNT",
      username: "qa.alpha",
    }),
  );
  mergeInsightReports(account, base, "file");
  mergeInsightReports(account, revision, "manual");
  assert.equal(account.insights?.length, 2);
  mergeInsightReports(account, revision, "manual");
  assert.equal(account.insights?.length, 2);
  assert.throws(
    () => contentRevision(base, "qa.beta", base, edited),
    /outra conta/,
  );
});
test("link canônico impede contar a mesma publicação duas vezes e conserva identidade na edição", () => {
  const c = { ...item(0), url: "https://www.instagram.com/reel/abc/" };
  const base = report([c]);
  const revision = contentRevision(base, "qa.alpha", base, {
    ...c,
    id: "novo",
    url: "https://instagram.com/reel/abc?x=1",
    metrics: { follows: 50 },
  });
  assert.equal(revision.content.length, 1);
  assert.equal(revision.content[0].id, c.id);
  assert.throws(() => report([c, { ...c, id: "outro" }]), /mesmo link/);
});
test("primeira publicação pode criar relatório sem inventar métricas totais", () => {
  const r = contentRevision(
    undefined,
    "qa.alpha",
    {
      start: "2026-10-01",
      end: "2026-10-31",
      coverage: "organic",
      contentWindow: "period",
    },
    item(0),
  );
  assert.deepEqual(r.metrics, {});
  assert.equal(r.content.length, 1);
  assert.equal(r.source, "manual");
});
test("vida inteira não é usada como primeiras horas e janelas disponíveis respeitam o formato", () => {
  const r = report();
  const life = { ...r, contentWindow: "lifetime" as const };
  assert.equal(defaultGrowthWindow(life), "all");
  assert.equal(
    growthAnalysis(life, { ...options, window: "all" }).hypotheses.length,
    0,
  );
  assert.deepEqual(growthAnalysis(life, options).availableWindows, []);
  assert.throws(
    () =>
      validateInsightReport(
        { ...r, contentWindow: "lifetime" },
        "qa.alpha",
        "file",
      ),
    /Vida inteira/,
  );
  const split = report([{ ...item(0), observationHours: 24 }, item(3)]);
  assert.deepEqual(
    growthAnalysis(split, { ...options, format: "reel" }).availableWindows,
    [24],
  );
});
test("lacunas de tema, abertura e CTA são explícitas e janelas fora do período não entram na cobertura", () => {
  const r = report([
    { ...item(0), theme: undefined, hook: undefined, cta: undefined },
    { ...item(1), publishedAt: "2026-09-10T12:00:00Z" },
  ]);
  const a = growthAnalysis(r, options);
  assert.equal(a.coverage.standardWindow, 1);
  assert.equal(a.metadataGaps.find((g) => g.dimension === "theme")?.missing, 1);
});
test("CSV rejeita conteúdo sem id e metadados de identidade conflitantes", () => {
  const header = "account,start,end,scope,content_id,title,url,metric,value\n";
  const row =
    "qa.alpha,2026-10-01,2026-10-31,reel,p1,Nome,https://instagram.com/reel/abc,views,100";
  assert.throws(
    () => parseInsightFile(header + row.replace("reel,p1,", "reel,,")),
    /content_id/,
  );
  assert.throws(
    () =>
      parseInsightFile(
        header +
          row +
          "\n" +
          row.replace("views,100", "reach,50").replace(",Nome,", ",Outro,"),
      ),
    /Títulos conflitantes/,
  );
  assert.throws(
    () =>
      parseInsightFile(
        header +
          row +
          "\n" +
          row.replace("views,100", "reach,50").replace("/abc", "/outro"),
      ),
    /Links conflitantes/,
  );
  const same = parseInsightFile(
    header +
      row +
      "\n" +
      row
        .replace("views,100", "reach,50")
        .replace(
          "https://instagram.com/reel/abc",
          "https://www.instagram.com/reel/abc/",
        ),
  ) as unknown[];
  assert.equal(
    validateInsightReport(same[0], "qa.alpha", "file").content.length,
    1,
  );
});
