import test from "node:test";
import assert from "node:assert/strict";
import { JSDOM } from "jsdom";
import { profilePhotoUrl } from "../src/core/photos.ts";
import { collectLoaded, sessionProfilePhoto } from "../src/extension/dom.ts";
import {
  initialState,
  applyCommand,
  mergeCandidates,
} from "../src/core/domain.ts";
import {
  accountBackup,
  accountCommand,
  applyScopedCommand,
  bindVerifiedAccount,
  initialStore,
  migrateStore,
  workspace,
} from "../src/core/accounts.ts";
import { exportCsv, parseCandidates } from "../src/core/io.ts";

const first =
  "https://scontent.test.cdninstagram.com/photo-a.jpg?oh=signed&oe=123";
const second = "https://instagram.test.fbcdn.net/photo-b.jpg";
const doc = (html: string) =>
  new JSDOM(html, { url: "https://www.instagram.com/qa.alpha/" }).window
    .document;

test("menu com rótulo no próprio link identifica a sessão e sua foto", () => {
  assert.equal(
    sessionProfilePhoto(
      doc(
        `<nav><a aria-label="Perfil" href="/qa.alpha/"><img src="${first}"></a></nav>`,
      ),
      "/qa.alpha/",
    ),
    first,
  );
});
test("srcset sem src é aceito e currentSrc tem precedência sobre o atributo src", () => {
  const page = doc(
    `<div role="dialog"><a href="/ana/"><img srcset="${first} 150w, ${second} 320w"></a><a href="/bia/"><img src="${second}"></a></div>`,
  );
  Object.defineProperty(page.querySelectorAll("img")[1], "currentSrc", {
    value: first,
  });
  const candidates = collectLoaded(page, "followers", "alvo").candidates;
  assert.equal(candidates[0].avatarUrl, first);
  assert.equal(candidates[1].avatarUrl, first);
});
test("menu prefere a foto identificada a um selo e cabeçalho aceita assinaturas da mesma imagem", () => {
  assert.equal(
    sessionProfilePhoto(
      doc(
        `<nav><a href="/qa.alpha/">Perfil<img alt="Selo" src="${second}"><img alt="profile picture" src="${first}"></a></nav>`,
      ),
      "/qa.alpha/",
    ),
    first,
  );
  const refreshed = first.replace("oe=123", "oe=456");
  assert.equal(
    sessionProfilePhoto(
      doc(
        `<nav><a href="/qa.alpha/">Perfil</a></nav><main><header><h2>qa.alpha</h2><img alt="profile picture" src="${first}"><img alt="profile picture" src="${refreshed}"></header></main>`,
      ),
      "/qa.alpha/",
    ),
    first,
  );
});
test("leitura do cadastro remove só URLs inválidas de foto antes do backup", () => {
  const store = accountCommand(initialStore(), {
    type: "ADD_ACCOUNT",
    username: "qa.alpha",
  });
  const a = workspace(store);
  a.avatarUrl = "javascript:alert(1)";
  a.data = applyCommand(a.data, {
    type: "CREATE_CAMPAIGN",
    name: "QA",
    kind: "followers",
    target: "alvo",
  });
  mergeCandidates(a.data, a.data.campaigns[0].id, [
    { username: "ana", avatarUrl: first },
  ]);
  a.data.candidates[0].avatarUrl = "https://evil.test/photo";
  a.data.candidates[0].stage = "queued";
  a.data.runtime.sessionAttempts = 3;
  const migrated = migrateStore(store),
    account = workspace(migrated);
  assert.equal(account.avatarUrl, undefined);
  assert.equal(account.data.candidates[0].avatarUrl, undefined);
  assert.equal(account.data.candidates[0].stage, "queued");
  assert.equal(account.data.runtime.sessionAttempts, 3);
  assert.equal(accountBackup(account).account.avatarUrl, undefined);
});

test("fotos aceitam URLs HTTPS das CDNs e preservam a assinatura; recusam dados e hosts alheios", () => {
  assert.equal(profilePhotoUrl(` ${first}#preview `), first);
  assert.equal(profilePhotoUrl(second), second);
  for (const input of [
    undefined,
    null,
    {},
    "data:image/png;base64,AA==",
    "javascript:alert(1)",
    "http://cdninstagram.com/a.jpg",
    "https://cdninstagram.com.evil.test/a.jpg",
    "https://evilcdninstagram.com/a.jpg",
    "https://user:secret@fbcdn.net/a.jpg",
    "https://fbcdn.net:444/a.jpg",
    "https://127.0.0.1/a.jpg",
    "https://fbcdn.net/" + "a".repeat(4096),
  ])
    assert.equal(profilePhotoUrl(input), undefined);
});

test("captura une foto e nome do mesmo @ sem pegar imagem de vizinho ou fora da lista", () => {
  const page = doc(
    `<aside><a href="/ana/"><img src="${second}"></a></aside><div role="dialog"><a href="/ana/"><img src="${first}"></a><a href="/ana/">Ana Artista</a><a href="/bia/">Bia</a><a href="/carla/"><img src="https://evil.test/a.jpg"></a></div>`,
  );
  const result = collectLoaded(page, "followers", "alvo").candidates;
  assert.equal(result.length, 3);
  assert.equal(result[0].username, "ana");
  assert.equal(result[0].name, "Ana Artista");
  assert.equal(result[0].avatarUrl, first);
  assert.equal(result[1].avatarUrl, undefined);
  assert.equal(result[2].avatarUrl, undefined);
});

test("foto de comentário precisa estar em uma âncora do próprio autor da linha", () => {
  const page = doc(
    `<main><article><ul><li><a href="/ana/">ana</a><a href="/bia/"><img src="${second}"></a></li><li><a href="/carla/">carla</a><a href="/carla/"><img src="${first}"></a></li></ul></article></main>`,
  );
  const result = collectLoaded(page, "commenters", "post").candidates;
  assert.equal(result[0].avatarUrl, undefined);
  assert.equal(result[1].avatarUrl, first);
});

test("foto da sessão vem do menu da conta, mesmo visitando um perfil diferente", () => {
  const page = doc(
    `<nav><a href="/qa.alpha/"><img src="${first}"><span>Perfil</span></a></nav><main><header><h2>qa.beta</h2><img alt="Foto do perfil de qa.beta" src="${second}"></header></main>`,
  );
  assert.equal(sessionProfilePhoto(page, "/qa.beta/"), first);
});

test("cabeçalho só fornece foto quando sessão, rota e identidade coincidem; imagem genérica não serve", () => {
  const page = doc(
    `<nav><a href="/qa.alpha/">Perfil</a></nav><main><header><h2>qa.alpha</h2><img alt="Logo de uma publicação" src="${second}"><img alt="Foto do perfil de qa.alpha" src="${first}"></header></main>`,
  );
  assert.equal(sessionProfilePhoto(page, "/qa.alpha/"), first);
  assert.equal(sessionProfilePhoto(page, "/qa.beta/"), undefined);
  page.querySelector("h2")!.textContent = "qa.beta";
  assert.equal(sessionProfilePhoto(page, "/qa.alpha/"), undefined);
  assert.equal(
    sessionProfilePhoto(
      doc(
        `<main><header><h2>qa.alpha</h2><img alt="profile picture" src="${first}"></header></main>`,
      ),
      "/qa.alpha/",
    ),
    undefined,
  );
});

test("sessão ambígua e cabeçalho com fotos diferentes não escolhem uma pessoa por acaso", () => {
  assert.equal(
    sessionProfilePhoto(
      doc(
        `<nav><a href="/um/">Perfil<img src="${first}"></a><a href="/dois/">Profile<img src="${second}"></a></nav>`,
      ),
      "/um/",
    ),
    undefined,
  );
  assert.equal(
    sessionProfilePhoto(
      doc(
        `<nav><a href="/qa.alpha/">Perfil</a></nav><main><header><h2>qa.alpha</h2><img alt="profile picture" src="${first}"><img alt="profile picture" src="${second}"></header></main>`,
      ),
      "/qa.alpha/",
    ),
    undefined,
  );
});

test("recaptura atualiza a foto sem duplicar a pessoa ou alterar aprovação, fila e avisos", () => {
  const state = applyCommand(initialState(), {
    type: "CREATE_CAMPAIGN",
    name: "QA",
    kind: "followers",
    target: "alvo",
  });
  const id = state.campaigns[0].id;
  mergeCandidates(state, id, [{ username: "ana", avatarUrl: first }]);
  const candidate = state.candidates[0];
  candidate.stage = "queued";
  candidate.queueAccount = "qa.alpha";
  state.settings.hasPendingWarning = true;
  state.runtime.sessionAttempts = 3;
  const result = mergeCandidates(state, id, [
    { username: "ana", avatarUrl: second },
  ]);
  assert.deepEqual(result, { added: 0, merged: 1, invalid: 0 });
  assert.equal(state.candidates.length, 1);
  assert.equal(candidate.avatarUrl, second);
  mergeCandidates(state, id, [
    { username: "ana", avatarUrl: "https://evil.test/tracker" },
  ]);
  assert.equal(candidate.avatarUrl, second);
  assert.equal(candidate.stage, "queued");
  assert.equal(candidate.queueAccount, "qa.alpha");
  assert.equal(state.settings.hasPendingWarning, true);
  assert.equal(state.runtime.sessionAttempts, 3);
});

test("CSV de foto é validado e sobrevive a exportação e reimportação", () => {
  const state = applyCommand(initialState(), {
    type: "CREATE_CAMPAIGN",
    name: "QA",
    kind: "import",
    target: "",
  });
  const input = parseCandidates(
    `username,avatar_url\nana,${first}\nbia,https://evil.test/a.jpg`,
  );
  mergeCandidates(state, state.campaigns[0].id, input.candidates);
  assert.equal(state.candidates[0].avatarUrl, first);
  assert.equal(state.candidates[1].avatarUrl, undefined);
  const roundtrip = parseCandidates(exportCsv(state.candidates));
  assert.equal(roundtrip.candidates[0].avatarUrl, first);
});

test("foto da sessão fica apenas na conta verificada e uma sessão errada não altera o cadastro", () => {
  let store = accountCommand(initialStore(), {
    type: "ADD_ACCOUNT",
    username: "qa.alpha",
  });
  const alpha = store.activeId;
  store = bindVerifiedAccount(store, alpha, "qa.alpha", first);
  store = accountCommand(store, { type: "ADD_ACCOUNT", username: "qa.beta" });
  const beta = store.activeId;
  const before = JSON.stringify(store);
  assert.throws(() => bindVerifiedAccount(store, beta, "qa.alpha", second));
  assert.equal(JSON.stringify(store), before);
  store = bindVerifiedAccount(store, beta, "qa.beta", second);
  assert.equal(workspace(store, alpha).avatarUrl, first);
  assert.equal(workspace(store, beta).avatarUrl, second);
  store = bindVerifiedAccount(store, beta, "qa.beta", undefined);
  assert.equal(workspace(store).avatarUrl, second);
});

test("backup preserva fotos da conta e dos candidatos e mantém compatibilidade com contas antigas", () => {
  let store = accountCommand(initialStore(), {
    type: "ADD_ACCOUNT",
    username: "qa.alpha",
  });
  store = bindVerifiedAccount(store, store.activeId, "qa.alpha", first);
  let account = workspace(store);
  account.data = applyCommand(account.data, {
    type: "CREATE_CAMPAIGN",
    name: "QA",
    kind: "followers",
    target: "alvo",
  });
  mergeCandidates(account.data, account.data.campaigns[0].id, [
    { username: "ana", avatarUrl: second },
  ]);
  const backup = accountBackup(account);
  let restored = accountCommand(initialStore(), {
    type: "ADD_ACCOUNT",
    username: "qa.alpha",
  });
  restored = applyScopedCommand(restored, restored.activeId, {
    type: "RESTORE",
    data: backup,
  });
  assert.equal(workspace(restored).avatarUrl, first);
  assert.equal(workspace(restored).data.candidates[0].avatarUrl, second);
  assert.equal(workspace(restored).verifiedAt, undefined);
  account = workspace(initialStore());
  assert.equal(workspace(migrateStore(initialStore())).avatarUrl, undefined);
  assert.equal(account.avatarUrl, undefined);
});
