import test from "node:test";
import assert from "node:assert/strict";
import {
  applyCommand,
  attemptsToday,
  audit,
  initialState,
  insideWindow,
  matchesFilters,
  mergeCandidates,
  normalizeUsername,
  recoverInterrupted,
  restoreState,
  sourceUrl,
  validateSettings,
} from "../src/core/domain.ts";
import { exportCsv, parseCandidates } from "../src/core/io.ts";
import type { AppState, Filters } from "../src/core/types.ts";

function workspace(): AppState {
  return applyCommand(initialState(), {
    type: "CREATE_CAMPAIGN",
    name: "Público A",
    kind: "followers",
    target: "@referencia",
  });
}
function withPerson(): AppState {
  const s = workspace();
  mergeCandidates(s, s.campaigns[0].id, [{ username: "ana.exemplo" }]);
  return s;
}
const filters: Filters = {
  query: "",
  campaignId: "",
  stage: "",
  minFollowers: "",
  maxFollowers: "",
  bio: "",
  publicOnly: false,
  requireKnown: false,
};
test("normaliza usuários e rejeita rotas e entradas inválidas", () => {
  assert.equal(normalizeUsername(" @Ana.Exemplo "), "ana.exemplo");
  for (const v of [
    "accounts",
    "p",
    "http://evil.test",
    "<script>",
    "a b",
    "a".repeat(31),
  ])
    assert.equal(normalizeUsername(v), null);
});
test("fontes aceitam apenas domínios e rotas do Instagram esperados", () => {
  assert.equal(
    sourceUrl("followers", "@Ana"),
    "https://www.instagram.com/ana/followers/",
  );
  assert.equal(
    sourceUrl("followers", "https://instagram.com/ana/"),
    "https://www.instagram.com/ana/followers/",
  );
  assert.equal(
    sourceUrl(
      "commenters",
      "https://www.instagram.com/p/AbC123/?secret=removed",
    ),
    "https://www.instagram.com/p/AbC123/",
  );
  for (const url of [
    "https://instagram.com.evil.test/p/abc/",
    "http://instagram.com/p/abc/",
    "https://instagram.com/accounts/login/",
    "javascript:alert(1)",
  ])
    assert.throws(() => sourceUrl("commenters", url));
});
test("deduplicação conserva a origem sem apagar o estado de revisão", () => {
  const s = withPerson();
  const c = s.candidates[0];
  c.stage = "approved";
  const other = applyCommand(s, {
    type: "CREATE_CAMPAIGN",
    name: "Público B",
    kind: "import",
    target: "",
  });
  const result = mergeCandidates(
    other,
    other.campaigns[0].id,
    [{ username: "@ANA.EXEMPLO", followers: 1234 }],
    "https://www.instagram.com/p/abc/",
  );
  assert.deepEqual(result, { added: 0, merged: 1, invalid: 0 });
  assert.equal(other.candidates.length, 1);
  assert.equal(other.candidates[0].stage, "approved");
  assert.equal(other.candidates[0].sources.length, 2);
  assert.equal(other.candidates[0].followers, 1234);
});
test("identidade numérica preserva o candidato quando muda o username", () => {
  const s = workspace();
  mergeCandidates(s, s.campaigns[0].id, [
    { username: "antigo", platformId: "123" },
  ]);
  const id = s.candidates[0].id;
  mergeCandidates(s, s.campaigns[0].id, [
    { username: "novo", platformId: "123" },
  ]);
  assert.equal(s.candidates.length, 1);
  assert.equal(s.candidates[0].id, id);
  assert.equal(s.candidates[0].username, "novo");
});
test("IDs conflitantes nunca são mesclados pelo mesmo username", () => {
  const s = workspace();
  mergeCandidates(s, s.campaigns[0].id, [
    { username: "ana", platformId: "123" },
  ]);
  assert.equal(
    mergeCandidates(s, s.campaigns[0].id, [
      { username: "ana", platformId: "456" },
    ]).invalid,
    1,
  );
  assert.equal(s.candidates[0].platformId, "123");
});
test("dados desconhecidos não passam por filtros de contagem ou público", () => {
  const s = withPerson(),
    c = s.candidates[0];
  assert.equal(matchesFilters(c, filters), true);
  assert.equal(matchesFilters(c, { ...filters, minFollowers: "1" }), false);
  assert.equal(matchesFilters(c, { ...filters, publicOnly: true }), false);
  c.followers = 0;
  c.isPrivate = false;
  assert.equal(
    matchesFilters(c, { ...filters, maxFollowers: "100", publicOnly: true }),
    true,
  );
});
test("a fila exige conta, revisão e não aceita demonstração", () => {
  let s = withPerson();
  const ids = [s.candidates[0].id];
  assert.throws(() => applyCommand(s, { type: "QUEUE", ids }), /Conecte/);
  s.runtime.account = "minha_conta";
  assert.throws(() => applyCommand(s, { type: "QUEUE", ids }), /aprovados/);
  s = applyCommand(s, { type: "APPROVE", ids });
  s = applyCommand(s, { type: "QUEUE", ids });
  assert.equal(s.candidates[0].stage, "queued");
  assert.equal(s.candidates[0].queueAccount, "minha_conta");
  assert.throws(() => applyCommand(s, { type: "QUEUE", ids }));
  let demo = applyCommand(initialState(), { type: "DEMO" });
  demo.runtime.account = "minha_conta";
  const demoIds = demo.candidates.map((c) => c.id);
  demo = applyCommand(demo, { type: "APPROVE", ids: demoIds });
  assert.throws(() => applyCommand(demo, { type: "QUEUE", ids: demoIds }));
});
test("exclusões persistem em novas coletas e removem candidatos da fila", () => {
  let s = withPerson();
  const ids = [s.candidates[0].id];
  s = applyCommand(s, { type: "EXCLUDE", ids });
  mergeCandidates(s, s.campaigns[0].id, [
    { username: "ana.exemplo", name: "Ana" },
  ]);
  assert.equal(s.candidates[0].stage, "excluded");
  assert.ok(s.settings.exclusions.includes("ana.exemplo"));
  s = applyCommand(s, { type: "RETURN_TO_REVIEW", id: ids[0] });
  assert.equal(s.candidates[0].stage, "new");
  assert.ok(!s.settings.exclusions.includes("ana.exemplo"));
});
test("pausar invalida a autorização e não apaga ação em andamento", () => {
  const s = withPerson();
  s.runtime.mode = "running";
  s.runtime.activeToken = "token";
  s.candidates[0].stage = "attempting";
  const paused = applyCommand(s, { type: "PAUSE" });
  assert.equal(paused.runtime.mode, "paused");
  assert.equal(paused.runtime.activeToken, undefined);
  assert.equal(paused.candidates[0].stage, "attempting");
  assert.equal(s.runtime.activeToken, "token");
});
test("interrupção vira resultado incerto, sem repetição automática", () => {
  const s = withPerson();
  s.candidates[0].stage = "attempting";
  s.runtime.mode = "running";
  const recovered = recoverInterrupted(s);
  assert.equal(recovered.candidates[0].stage, "uncertain");
  assert.equal(recovered.runtime.mode, "paused");
});
test("janela de horários trata intervalo normal e passagem da meia-noite", () => {
  const settings = initialState().settings;
  assert.equal(insideWindow(new Date(2026, 10, 2, 9, 0), settings), true);
  assert.equal(insideWindow(new Date(2026, 10, 2, 18, 0), settings), false);
  const night = { ...settings, startHour: "22:00", endHour: "02:00" };
  assert.equal(insideWindow(new Date(2026, 10, 2, 23, 30), night), true);
  assert.equal(insideWindow(new Date(2026, 10, 3, 1, 0), night), true);
  assert.equal(insideWindow(new Date(2026, 10, 3, 3, 0), night), false);
});
test("teto diário conta tentativas da conta e do dia local, não apenas sucessos", () => {
  const s = initialState();
  s.runtime.account = "conta";
  const now = new Date(2026, 10, 2, 12);
  const event = {
    id: "a",
    at: now.toISOString(),
    kind: "attempt",
    account: "conta",
    message: "Tentativa",
  };
  s.audit = [
    event,
    { ...event, id: "b", account: "outra" },
    { ...event, id: "c", kind: "followed" },
    { ...event, id: "d", at: new Date(2026, 10, 1, 12).toISOString() },
  ];
  assert.equal(attemptsToday(s, now), 1);
});
test("preferências rejeitam horários, números e listas inválidos", () => {
  const settings = initialState().settings;
  assert.throws(() => validateSettings({ ...settings, intervalMinutes: NaN }));
  assert.throws(() => validateSettings({ ...settings, startHour: "25:00" }));
  assert.throws(() => validateSettings({ ...settings, dailyLimit: 1.5 }));
  assert.throws(() =>
    validateSettings({ ...settings, endHour: settings.startHour }),
  );
});
test("backup não restaura autorização, conta ou fila executável", () => {
  const s = withPerson();
  s.runtime.account = "minha_conta";
  s.runtime.mode = "running";
  s.runtime.activeToken = "not-restored";
  s.candidates[0].stage = "queued";
  const restored = restoreState(JSON.parse(JSON.stringify(s)));
  assert.equal(restored.runtime.account, undefined);
  assert.equal(restored.runtime.activeToken, undefined);
  assert.equal(restored.runtime.mode, "paused");
  assert.equal(restored.candidates[0].stage, "uncertain");
  assert.throws(() => restoreState({ version: 2 }));
});
test("CSV importa campos citados, vírgulas, quebras de linha e campos desconhecidos", () => {
  const parsed = parseCandidates(
    'username,name,bio,followers,is_private\r\n@ana,"Ana, artista","Design\nSão Paulo",1200,false\r\n@bia,Bia,,,\r\n<script>,Inválido,,,',
  );
  assert.equal(parsed.candidates.length, 2);
  assert.equal(parsed.candidates[0].name, "Ana, artista");
  assert.equal(parsed.candidates[0].bio, "Design\nSão Paulo");
  assert.equal(parsed.candidates[0].followers, 1200);
  assert.equal(parsed.candidates[0].isPrivate, false);
  assert.equal(parsed.candidates[1].isPrivate, undefined);
  assert.equal(parsed.invalid, 1);
});
test("CSV com ponto e vírgula e lista simples de URLs são aceitos", () => {
  assert.equal(
    parseCandidates("usuario;nome;seguidores\nana;Ana;100").candidates[0]
      .followers,
    100,
  );
  assert.equal(
    parseCandidates("@ana\nhttps://instagram.com/bia/").candidates[1].username,
    "bia",
  );
});
test("exportação CSV neutraliza fórmulas e escapa aspas", () => {
  const s = withPerson();
  s.candidates[0].name = '=HYPERLINK("https://evil.test")';
  const text = exportCsv(s.candidates);
  assert.ok(text.includes("'=HYPERLINK"));
  assert.ok(text.includes('""https://evil.test""'));
  assert.throws(() => parseCandidates('username,name\nana,"sem fechamento'));
});
test("renomear por ID não colide com username já ocupado", () => {
  const s = workspace();
  mergeCandidates(s, s.campaigns[0].id, [
    { username: "antigo", platformId: "1" },
    { username: "ocupado", platformId: "2" },
  ]);
  const result = mergeCandidates(s, s.campaigns[0].id, [
    { username: "ocupado", platformId: "1" },
  ]);
  assert.equal(result.invalid, 1);
  assert.equal(new Set(s.candidates.map((c) => c.username)).size, 2);
  assert.doesNotThrow(() => restoreState(s));
});
test("contagem de tentativas sobrevive ao corte do histórico e ao backup", () => {
  const s = initialState();
  s.runtime.account = "conta";
  audit(s, "attempt", "Tentativa");
  for (let i = 0; i < 3010; i++) audit(s, "collection", "Captura");
  assert.equal(
    s.audit.some((a) => a.kind === "attempt"),
    false,
  );
  assert.equal(attemptsToday(s), 1);
  const restored = restoreState(s);
  restored.runtime.account = "conta";
  assert.equal(attemptsToday(restored), 1);
});
test("backup sem preferências retorna um erro compreensível", () => {
  const s = initialState();
  assert.throws(
    () => restoreState({ ...s, settings: undefined }),
    /Preferências ausentes/,
  );
});
