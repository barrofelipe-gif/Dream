import test from "node:test";
import assert from "node:assert/strict";
import {
  improvementReview,
  validatePerformanceBenchmark,
} from "../src/core/improvement.ts";
import { validateInsightReport } from "../src/core/insights.ts";
import {
  accountBackup,
  accountCommand,
  applyScopedCommand,
  initialStore,
  migrateStore,
  workspace,
} from "../src/core/accounts.ts";
import { emptyMarket } from "../src/core/market.ts";
import type {
  AccountWorkspace,
  InsightReport,
  PerformanceBenchmark,
} from "../src/core/types.ts";

const today = "2026-11-03";
test("valores iguais com uma base válida são estáveis, não ausência de comparação", () => {
  const previous = report(2, { views: 100, unfollows: 10 }),
    current = report(3, { views: 100, unfollows: 10 });
  const result = improvementReview(
    account([previous, current]),
    current,
    today,
  );
  assert.equal(result.priorities.length, 0);
  assert.equal(result.strengths.length, 0);
  assert.deepEqual(result.stable.map((metric) => metric.key).sort(), [
    "unfollows",
    "views",
  ]);
});
const dates = [
  ["2026-10-01", "2026-10-07"],
  ["2026-10-08", "2026-10-14"],
  ["2026-10-15", "2026-10-21"],
  ["2026-10-22", "2026-10-28"],
];
const report = (
  index: number,
  metrics: Record<string, number>,
  patch: Partial<InsightReport> = {},
) =>
  validateInsightReport(
    {
      account: "qa.evolve",
      start: dates[index][0],
      end: dates[index][1],
      coverage: "organic",
      contentWindow: "period",
      metrics,
      ...patch,
    },
    "qa.evolve",
    "manual",
  );
function registered() {
  let store = accountCommand(initialStore(), {
    type: "ADD_ACCOUNT",
    username: "qa.evolve",
  });
  workspace(store).market = {
    ...emptyMarket("qa.evolve"),
    profile: {
      sector: "fitness",
      model: "wholesale",
      audience: "Lojistas",
      bio: "",
      updatedAt: new Date().toISOString(),
    },
  };
  return store;
}
function account(reports: InsightReport[]): AccountWorkspace {
  const a = workspace(registered());
  a.insights = reports;
  return a;
}
const reference = (
  patch: Partial<PerformanceBenchmark> = {},
): PerformanceBenchmark => ({
  account: "qa.evolve",
  sector: "fitness",
  model: "wholesale",
  metric: "interactions_per_reach",
  value: 6,
  coverage: "organic",
  start: "2026-10-15",
  end: "2026-10-21",
  sampleSize: 20,
  sourceTitle: "Amostra fictícia para teste",
  sourceUrl: "https://example.com/coorte",
  note: "Dados fictícios; não é média real do setor.",
  updatedAt: new Date().toISOString(),
  ...patch,
});

test("histórico limita a seis períodos e não usa observações com mais de 180 dias", () => {
  const current = report(3, { views: 100 });
  const reports: InsightReport[] = [];
  for (let i = 1; i <= 8; i++) {
    const end = new Date(
      Date.parse(current.start) - i * 7 * 86400000 + 6 * 86400000,
    )
      .toISOString()
      .slice(0, 10);
    const start = new Date(Date.parse(end) - 6 * 86400000)
      .toISOString()
      .slice(0, 10);
    reports.push(report(0, { views: 100 }, { start, end }));
  }
  reports.push(
    report(0, { views: 9000 }, { start: "2025-01-01", end: "2025-01-07" }),
  );
  const r = improvementReview(account([...reports, current]), current, today);
  assert.equal(r.historyPeriods, 6);
});
test("salvar exige setor do Radar e restauração inválida não modifica o cadastro original", () => {
  const store = registered();
  const before = JSON.stringify(store);
  assert.throws(() =>
    accountCommand(store, {
      type: "SAVE_PERFORMANCE_BENCHMARK",
      data: reference({ sector: "beachwear" }),
    }),
  );
  assert.equal(JSON.stringify(store), before);
  const backup = accountBackup(workspace(store));
  backup.account.performanceBenchmark = reference({ sampleSize: 1 });
  assert.throws(() =>
    applyScopedCommand(store, store.activeId, {
      type: "RESTORE",
      data: backup,
    }),
  );
  assert.equal(JSON.stringify(store), before);
});

test("melhorar no último período não esconde resultado ainda abaixo da média pessoal", () => {
  const reports = [
    report(0, { views: 100 }),
    report(1, { views: 100 }),
    report(2, { views: 20 }),
    report(3, { views: 30 }),
  ];
  const r = improvementReview(account(reports), reports[3], today),
    item = r.priorities.find((m) => m.key === "views")!;
  assert.equal(
    item.signals.find((s) => s.basis === "previous")!.tone,
    "positive",
  );
  assert.equal(
    item.signals.find((s) => s.basis === "history")!.tone,
    "negative",
  );
  assert.ok(
    Math.abs(
      item.signals.find((s) => s.basis === "history")!.reference - 220 / 3,
    ) < 1e-10,
  );
  assert.equal(
    r.strengths.some((m) => m.key === "views"),
    false,
  );
});
test("taxa histórica é ponderada por alcance, sem média das porcentagens", () => {
  const reports = [
    report(0, { reach: 100, total_interactions: 10 }),
    report(1, { reach: 100, total_interactions: 90 }),
    report(2, { reach: 1000, total_interactions: 200 }),
    report(3, { reach: 100, total_interactions: 30 }),
  ];
  const r = improvementReview(account(reports), reports[3], today);
  const item = r.strengths.find((m) => m.key === "engagement_rate")!;
  assert.equal(item.signals.find((s) => s.basis === "history")!.reference, 25);
  assert.equal(
    r.priorities.some((m) => m.key === "engagement_rate"),
    false,
  );
});
test("campos ausentes não viram zero; mínimo de três é por indicador", () => {
  const reports = [
    report(0, { views: 0 }),
    report(1, { views: 0 }),
    report(2, { reach: 100 }),
    report(3, { views: 10, reach: 90 }),
  ];
  const r = improvementReview(account(reports), reports[3], today);
  assert.equal(r.historyPeriods, 3);
  for (const item of [...r.priorities, ...r.strengths])
    assert.equal(
      item.signals.some((s) => s.basis === "history"),
      false,
    );
  reports[2] = report(2, { views: 0 });
  const complete = improvementReview(
    account(reports),
    reports[3],
    today,
  ).strengths.find((m) => m.key === "views")!;
  assert.equal(
    complete.signals.find((s) => s.basis === "history")!.reference,
    0,
  );
  assert.equal(
    complete.signals.find((s) => s.basis === "history")!.relative,
    undefined,
  );
});
test("perdas maiores são desfavoráveis, médias de tempo e taxas de pulos não são agregadas", () => {
  const reports = [0, 1, 2, 3].map((i) =>
    report(i, {
      unfollows: i === 3 ? 20 : 10,
      avg_watch_time_seconds: i === 3 ? 5 : 10,
      reels_skip_rate: i === 3 ? 50 : 30,
    }),
  );
  const r = improvementReview(account(reports), reports[3], today);
  assert.equal(
    r.priorities
      .find((m) => m.key === "unfollows")!
      .signals.find((s) => s.basis === "history")!.tone,
    "negative",
  );
  for (const key of ["avg_watch_time_seconds", "reels_skip_rate"])
    assert.equal(
      r.priorities
        .find((m) => m.key === key)!
        .signals.some((s) => s.basis === "history"),
      false,
    );
});
test("histórico elimina revisões duplicadas e períodos sobrepostos e usa a revisão mais recente", () => {
  const original = report(1, { views: 800 });
  original.recordedAt = "2026-10-25T12:00:00Z";
  const latest = structuredClone(original);
  latest.id = "latest";
  latest.recordedAt = "2026-10-26T12:00:00Z";
  latest.metrics.views = 80;
  const overlap = report(
    1,
    { views: 9000 },
    { start: "2026-10-12", end: "2026-10-18" },
  );
  const reports = [
    report(0, { views: 100 }),
    original,
    latest,
    overlap,
    report(2, { views: 120 }),
    report(3, { views: 90 }),
  ];
  const r = improvementReview(account(reports), reports.at(-1)!, today);
  assert.equal(r.historyPeriods, 3);
  assert.equal(
    r.priorities
      .find((m) => m.key === "views")!
      .signals.find((s) => s.basis === "history")!.reference,
    100,
  );
});
test("histórico ignora outra conta, cobertura, duração e dados de vida inteira", () => {
  const reports = [
    report(0, { views: 100 }),
    report(1, { views: 100 }),
    report(2, { views: 100 }),
    report(3, { views: 50 }),
  ];
  const a = account(reports);
  a.insights = [
    ...reports,
    { ...reports[0], account: "qa.other", metrics: { views: 9999 } },
    { ...reports[1], coverage: "paid", metrics: { views: 9999 } },
    { ...reports[2], contentWindow: "lifetime", metrics: { views: 9999 } },
    { ...reports[1], end: "2026-10-13", metrics: { views: 9999 } },
  ];
  const r = improvementReview(a, reports[3], today);
  assert.equal(r.historyPeriods, 3);
  assert.equal(
    r.priorities
      .find((m) => m.key === "views")!
      .signals.find((s) => s.basis === "history")!.reference,
    100,
  );
});
test("período aberto, vida inteira, cobertura desconhecida e conta trocada suspendem o julgamento", () => {
  const current = report(3, { reach: 100, total_interactions: 10 });
  const a = account([current]);
  for (const patch of [
    { end: today },
    { contentWindow: "lifetime" as const },
    { coverage: "unknown" as const },
    { account: "qa.other" },
  ]) {
    const r = improvementReview(a, { ...current, ...patch }, today);
    assert.ok(r.blocked);
    assert.equal(r.priorities.length, 0);
    assert.equal(r.strengths.length, 0);
  }
});
test("referência compatível pode revelar atenção mesmo com melhora frente ao período anterior", () => {
  const previous = report(2, { reach: 100, total_interactions: 4 }),
    current = report(3, { reach: 100, total_interactions: 5 });
  const a = account([previous, current]);
  a.performanceBenchmark = reference();
  const r = improvementReview(a, current, today),
    metric = r.priorities.find((m) => m.key === "engagement_rate")!;
  assert.equal(r.market.status, "ready");
  assert.equal(metric.signals.find((s) => s.basis === "sector")!.reference, 6);
  assert.equal(
    metric.signals.find((s) => s.basis === "sector")!.difference,
    -1,
  );
  assert.equal(
    metric.signals.find((s) => s.basis === "previous")!.tone,
    "positive",
  );
});
test("setor, modelo, cobertura, duração, idade, cronologia e proprietário incompatíveis não criam sinal de mercado", () => {
  const current = report(3, { reach: 100, total_interactions: 5 });
  for (const patch of [
    { sector: "beachwear" },
    { model: "retail" as const },
    { coverage: "paid" as const },
    { start: "2026-10-17" },
    { start: "2026-04-01", end: "2026-04-07" },
    { start: "2026-10-23", end: "2026-10-29" },
    { account: "qa.other" },
  ]) {
    const a = account([current]);
    a.performanceBenchmark = reference(patch);
    const r = improvementReview(a, current, today);
    assert.equal(r.market.status, "incompatible");
    assert.equal(
      r.priorities.some((m) => m.signals.some((s) => s.basis === "sector")),
      false,
    );
  }
});
test("zero no alcance impede taxa e não gera falso alerta de mercado", () => {
  const current = report(3, { reach: 0, total_interactions: 0 });
  const a = account([current]);
  a.performanceBenchmark = reference();
  const r = improvementReview(a, current, today);
  assert.equal(r.market.status, "incompatible");
  assert.equal(
    r.priorities.some((m) => m.key === "engagement_rate"),
    false,
  );
});
test("cadastro rejeita fórmula, amostra, origem, conta, datas e valores inválidos", () => {
  assert.equal(validatePerformanceBenchmark(reference(), "qa.evolve").value, 6);
  for (const patch of [
    { metric: "engagement_by_followers" },
    { sampleSize: 4 },
    { value: NaN },
    { value: -1 },
    { model: "unknown" },
    { coverage: "unknown" },
    { account: "qa.other" },
    { start: "2026-02-31" },
    { start: "2026-10-22", end: "2026-10-21" },
    { sourceUrl: "http://example.com/" },
    { sourceUrl: "https://localhost/" },
    { updatedAt: "bad" },
  ])
    assert.throws(() =>
      validatePerformanceBenchmark({ ...reference(), ...patch }, "qa.evolve"),
    );
});
test("salvar referência isola as contas e preserva avisos, tentativas e fila", () => {
  let store = registered();
  const alpha = store.activeId;
  workspace(store).data.settings.hasPendingWarning = true;
  workspace(store).data.runtime.sessionAttempts = 3;
  const before = JSON.stringify(workspace(store).data);
  store = accountCommand(store, {
    type: "SAVE_PERFORMANCE_BENCHMARK",
    data: reference(),
  });
  assert.equal(JSON.stringify(workspace(store).data), before);
  store = accountCommand(store, { type: "ADD_ACCOUNT", username: "qa.other" });
  assert.equal(workspace(store).performanceBenchmark, undefined);
  assert.equal(workspace(store, alpha).performanceBenchmark!.value, 6);
  const snapshot = JSON.stringify(store);
  assert.throws(() =>
    accountCommand(store, {
      type: "SAVE_PERFORMANCE_BENCHMARK",
      data: reference(),
    }),
  );
  assert.equal(JSON.stringify(store), snapshot);
});
test("backup, migração antiga e remoção preservam o contrato da referência", () => {
  let store = accountCommand(registered(), {
    type: "SAVE_PERFORMANCE_BENCHMARK",
    data: reference(),
  });
  const backup = accountBackup(workspace(store));
  let restored = registered();
  restored = applyScopedCommand(restored, restored.activeId, {
    type: "RESTORE",
    data: backup,
  });
  assert.equal(
    workspace(migrateStore(restored)).performanceBenchmark!.value,
    6,
  );
  restored = accountCommand(restored, { type: "REMOVE_PERFORMANCE_BENCHMARK" });
  assert.equal(workspace(restored).performanceBenchmark, undefined);
  assert.equal(
    workspace(migrateStore(initialStore())).performanceBenchmark,
    undefined,
  );
});
