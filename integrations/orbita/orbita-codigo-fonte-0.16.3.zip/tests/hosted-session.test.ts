import test from "node:test";
import assert from "node:assert/strict";
import {
  hostedSessionMatches,
  supportedHostedExtension,
} from "../src/core/hosted-session.ts";

test("sessão confirma a mesma identidade que abriu o painel", () => {
  const scope = "a".repeat(32);
  assert.equal(
    hostedSessionMatches({ ready: true, userScope: scope }, scope),
    true,
  );
  assert.equal(
    hostedSessionMatches({ ready: true, userScope: "b".repeat(32) }, scope),
    false,
  );
  for (const data of [
    { ready: true },
    { ready: false, userScope: scope },
    null,
    "login",
    { ready: "true", userScope: scope },
  ])
    assert.equal(hostedSessionMatches(data, scope), false);
});

test("painel exige extensão com o protocolo de identidade e prazo", () => {
  for (const v of [undefined, "", "0.15.0", "0.9.0", "invalid"])
    assert.equal(supportedHostedExtension(v), false);
  for (const v of ["0.16.0", "0.16.1", "0.17.0", "1.0.0"])
    assert.equal(supportedHostedExtension(v), true);
});
test("escopo inválido não libera leitura mesmo que a resposta o repita", () => {
  for (const scope of [
    null,
    undefined,
    "",
    "user-a",
    "A".repeat(32),
    "a".repeat(31),
  ])
    assert.equal(
      hostedSessionMatches({ ready: true, userScope: scope }, scope),
      false,
    );
});
