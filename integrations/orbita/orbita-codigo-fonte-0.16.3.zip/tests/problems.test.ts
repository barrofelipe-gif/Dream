import test from "node:test";
import assert from "node:assert/strict";
import {
  APP_SCOPE,
  emptyProblems,
  problemAdvice,
  problemCategory,
  problemText,
  PROBLEM_LIMIT,
  recordProblem,
  recoverProblem,
  scopedProblems,
  updateProblem,
  validateProblems,
} from "../src/core/problems.ts";
import { recoverStateRead } from "../src/core/recovery.ts";
import type { ProblemInput } from "../src/core/problems.ts";
const first = "2026-11-01T12:00:00.000Z",
  later = "2026-11-02T12:00:00.000Z";
const input = (patch: Partial<ProblemInput> = {}): ProblemInput => ({
  scope: "account-alpha",
  operation: "ACCOUNT_IMPORT_INSIGHTS",
  source: "dashboard",
  message: "Arquivo com formato inválido.",
  ...patch,
});
test("falhas iguais são agrupadas sem alterar o estado original", () => {
  const a = recordProblem(emptyProblems(), input(), first),
    copy = structuredClone(a.store),
    b = recordProblem(a.store, input(), later);
  assert.equal(b.store.entries.length, 1);
  assert.equal(b.id, a.id);
  assert.equal(b.store.entries[0].count, 2);
  assert.equal(b.store.entries[0].lastAt, later);
  assert.deepEqual(a.store, copy);
});
test("cada conta vê seus problemas e os gerais, sem incluir os de outras contas", () => {
  let s = recordProblem(emptyProblems(), input(), first).store;
  s = recordProblem(s, input({ scope: "account-beta" }), first).store;
  s = recordProblem(
    s,
    input({ scope: APP_SCOPE, message: "Falha ao carregar o painel." }),
    later,
  ).store;
  const visible = scopedProblems(s, "account-alpha");
  assert.equal(visible.length, 2);
  assert.ok(visible.every((p) => p.scope !== "account-beta"));
  assert.throws(
    () =>
      updateProblem(
        s,
        "account-beta",
        visible.find((p) => p.scope === "account-alpha")!.id,
        "resolved",
        "Conferido por teste completo.",
      ),
    /não encontrado/,
  );
});
test("resolução exige nota, preserva histórico e nova ocorrência reabre o grupo", () => {
  const a = recordProblem(emptyProblems(), input(), first);
  assert.throws(
    () => updateProblem(a.store, "account-alpha", a.id, "resolved", "ok"),
    /10/,
  );
  const fixed = updateProblem(
    a.store,
    "account-alpha",
    a.id,
    "resolved",
    "Corrigi o arquivo e importei com sucesso.",
    later,
  );
  assert.equal(fixed.entries[0].status, "resolved");
  assert.match(fixed.entries[0].events.at(-1)!.note, /Registro manual/);
  const again = recordProblem(fixed, input(), later).store;
  assert.equal(again.entries[0].status, "open");
  assert.equal(again.entries[0].count, 2);
  assert.ok(again.entries[0].events.some((e) => e.status === "resolved"));
});
test("recuperação de leitura é observação, não correção definitiva, e é idempotente", () => {
  const a = recordProblem(
    emptyProblems(),
    input({
      scope: APP_SCOPE,
      operation: "LOAD_STATE",
      message: "Could not establish connection. Receiving end does not exist.",
    }),
    first,
  );
  const recovered = recoverProblem(a.store, APP_SCOPE, a.id, later);
  assert.equal(recovered.entries[0].status, "monitoring");
  assert.equal(recovered.entries[0].recoveries, 1);
  assert.match(recovered.entries[0].events.at(-1)!.note, /causa ainda/);
  assert.equal(
    recoverProblem(recovered, APP_SCOPE, a.id, later).entries[0].recoveries,
    1,
  );
  const again = recordProblem(
    recovered,
    input({
      scope: APP_SCOPE,
      operation: "LOAD_STATE",
      message: a.store.entries[0].message,
    }),
    later,
  ).store;
  assert.equal(again.entries[0].status, "open");
});
test("registro de seguir ou aviso da plataforma não pode ser marcado como recuperação automática", () => {
  const a = recordProblem(
    emptyProblems(),
    input({
      operation: "QUEUE_ACTION",
      category: "uncertain",
      message: "Retorno da ação expirou.",
    }),
    first,
  );
  assert.throws(
    () => recoverProblem(a.store, "account-alpha", a.id, later),
    /Somente/,
  );
  assert.throws(
    () =>
      updateProblem(
        a.store,
        "account-alpha",
        a.id,
        "monitoring",
        "Tentar contornar o aviso.",
      ),
    /automática/,
  );
  assert.match(problemAdvice(a.store.entries[0]), /Não repetimos/);
});
test("credenciais e links são omitidos de mensagens e notas", () => {
  const raw =
    'Falha https://site.example/path?access_token=URLSECRET#x Bearer ABCSECRET {"password":"PASS SECRET","access_token":"TOKENVALUE"} senha=SENHASECRETA cookie=sessionidVALUE';
  const clean = problemText(raw);
  for (const value of [
    "URLSECRET",
    "ABCSECRET",
    "PASS SECRET",
    "TOKENVALUE",
    "SENHASECRETA",
    "sessionidVALUE",
  ])
    assert.equal(clean.includes(value), false, clean);
  assert.match(clean, /omitido/);
  assert.ok(clean.length <= 600);
  const a = recordProblem(emptyProblems(), input({ message: raw }), first);
  const b = updateProblem(
    a.store,
    "account-alpha",
    a.id,
    "resolved",
    raw,
    later,
  );
  assert.equal(JSON.stringify(b).includes("TOKENVALUE"), false);
});
test("erro de JSON não inclui trecho do arquivo, nem payload anexado a Error", () => {
  const error = new SyntaxError(
    'Unexpected token, "MINHA-SENHA-SEM-ROTULO" is not valid JSON',
  );
  assert.equal(problemText(error).includes("MINHA-SENHA"), false);
  assert.equal(problemText(error.message), problemText(error));
  const ordinary = Object.assign(new Error("Falha na leitura."), {
    payload: { password: "SECRET" },
  });
  assert.equal(problemText(ordinary), "Falha na leitura.");
});
test("validação do diagnóstico preserva somente campos conhecidos", () => {
  const a = recordProblem(emptyProblems(), input(), first).store;
  const raw = {
    ...a,
    access_token: "ROOT-SECRET",
    entries: [
      {
        ...a.entries[0],
        payload: { password: "NESTED-SECRET" },
        events: [{ ...a.entries[0].events[0], password: "EVENT-SECRET" }],
      },
    ],
  };
  const checked = validateProblems(raw);
  assert.equal(JSON.stringify(checked).includes("SECRET"), false);
  assert.deepEqual(checked, a);
});
test("histórico inválido é rejeitado sem zerar ou modificar os dados recebidos", () => {
  const raw = { version: 99, entries: [], pruned: 0, prunedOpen: 0 },
    copy = structuredClone(raw);
  assert.throws(() => validateProblems(raw));
  assert.deepEqual(raw, copy);
  const a = recordProblem(emptyProblems(), input(), first).store;
  assert.throws(
    () => validateProblems({ ...a, entries: [...a.entries, a.entries[0]] }),
    /inválido/,
  );
});
test("retenção remove resolvidos primeiro, informa descarte e preserva o problema novo", () => {
  const base = recordProblem(emptyProblems(), input(), first).store.entries[0],
    store = {
      version: 1 as const,
      entries: Array.from({ length: PROBLEM_LIMIT }, (_, i) => ({
        ...base,
        id: String(i),
        message: `Falha ${i}`,
        status: i === 20 ? ("resolved" as const) : ("open" as const),
      })),
      pruned: 0,
      prunedOpen: 0,
    };
  const result = recordProblem(
    store,
    input({ message: "Falha nova" }),
    later,
  ).store;
  assert.equal(result.entries.length, PROBLEM_LIMIT);
  assert.equal(result.pruned, 1);
  assert.equal(result.prunedOpen, 0);
  assert.equal(
    result.entries.some((p) => p.id === "20"),
    false,
  );
  const second = recordProblem(
    result,
    input({ message: "Outra falha nova" }),
    later,
  ).store;
  assert.equal(second.prunedOpen, 1);
  assert.ok(second.entries.some((p) => p.message === "Outra falha nova"));
});
test("eventos por grupo são limitados sem perder o total de ocorrências", () => {
  let s = emptyProblems();
  for (let i = 0; i < 20; i++) s = recordProblem(s, input(), first).store;
  assert.equal(s.entries[0].count, 20);
  assert.equal(s.entries[0].events.length, 12);
});
test("tipos de falha encaminham validação, armazenamento, plataforma e ação incerta", () => {
  assert.equal(problemCategory("QuotaExceededError storage failed"), "storage");
  assert.equal(
    problemCategory("Há um aviso do Instagram pendente."),
    "platform",
  );
  assert.equal(
    problemCategory(
      "Retorno da ação expirou. Confira o perfil antes de repetir.",
    ),
    "uncertain",
  );
  assert.equal(problemCategory("Receiving end does not exist"), "connection");
  assert.equal(problemCategory("Arquivo inválido"), "validation");
});
test("GET_STATE tenta uma vez mais após falha transitória e só então registra recuperação", async () => {
  let calls = 0;
  const events: string[] = [];
  const value = await recoverStateRead(
    "GET_STATE",
    async () => {
      calls++;
      if (calls === 1) throw new Error("Receiving end does not exist");
      return { ok: true };
    },
    {
      report: async () => {
        events.push("reported");
        return "id";
      },
      recovered: async (id) => {
        events.push(`recovered:${id}`);
      },
    },
    async (ms) => {
      assert.equal(ms, 250);
      events.push("wait");
    },
  );
  assert.equal(calls, 2);
  assert.deepEqual(events, ["reported", "wait", "recovered:id"]);
  assert.deepEqual(value, { ok: true });
});
test("erro de dados não dispara nova leitura", async () => {
  let calls = 0;
  const error = new Error("Cadastro inválido"),
    events: string[] = [];
  await assert.rejects(
    () =>
      recoverStateRead(
        "GET_STATE",
        async () => {
          calls++;
          throw error;
        },
        {
          report: async () => {
            events.push("reported");
            return "id";
          },
          recovered: async () => {
            events.push("recovered");
          },
        },
        async () => {
          throw Error("Não deveria esperar");
        },
      ),
    (e) => e === error,
  );
  assert.equal(calls, 1);
  assert.deepEqual(events, ["reported"]);
});
test("resposta explícita do worker com a palavra timeout também não é repetida", async () => {
  let calls = 0;
  const error = new Error("Timeout em uma validação de estado");
  error.name = "OrbitaResponseError";
  await assert.rejects(() =>
    recoverStateRead(
      "GET_STATE",
      async () => {
        calls++;
        throw error;
      },
      { report: async () => undefined, recovered: async () => {} },
      async () => {},
    ),
  );
  assert.equal(calls, 1);
});
test("ações e mutações não podem usar o mecanismo de repetição", async () => {
  for (const op of [
    "FOLLOW",
    "START",
    "ACCOUNT_COMMAND",
    "IMPORT_INSIGHTS",
    "READ_MARKET_PAGE",
    "COMMAND",
  ]) {
    let calls = 0;
    await assert.rejects(
      () =>
        recoverStateRead(
          op,
          async () => {
            calls++;
            return true;
          },
          { report: async () => undefined, recovered: async () => {} },
          async () => {},
        ),
      /só aceita/,
    );
    assert.equal(calls, 0);
  }
});
test("segunda falha é final, registrada, e não gera recuperação nem terceira tentativa", async () => {
  let calls = 0,
    reports = 0,
    recovered = 0;
  const second = new Error("Message port closed");
  await assert.rejects(
    () =>
      recoverStateRead(
        "GET_STATE",
        async () => {
          calls++;
          throw calls === 1
            ? new Error("Receiving end does not exist")
            : second;
        },
        {
          report: async () => {
            reports++;
            return "id";
          },
          recovered: async () => {
            recovered++;
          },
        },
        async () => {},
      ),
    (e) => e === second,
  );
  assert.equal(calls, 2);
  assert.equal(reports, 2);
  assert.equal(recovered, 0);
});
test("falha no diagnóstico não mascara a operação ou transforma sucesso em erro", async () => {
  let calls = 0;
  assert.equal(
    await recoverStateRead(
      "GET_STATE",
      async () => {
        if (++calls === 1) throw Error("Message port closed");
        return "loaded";
      },
      {
        report: async () => {
          throw Error("logger unavailable");
        },
        recovered: async () => {
          throw Error("logger unavailable");
        },
      },
      async () => {},
    ),
    "loaded",
  );
  calls = 0;
  assert.equal(
    await recoverStateRead(
      "GET_STATE",
      async () => {
        if (++calls === 1) throw Error("Message port closed");
        return "loaded";
      },
      {
        report: async () => "id",
        recovered: async () => {
          throw Error("logger unavailable");
        },
      },
      async () => {},
    ),
    "loaded",
  );
  const original = new Error("Formato inválido");
  await assert.rejects(
    () =>
      recoverStateRead(
        "GET_STATE",
        async () => {
          throw original;
        },
        {
          report: async () => {
            throw Error("logger unavailable");
          },
          recovered: async () => {},
        },
        async () => {},
      ),
    (e) => e === original,
  );
});
