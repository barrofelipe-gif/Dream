import test from "node:test";
import assert from "node:assert/strict";
import { JSDOM } from "jsdom";
import { verifyHostedActor } from "../src/hosted-access.ts";

test("salvar no modo hospedado exige a identidade que abriu o painel", async () => {
  const dom = new JSDOM(
    `<meta name="orbita-user" content="${"a".repeat(32)}">`,
    { url: "https://app.bfffitnessatacado.com.br/api/growth/orbita/painel" },
  );
  const originals = new Map<string, PropertyDescriptor | undefined>();
  let reads = 0,
    scope = "a".repeat(32),
    failures = 0;
  for (const [key, value] of Object.entries({
    window: dom.window,
    document: dom.window.document,
    location: dom.window.location,
    CustomEvent: dom.window.CustomEvent,
    fetch: async () => {
      reads++;
      return {
        ok: true,
        type: "basic",
        json: async () => ({ ready: true, userScope: scope }),
      };
    },
  })) {
    originals.set(key, Object.getOwnPropertyDescriptor(globalThis, key));
    Object.defineProperty(globalThis, key, {
      value,
      writable: true,
      configurable: true,
    });
  }
  dom.window.addEventListener("orbita-transport-error", () => failures++);
  try {
    await verifyHostedActor();
    scope = "b".repeat(32);
    await assert.rejects(verifyHostedActor(), /usuário/);
    assert.equal(reads, 2);
    assert.equal(failures, 1);
  } finally {
    for (const [key, value] of originals)
      value
        ? Object.defineProperty(globalThis, key, value)
        : Reflect.deleteProperty(globalThis, key);
    dom.window.close();
  }
});
test("prévia independente não consulta o login do app", async () => {
  const oldLocation = Object.getOwnPropertyDescriptor(globalThis, "location"),
    oldFetch = globalThis.fetch;
  let reads = 0;
  Object.defineProperty(globalThis, "location", {
    value: { href: "http://127.0.0.1:4173/" },
    configurable: true,
  });
  globalThis.fetch = async () => {
    reads++;
    throw Error("Não deve consultar");
  };
  try {
    await verifyHostedActor();
    assert.equal(reads, 0);
  } finally {
    globalThis.fetch = oldFetch;
    oldLocation
      ? Object.defineProperty(globalThis, "location", oldLocation)
      : Reflect.deleteProperty(globalThis, "location");
  }
});
