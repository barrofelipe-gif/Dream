import test from "node:test";
import assert from "node:assert/strict";
import { JSDOM } from "jsdom";
import {
  accountBackup,
  accountCommand,
  applyScopedCommand,
  initialStore,
  migrateStore,
  workspace,
} from "../src/core/accounts.ts";
import {
  adaptation,
  emptyMarket,
  experimentMeasurement,
  inferPattern,
  marketAnalysis,
  marketProfile,
  marketUrl,
  mergeMarket,
  ownPatternMatches,
  saveMarketExperiment,
  saveMarketReferences,
  suggestMarket,
  validateMarket,
} from "../src/core/market.ts";
import { validateInsightReport } from "../src/core/insights.ts";
import { readMarketPage } from "../src/extension/market-dom.ts";
const account = "qa.market";
const now = Date.parse("2026-11-03T14:00:00Z");
const ref = (i = 0, patch: Record<string, unknown> = {}) => ({
  url: `https://www.instagram.com/reel/Ref${i}/`,
  creator: "loja.origem",
  sector: "fitness",
  model: "wholesale",
  kind: "reel",
  pattern: "demo",
  title: `Exemplo fictício ${i}`,
  distribution: "organic",
  publishedAt: "2026-10-25T12:00:00Z",
  observedAt: "2026-10-26T12:00:00Z",
  windowHours: 24,
  metrics: { views: i === 0 ? 1200 : 100 },
  ...patch,
});
const book = () =>
  saveMarketReferences(
    undefined,
    { account, references: Array.from({ length: 6 }, (_, i) => ref(i)) },
    account,
  );
const store = () =>
  accountCommand(initialStore(), { type: "ADD_ACCOUNT", username: account });
const profile = () =>
  marketProfile({
    sector: "fitness",
    model: "wholesale",
    audience: "lojistas",
    bio: "Moda fitness no atacado",
  });
test("sugestão exige confirmação e não transforma bio ambígua em um único setor", () => {
  assert.deepEqual(
    suggestMarket("Moda fitness e biquínis no atacado e varejo"),
    { candidates: ["fitness", "beachwear"], model: "both" },
  );
  assert.deepEqual(suggestMarket("Meu estilo de vida"), {
    candidates: [],
    model: "unknown",
  });
  assert.equal(
    marketProfile({ ...profile(), sector: "Moda fitness" }).sector,
    "fitness",
  );
  assert.equal(inferPattern("Provador da coleção"), "demo");
});
test("setor, referências e testes pertencem à conta selecionada e entram no backup", () => {
  let s = store();
  s = accountCommand(s, {
    type: "SET_MARKET_PROFILE",
    data: { account, ...profile() },
  });
  s = accountCommand(s, {
    type: "SAVE_MARKET_REFERENCES",
    data: { account, references: [ref()] },
  });
  const a = workspace(s),
    r = a.market!.references[0];
  s = accountCommand(s, {
    type: "SAVE_MARKET_EXPERIMENT",
    data: {
      account,
      experiment: { referenceId: r.id, ...adaptation(profile(), r) },
    },
  });
  const backup = accountBackup(workspace(s)),
    first = s.activeId;
  s = accountCommand(s, { type: "ADD_ACCOUNT", username: "qa.other" });
  assert.equal(workspace(s).market, undefined);
  assert.throws(
    () =>
      accountCommand(s, {
        type: "SET_MARKET_PROFILE",
        data: { account, ...profile() },
      }),
    /conta/,
  );
  assert.throws(
    () =>
      accountCommand(s, {
        type: "SAVE_MARKET_REFERENCES",
        data: { account, references: [ref()] },
      }),
    /@qa.other/,
  );
  assert.throws(
    () => applyScopedCommand(s, s.activeId, { type: "RESTORE", data: backup }),
    /pertence/,
  );
  s = accountCommand(s, { type: "SELECT_ACCOUNT", id: first });
  s = applyScopedCommand(s, first, { type: "RESTORE", data: backup });
  assert.equal(workspace(s).market!.references.length, 1);
  assert.equal(workspace(s).market!.experiments.length, 1);
  assert.equal(
    migrateStore(structuredClone(s)).accounts.find((a) => a.id === first)!
      .market!.profile!.sector,
    "fitness",
  );
});
test("lote inválido é atômico e links iguais com parâmetros não duplicam referências", () => {
  const b = book(),
    copy = structuredClone(b);
  assert.throws(() =>
    saveMarketReferences(
      b,
      { account, references: [ref(10), ref(11, { metrics: { views: -1 } })] },
      account,
    ),
  );
  assert.deepEqual(b, copy);
  assert.throws(
    () =>
      saveMarketReferences(
        b,
        {
          account,
          references: [
            ref(10),
            ref(10, {
              url: "https://instagram.com/reel/Ref10/?utm_source=abc",
            }),
          ],
        },
        account,
      ),
    /repetidos/,
  );
  const updated = saveMarketReferences(
    b,
    { account, references: [ref(0, { metrics: { views: 2000 } })] },
    account,
  );
  assert.equal(updated.references.length, 6);
  assert.equal(updated.references[0].id, b.references[0].id);
});
test("zero é medido, ausência fica desconhecida e arquivo não forja origem de leitura", () => {
  const b = saveMarketReferences(
    undefined,
    {
      account,
      mode: "file",
      references: [
        ref(0, { metrics: { views: 0, likes: null }, source: "instagram" }),
      ],
    },
    account,
  );
  assert.equal(b.references[0].metrics.views, 0);
  assert.equal(b.references[0].metrics.likes, undefined);
  assert.equal(b.references[0].source, "file");
  for (const metrics of [
    { views: "1,2 mil" },
    { views: 1.2 },
    { views: Infinity },
    { views: -1 },
  ])
    assert.throws(() =>
      saveMarketReferences(
        b,
        { account, references: [ref(1, { metrics })] },
        account,
      ),
    );
});
test("URLs são canônicas e não permitem endpoints de login, esquemas ativos ou domínios locais", () => {
  assert.equal(marketUrl("https://40graus.com.br/"), "https://40graus.com.br/");
  assert.equal(
    marketUrl("https://instagram.com/reels/AbC/?x=1#test", true),
    "https://www.instagram.com/reel/AbC/",
  );
  assert.equal(
    marketUrl("https://www.facebook.com/ads/library/?id=123&x=1"),
    "https://www.facebook.com/ads/library/?id=123",
  );
  for (const url of [
    "javascript:alert(1)",
    "http://instagram.com/test/",
    "https://user:pass@instagram.com/test/",
    "https://127.0.0.1/a",
    "https://example.local/a",
    "https://instagram.com/accounts/login/",
    "https://instagram.com/explore/",
    "https://www.facebook.com/ads/library/",
  ])
    assert.throws(() => marketUrl(url));
  assert.throws(() => marketUrl("https://brand.com/", true));
});
test("janela requer data e horário reais com tolerância declarada de 30 minutos", () => {
  for (const patch of [
    { publishedAt: "2026-02-30T12:00:00Z" },
    { observedAt: "2099-01-01T12:00:00Z" },
    { publishedAt: undefined },
    { windowHours: 0 },
    { windowHours: 24.5 },
    { windowHours: 8761 },
    { observedAt: "2026-10-26T13:00:00Z" },
    { publishedAt: "2026-10-27T12:00:00Z" },
  ])
    assert.throws(() =>
      saveMarketReferences(
        undefined,
        { account, references: [ref(0, patch)] },
        account,
      ),
    );
  const b = saveMarketReferences(
    undefined,
    { account, references: [ref(0, { observedAt: "2026-10-26T12:30:00Z" })] },
    account,
  );
  assert.equal(b.references[0].windowHours, 24);
});
test("destaque exige cinco outros Reels comparáveis e não significa viral no setor inteiro", () => {
  const b = book(),
    r = marketAnalysis(b, 30, now);
  assert.equal(r.highlights.length, 1);
  assert.equal(r.highlights[0].ratio, 12);
  assert.equal(r.highlights[0].n, 5);
  assert.equal(r.highlights[0].median, 100);
  b.references.pop();
  assert.equal(marketAnalysis(b, 30, now).highlights.length, 0);
});
test("não mistura perfil, pago, desconhecido, setor, atacado/varejo, janela ou período", () => {
  for (const patch of [
    { creator: "outro.perfil" },
    { distribution: "paid" as const },
    { distribution: "unknown" as const },
    { sector: "beachwear" },
    { model: "retail" as const },
    { windowHours: 48, publishedAt: "2026-10-24T12:00:00Z" },
    { observedAt: "2026-09-02T12:00:00Z", publishedAt: "2026-09-01T12:00:00Z" },
  ]) {
    const b = book();
    Object.assign(b.references[5], patch);
    assert.equal(marketAnalysis(b, 30, now).highlights.length, 0);
  }
  const b = book();
  b.profile = { ...profile(), sector: "beachwear" };
  assert.equal(marketAnalysis(b, 30, now).references.length, 0);
});
test("base mediana zero, janela ausente, autor ausente e conteúdo sem idade não ganham destaque", () => {
  for (const change of ["zero", "unknownAge", "unknownCreator", "noWindow"]) {
    const b = book();
    if (change === "zero")
      b.references.slice(1).forEach((r) => (r.metrics.views = 0));
    if (change === "unknownAge") delete b.references[0].publishedAt;
    if (change === "unknownCreator") b.references[0].creator = "";
    if (change === "noWindow") delete b.references[0].windowHours;
    assert.equal(marketAnalysis(b, 30, now).highlights.length, 0);
  }
});
test("arquivamento e perfil mais recente sobrevivem ao backup antigo e remapeiam vínculos por URL", () => {
  const old = book();
  old.profile = { ...profile(), updatedAt: "2026-10-01T12:00:00Z" };
  const current = structuredClone(old);
  current.references[0].id = "new-id";
  current.references[0].archived = true;
  current.references[0].updatedAt = "2026-11-02T12:00:00Z";
  old.references[0].updatedAt = "2026-10-01T12:00:00Z";
  current.profile = {
    ...profile(),
    audience: "lojistas atuais",
    updatedAt: "2026-11-02T12:00:00Z",
  };
  const withTest = saveMarketExperiment(
    old,
    {
      account,
      experiment: {
        referenceId: old.references[0].id,
        ...adaptation(profile(), old.references[0]),
      },
    },
    account,
  );
  const merged = mergeMarket(current, withTest, account);
  assert.equal(merged.profile!.audience, "lojistas atuais");
  assert.equal(merged.references[0].archived, true);
  assert.equal(merged.experiments[0].referenceId, "new-id");
  assert.equal(marketAnalysis(merged, 30, now).references.length, 5);
});
test("edição da medição preserva vínculo do teste e estado arquivado", () => {
  let b = book();
  b = saveMarketExperiment(
    b,
    {
      account,
      experiment: {
        referenceId: b.references[0].id,
        ...adaptation(profile(), b.references[0]),
      },
    },
    account,
  );
  b.references[0].archived = true;
  const updated = saveMarketReferences(
    b,
    { account, references: [ref(0, { metrics: { views: 1600 } })] },
    account,
  );
  assert.equal(updated.references[0].archived, true);
  assert.equal(updated.experiments[0].referenceId, updated.references[0].id);
});
test("teste rejeita referência alheia e link de perfil como resultado; medido não inventa número", () => {
  const b = book(),
    draft = {
      referenceId: b.references[0].id,
      ...adaptation(profile(), b.references[0]),
    };
  assert.throws(
    () =>
      saveMarketExperiment(
        b,
        { account, experiment: { ...draft, referenceId: "foreign" } },
        account,
      ),
    /conta/,
  );
  assert.throws(
    () =>
      saveMarketExperiment(
        b,
        {
          account,
          experiment: {
            ...draft,
            ownUrl: "https://www.instagram.com/qa.market/",
          },
        },
        account,
      ),
    /publicação/,
  );
  const saved = saveMarketExperiment(
      b,
      { account, experiment: { ...draft, status: "measured" } },
      account,
    ),
    a = workspace(store());
  assert.equal(experimentMeasurement(a, saved.experiments[0]), undefined);
  assert.match(draft.recipe, /sua gravação/);
  assert.match(draft.cta, /atacado/);
});
test("medição do teste usa somente conteúdo local da revisão recente e a mesma janela", () => {
  const b = book(),
    draft = {
      referenceId: b.references[0].id,
      ...adaptation(profile(), b.references[0]),
      ownUrl: "https://www.instagram.com/reel/MyOwn/",
    };
  const exp = saveMarketExperiment(b, { account, experiment: draft }, account)
      .experiments[0],
    a = workspace(store());
  const r = validateInsightReport(
    {
      account,
      start: "2026-10-01",
      end: "2026-10-31",
      coverage: "organic",
      contentWindow: "period",
      content: [
        {
          id: "story",
          kind: "story",
          title: "Story",
          url: "https://www.instagram.com/stories/qa.market/123/",
          metrics: { views: 1 },
        },
        {
          id: "own",
          kind: "reel",
          title: "Provador próprio",
          url: exp.ownUrl,
          publishedAt: "2026-10-20T12:00:00Z",
          observationHours: 24,
          metrics: { total_interactions: 0 },
        },
      ],
    },
    account,
    "manual",
  );
  a.insights = [r];
  assert.equal(experimentMeasurement(a, exp)!.value, 0);
  assert.equal(experimentMeasurement(a, exp)!.comparable, true);
  a.insights.push({
    ...r,
    id: "latest",
    recordedAt: "2026-11-03T14:00:00Z",
    coverage: "unknown",
    content: [{ ...r.content.find((c) => c.id === "own")!, metrics: {} }],
  });
  a.insights[0].recordedAt = "2026-11-01T12:00:00Z";
  assert.equal(experimentMeasurement(a, exp)!.comparable, false);
  assert.equal(experimentMeasurement(a, exp)!.value, undefined);
});
test("comparar comigo usa só o relatório selecionado e correspondência de texto", () => {
  const a = workspace(store());
  const r = validateInsightReport(
    {
      account,
      start: "2026-10-01",
      end: "2026-10-07",
      metrics: { views: 10 },
      content: [
        { id: "p", kind: "reel", title: "Provador", metrics: { views: 10 } },
      ],
    },
    account,
    "manual",
  );
  a.insights = [r, { ...r, id: "other", content: [] }];
  assert.equal(ownPatternMatches(a, r.id, "demo").length, 1);
  assert.equal(ownPatternMatches(a, "other", "demo").length, 0);
});
const doc = (html: string) => new JSDOM(html).window.document;
test("leitura DOM confere sessão e cabeçalho do próprio perfil", () => {
  const d = doc(
    '<nav><a href="/qa.market/">Perfil</a></nav><main><header><h2>qa.market</h2><p>Moda fitness no atacado</p></header></main>',
  );
  assert.match(
    readMarketPage(d, "https://www.instagram.com/qa.market/", account).text,
    /atacado/,
  );
  assert.throws(
    () => readMarketPage(d, "https://www.instagram.com/other/", account),
    /sessão/,
  );
});
test("DOM lê contagens exatas da publicação confirmada; abreviadas ou ambíguas ficam desconhecidas", () => {
  const d = doc(
    '<main><article><a href="/reel/ABC/"><time>Data</time></a>\n<p>1.000 visualizações</p>\n<p>0 curtidas</p>\n<p>Ver todos os 5 comentários</p></article></main>',
  );
  const reading = readMarketPage(d, "https://www.instagram.com/reel/ABC/");
  assert.deepEqual(reading.metrics, { views: 1000, likes: 0, comments: 5 });
  const ambiguous = doc(
    '<main><article><a href="/reel/ABC/"><time>Data</time></a>\n<p>1,2 mil visualizações</p>\n<p>10 curtidas</p>\n<p>2 curtidas</p></article></main>',
  );
  assert.deepEqual(
    readMarketPage(ambiguous, "https://www.instagram.com/reel/ABC/").metrics,
    {},
  );
  assert.throws(
    () => readMarketPage(d, "https://www.instagram.com/reel/WRONG/"),
    /confirmada/,
  );
});
test("leitura falha em login, verificação, página privada ou estrutura desconhecida", () => {
  assert.throws(() =>
    readMarketPage(doc("<main></main>"), "https://www.instagram.com/reel/ABC/"),
  );
  assert.throws(
    () =>
      readMarketPage(
        doc(
          '<main><article><a href="/reel/ABC/"><time>Data</time></a>Esta conta é privada</article></main>',
        ),
        "https://www.instagram.com/reel/ABC/",
      ),
    /privado/,
  );
  const blocked = doc(
    '<div role="alert">Try again later</div><main><article><a href="/reel/ABC/">Data</a></article></main>',
  );
  assert.throws(() =>
    readMarketPage(blocked, "https://www.instagram.com/reel/ABC/"),
  );
});
test("limites e proprietário são revalidados na restauração", () => {
  const b = book();
  assert.throws(
    () => validateMarket({ ...b, account: "other" }, account),
    /@qa.market/,
  );
  assert.throws(
    () =>
      validateMarket(
        { ...b, references: [...b.references, b.references[0]] },
        account,
      ),
    /repetidos/,
  );
  assert.throws(
    () =>
      saveMarketReferences(
        b,
        { account, references: Array.from({ length: 501 }, (_, i) => ref(i)) },
        account,
      ),
    /500/,
  );
});
test("revisão: links de perfil têm caixa canônica, shortcodes mantêm caixa e livro alheio é rejeitado", () => {
  assert.equal(
    marketUrl("https://instagram.com/Loja.Exemplo/?x=1"),
    "https://www.instagram.com/loja.exemplo/",
  );
  assert.equal(
    marketUrl("https://instagram.com/reel/aBcD/"),
    "https://www.instagram.com/reel/aBcD/",
  );
  assert.throws(
    () =>
      saveMarketReferences(
        { ...book(), account: "foreign" },
        { account, references: [ref(10)] },
        account,
      ),
    /pertencer/,
  );
  const b = book();
  b.profile = { ...profile(), model: "unknown" };
  assert.equal(marketAnalysis(b, 30, now).highlights.length, 0);
  const a = workspace(store()),
    r = validateInsightReport(
      {
        account: "qa.other",
        start: "2026-10-01",
        end: "2026-10-07",
        content: [
          { id: "p", kind: "reel", title: "Provador", metrics: { views: 1 } },
        ],
      },
      "qa.other",
      "manual",
    );
  a.insights = [r];
  assert.equal(ownPatternMatches(a, r.id, "demo").length, 0);
});
test("revisão: isola artigo pelo permalink de data e rejeita múltiplos artigos ou números sem rótulo exato", () => {
  const d = doc(
    '<article><a href="/reel/OTHER/"><time>Data</time></a>\n<p>999 visualizações</p></article><main><article><a href="/reel/ABC/"><time>Data</time></a>\n<p>100 visualizações</p></article></main>',
  );
  assert.equal(
    readMarketPage(d, "https://www.instagram.com/reel/ABC/").metrics.views,
    100,
  );
  assert.throws(
    () =>
      readMarketPage(
        doc(
          '<article><a href="/reel/ABC/"><time>Data</time></a></article><article><a href="/reel/ABC/"><time>Data</time></a></article>',
        ),
        "https://www.instagram.com/reel/ABC/",
      ),
    /único/,
  );
  const ambiguous = doc(
    '<article><a href="/reel/ABC/"><time>Data</time></a>\n<p>1.234,567 visualizações</p>\n<p>100 reproduções</p></article>',
  );
  assert.equal(
    readMarketPage(ambiguous, "https://www.instagram.com/reel/ABC/").metrics
      .views,
    undefined,
  );
});
