import test from "node:test";
import assert from "node:assert/strict";
import {
  applyCommand,
  attemptsToday,
  audit,
  initialState,
  restoreState,
  validateSettings,
} from "../src/core/domain.ts";
import {
  budgetStopReason,
  pendingWarningReason,
  safetyAssessment,
  sessionLimit,
  STARTER,
  intervalReadyAt,
  lastAttemptTime,
} from "../src/core/safety.ts";

test("começo guiado define um piloto pequeno sem qualquer aumento automático", () => {
  const state = initialState();
  assert.equal(state.settings.dailyLimit, 5);
  assert.equal(state.settings.intervalMinutes, 15);
  assert.equal(sessionLimit(state.settings), 5);
  const assessment = safetyAssessment(state, 0);
  assert.equal(assessment.expanded, false);
  assert.equal(assessment.label, "Começo guiado configurado");
});
test("preferências antigas e backups recebem o controle de lote sem apagar os limites anteriores", () => {
  const settings = {
    ...initialState().settings,
    dailyLimit: 20,
    intervalMinutes: 10,
  };
  delete settings.sessionLimit;
  delete settings.hasPendingWarning;
  const validated = validateSettings(settings);
  assert.equal(validated.dailyLimit, 20);
  assert.equal(validated.sessionLimit, 5);
  assert.equal(validated.hasPendingWarning, false);
  const restored = restoreState({ ...initialState(), settings });
  assert.equal(restored.settings.dailyLimit, 20);
  assert.equal(restored.settings.sessionLimit, 5);
});
test("aplicar começo guiado pausa e mantém contadores, exclusões e aviso pendente", () => {
  const state = initialState();
  state.runtime.account = "conta";
  state.runtime.mode = "running";
  state.runtime.activeToken = "token";
  state.settings.dailyLimit = 100;
  state.settings.sessionLimit = 30;
  state.settings.hasPendingWarning = true;
  state.settings.exclusions = ["protegido"];
  audit(state, "attempt", "Tentativa");
  const guided = applyCommand(state, { type: "APPLY_STARTER" });
  assert.equal(guided.settings.dailyLimit, STARTER.dailyLimit);
  assert.equal(guided.settings.sessionLimit, 5);
  assert.equal(guided.settings.hasPendingWarning, true);
  assert.deepEqual(guided.settings.exclusions, ["protegido"]);
  assert.equal(attemptsToday(guided), 1);
  assert.equal(guided.runtime.sessionAttempts, 1);
  assert.equal(guided.runtime.mode, "paused");
  assert.equal(guided.runtime.activeToken, undefined);
});
test("cada tentativa consome também o lote, inclusive sem sucesso confirmado", () => {
  const state = initialState();
  state.runtime.account = "conta";
  state.settings.dailyLimit = 20;
  state.settings.sessionLimit = 2;
  audit(state, "attempt", "Já seguia");
  assert.equal(budgetStopReason(state, attemptsToday(state)), null);
  audit(state, "attempt", "Sem confirmação");
  assert.match(
    budgetStopReason(state, attemptsToday(state))!,
    /Lote encerrado/,
  );
  assert.equal(attemptsToday(state), 2);
});
test("aviso pendente tem prioridade sobre o saldo disponível", () => {
  const state = applyCommand(initialState(), { type: "REPORT_WARNING" });
  assert.equal(state.settings.hasPendingWarning, true);
  assert.ok(pendingWarningReason(state.settings));
  assert.match(budgetStopReason(state, 0)!, /aviso/);
  assert.equal(safetyAssessment(state, 0).notices[0].severity, "stop");
  assert.equal(safetyAssessment(state, 0).nextBatch, 0);
});
test("alterar controles invalida a autorização de uma ação ainda não enviada", () => {
  const state = initialState();
  state.runtime.mode = "running";
  state.runtime.activeToken = "token";
  state.runtime.nextRun = Date.now();
  const saved = applyCommand(state, {
    type: "SETTINGS",
    settings: { ...state.settings, dailyLimit: 10 },
  });
  assert.equal(saved.runtime.mode, "paused");
  assert.equal(saved.runtime.activeToken, undefined);
  assert.equal(saved.runtime.nextRun, undefined);
});
test("fila grande não aumenta o orçamento diário nem implica novos seguidores", () => {
  let state = applyCommand(initialState(), { type: "DEMO" });
  state.candidates.forEach((c) => {
    c.stage = "queued";
  });
  const assessment = safetyAssessment(state, 4);
  assert.equal(assessment.queued, 5);
  assert.equal(assessment.remaining, 1);
  assert.equal(assessment.nextBatch, 1);
  assert.ok(assessment.notices.some((n) => n.id === "backlog"));
  assert.ok(assessment.notices.some((n) => n.id === "near"));
  assert.equal(
    state.candidates.some((c) => c.stage === "followed"),
    false,
  );
});
test("avisa sobre várias fontes e sobre volume maior que o piloto", () => {
  let state = applyCommand(initialState(), {
    type: "CREATE_CAMPAIGN",
    name: "A",
    kind: "followers",
    target: "@um",
  });
  state = applyCommand(state, {
    type: "CREATE_CAMPAIGN",
    name: "B",
    kind: "following",
    target: "@dois",
  });
  state.settings.intervalMinutes = 1;
  const a = safetyAssessment(state, 0);
  assert.ok(a.notices.some((n) => n.id === "sources"));
  assert.ok(a.notices.some((n) => n.id === "pace"));
  assert.equal(a.sources, 2);
});
test("teto diário atingido zera o lote planejado sem sugerir que o próximo dia é seguro", () => {
  const state = applyCommand(initialState(), { type: "DEMO" });
  state.candidates[0].stage = "queued";
  const a = safetyAssessment(state, 5);
  assert.equal(a.nextBatch, 0);
  assert.match(a.notices.find((n) => n.id === "daily")!.text, /não comprova/);
});
test("lotes inválidos e campos de aviso adulterados são rejeitados", () => {
  for (const sessionLimit of [0, -1, 1.5, 501, NaN])
    assert.throws(() =>
      validateSettings({ ...initialState().settings, sessionLimit }),
    );
  assert.throws(() =>
    validateSettings({
      ...initialState().settings,
      hasPendingWarning: "false" as unknown as boolean,
    }),
  );
});
test("restaurar um backup anterior não apaga aviso atual nem devolve tentativas consumidas", () => {
  const oldBackup = initialState();
  let current = initialState();
  current.runtime.account = "conta";
  audit(current, "attempt", "Tentativa real registrada");
  current = applyCommand(current, { type: "REPORT_WARNING" });
  const restored = applyCommand(current, { type: "RESTORE", data: oldBackup });
  restored.runtime.account = "conta";
  assert.equal(restored.settings.hasPendingWarning, true);
  assert.equal(attemptsToday(restored), 1);
  assert.equal(restored.runtime.mode, "paused");
  assert.equal(lastAttemptTime(restored), lastAttemptTime(current));
});
test("pausar e aplicar o piloto não encurtam o intervalo entre tentativas", () => {
  const state = initialState();
  state.runtime.account = "conta";
  audit(state, "attempt", "Tentativa");
  const expected = lastAttemptTime(state) + 15 * 60000;
  assert.equal(
    intervalReadyAt(applyCommand(state, { type: "PAUSE" })),
    expected,
  );
  assert.equal(
    intervalReadyAt(applyCommand(state, { type: "APPLY_STARTER" })),
    expected,
  );
});
test("o intervalo sobrevive ao corte do histórico e mantém a conta correspondente", () => {
  const state = initialState();
  state.runtime.account = "conta";
  audit(state, "attempt", "Tentativa");
  const expected = intervalReadyAt(state);
  state.audit = [];
  assert.equal(intervalReadyAt(state), expected);
  state.runtime.account = "outra";
  assert.equal(intervalReadyAt(state), 0);
});
test("backup restaura a última tentativa sem antecipar o relógio atual da conta", () => {
  const state = initialState();
  state.runtime.account = "conta";
  audit(state, "attempt", "Tentativa");
  const restored = restoreState(JSON.parse(JSON.stringify(state)));
  restored.runtime.account = "conta";
  assert.equal(intervalReadyAt(restored), intervalReadyAt(state));
  const newer = new Date(Date.now() + 1000).toISOString();
  state.lastAttempts = { "@conta": newer };
  const merged = applyCommand(state, { type: "RESTORE", data: restored });
  merged.runtime.account = "conta";
  assert.equal(lastAttemptTime(merged), Date.parse(newer));
});
