import test from "node:test";
import assert from "node:assert/strict";
import {
  addChannelResult,
  followerAcquisition,
  mergeAcquisition,
  parseFollowerOrigins,
  setFollowerOrigins,
  validateAcquisition,
  validateChannelResult,
} from "../src/core/acquisition.ts";
import {
  accountBackup,
  accountCommand,
  applyScopedCommand,
  initialStore,
  migrateStore,
  workspace,
} from "../src/core/accounts.ts";
import { addRelationshipSnapshot } from "../src/core/relationships.ts";
import type { AccountWorkspace } from "../src/core/types.ts";
function account(): AccountWorkspace {
  const a = workspace(
    accountCommand(initialStore(), {
      type: "ADD_ACCOUNT",
      username: "qa.origins",
    }),
  );
  a.relationships = addRelationshipSnapshot(
    undefined,
    {
      account: a.username,
      at: "2026-10-01T12:00:00Z",
      source: "file",
      followers: ["antigo"],
      following: [],
      followersComplete: true,
      followingComplete: true,
    },
    a.username!,
  );
  a.relationships = addRelationshipSnapshot(
    a.relationships,
    {
      account: a.username,
      at: "2026-10-15T12:00:00Z",
      source: "file",
      followers: ["antigo", "dalu_novo", "anuncio", "organico", "sem_origem"],
      following: [],
      followersComplete: true,
      followingComplete: true,
    },
    a.username!,
  );
  a.data.campaigns = [
    {
      id: "dalu",
      name: "Dalu Fitness",
      kind: "followers",
      target: "dalu.fitness",
      createdAt: "2026-09-25T12:00:00Z",
      archived: false,
    },
    {
      id: "comments",
      name: "Comentários do Reel",
      kind: "commenters",
      target: "https://www.instagram.com/reel/exemplo/",
      createdAt: "2026-09-25T12:00:00Z",
      archived: false,
    },
  ];
  a.data.candidates = [
    {
      id: "lead",
      username: "dalu_novo",
      name: "",
      sources: [
        {
          campaignId: "dalu",
          url: "https://www.instagram.com/dalu.fitness/followers/",
          at: "2026-09-30T12:00:00Z",
        },
        {
          campaignId: "comments",
          url: "https://www.instagram.com/reel/exemplo/",
          at: "2026-10-05T12:00:00Z",
        },
      ],
      stage: "followed",
      createdAt: "2026-09-30T12:00:00Z",
      updatedAt: "2026-10-10T12:00:00Z",
      note: "",
    },
  ];
  a.data.audit = [
    {
      id: "event",
      username: "dalu_novo",
      account: a.username,
      kind: "followed",
      at: "2026-10-10T12:00:00Z",
      message: "Seguindo confirmado",
    },
  ];
  return a;
}
const origin = (username = "dalu_novo") => ({
  account: "qa.origins",
  username,
  channel: "prospecting",
  sourceLabel: "Seguidores de Dalu Fitness",
  campaignId: "dalu",
  evidence: "self_report",
  note: "Informado pela pessoa",
});
const report = () => ({
  account: "qa.origins",
  start: "2026-10-01",
  end: "2026-10-15",
  channel: "paid",
  name: "Anúncio de outubro",
  followers: 40,
  attributionWindow: "Regra copiada do relatório consultado",
  note: "Dado manual fictício",
});
test("fonte encontrada não confirma origem e desconhecido nunca vira orgânico", () => {
  const a = account(),
    r = followerAcquisition(a, { scope: "new" });
  assert.equal(r.rows.length, 4);
  assert.equal(r.counts.unknown, 4);
  assert.equal(r.counts.organic, 0);
  assert.equal(r.counts.prospecting, 0);
  const row = r.rows.find((r) => r.username === "dalu_novo")!;
  assert.equal(row.origin, undefined);
  assert.equal(row.associations.length, 2);
  assert.equal(row.outboundAction?.kind, "followed");
  assert.equal(r.associated, 1);
});
test("datas distinguem fonte anterior ao intervalo de fonte dentro do intervalo sem inferir ordem do follow", () => {
  const row = followerAcquisition(account(), { scope: "new" }).rows.find(
    (r) => r.username === "dalu_novo",
  )!;
  assert.equal(row.associations[0].timing, "before_interval");
  assert.equal(row.associations[1].timing, "within_interval");
});
test("coleta ou campanha posterior à medição não cria associação retroativa", () => {
  const a = account();
  a.data.candidates[0].sources[0].at = "2026-10-20T12:00:00Z";
  a.data.campaigns[1].createdAt = "2026-10-20T12:00:00Z";
  assert.equal(
    followerAcquisition(a, { scope: "new" }).rows.find(
      (r) => r.username === "dalu_novo",
    )!.associations.length,
    0,
  );
});
test("fontes sobrepostas preservam todos os caminhos sem somar pessoas duas vezes", () => {
  const a = account();
  a.data.candidates[0].sources.push({
    ...a.data.candidates[0].sources[0],
    url: "https://www.instagram.com/outra/",
  });
  const r = followerAcquisition(a, { scope: "new" });
  assert.equal(r.associated, 1);
  assert.equal(r.sources.length, 2);
  assert.equal(
    r.sources.reduce((n, s) => n + s.matches, 0),
    2,
  );
  assert.equal(
    r.rows[0].associations?.length ||
      r.rows.find((x) => x.username === "dalu_novo")?.associations.length,
    2,
  );
});
test("somente ação da própria conta e anterior à medição aparece como histórico de saída", () => {
  const a = account();
  a.data.audit[0].account = "qa.other";
  assert.equal(
    followerAcquisition(a, { scope: "new" }).rows.find(
      (r) => r.username === "dalu_novo",
    )!.outboundAction,
    undefined,
  );
  a.data.audit[0].account = a.username;
  a.data.audit[0].at = "2026-10-20T12:00:00Z";
  assert.equal(
    followerAcquisition(a, { scope: "new" }).rows.find(
      (r) => r.username === "dalu_novo",
    )!.outboundAction,
    undefined,
  );
});
test("sem duas listas completas não há coorte inventada de novos seguidores", () => {
  const a = account();
  a.relationships!.snapshots[1].followersComplete = false;
  const newer = followerAcquisition(a, { scope: "new" });
  assert.equal(newer.available, false);
  assert.equal(newer.rows.length, 0);
  const current = followerAcquisition(a, { scope: "current" });
  assert.equal(current.available, true);
  assert.equal(current.rows.length, 5);
});
test("quem já estava na base não conta como novo, mas pode ser consultado no recorte atual", () => {
  const a = account();
  assert.ok(
    !followerAcquisition(a, { scope: "new" }).rows.some(
      (r) => r.username === "antigo",
    ),
  );
  assert.equal(
    followerAcquisition(a, { scope: "current" }).rows.find(
      (r) => r.username === "antigo",
    )?.alreadyInBaseline,
    true,
  );
});
test("classificação informada é exclusiva por pessoa e não apaga associações observadas", () => {
  const a = account();
  a.acquisition = setFollowerOrigins(a, [
    origin(),
    {
      ...origin("anuncio"),
      channel: "paid",
      sourceLabel: "Campanha verão",
      campaignId: undefined,
      evidence: "tracking",
    },
    {
      ...origin("organico"),
      channel: "organic",
      sourceLabel: "Busca",
      campaignId: undefined,
      evidence: "manual",
    },
  ]);
  const r = followerAcquisition(a, { scope: "new" });
  assert.deepEqual(r.counts, {
    organic: 1,
    paid: 1,
    prospecting: 1,
    unknown: 1,
  });
  assert.equal(
    r.rows.find((r) => r.username === "dalu_novo")!.associations.length,
    2,
  );
  assert.equal(r.sources.find((s) => s.campaignId === "dalu")!.informed, 1);
});
test("classificar um candidato não o transforma em seguidor sem observação na lista", () => {
  const a = account();
  a.acquisition = setFollowerOrigins(a, origin("ainda_nao_segue"));
  const r = followerAcquisition(a, { scope: "current" });
  assert.ok(!r.rows.some((row) => row.username === "ainda_nao_segue"));
  assert.equal(r.counts.prospecting, 0);
});
test("remover a classificação mantém desconhecido e backup antigo não a reativa", () => {
  const a = account();
  a.acquisition = setFollowerOrigins(a, origin());
  const old = structuredClone(a.acquisition);
  a.acquisition = setFollowerOrigins(a, {
    ...origin(),
    channel: "unknown",
    campaignId: undefined,
    sourceLabel: "",
  });
  const merged = mergeAcquisition(a, old);
  assert.equal(merged.assignments[0].channel, "unknown");
  assert.equal(merged.assignments[0].campaignId, undefined);
});
test("total agregado de anúncio não é distribuído entre @perfis nem subtraído para inventar orgânico", () => {
  const a = account();
  a.acquisition = addChannelResult(a, report());
  const r = followerAcquisition(a, { scope: "new" });
  assert.equal(a.acquisition.reports[0].followers, 40);
  assert.equal(r.counts.paid, 0);
  assert.equal(r.counts.organic, 0);
  assert.equal(r.counts.unknown, 4);
});
test("resultados agregados deduplicam a cópia idêntica e mantêm recortes diferentes sem somá-los", () => {
  const a = account();
  a.acquisition = addChannelResult(a, report());
  a.acquisition = addChannelResult(a, report());
  assert.equal(a.acquisition.reports.length, 1);
  a.acquisition = addChannelResult(a, {
    ...report(),
    attributionWindow: "Outra regra",
  });
  assert.equal(a.acquisition.reports.length, 2);
  for (const data of [
    { ...report(), followers: -1 },
    { ...report(), followers: 1.5 },
    { ...report(), start: "2026-02-30" },
    { ...report(), end: "2099-01-01" },
    { ...report(), attributionWindow: "" },
  ])
    assert.throws(() => validateChannelResult(data, "qa.origins"));
});
test("classificações de outro dono, campanha alheia e importação com erro são atômicas", () => {
  const a = account(),
    before = JSON.stringify(a);
  assert.throws(
    () =>
      setFollowerOrigins(a, [
        origin(),
        { ...origin("outro"), account: "qa.other" },
      ]),
    /@qa.origins/,
  );
  assert.throws(
    () => setFollowerOrigins(a, { ...origin(), campaignId: "alheia" }),
    /não pertence/,
  );
  assert.throws(
    () => setFollowerOrigins(a, [origin(), origin()]),
    /mais de uma vez/,
  );
  assert.equal(JSON.stringify(a), before);
});
test("CSV e JSON preservam conta e evidência sem aceitar um relatório anônimo de anúncios como pessoas", () => {
  const a = account(),
    csv =
      "account,username,channel,source_label,evidence,note\nqa.origins,anuncio,paid,Campanha outubro,manual,Informado";
  a.acquisition = setFollowerOrigins(a, parseFollowerOrigins(csv));
  assert.equal(a.acquisition.assignments[0].channel, "paid");
  assert.throws(
    () => parseFollowerOrigins("campaign,followers\nCampanha,40"),
    /não identifica/,
  );
  assert.throws(
    () =>
      parseFollowerOrigins(
        JSON.stringify({
          account: "qa.origins",
          assignments: [{ ...origin(), account: "qa.other" }],
        }),
      ),
    /contas diferentes/,
  );
});
test("backup e migração mantêm classificação, agregado e isolamento por conta", () => {
  let s = accountCommand(initialStore(), {
    type: "ADD_ACCOUNT",
    username: "qa.origins",
  });
  workspace(s).data = account().data;
  s = accountCommand(s, { type: "SET_FOLLOWER_ORIGIN", data: origin() });
  s = accountCommand(s, { type: "RECORD_CHANNEL_RESULT", data: report() });
  const backup = accountBackup(workspace(s));
  let fresh = initialStore();
  fresh = applyScopedCommand(fresh, fresh.activeId, {
    type: "RESTORE",
    data: backup,
  });
  fresh = applyScopedCommand(fresh, fresh.activeId, {
    type: "RESTORE",
    data: backup,
  });
  const a = workspace(migrateStore(JSON.parse(JSON.stringify(fresh))));
  assert.equal(a.acquisition!.assignments.length, 1);
  assert.equal(a.acquisition!.reports.length, 1);
  fresh = accountCommand(fresh, { type: "ADD_ACCOUNT", username: "qa.other" });
  assert.equal(workspace(fresh).acquisition, undefined);
  assert.throws(
    () =>
      accountCommand(fresh, { type: "SET_FOLLOWER_ORIGIN", data: origin() }),
    /@qa.other/,
  );
});
test("armazenamento rejeita dono e metadados corrompidos sem apagar fontes salvas", () => {
  const a = account();
  a.acquisition = setFollowerOrigins(a, origin());
  assert.throws(
    () => validateAcquisition({ ...a.acquisition, account: "qa.other" }, a),
    /@qa.origins/,
  );
  const copy = structuredClone(a.acquisition);
  copy.assignments[0].updatedAt = "2026-02-30T12:00:00Z";
  assert.throws(() => validateAcquisition(copy, a), /Data/);
});
