import test from "node:test";
import assert from "node:assert/strict";
import { contentGuidance, publicationClock } from "../src/core/guidance.ts";
import { contentPerformance } from "../src/core/growth.ts";
import {
  parseInsightFile,
  validateInsightReport,
  contentRevision,
  localDay,
} from "../src/core/insights.ts";
import {
  accountBackup,
  accountCommand,
  initialStore,
  migrateStore,
  workspace,
} from "../src/core/accounts.ts";
import type { InsightContent, InsightReport } from "../src/core/types.ts";
const options = {
  objective: "engagementRate" as const,
  window: 24,
  format: "story" as const,
  timeZone: "America/Sao_Paulo",
};
function report(): InsightReport {
  return validateInsightReport(
    {
      account: "qa.stories",
      start: "2026-10-01",
      end: "2026-10-31",
      coverage: "organic",
      metrics: { follows: 999 },
      content: Array.from({ length: 6 }, (_, i) => ({
        id: `s${i}`,
        kind: "story",
        title: `Story ${i}`,
        publishedAt: `2026-10-${10 + i}T${i < 3 ? "18" : "12"}:00:00-03:00`,
        observationHours: 24,
        storyMedia: i < 3 ? "photo" : "video",
        storySticker: i < 3 ? "question_box" : "none",
        theme: "Dicas",
        metrics: {
          reach: 1000,
          total_interactions: i < 3 ? 200 : 50,
          replies: i < 3 ? 20 : 5,
          question_answers: i < 3 ? 10 : 0,
        },
      })),
    },
    "qa.stories",
    "file",
  );
}
test("mídia e figurinha são dimensões separadas e permanecem no CSV e JSON", () => {
  const r = report();
  assert.equal(r.content[0].storyMedia, "photo");
  assert.equal(r.content[0].storySticker, "question_box");
  const csv =
    "account,start,end,coverage,scope,content_id,metric,value,story_media,story_sticker\nqa.stories,2026-10-01,2026-10-31,organic,story,s1,reach,100,photo,question_box";
  const parsed = parseInsightFile(csv) as { content: InsightContent[] }[];
  assert.equal(parsed[0].content[0].storyMedia, "photo");
  assert.equal(parsed[0].content[0].storySticker, "question_box");
  assert.throws(
    () =>
      parseInsightFile(
        csv +
          "\nqa.stories,2026-10-01,2026-10-31,organic,story,s1,replies,1,video,question_box",
      ),
    /conflitantes/,
  );
});
test("campos de Story rejeitam enum inválido e outros formatos sem inferir nenhum", () => {
  const r = report();
  for (const content of [
    { ...r.content[0], storyMedia: "audio" },
    { ...r.content[0], storySticker: "pergunta" },
    { ...r.content[0], kind: "post" },
  ]) {
    assert.throws(
      () =>
        validateInsightReport(
          { ...r, content: [content] },
          r.account,
          "manual",
        ),
      /Story/,
    );
  }
  const c = { ...r.content[0] };
  delete c.storyMedia;
  delete c.storySticker;
  const old = validateInsightReport({ ...r, content: [c] }, r.account, "file")
    .content[0];
  assert.equal(old.storySticker, undefined);
  assert.equal(old.storyMedia, undefined);
});
test("respostas à caixinha não são inferidas de replies ou de toques", () => {
  const c = report().content[0];
  const a = contentPerformance({
    ...c,
    metrics: { reach: 100, replies: 2, sticker_taps: 10 },
  });
  assert.equal(a.repliesPer1000, 20);
  assert.equal(a.questionAnswersPer1000, undefined);
  assert.equal(
    contentPerformance({ ...c, metrics: { reach: 100, question_answers: 0 } })
      .questionAnswersPer1000,
    0,
  );
  assert.equal(
    contentPerformance({ ...c, metrics: { reach: 0, question_answers: 1 } })
      .questionAnswersPer1000,
    undefined,
  );
});
test("uma janela que termina mais tarde hoje ainda não é uma medição completa", () => {
  const r = report();
  assert.throws(
    () =>
      validateInsightReport(
        {
          ...r,
          start: localDay(),
          end: localDay(),
          content: [
            {
              ...r.content[0],
              publishedAt: new Date(Date.now() - 3600000).toISOString(),
              observationHours: 24,
            },
          ],
        },
        r.account,
        "manual",
      ),
    /não está completa/,
  );
});
test("horários usam um fuso explícito e convertem o dia sem alterar o relatório", () => {
  assert.deepEqual(publicationClock("2026-10-10T23:30:00-03:00", "UTC"), {
    date: "2026-10-11",
    hour: 2,
    weekday: 0,
  });
  assert.equal(
    publicationClock("2026-10-10T00:30:00-03:00", "America/Sao_Paulo").hour,
    0,
  );
  assert.equal(
    publicationClock("2026-07-01T12:00:00Z", "America/New_York").hour,
    8,
  );
  assert.equal(
    publicationClock("2026-12-01T12:00:00Z", "America/New_York").hour,
    7,
  );
  assert.throws(
    () =>
      contentGuidance(report(), { ...options, timeZone: "Fuso/Inexistente" }),
    RangeError,
  );
});
test("orientação usa medianas da conta, formato e janela escolhidos", () => {
  const r = report(),
    original = JSON.stringify(r),
    a = contentGuidance(r, options);
  assert.equal(a.hourBest?.label, "18h–20h");
  assert.equal(a.hourBest?.value, 20);
  assert.equal(a.hourBest?.reference, 5);
  assert.equal(a.hourBest?.n, 3);
  assert.equal(a.mediaBest?.label, "Foto");
  assert.equal(a.stickerBest?.label, "Caixinha de perguntas");
  assert.equal(
    contentGuidance(r, { ...options, timeZone: "UTC" }).hourBest?.label,
    "20h–22h",
  );
  assert.equal(JSON.stringify(r), original);
});
test("mistura de formatos e falta de dados não produzem melhor horário", () => {
  const r = report();
  assert.equal(
    contentGuidance(r, { ...options, format: "all" }).hourBest,
    undefined,
  );
  assert.equal(
    contentGuidance(r, { ...options, format: "reel" }).hourBest,
    undefined,
  );
  assert.equal(
    contentGuidance({ ...r, content: r.content.slice(0, 5) }, options).hourBest,
    undefined,
  );
  assert.equal(
    contentGuidance(r, { ...options, window: 48 }).hourBest,
    undefined,
  );
});
test("cobertura desconhecida, vida inteira e exploração não orientam horários ou tipos", () => {
  const r = report();
  for (const [data, opts] of [
    [{ ...r, coverage: "unknown" }, options],
    [{ ...r, contentWindow: "lifetime" }, options],
    [r, { ...options, window: "all" }],
  ] as const) {
    const a = contentGuidance(data as InsightReport, opts);
    assert.equal(a.hourBest, undefined);
    assert.equal(a.mediaBest, undefined);
    assert.equal(a.stickerBest, undefined);
  }
});
test("rajada de Stories num único dia não basta para uma recomendação", () => {
  const r = report();
  r.content = r.content.map((c) => ({
    ...c,
    publishedAt: c.publishedAt!.replace(/2026-10-\d{2}/, "2026-10-10"),
  }));
  const a = contentGuidance(r, options);
  assert.equal(a.hourBest, undefined);
  assert.equal(a.mediaBest, undefined);
  assert.equal(a.stickerBest, undefined);
});
test("metadado desconhecido não vira sem figurinha nem entra no contraste", () => {
  const r = report();
  for (const c of r.content.slice(3)) delete c.storySticker;
  const a = contentGuidance(r, options);
  assert.equal(a.stickerBest, undefined);
  assert.equal(a.stickerGroups[0].otherN, 0);
  assert.equal(a.missingStorySticker, 3);
});
test("seguidores totais e métricas ausentes não viram taxas para orientar", () => {
  const r = report();
  r.content = r.content.map((c) => ({ ...c, metrics: { reach: 1000 } }));
  const a = contentGuidance(r, { ...options, objective: "followersPer1000" });
  assert.equal(a.eligible, 0);
  assert.equal(a.hourBest, undefined);
});
test("não força vencedor com taxas iguais ou zero", () => {
  for (const value of [0, 10]) {
    const r = report();
    for (const c of r.content) c.metrics.total_interactions = value;
    const a = contentGuidance(r, options);
    assert.equal(a.hourBest, undefined);
    assert.equal(a.mediaBest, undefined);
  }
});
test("dia da semana exige observações em datas distintas e não é combinado com horário", () => {
  const r = report();
  r.content.forEach(
    (c, i) =>
      (c.publishedAt = `2026-10-${String([5, 12, 19, 6, 13, 20][i]).padStart(2, "0")}T${i < 3 ? "18" : "12"}:00:00-03:00`),
  );
  const a = contentGuidance(r, options);
  assert.equal(a.dayBest?.label, "Segunda-feira");
  assert.equal(a.hourBest?.label, "18h–20h");
  assert.equal(a.dayBest?.dates, 3);
});
test("classificações de Story sobrevivem a versões, armazenamento e backup", () => {
  let s = initialStore();
  s = accountCommand(s, { type: "ADD_ACCOUNT", username: "qa.stories" });
  s = accountCommand(s, { type: "IMPORT_INSIGHTS", data: [report()] });
  const base = workspace(s).insights![0],
    content = {
      ...base.content[0],
      storyMedia: "video",
      metrics: { ...base.content[0].metrics, total_interactions: 250 },
    };
  const edited = contentRevision(base, base.account, base, content);
  s = accountCommand(s, { type: "RECORD_INSIGHTS", data: edited });
  const restored = migrateStore(JSON.parse(JSON.stringify(s)));
  const reports = workspace(restored).insights!;
  assert.equal(reports[0].content[0].storyMedia, "photo");
  assert.equal(reports[1].content[0].storyMedia, "video");
  assert.ok(
    JSON.stringify(accountBackup(workspace(restored))).includes("question_box"),
  );
});
