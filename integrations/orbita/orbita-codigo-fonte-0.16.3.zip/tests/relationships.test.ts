import test from "node:test";
import assert from "node:assert/strict";
import {
  addRelationshipSnapshot,
  emptyRelationships,
  mergeRelationships,
  parseRelationshipList,
  relationshipAnalysis,
  relationshipUsername,
  setRelationshipProtection,
  validateRelationships,
  validateRelationshipSnapshot,
} from "../src/core/relationships.ts";
import {
  accountBackup,
  accountCommand,
  applyScopedCommand,
  initialStore,
  migrateStore,
  workspace,
} from "../src/core/accounts.ts";
import type { RelationshipSnapshot } from "../src/core/types.ts";
const raw = (at = "2026-10-01T12:00:00Z") => ({
  account: "qa.relations",
  at,
  source: "file",
  followers: ["amiga", "antigo", "mutuo"],
  following: ["amiga", "importante", "mutuo", "naoreciproco"],
  followersComplete: true,
  followingComplete: true,
  note: "Dados fictícios",
});
const book = () => addRelationshipSnapshot(undefined, raw(), "qa.relations");
const store = () =>
  accountCommand(initialStore(), {
    type: "ADD_ACCOUNT",
    username: "qa.relations",
    accountType: "personal",
  });
test("normaliza listas explícitas, links diretos e _u sem inferir dados", () => {
  const parsed = parseRelationshipList(
    "@Amiga\nhttps://www.instagram.com/_u/mutuo/\namiga\n",
    "followers",
    "qa.relations",
  );
  assert.deepEqual(parsed.names, ["amiga", "mutuo"]);
  assert.equal(parsed.duplicates, 1);
  assert.deepEqual(
    parseRelationshipList(
      "username\n@amiga\nmutuo",
      "following",
      "qa.relations",
      "seguidos.csv",
    ).names,
    ["amiga", "mutuo"],
  );
  assert.deepEqual(
    parseRelationshipList("[]", "followers", "qa.relations").names,
    [],
  );
});
test("texto não perde a primeira pessoa por parecer cabeçalho, e extensões têm formatos explícitos", () => {
  assert.deepEqual(
    parseRelationshipList(
      "username\nperfil\n@perfil",
      "followers",
      "qa.relations",
    ).names,
    ["perfil", "username"],
  );
  assert.throws(
    () =>
      parseRelationshipList(
        "amiga\nmutuo",
        "followers",
        "qa.relations",
        "lista.csv",
      ),
    /cabeçalho username/,
  );
  assert.throws(
    () =>
      parseRelationshipList(
        "amiga",
        "followers",
        "qa.relations",
        "followers_1.json",
      ),
    /JSON/,
  );
});
test("rejeita URLs externas, rotas de publicação, linhas inválidas e formatos ambíguos", () => {
  for (const value of [
    "https://evil.test/amiga",
    "https://www.instagram.com/p/abc",
    "javascript:alert(1)",
    "https://www.instagram.com:1234/amiga",
    "https://www.instagram.com/amiga/followers/",
    "https://user:pass@instagram.com/amiga",
  ])
    assert.throws(() => relationshipUsername(value));
  for (const text of [
    "",
    "<html>amiga</html>",
    "username,nome\namiga,Nome",
    "amiga\nperfil inválido",
    '["amiga",null]',
    '{"foo":[]}',
  ])
    assert.throws(() =>
      parseRelationshipList(text, "followers", "qa.relations"),
    );
});
test("lê formatos conhecidos do JSON de seguidores e seguidos, inclusive título sem value", () => {
  const followers = JSON.stringify([
    {
      title: "",
      string_list_data: [
        {
          value: "amiga",
          href: "https://www.instagram.com/amiga/",
          timestamp: 100,
        },
      ],
    },
  ]);
  assert.deepEqual(
    parseRelationshipList(
      followers,
      "followers",
      "qa.relations",
      "followers_1.json",
    ).names,
    ["amiga"],
  );
  const following = JSON.stringify({
    relationships_following: [
      {
        title: "importante",
        string_list_data: [
          { href: "https://www.instagram.com/_u/importante/", timestamp: 200 },
        ],
      },
    ],
  });
  assert.deepEqual(
    parseRelationshipList(
      following,
      "following",
      "qa.relations",
      "following.json",
    ).names,
    ["importante"],
  );
  assert.throws(
    () => parseRelationshipList(following, "followers", "qa.relations"),
    /não corresponde/,
  );
  assert.throws(
    () =>
      parseRelationshipList(
        followers,
        "followers",
        "qa.relations",
        "following.json",
      ),
    /trocados/,
  );
});
test("um registro conflitante não é descartado para produzir falsa ausência", () => {
  const conflicting = JSON.stringify([
    {
      string_list_data: [
        { value: "amiga", href: "https://www.instagram.com/outra/" },
      ],
    },
  ]);
  assert.throws(
    () => parseRelationshipList(conflicting, "followers", "qa.relations"),
    /conflitantes/,
  );
  assert.throws(
    () =>
      parseRelationshipList('[{"title":"amiga"}]', "followers", "qa.relations"),
    /não reconhecido/,
  );
});
test("exportação Órbita mantém dono e não usa timestamp de início do follow como data da medição", () => {
  const s = book().snapshots[0],
    text = JSON.stringify({ type: "orbita-connections-snapshot", snapshot: s });
  assert.deepEqual(
    parseRelationshipList(text, "following", "qa.relations").names,
    s.following,
  );
  assert.throws(
    () => parseRelationshipList(text, "following", "qa.other"),
    /@qa.other/,
  );
  const parsed = parseRelationshipList(
    '[{"string_list_data":[{"value":"amiga","timestamp":1}]}]',
    "followers",
    "qa.relations",
  );
  assert.equal("at" in parsed, false);
});
test("medições exigem dono, calendário, data não futura e completude explícita", () => {
  for (const value of [
    { ...raw(), account: "qa.other" },
    { ...raw(), at: "2026-02-30T12:00:00Z" },
    { ...raw(), at: "2026-10-01" },
    { ...raw(), at: "2099-01-01T00:00:00Z" },
    { ...raw(), followersComplete: "true" },
    { ...raw(), followingComplete: undefined },
    { ...raw(), followers: ["qa.relations"] },
  ])
    assert.throws(() => validateRelationshipSnapshot(value, "qa.relations"));
  const result = validateRelationshipSnapshot(
    { ...raw(), at: "2026-10-01T09:00:00-03:00" },
    "qa.relations",
  );
  assert.equal(result.at, "2026-10-01T12:00:00.000Z");
});
test("mesma medição é deduplicada; observação diferente no mesmo instante é rejeitada atomicamente", () => {
  const b = book(),
    copy = JSON.stringify(b),
    again = addRelationshipSnapshot(b, raw(), "qa.relations");
  assert.equal(again.snapshots.length, 1);
  assert.equal(again.snapshots[0].id, b.snapshots[0].id);
  assert.throws(
    () =>
      addRelationshipSnapshot(b, { ...raw(), followers: [] }, "qa.relations"),
    /instante/,
  );
  assert.equal(JSON.stringify(b), copy);
});
test("não seguem de volta requer seguidores completos; mútuos são presenças observadas", () => {
  const b = book(),
    a = relationshipAnalysis(b);
  assert.deepEqual(a.notFollowingBack, ["importante", "naoreciproco"]);
  assert.deepEqual(a.mutual, ["amiga", "mutuo"]);
  b.snapshots[0].followersComplete = false;
  const partial = relationshipAnalysis(b);
  assert.equal(partial.notFollowingBack, undefined);
  assert.equal(partial.lost, undefined);
  assert.deepEqual(partial.mutual, ["amiga", "mutuo"]);
  b.snapshots[0].followersComplete = true;
  b.snapshots[0].followingComplete = false;
  assert.deepEqual(relationshipAnalysis(b).notFollowingBack, [
    "importante",
    "naoreciproco",
  ]);
});
test("primeiro histórico não inventa quem deixou de seguir; comparação identifica apenas mudanças de lista", () => {
  const b = book();
  assert.equal(relationshipAnalysis(b).lost, undefined);
  const next = addRelationshipSnapshot(
    b,
    { ...raw("2026-10-15T12:00:00Z"), followers: ["amiga", "mutuo", "novo"] },
    "qa.relations",
  );
  const a = relationshipAnalysis(next);
  assert.deepEqual(a.lost, ["antigo"]);
  assert.deepEqual(a.gained, ["novo"]);
  assert.equal(a.previous?.id, b.snapshots[0].id);
  assert.equal(
    relationshipAnalysis(next, next.snapshots[0].id).lost,
    undefined,
  );
});
test("histórico parcial é ignorado como base e não gera perdas", () => {
  let b = book();
  b = addRelationshipSnapshot(
    b,
    { ...raw("2026-10-10T12:00:00Z"), followers: [], followersComplete: false },
    "qa.relations",
  );
  assert.equal(relationshipAnalysis(b).lost, undefined);
  b = addRelationshipSnapshot(
    b,
    { ...raw("2026-10-20T12:00:00Z"), followers: ["amiga"] },
    "qa.relations",
  );
  const a = relationshipAnalysis(b);
  assert.equal(a.previous?.at, b.snapshots[0].at);
  assert.deepEqual(a.lost, ["antigo", "mutuo"]);
  assert.equal(
    relationshipAnalysis(b, undefined, b.snapshots[1].id).lost,
    undefined,
  );
});
test("proteger amigo não altera as relações observadas nem configura unfollow", () => {
  const b = book(),
    next = setRelationshipProtection(
      b,
      "@IMPORTANTE",
      true,
      "friend",
      "Amigo de infância",
    );
  assert.equal(b.protections.length, 0);
  assert.deepEqual(next.snapshots, b.snapshots);
  assert.equal(relationshipAnalysis(next).protections[0].reason, "friend");
  const off = setRelationshipProtection(next, "importante", false);
  assert.equal(relationshipAnalysis(off).protections.length, 0);
  assert.equal(off.protections[0].enabled, false);
  assert.throws(
    () => setRelationshipProtection(b, "amiga", true, "falso"),
    /motivo/,
  );
});
test("novas proteções e remoções atuais sobrevivem à restauração de backup antigo", () => {
  const old = setRelationshipProtection(
    book(),
    "importante",
    true,
    "important",
    "Manter",
  );
  const current = setRelationshipProtection(old, "importante", false);
  const merged = mergeRelationships(current, old, "qa.relations");
  assert.equal(merged.protections[0].enabled, false);
  assert.equal(merged.snapshots.length, 1);
  const more = setRelationshipProtection(
    current,
    "amiga",
    true,
    "friend",
    "Amiga",
  );
  assert.equal(
    mergeRelationships(more, old, "qa.relations").protections.length,
    2,
  );
});
test("contas pessoais têm históricos e proteções separados e dados persistem após migração", () => {
  let s = store();
  s = accountCommand(s, { type: "RECORD_RELATIONSHIPS", data: raw() });
  s = accountCommand(s, {
    type: "PROTECT_RELATIONSHIP",
    username: "importante",
    reason: "important",
    note: "Manter",
  });
  const id = s.activeId;
  s = accountCommand(s, { type: "ADD_ACCOUNT", username: "qa.other" });
  assert.equal(workspace(s).relationships, undefined);
  assert.throws(
    () => accountCommand(s, { type: "RECORD_RELATIONSHIPS", data: raw() }),
    /@qa.other/,
  );
  s = accountCommand(s, { type: "SELECT_ACCOUNT", id });
  const migrated = migrateStore(JSON.parse(JSON.stringify(s)));
  assert.equal(workspace(migrated).relationships?.snapshots.length, 1);
  assert.equal(workspace(migrated).relationships?.protections.length, 1);
});
test("backup recupera relações sem duplicar nem apagar proteções posteriores", () => {
  let s = store();
  s = accountCommand(s, { type: "RECORD_RELATIONSHIPS", data: raw() });
  const backup = accountBackup(workspace(s));
  s = accountCommand(s, {
    type: "PROTECT_RELATIONSHIP",
    username: "amiga",
    reason: "friend",
    note: "Manter",
  });
  s = applyScopedCommand(s, s.activeId, { type: "RESTORE", data: backup });
  s = applyScopedCommand(s, s.activeId, { type: "RESTORE", data: backup });
  assert.equal(workspace(s).relationships?.snapshots.length, 1);
  assert.equal(workspace(s).relationships?.protections[0].enabled, true);
  let fresh = initialStore();
  fresh = applyScopedCommand(fresh, fresh.activeId, {
    type: "RESTORE",
    data: backup,
  });
  assert.equal(workspace(fresh).relationships?.snapshots.length, 1);
});
test("backup conflitante não altera dados originais e dono corrompido é rejeitado no carregamento", () => {
  let s = store();
  s = accountCommand(s, { type: "RECORD_RELATIONSHIPS", data: raw() });
  const before = JSON.stringify(s),
    backup = accountBackup(workspace(s));
  backup.account.relationships!.snapshots[0].followers = [];
  assert.throws(
    () => applyScopedCommand(s, s.activeId, { type: "RESTORE", data: backup }),
    /conflitante/,
  );
  assert.equal(JSON.stringify(s), before);
  const broken = structuredClone(s);
  workspace(broken).relationships!.snapshots[0].account = "qa.other";
  assert.throws(() => migrateStore(broken), /@qa.relations/);
});
test("remover medição não remove proteção e funciona só na conta selecionada", () => {
  let s = store();
  s = accountCommand(s, { type: "RECORD_RELATIONSHIPS", data: raw() });
  s = accountCommand(s, {
    type: "PROTECT_RELATIONSHIP",
    username: "amiga",
    reason: "friend",
    note: "",
  });
  const id = workspace(s).relationships!.snapshots[0].id;
  s = accountCommand(s, { type: "REMOVE_RELATIONSHIP_SNAPSHOT", id });
  assert.equal(workspace(s).relationships!.snapshots.length, 0);
  assert.equal(workspace(s).relationships!.protections[0].enabled, true);
  assert.throws(
    () => accountCommand(s, { type: "REMOVE_RELATIONSHIP_SNAPSHOT", id }),
    /não encontrada/,
  );
});
test("capacidade é explícita, sem descartar histórico silenciosamente", () => {
  assert.throws(
    () =>
      validateRelationshipSnapshot(
        { ...raw(), followers: Array(20001).fill("amiga") },
        "qa.relations",
      ),
    /20.000/,
  );
  let b = emptyRelationships();
  for (let i = 1; i <= 24; i++)
    b = addRelationshipSnapshot(
      b,
      raw(`2026-10-${String(i).padStart(2, "0")}T12:00:00Z`),
      "qa.relations",
    );
  assert.throws(
    () =>
      addRelationshipSnapshot(b, raw("2026-10-25T12:00:00Z"), "qa.relations"),
    /24 medições/,
  );
  assert.equal(b.snapshots.length, 24);
});
test("armazenamento rejeita duplicatas, flags corrompidas e notas incompatíveis", () => {
  const b = book();
  assert.throws(
    () =>
      validateRelationships(
        { ...b, snapshots: [...b.snapshots, ...b.snapshots] },
        "qa.relations",
      ),
    /duplicadas/,
  );
  const bad = structuredClone(b);
  bad.protections = [
    {
      username: "amiga",
      enabled: "sim" as unknown as boolean,
      reason: "friend",
      note: "",
      updatedAt: "2026-10-01T12:00:00Z",
    },
  ];
  assert.throws(() => validateRelationships(bad, "qa.relations"), /proteção/);
});
test("relações em backup sem identificação da conta são rejeitadas mesmo com conta de destino", () => {
  let s = store();
  s = accountCommand(s, { type: "RECORD_RELATIONSHIPS", data: raw() });
  const backup = accountBackup(workspace(s));
  delete backup.account.username;
  delete backup.account.data.runtime.account;
  assert.throws(
    () => applyScopedCommand(s, s.activeId, { type: "RESTORE", data: backup }),
    /identificar a conta/,
  );
  assert.throws(
    () => validateRelationships(emptyRelationships(), ""),
    /conta identificada/,
  );
});
test("limite agregado de entradas não remove medições quando o histórico é grande", () => {
  const names = Array.from({ length: 20000 }, (_, i) => `perfil${i}`);
  const snapshots = Array.from({ length: 6 }, (_, i) =>
    validateRelationshipSnapshot(
      {
        ...raw(`2026-10-${String(i + 1).padStart(2, "0")}T12:00:00Z`),
        followers: names,
        following: names,
      },
      "qa.relations",
    ),
  );
  assert.throws(
    () =>
      validateRelationships(
        { version: 1, snapshots, protections: [] },
        "qa.relations",
      ),
    /200.000/,
  );
});
