import test from "node:test";
import assert from "node:assert/strict";
import { JSDOM } from "jsdom";
import {
  collectLoaded,
  detectAccount,
  pageRestriction,
  profileControls,
  usernameFromHref,
} from "../src/extension/dom.ts";
const documentOf = (html: string) =>
  new JSDOM(html, { url: "https://www.instagram.com/alvo/" }).window.document;
test("identifica a conta apenas pelo menu de Perfil, não por conteúdo ou sugestões", () => {
  const doc = documentOf(
    '<nav><a href="/minha.conta/">Perfil</a></nav><main><a href="/falso/">Perfil</a><article><a href="/outro/">Profile</a></article></main>',
  );
  assert.equal(detectAccount(doc), "minha.conta");
  assert.equal(
    detectAccount(documentOf('<main><a href="/falso/">Perfil</a></main>')),
    null,
  );
  assert.equal(
    detectAccount(
      documentOf(
        '<nav><a href="/um/">Perfil</a><a href="/dois/">Profile</a></nav>',
      ),
    ),
    null,
  );
});
test("captura modal carregado e exclui links externos, rotas e conta própria", () => {
  const doc = documentOf(
    '<a href="/fora/">Sugestão fora da lista</a><div role="dialog"><a href="/ana/">ana</a><a href="/ana/">foto</a><a href="/bia/">bia</a><a href="/minha/">minha</a><a href="/explore/">Explorar</a><a href="https://evil.test/roubo/">externo</a></div>',
  );
  const result = collectLoaded(doc, "followers", "@alvo", "minha");
  assert.deepEqual(
    result.candidates.map((c) => c.username),
    ["ana", "bia"],
  );
  assert.equal(result.candidates[0].followers, undefined);
  assert.match(result.message, /parcial/);
});
test("captura recusa modais ausentes ou ambíguos", () => {
  assert.throws(() =>
    collectLoaded(
      documentOf('<main><a href="/ana/">Ana</a></main>'),
      "followers",
      "@alvo",
    ),
  );
  assert.throws(() =>
    collectLoaded(
      documentOf('<div role="dialog"></div><div role="dialog"></div>'),
      "likers",
      "url",
    ),
  );
});
test("comentários não capturam a barra lateral de sugestões", () => {
  const doc = documentOf(
    '<aside><a href="/sugerido/">Sugerido</a></aside><main><article><ul><li><a href="/ana/">Ana</a><span>Comentário</span></li><li><a href="/bia/">Bia</a></li></ul></article></main>',
  );
  assert.deepEqual(
    collectLoaded(doc, "commenters", "url").candidates.map((c) => c.username),
    ["ana", "bia"],
  );
});
test("seguir exige identidade do perfil e um único botão no cabeçalho", () => {
  const doc = documentOf(
    "<main><header><h2>alvo</h2><button>Seguir</button></header><section><button>Seguir</button></section></main>",
  );
  assert.ok(profileControls(doc, "/alvo/", "alvo").follow);
  assert.ok(profileControls(doc, "/outro/", "alvo").error);
  assert.ok(profileControls(doc, "/alvo/", "falso").error);
  const ambiguous = documentOf(
    "<main><header><h2>alvo</h2><button>Seguir</button><button>Seguir</button></header></main>",
  );
  assert.ok(profileControls(ambiguous, "/alvo/", "alvo").error);
});
test("estado existente nunca oferece clique de seguir", () => {
  for (const [label, state] of [
    ["Seguindo", "followed"],
    ["Following", "followed"],
    ["Solicitado", "requested"],
    ["Requested", "requested"],
  ]) {
    const controls = profileControls(
      documentOf(
        `<main><header><h2>alvo</h2><button>${label}</button></header></main>`,
      ),
      "/alvo/",
      "alvo",
    );
    assert.equal(controls.state, state);
    assert.equal(controls.follow, undefined);
  }
});
test("desafios e restrições interrompem; texto normal de posts não dispara bloqueio", () => {
  assert.ok(pageRestriction(documentOf(""), "/challenge/123"));
  assert.ok(
    pageRestriction(
      documentOf('<div role="dialog">Tente novamente mais tarde</div>'),
      "/alvo/",
    ),
  );
  assert.equal(
    pageRestriction(
      documentOf(
        "<article>Tente novamente mais tarde: uma história sobre viagens</article>",
      ),
      "/alvo/",
    ),
    null,
  );
});
test("links de mídia e domínios parecidos nunca viram usernames", () => {
  assert.equal(usernameFromHref("/p/abc/"), null);
  assert.equal(usernameFromHref("https://instagram.com.evil.test/ana/"), null);
  assert.equal(usernameFromHref("/ana/?x=1"), "ana");
});
test("não perde o nome em âncora duplicada depois do avatar", () => {
  const doc = documentOf(
    '<div role="dialog"><a href="/ana/"><img alt="avatar"></a><a href="/ana/">Ana Artista</a></div>',
  );
  assert.equal(
    collectLoaded(doc, "followers", "@alvo").candidates[0].name,
    "Ana Artista",
  );
});
test("autor da publicação não é incluído entre comentaristas", () => {
  const doc = documentOf(
    '<main><article><header><a href="/autor/">autor</a></header><ul><li><a href="/autor/">autor</a>Legenda</li><li><a href="/ana/">ana</a>Comentário</li></ul></article></main>',
  );
  assert.deepEqual(
    collectLoaded(doc, "commenters", "url").candidates.map((c) => c.username),
    ["ana"],
  );
});

const divComment = (
  user: string,
  id: string,
  code = "QApost",
  text = "Texto de teste",
) =>
  `<div data-row><div><a role="link" href="/${user}/"><img alt="Foto do perfil" src="https://scontent.cdninstagram.com/${user}.jpg"></a></div><div><div><div><span><a role="link" href="/${user}/"><div><span>${user}</span></div></a></span><span><a role="link" href="/p/${code}/c/${id}/"><time datetime="2026-10-10T12:00:00Z">3 sem</time></a></span></div><div><span>${text}</span></div></div><div><div role="button"><span>1 curtida</span></div><div role="button"><span>Responder</span></div></div></div><div role="button"><svg aria-label="Curtir"></svg></div></div>`;
const modernPost = (rows: string, ownerCode = "QApost") =>
  documentOf(
    `<nav><a href="/qa.nav/">qa.nav</a></nav><main role="main"><div><a href="/qa.owner/">qa.owner</a><span>Legenda de teste</span><time datetime="2026-10-10T12:00:00Z">3 sem</time></div><div>${rows}</div><div role="button"><svg aria-label="Curtir"></svg></div><a href="/qa.owner/p/${ownerCode}/"><time datetime="2026-10-10T12:00:00Z">3 semanas</time></a></main><aside><a href="/qa.suggested/">qa.suggested</a></aside>`,
  );
test("comentários DIV usam permalink da fonte e excluem autor, conta própria e menções", () => {
  const doc = modernPost(
    divComment(
      "qa.client",
      "100",
      "QApost",
      'Oi <a href="/qa.mentioned/">qa.mentioned</a>',
    ) +
      divComment("qa.owner", "101") +
      divComment("qa.own", "102") +
      divComment("qa.client", "103"),
  );
  const result = collectLoaded(
    doc,
    "commenters",
    "https://www.instagram.com/p/QApost/",
    "qa.own",
  );
  assert.deepEqual(
    result.candidates.map((c) => c.username),
    ["qa.client"],
  );
  assert.equal(
    result.candidates[0].avatarUrl,
    "https://scontent.cdninstagram.com/qa.client.jpg",
  );
});
test("comentários DIV recusam permalink de outro post e dono não confirmado pelo shortcode", () => {
  assert.throws(() =>
    collectLoaded(
      modernPost(divComment("qa.client", "100", "OtherPost")),
      "commenters",
      "https://www.instagram.com/p/QApost/",
    ),
  );
  assert.throws(() =>
    collectLoaded(
      modernPost(divComment("qa.client", "100"), "OtherPost"),
      "commenters",
      "https://www.instagram.com/p/QApost/",
    ),
  );
});
test("legenda, sugestões e linhas DIV sem ação de comentário não são candidatos", () => {
  const doc = modernPost(
    divComment("qa.client", "100").replace(
      "<span>Responder</span>",
      "<span>Ver perfil</span>",
    ),
  );
  assert.throws(() =>
    collectLoaded(doc, "commenters", "https://www.instagram.com/p/QApost/"),
  );
});
test("curtidas exigem título próprio do diálogo e não capturam comentários de um postmodal", () => {
  assert.throws(() =>
    collectLoaded(
      documentOf(
        '<div role="dialog"><div role="heading">Comentários</div><a href="/qa.commenter/">qa.commenter</a></div>',
      ),
      "likers",
      "https://www.instagram.com/p/QApost/",
    ),
  );
  const doc = documentOf(
    '<div role="dialog"><div role="heading">Publicação</div><a href="/qa.outside/">qa.outside</a><div role="dialog"><div><div role="heading">Curtidas</div><svg aria-label="Fechar"></svg></div><a href="/qa.liker/">qa.liker</a><a href="/qa.liker/">Foto</a></div></div>',
  );
  assert.deepEqual(
    collectLoaded(
      doc,
      "likers",
      "https://www.instagram.com/p/QApost/",
    ).candidates.map((c) => c.username),
    ["qa.liker"],
  );
});
test("curtidas recusam dois diálogos tipados e aceitam heading Likes", () => {
  assert.throws(() =>
    collectLoaded(
      documentOf(
        '<div role="dialog"><div role="heading">Curtidas</div></div><div role="dialog"><div role="heading">Likes</div></div>',
      ),
      "likers",
      "https://www.instagram.com/p/QApost/",
    ),
  );
  assert.deepEqual(
    collectLoaded(
      documentOf(
        '<div role="dialog"><div role="heading">Likes</div><a href="/qa.liker/">qa.liker</a></div>',
      ),
      "likers",
      "https://www.instagram.com/p/QApost/",
    ).candidates.map((c) => c.username),
    ["qa.liker"],
  );
});
