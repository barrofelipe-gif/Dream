import test from "node:test";
import assert from "node:assert/strict";
import {
  trustedHostedPage,
  allowedHostedMessage,
  hostedStorageKey,
} from "../src/core/hosted.ts";

test("conector aceita somente os dois hosts HTTPS e a rota exata do painel", () => {
  for (const host of [
    "app.bfffitnessatacado.com.br",
    "bff-painel-pendencias.vercel.app",
  ]) {
    assert.equal(
      trustedHostedPage(`https://${host}/api/growth/orbita/painel`),
      true,
    );
    assert.equal(
      trustedHostedPage(`https://${host}/api/growth/orbita/painel?test=1`),
      true,
    );
  }
  for (const value of [
    undefined,
    "",
    "javascript:alert(1)",
    "http://app.bfffitnessatacado.com.br/api/growth/orbita/painel",
    "https://app.bfffitnessatacado.com.br.evil.test/api/growth/orbita/painel",
    "https://app.bfffitnessatacado.com.br/api/growth/orbita/painel/extra",
    "https://app.bfffitnessatacado.com.br/api/growth/orbita/painel-evil",
    "https://app.bfffitnessatacado.com.br/areas/growth",
  ])
    assert.equal(trustedHostedPage(value), false, value);
});
test("conector não oferece mensagens do coletor, navegação arbitrária ou APIs do Chrome", () => {
  for (const type of [
    "GET_STATE",
    "ACCOUNT_COMMAND",
    "COMMAND",
    "GET_PROBLEMS",
    "READ_MARKET_PAGE",
  ])
    assert.equal(allowedHostedMessage({ type }), true);
  for (const type of [
    "GET_COLLECTOR",
    "OPEN_DASHBOARD",
    "FOLLOW_RESULT",
    "tabs.create",
    "HOSTED_CONNECT",
    "toString",
  ])
    assert.equal(allowedHostedMessage({ type }), false);
  assert.equal(allowedHostedMessage(null), false);
});

test("modo hospedado recusa escopo ausente e separa usuários; prévia e extensão mantêm suas chaves", () => {
  assert.throws(() => hostedStorageKey("accounts", null, true));
  assert.throws(() => hostedStorageKey("accounts", "invalid", true));
  assert.notEqual(
    hostedStorageKey("accounts", "a".repeat(32), true),
    hostedStorageKey("accounts", "b".repeat(32), true),
  );
  assert.equal(hostedStorageKey("accounts", null, false), "accounts");
});
