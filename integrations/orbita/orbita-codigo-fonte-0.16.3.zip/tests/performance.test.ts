import test from "node:test";
import assert from "node:assert/strict";
import { validateInsightReport } from "../src/core/insights.ts";
import {
  performanceReview,
  performanceTone,
  recoveryTest,
} from "../src/core/performance.ts";
import type { InsightReport } from "../src/core/types.ts";
const today = "2026-11-03";
const make = (metrics: Record<string, number>, previous = false) =>
  validateInsightReport(
    {
      account: "qa.alerts",
      start: previous ? "2026-10-01" : "2026-10-08",
      end: previous ? "2026-10-07" : "2026-10-14",
      coverage: "organic",
      contentWindow: "period",
      metrics,
    },
    "qa.alerts",
    "manual",
  );
const review = (current: InsightReport, previous: InsightReport) =>
  performanceReview(current, [previous, current], today);

test("alertas separam taxa de engajamento em p.p. de totais em percentual e diferença absoluta", () => {
  const a = make({ reach: 1000, total_interactions: 100 }, true),
    b = make({ reach: 800, total_interactions: 48 });
  const r = review(b, a);
  assert.equal(r.status, "ready");
  const rate = r.alerts.find((c) => c.key === "engagement_rate")!;
  assert.equal(rate.before, 10);
  assert.equal(rate.current, 6);
  assert.equal(rate.difference, -4);
  assert.equal(rate.unit, "percent");
  const interactions = r.alerts.find((c) => c.key === "total_interactions")!;
  assert.equal(interactions.difference, -52);
  assert.equal(interactions.relative, -52);
  assert.match(r.observations[0], /caíram juntos/);
});
test("queda de alcance com taxa preservada orienta investigar exposição; taxa em queda com alcance estável orienta resposta", () => {
  const a = make({ reach: 1000, total_interactions: 100 }, true);
  const exposure = review(make({ reach: 500, total_interactions: 75 }), a);
  assert.equal(
    exposure.alerts.some((c) => c.key === "engagement_rate"),
    false,
  );
  assert.match(exposure.observations[0], /volume de exposição/);
  assert.match(
    review(make({ reach: 1000, total_interactions: 50 }), a).observations[0],
    /chamadas para interação/,
  );
});
test("campos ausentes não viram zero nem permitem inventar explicação para queda", () => {
  const r = review(
    make({ total_interactions: 0 }),
    make({ total_interactions: 50, reach: 1000 }, true),
  );
  assert.deepEqual(
    r.alerts.map((c) => c.key),
    ["total_interactions"],
  );
  assert.equal(r.alerts[0].relative, -100);
  assert.ok(r.missing.includes("Contas alcançadas"));
  assert.match(r.observations[0], /faltam dados de alcance/);
  assert.equal(
    review(make({ content_published: 1 }), make({ content_published: 2 }, true))
      .comparisons.length,
    0,
  );
});
test("zero explícito permite diferença absoluta, nunca percentual com denominador zero", () => {
  const r = review(
    make({ unfollows: 3, reach: 0, total_interactions: 0 }),
    make({ unfollows: 0, reach: 0, total_interactions: 0 }, true),
  );
  assert.equal(r.alerts.length, 1);
  assert.equal(r.alerts[0].relative, undefined);
  assert.equal(r.alerts[0].difference, 3);
  assert.equal(
    r.comparisons.some((c) => c.key === "engagement_rate"),
    false,
  );
});
test("redução em perdas e pulos é melhora; direção ambígua e campos adicionais não geram julgamento", () => {
  const r = review(
    make({
      unfollows: 4,
      reels_skip_rate: 25,
      content_published: 1,
      story_exits: 900,
      story_forward: 0,
      custom_metric: 0,
    }),
    make(
      {
        unfollows: 8,
        reels_skip_rate: 50,
        content_published: 2,
        story_exits: 50,
        story_forward: 100,
        custom_metric: 100,
      },
      true,
    ),
  );
  assert.equal(r.alerts.length, 0);
  assert.equal(r.comparisons.length, 2);
  assert.ok(r.comparisons.every((c) => c.tone === "positive"));
  assert.equal(performanceTone("story_exits", 100), "neutral");
  assert.equal(performanceTone("toString", 1), "neutral");
  assert.equal(performanceTone("unfollows", 0), "neutral");
  assert.match(r.observations[0], /2 → 1/);
});
test("subida em pulos dos Reels é adversa e a diferença usa pontos percentuais", () => {
  const r = review(
    make({ reels_skip_rate: 40 }),
    make({ reels_skip_rate: 25 }, true),
  );
  assert.equal(r.alerts[0].difference, 15);
  assert.equal(r.alerts[0].unit, "percent");
  assert.match(recoveryTest("reels_skip_rate").test, /abertura/);
});
test("não compara outra conta, cobertura divergente, lacuna, sobreposição ou duração diferente", () => {
  const b = make({ follows: 5 }),
    a = make({ follows: 10 }, true);
  for (const patch of [
    { account: "qa.other" },
    { coverage: "paid" as const },
    { contentWindow: "lifetime" as const },
    { start: "2026-09-30", end: "2026-10-06" },
    { start: "2026-10-02", end: "2026-10-08" },
    { start: "2026-09-30" },
  ])
    assert.equal(review(b, { ...a, ...patch }).status, "waiting");
});
test("cobertura desconhecida, acumulado e período não encerrado têm orientação específica", () => {
  const a = make({ follows: 10 }, true),
    b = make({ follows: 5 });
  for (const [r, day, pattern] of [
    [{ ...b, coverage: "unknown" }, today, /cobertura/],
    [{ ...b, contentWindow: "lifetime" }, today, /vida inteira/],
    [b, "2026-10-14", /dia atual/],
    [b, "2026-10-12", /dia atual/],
  ] as const) {
    const result = performanceReview(r, [a], day);
    assert.equal(result.status, "waiting");
    assert.match(result.reason!, pattern);
    assert.equal(result.alerts.length, 0);
  }
});
test("última revisão da base é escolhida sem somar versões nem depender da ordem de entrada", () => {
  const a = {
      ...make({ follows: 10 }, true),
      recordedAt: "2026-10-15T12:00:00Z",
    },
    updated = {
      ...a,
      id: "revision",
      recordedAt: "2026-10-16T12:00:00Z",
      metrics: { follows: 4 },
    },
    b = make({ follows: 5 });
  const all = [updated, b, a],
    copy = structuredClone(all);
  const r = performanceReview(b, all, today);
  assert.equal(r.previous?.id, "revision");
  assert.equal(r.alerts.length, 0);
  assert.equal(r.comparisons[0].before, 4);
  assert.deepEqual(all, copy);
});
test("taxas podem exceder 100% e igualdade numérica não gera alerta por arredondamento", () => {
  const a = make({ reach: 3, total_interactions: 1 }, true),
    b = make({ reach: 9, total_interactions: 3 });
  assert.equal(
    review(b, a).comparisons.find((c) => c.key === "engagement_rate")!
      .difference,
    0,
  );
  const r = review(
    make({ reach: 10, total_interactions: 20 }),
    make({ reach: 10, total_interactions: 30 }, true),
  );
  assert.equal(r.alerts.find((c) => c.key === "engagement_rate")!.current, 200);
});
test("qualquer queda medida é sinal observacional e cada plano dá um teste sem garantir causa", () => {
  const r = review(make({ reach: 9999 }), make({ reach: 10000 }, true));
  assert.equal(r.alerts.length, 1);
  for (const key of [
    "reach",
    "follows",
    "unfollows",
    "avg_watch_time_seconds",
    "saves",
    "shares",
    "question_answers",
    "total_interactions",
  ]) {
    const plan = recoveryTest(key);
    assert.ok(plan.investigate.length > 30);
    assert.ok(plan.test.length > 30);
  }
});
