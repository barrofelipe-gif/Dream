import test from "node:test";
import assert from "node:assert/strict";
import {
  INSIGHT_METRICS,
  insightSummary,
  insightTemplate,
  mergeInsightReports,
  parseInsightFile,
  validateInsightReport,
} from "../src/core/insights.ts";
import {
  accountBackup,
  accountCommand,
  applyScopedCommand,
  initialStore,
  migrateStore,
  workspace,
} from "../src/core/accounts.ts";
const report = (
  metrics: Record<string, unknown> = {
    views: 1000,
    reach: 400,
    total_interactions: 40,
  },
) => ({
  account: "qa.alpha",
  start: "2026-10-15",
  end: "2026-10-21",
  coverage: "organic",
  metrics,
});
const store = () =>
  accountCommand(initialStore(), { type: "ADD_ACCOUNT", username: "qa.alpha" });
test("Insights não aceitam relatório de outra conta e importação em lote é atômica", () => {
  const a = workspace(store());
  const wrong = { ...report(), account: "qa.beta" };
  assert.throws(
    () => mergeInsightReports(a, [report(), wrong], "file"),
    /qa.alpha/,
  );
  assert.equal(a.insights, undefined);
  assert.throws(() =>
    validateInsightReport(
      { ...report(), account: undefined },
      "qa.alpha",
      "file",
    ),
  );
});
test("zero continua conhecido, ausente não vira zero, origem não pode ser forjada pelo arquivo", () => {
  const parsed = validateInsightReport(
    {
      ...report({ views: 0, reach: null }),
      source: "meta-api",
      access_token: "nao-armazenar",
    },
    "qa.alpha",
    "file",
  );
  assert.equal(parsed.metrics.views, 0);
  assert.equal(parsed.metrics.reach, undefined);
  assert.equal(parsed.source, "file");
  assert.equal(JSON.stringify(parsed).includes("nao-armazenar"), false);
});
test("valida calendário real, ordem do período, data futura e números sem estimativas", () => {
  for (const v of [
    { ...report(), start: "2026-02-30" },
    { ...report(), end: "2026-10-01" },
    { ...report(), end: "2099-01-01" },
    { ...report(), start: "2020-01-01" },
    report({ views: -1 }),
    report({ views: 1.5 }),
    report({ views: "1,2 mil" }),
    report({ views: NaN }),
    report({ views: Infinity }),
    report({ reels_skip_rate: 101 }),
  ])
    assert.throws(() => validateInsightReport(v, "qa.alpha", "manual"));
  assert.equal(
    validateInsightReport(
      report({ avg_watch_time_seconds: 1.25, reels_skip_rate: 0 }),
      "qa.alpha",
      "manual",
    ).metrics.avg_watch_time_seconds,
    1.25,
  );
});
test("conteúdo tem identidade única e links restritos, com unidade do tempo explícita", () => {
  const content = {
    id: "r1",
    kind: "reel",
    title: "Reel",
    url: "https://www.instagram.com/reel/AbC/?token=removed",
    metrics: { views: 100, avg_watch_time_seconds: 8.25 },
  };
  const v = validateInsightReport(
    { ...report(), content: [content], contentWindow: "lifetime" },
    "qa.alpha",
    "file",
  );
  assert.equal(v.content[0].url, "https://www.instagram.com/reel/AbC/");
  assert.equal(v.contentWindow, "lifetime");
  assert.throws(() =>
    validateInsightReport(
      { ...report(), content: [content, content] },
      "qa.alpha",
      "file",
    ),
  );
  assert.throws(() =>
    validateInsightReport(
      {
        ...report(),
        content: [
          { ...content, url: "https://instagram.com.evil.test/reel/abc/" },
        ],
      },
      "qa.alpha",
      "file",
    ),
  );
  assert.throws(() =>
    validateInsightReport(
      { ...report(), content: [{ ...content, url: "javascript:alert(1)" }] },
      "qa.alpha",
      "file",
    ),
  );
});
test("público valida unidade e grupos, sem exigir que um recorte parcial some todos os seguidores", () => {
  const row = {
    audience: "followers",
    dimension: "country",
    unit: "percent",
    values: [{ label: "Brasil", value: 75 }],
  };
  const v = validateInsightReport(
    { ...report({}), audience: [row] },
    "qa.alpha",
    "file",
  );
  assert.equal(v.audience[0].values[0].value, 75);
  assert.throws(() =>
    validateInsightReport(
      {
        ...report(),
        audience: [
          {
            ...row,
            values: [
              { label: "BR", value: 80 },
              { label: "PT", value: 30 },
            ],
          },
        ],
      },
      "qa.alpha",
      "file",
    ),
  );
  assert.throws(() =>
    validateInsightReport(
      { ...report(), audience: [row, row] },
      "qa.alpha",
      "file",
    ),
  );
  assert.throws(() =>
    validateInsightReport(
      {
        ...report(),
        audience: [
          { ...row, unit: "count", values: [{ label: "Brasil", value: 1.2 }] },
        ],
      },
      "qa.alpha",
      "file",
    ),
  );
});
test("deduplica a mesma medição mesmo com ordem de métricas e conteúdo diferente", () => {
  const a = workspace(store());
  mergeInsightReports(a, report({ views: 100, reach: 50 }), "manual");
  mergeInsightReports(a, report({ reach: 50, views: 100 }), "file");
  assert.equal(a.insights?.length, 1);
  assert.equal(a.insights?.[0].source, "manual");
});
test("Insights são separados da fila, das medições públicas e de outras contas", () => {
  let s = store();
  const alpha = s.activeId;
  s = accountCommand(s, {
    type: "RECORD_INSIGHTS",
    data: report({ follows: 100, unfollows: 10 }),
  });
  assert.equal(workspace(s).data.candidates.length, 0);
  assert.deepEqual(workspace(s).data.dailyAttempts, {});
  assert.equal(workspace(s).snapshots.length, 0);
  s = accountCommand(s, { type: "ADD_ACCOUNT", username: "qa.beta" });
  assert.equal(workspace(s).insights, undefined);
  assert.equal(workspace(s, alpha).insights?.length, 1);
  const saved = structuredClone(s);
  assert.throws(() =>
    accountCommand(s, { type: "IMPORT_INSIGHTS", data: report() }),
  );
  assert.deepEqual(s, saved);
});
test("remover relatório atua apenas na conta ativa e não muda a fila ou outras medições", () => {
  let s = store();
  s = accountCommand(s, { type: "RECORD_INSIGHTS", data: report() });
  const alpha = s.activeId;
  const id = workspace(s).insights![0].id;
  s = accountCommand(s, { type: "ADD_ACCOUNT", username: "qa.beta" });
  assert.throws(
    () => accountCommand(s, { type: "REMOVE_INSIGHT_REPORT", id }),
    /nesta conta/,
  );
  const beta = structuredClone(workspace(s));
  s = accountCommand(s, { type: "SELECT_ACCOUNT", id: alpha });
  const data = structuredClone(workspace(s).data);
  s = accountCommand(s, { type: "REMOVE_INSIGHT_REPORT", id });
  assert.equal(workspace(s).insights?.length, 0);
  assert.deepEqual(workspace(s).data, data);
  assert.deepEqual(workspace(s, beta.id), beta);
});
test("CSV não mistura cobertura paga com orgânica no mesmo período", () => {
  const raw = parseInsightFile(
    "account,start,end,coverage,content_window,scope,metric,value\nqa.alpha,2026-10-15,2026-10-21,organic,period,account,reach,100\nqa.alpha,2026-10-15,2026-10-21,paid,lifetime,account,reach,150",
  ) as unknown[];
  const a = validateInsightReport(raw[0], "qa.alpha", "file"),
    b = validateInsightReport(raw[1], "qa.alpha", "file");
  assert.equal(a.metrics.reach, 100);
  assert.equal(b.metrics.reach, 150);
  assert.equal(b.contentWindow, "lifetime");
  assert.equal(raw.length, 2);
});
test("CSV com aspas e decimais organiza conteúdo sem agregar alcance único", () => {
  const csv =
    'account,start,end,scope,content_id,title,url,metric,value\nqa.alpha,2026-10-15,2026-10-21,account,,,,views,1000\nqa.alpha,2026-10-15,2026-10-21,reel,r1,"Título, com vírgula",,reach,300\nqa.alpha,2026-10-15,2026-10-21,reel,r1,"Título, com vírgula",,avg_watch_time_seconds,7.5\nqa.alpha,2026-10-15,2026-10-21,post,p1,Outro,,reach,300';
  const raw = parseInsightFile(csv) as unknown[];
  const r = validateInsightReport(raw[0], "qa.alpha", "file");
  assert.equal(r.content.length, 2);
  assert.equal(
    r.content.find((c) => c.id === "r1")?.title,
    "Título, com vírgula",
  );
  assert.equal(r.metrics.reach, undefined);
  assert.equal(insightSummary(r, [r]).rate, undefined);
});
test("CSV não soma entradas duplicadas, não aceita cabeçalhos nativos sem mapeamento nem chaves perigosas", () => {
  const header = "account,start,end,scope,metric,value\n",
    row = "qa.alpha,2026-10-15,2026-10-21,account,views,100";
  assert.throws(() => parseInsightFile(header + row + "\n" + row), /repetida/);
  assert.throws(
    () => parseInsightFile("Data,Alcance\n2026-10-15,100"),
    /modelo/,
  );
  assert.throws(
    () => parseInsightFile(header + row.replace("views", "__proto__")),
    /inválido/,
  );
  assert.throws(() =>
    validateInsightReport(
      report(JSON.parse('{"constructor":1}')),
      "qa.alpha",
      "file",
    ),
  );
});
test("modelos não criam números fictícios e JSON exportado pode voltar pelo mesmo caminho", () => {
  const template = insightTemplate("qa.alpha", "2026-10-15", "2026-10-21");
  assert.deepEqual(parseInsightFile(template), []);
  const r = validateInsightReport(report(), "qa.alpha", "manual");
  const decoded = parseInsightFile(
    JSON.stringify({ version: 1, reports: [r] }),
  );
  assert.deepEqual((decoded as (typeof r)[])[0].metrics, r.metrics);
  assert.equal(INSIGHT_METRICS.length, 31);
});
test("comparação exige períodos contíguos, mesma duração, conta e cobertura", () => {
  const prev = validateInsightReport(
    {
      ...report({ views: 500, reach: 200, total_interactions: 0 }),
      start: "2026-10-08",
      end: "2026-10-14",
    },
    "qa.alpha",
    "file",
  );
  const current = validateInsightReport(
    report({
      views: 1000,
      reach: 400,
      total_interactions: 40,
      follows: 15,
      unfollows: 5,
    }),
    "qa.alpha",
    "file",
  );
  const m = insightSummary(current, [prev, current]);
  assert.equal(m.change("views"), 100);
  assert.equal(m.change("total_interactions"), undefined);
  assert.equal(m.net, 10);
  assert.equal(m.rate, 10);
  assert.equal(
    insightSummary({ ...current, coverage: "paid" }, [prev, current]).previous,
    undefined,
  );
  assert.equal(
    insightSummary({ ...current, coverage: "unknown" }, [prev, current])
      .previous,
    undefined,
  );
  assert.equal(
    insightSummary({ ...current, start: "2026-10-14" }, [prev, current])
      .previous,
    undefined,
  );
  assert.equal(
    insightSummary({ ...current, account: "qa.beta" }, [prev, current])
      .previous,
    undefined,
  );
});
test("a razão de interações admite repetições e não vira taxa de pessoas únicas", () => {
  const r = validateInsightReport(
    report({ reach: 100, total_interactions: 250 }),
    "qa.alpha",
    "manual",
  );
  assert.equal(insightSummary(r, [r]).rate, 250);
  assert.equal(
    insightSummary({ ...r, metrics: { reach: 0, total_interactions: 250 } }, [
      r,
    ]).rate,
    undefined,
  );
  assert.equal(
    insightSummary({ ...r, metrics: { follows: 10 } }, [r]).net,
    undefined,
  );
});
test("backup preserva relatórios sem duplicar na restauração e sem mudar outras contas", () => {
  let s = store();
  s = accountCommand(s, { type: "RECORD_INSIGHTS", data: report() });
  const alpha = s.activeId;
  const backup = accountBackup(workspace(s));
  s = accountCommand(s, { type: "ADD_ACCOUNT", username: "qa.beta" });
  const beta = structuredClone(workspace(s));
  s = accountCommand(s, { type: "SELECT_ACCOUNT", id: alpha });
  s = applyScopedCommand(s, alpha, { type: "RESTORE", data: backup });
  s = applyScopedCommand(s, alpha, { type: "RESTORE", data: backup });
  assert.equal(workspace(s).insights?.length, 1);
  assert.equal(workspace(s).insights?.[0].id, backup.account.insights?.[0].id);
  assert.equal(
    workspace(s).insights?.[0].recordedAt,
    backup.account.insights?.[0].recordedAt,
  );
  assert.deepEqual(workspace(s, beta.id), beta);
  assert.equal(migrateStore(s).version, 2);
});
test("carregamento recusa Insights com conta incorreta ou números corrompidos", () => {
  let s = store();
  s = accountCommand(s, { type: "RECORD_INSIGHTS", data: report() });
  const wrong = structuredClone(s);
  workspace(wrong).insights![0].account = "qa.beta";
  assert.throws(() => migrateStore(wrong), /qa.alpha/);
  const negative = structuredClone(s);
  workspace(negative).insights![0].metrics.views = -1;
  assert.throws(() => migrateStore(negative), /inválido/);
  const badDate = structuredClone(s);
  workspace(badDate).insights![0].recordedAt = "invalido";
  assert.throws(() => migrateStore(badDate), /inválidos/);
});
test("URLs inválidas produzem orientação em português", () => {
  assert.throws(
    () =>
      validateInsightReport(
        {
          ...report(),
          content: [
            {
              id: "x",
              kind: "post",
              url: "instagram.com/p/abc",
              metrics: { views: 1 },
            },
          ],
        },
        "qa.alpha",
        "file",
      ),
    /links completos/,
  );
});
test("restauração aguarda ação em andamento e recusa envelope incompleto", () => {
  const s = store();
  const a = workspace(s);
  const backup = accountBackup(a);
  a.data.runtime.mode = "running";
  assert.throws(
    () => applyScopedCommand(s, s.activeId, { type: "RESTORE", data: backup }),
    /Pause/,
  );
  a.data.runtime.mode = "paused";
  assert.throws(
    () =>
      applyScopedCommand(s, s.activeId, {
        type: "RESTORE",
        data: {
          type: "orbita-account-backup",
          account: { username: "qa.alpha" },
        },
      }),
    /ausentes/,
  );
});
test("comparação percentual distingue pontos percentuais e recorte de vida inteira", () => {
  const prev = validateInsightReport(
    {
      ...report({ reels_skip_rate: 0 }),
      start: "2026-10-08",
      end: "2026-10-14",
    },
    "qa.alpha",
    "file",
  );
  const r = validateInsightReport(
    report({ reels_skip_rate: 25 }),
    "qa.alpha",
    "file",
  );
  const m = insightSummary(r, [prev, r]);
  assert.equal(m.change("reels_skip_rate"), undefined);
  assert.equal(m.difference("reels_skip_rate"), 25);
  assert.equal(
    insightSummary({ ...r, contentWindow: "lifetime" }, [prev, r]).previous,
    undefined,
  );
});
