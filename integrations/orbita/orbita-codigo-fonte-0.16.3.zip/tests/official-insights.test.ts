import test from "node:test";
import assert from "node:assert/strict";
import {
  officialRange,
  officialInsightResult,
  officialChoices,
} from "../src/core/official-insights.ts";

const scope = "a".repeat(32);
const result = () => ({
  userScope: scope,
  reports: [
    {
      account: "qa.alpha",
      start: "2026-10-01",
      end: "2026-10-07",
      coverage: "unknown",
      contentWindow: "period",
      metrics: { views: 0 },
      note: "Coleta oficial do app",
      content: [],
      audience: [],
    },
  ],
  warnings: ["Alcance não agregado"],
  source: {
    type: "app-official-collection",
    username: "qa.alpha",
    loja: "bff",
    lastCollectedAt: "2026-10-08T12:00:00Z",
    daysAvailable: 7,
    daysExpected: 7,
    contentAvailable: 0,
    readOnly: true,
  },
});
test("consulta oficial preserva zero, ausências e período; segredos não entram no relatório", () => {
  const raw = result();
  Object.assign(raw.reports[0], { access_token: "não guardar" });
  const parsed = officialInsightResult(
    raw,
    "qa.alpha",
    "2026-10-01",
    "2026-10-07",
    scope,
  );
  assert.equal(parsed.reports[0].metrics.views, 0);
  assert.equal(parsed.reports[0].metrics.reach, undefined);
  assert.equal(parsed.reports[0].coverage, "unknown");
  assert.equal(parsed.reports[0].source, "file");
  assert.equal(JSON.stringify(parsed).includes("não guardar"), false);
});
test("troca de usuário, conta ou janela rejeita todo o lote", () => {
  assert.throws(
    () =>
      officialInsightResult(
        result(),
        "qa.alpha",
        "2026-10-01",
        "2026-10-07",
        "b".repeat(32),
      ),
    /usuário/,
  );
  assert.throws(
    () =>
      officialInsightResult(
        result(),
        "qa.beta",
        "2026-10-01",
        "2026-10-07",
        scope,
      ),
    /conta/,
  );
  assert.throws(
    () =>
      officialInsightResult(
        result(),
        "qa.alpha",
        "2026-10-02",
        "2026-10-07",
        scope,
      ),
    /período/,
  );
  const raw = result();
  raw.reports.push({ ...raw.reports[0], account: "qa.beta" });
  assert.throws(() =>
    officialInsightResult(raw, "qa.alpha", "2026-10-01", "2026-10-07", scope),
  );
});
test("período precisa ser encerrado, calendário real e no máximo 90 dias", () => {
  assert.doesNotThrow(() =>
    officialRange("2026-10-01", "2026-10-07", "2026-10-08"),
  );
  for (const [start, end] of [
    ["2026-10-01", "2026-10-08"],
    ["2026-02-30", "2026-03-01"],
    ["2026-99-01", "2026-99-02"],
    ["2026-10-07", "2026-10-01"],
    ["2025-01-01", "2026-10-01"],
  ])
    assert.throws(() => officialRange(start, end, "2026-10-08"));
});
test("escolhas e resposta vazia não inventam conta ou relatório", () => {
  assert.deepEqual(
    officialChoices(
      [
        { id: "a", username: "qa.alpha", loja: "bff" },
        { id: "b", username: "qa.beta", loja: "moranga" },
      ],
      "qa.alpha",
    ),
    [{ id: "a", username: "qa.alpha", loja: "bff" }],
  );
  const raw = result();
  raw.reports = [];
  raw.source.lastCollectedAt = null as unknown as string;
  assert.deepEqual(
    officialInsightResult(raw, "qa.alpha", "2026-10-01", "2026-10-07", scope)
      .reports,
    [],
  );
});
