# Perfis informados pelo usuário

Informados em 03/11/2026 para contextualizar o trabalho por conta:

| Perfil | Setor informado |
| --- | --- |
| @bfffitness_atacado | Fitness no atacado |
| @moranga_biquinis | Biquínis / moda praia |

O setor acima veio do contexto fornecido pelo usuário; não foi inferido de uma bio lida. A tentativa de consultar as duas páginas públicas pelo navegador de pesquisa em 03/11/2026 falhou. Isso não demonstra que os perfis não existam. Foto, bio, contadores, desempenho e tipo profissional ainda precisam ser lidos ou confirmados no Instagram conectado.

O projeto continua com cadastro por conta. Esse registro não faz login, não declara uma sessão verificada e não preenche métricas.
