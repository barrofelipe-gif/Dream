# Revisão da leitura de fotos · 0.13.0

Segunda opinião consultada pelo script local do Claude Code em 03/11/2026, com ferramentas desativadas e apenas seis arquivos de código/teste, sem credenciais ou dados de contas reais. A resposta foi lida e confrontada com o restante do projeto.

Foram reproduzidos quatro grupos de falha em novos testes: rótulo Perfil no próprio link, imagem em srcset, preferência por avatar identificado e assinaturas da mesma imagem, e URL inválida no cadastro antes da exportação. Os quatro testes falharam no protótipo e passaram após os ajustes. A suíte completa terminou com 221 testes aprovados.

Mantivemos a URL assinada completa na atualização: trocar a assinatura pode renovar uma foto expirada. Ignorar sempre a query, como sugerido, impediria essa renovação. O coletor compara a informação completa e não reenvia uma captura idêntica. Isso atualiza metadados locais, sem executar ações de seguir.

Também mantivemos `src=""` como escolha explícita de usar iniciais em cartões de contas sem foto própria, evitando aproveitar uma foto de candidato de outro contexto. A foto não verifica login: backups preservam a imagem, mas não restauram a sessão. O CSS fixa as dimensões dos avatares e o nome/@ fica como texto adjacente; as imagens são decorativas para leitores de tela.

Outros pontos dependiam de arquivos não enviados: conferimos que a CSP permite as CDNs, nomes de rotas reservadas já são recusados pelo normalizador, e as atualizações do cadastro chegam à interface como novos objetos. O isolamento e a renovação da imagem foram conferidos no navegador. Não tratamos hipóteses sobre layouts não observados do Instagram como falhas já comprovadas.
