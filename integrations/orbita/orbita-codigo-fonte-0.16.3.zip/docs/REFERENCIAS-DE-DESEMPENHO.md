# Referências do plano de melhoria · 0.14.0

O vermelho identifica uma diferença desfavorável em relação a uma base disponível, com o próximo teste visível. Não é uma inferência de causa nem um limiar de significância estatística. O plano sugere uma variável por vez e uma nova medição com duração e cobertura iguais.

## Bases

- Período anterior: preserva as regras de calendário encerrado, conta, duração, cobertura e valores do período. Base zero permite diferença absoluta, sem variação percentual.
- Histórico pessoal: até seis intervalos anteriores disjuntos em 180 dias, usando a revisão mais recente de cada intervalo. Cada indicador precisa de três valores. Totais usam média por período; a taxa de engajamento usa soma de interações dividida pela soma de alcance, sem tratar isso como público deduplicado entre períodos. Taxas de pulos e médias de tempo não são agregadas.
- Setor: referência cadastrada por conta, apenas para interações/alcance no agregado da conta. Setor, modelo, cobertura, duração, cronologia, fonte e amostra declarados acompanham o sinal. O período da fonte pode estar até 180 dias antes do relatório; não pode estar aberto ou ser posterior a ele. Cinco contas é um mínimo operacional, sem garantia de representatividade. A fonte é informada manualmente e não verificada automaticamente.

Uma melhora versus o período anterior não cancela uma diferença desfavorável versus histórico ou setor. Uma força aparece na área verde somente quando há sinal favorável e nenhum sinal desfavorável nas bases disponíveis.

Indicadores iguais às bases são classificados como estáveis, sem confundir isso com falta de comparação. O diagnóstico exporta as três listas completas: prioridades, forças e estáveis. Diferenças não nulas menores que 0,01 são identificadas na interface; os valores completos continuam na exportação.

## Fontes primárias consultadas em 03/11/2026

- [Rival IQ · métodos de engajamento](https://help.rivaliq.com/en/articles/2043672-understanding-engagement-rates): distingue fórmulas baseadas em seguidores, alcance e impressões, inclusive entre dados públicos e privados. Isso não fornece uma referência para fitness no atacado ou biquínis. O produto usa a fonte para explicar por que denominadores diferentes não devem ser misturados.
- [Dash Social · relatório de moda 2026](https://www.dashsocial.com/social-media-benchmarks/fashion-industry): a página apresenta Instagram com engajamento por visualizações e um recorte amplo de marcas de moda. Não é a mesma definição da taxa por alcance usada na conta. Não aplicamos seus números como média dos perfis informados pelo usuário.

Não foi validada nesta consulta uma média comparável para os dois negócios. Na ausência de fonte adequada, o painel sinaliza a falta da referência e continua usando as bases pessoais disponíveis.

## Conferência

Os testes cobrem ponderação, revisão mais recente, intervalos sobrepostos, mínimo de dados por métrica, direção de perdas/pulos, diferenças entre conta/cobertura/duração, fonte incompatível, backup e preservação de avisos/tentativas. A conferência de interface usa dados fictícios identificados na tela.

Foi solicitada uma revisão adicional pelo script local do Claude Code com três arquivos de código/teste, sem credenciais. O processo atingiu o limite de cinco minutos sem retornar um parecer. Nenhuma conclusão desse pedido foi presumida ou incorporada; a verificação realizada está nos testes e no registro de validação.
