import { readFile, writeFile, mkdir, copyFile } from "node:fs/promises";
import { join } from "node:path";
// Reviewable, buildless preview. The extension itself retains its strict CSP.
const html = await readFile("dist/index.html", "utf8");
const scriptPath = html.match(/<script[^>]+src="([^"]+)"[^>]*><\/script>/)?.[1];
const cssPath = html.match(/<link[^>]+href="([^"]+\.css)"[^>]*>/)?.[1];
if (!scriptPath || !cssPath)
  throw new Error("Assets da compilação não encontrados.");
const script = (await readFile(join("dist", scriptPath), "utf8")).replace(
  /<\/script/gi,
  "<\\/script",
);
const css = await readFile(join("dist", cssPath), "utf8");
const svg = await readFile("public/orbita.svg", "utf8");
const icon = `data:image/svg+xml,${encodeURIComponent(svg)}`;
const preview = html
  .replace(
    /<script[^>]+src="[^"]+"[^>]*><\/script>/,
    () => `<script type="module">${script}</script>`,
  )
  .replace(/<link[^>]+href="[^"]+\.css"[^>]*>/, () => `<style>${css}</style>`)
  .replaceAll("./orbita.svg", icon);
await mkdir("entrega", { recursive: true });
await writeFile("entrega/ABRIR-PREVIA.html", preview, "utf8");
await copyFile("README.md", "entrega/GUIA.md");
await mkdir("entrega/docs", {recursive:true});
await Promise.all([
  copyFile("AGENTS.md","entrega/AGENTS.md"),
  copyFile("docs/REGISTRO-DE-PROBLEMAS.md","entrega/docs/REGISTRO-DE-PROBLEMAS.md")
]);
console.log("Prévia independente e guia salvos em entrega/.");
