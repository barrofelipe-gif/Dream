# Registro contínuo de problemas

O usuário pediu que os problemas encontrados sejam registrados, corrigidos e acompanhados para evitar que o trabalho fique parado.

- Ao encontrar um defeito concreto na Órbita, registre em `docs/REGISTRO-DE-PROBLEMAS.md`: identificador, data/versão, comportamento observado, reprodução, situação, correção e validação. Não invente falhas ou evidências para preencher o histórico.
- Corrija defeitos dentro do trabalho autorizado e prossiga com verificações adequadas. Use um teste que reproduza o problema quando ele proteger um comportamento importante; evite testes que apenas espelhem uma alteração trivial.
- Só marque como conferido após ler o resultado da validação. Distingua uma operação recuperada de uma causa corrigida. Se depender de conta, credencial, disponibilidade externa ou decisão do usuário, registre a dependência e continue o que for independente dela.
- Não repita automaticamente ações no Instagram, mutações ou importações como tentativa de correção. Preserve os controles de sessão, avisos, fila e tentativas consumidas.
- Não guarde credenciais, arquivos pessoais ou listas de clientes no histórico técnico. Trabalhe com uma reprodução mínima e dados fictícios. Não envie diagnósticos ou mensagens a terceiros sem autorização.
- O registro da aplicação fica separado do registro do repositório. Analise a evidência recebida antes de alterar o código e atualize o histórico após uma correção validada.

As instruções do usuário sobre segunda opinião com Claude Code continuam aplicáveis; confira os achados antes de incorporá-los.
