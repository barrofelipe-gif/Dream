# Registro contínuo de problemas

O usuário pediu que os problemas encontrados sejam registrados, corrigidos e acompanhados para evitar que o trabalho fique parado.

- Ao encontrar um defeito concreto na Órbita, registre em `docs/REGISTRO-DE-PROBLEMAS.md`: identificador, data/versão, comportamento observado, reprodução, situação, correção e validação. Não invente falhas ou evidências para preencher o histórico.
- Corrija defeitos dentro do trabalho autorizado e prossiga com verificações adequadas. Use um teste que reproduza o problema quando ele proteger um comportamento importante; evite testes que apenas espelhem uma alteração trivial.
- Só marque como conferido após ler o resultado da validação. Distingua uma operação recuperada de uma causa corrigida. Se depender de conta, credencial, disponibilidade externa ou decisão do usuário, registre a dependência e continue o que for independente dela.
- Não repita automaticamente ações no Instagram, mutações ou importações como tentativa de correção. Preserve os controles de sessão, avisos, fila e tentativas consumidas.
- Não guarde credenciais, arquivos pessoais ou listas de clientes no histórico técnico. Trabalhe com uma reprodução mínima e dados fictícios. Não envie diagnósticos ou mensagens a terceiros sem autorização.
- O registro da aplicação fica separado do registro do repositório. Analise a evidência recebida antes de alterar o código e atualize o histórico após uma correção validada.

As instruções do usuário sobre segunda opinião com Claude Code continuam aplicáveis; confira os achados antes de incorporá-los.

# País da conexão e dados de cadastro

- O usuário proibiu migração nesta revisão. Perguntas sobre nuvem ou Vercel não autorizam transferir execução, sessões, contas, dados ou infraestrutura. Valide possibilidades com evidências e indique o que ainda não foi testado.

- O usuário pediu usar conexão do Brasil para acessar suas contas do Instagram. Preserve a execução no Chrome local; não migre login, coleta ou ações para um navegador em servidor estrangeiro.
- A checagem no próprio Chrome em 03/11/2026 retornou `loc=BR` no diagnóstico da Cloudflare. Isso registra aquela conexão, não implementa uma trava geográfica permanente nem comprova todas as rotas de outros aplicativos. Não armazene o IP no diagnóstico.
- Hospedagem do painel e origem da conexão do Chrome são coisas diferentes. Confirme o escopo antes de alterar infraestrutura.
- Se for necessário preencher endereço de publicador na loja, use dados reais fornecidos pelo usuário. Não invente endereço, CPF/CNPJ ou país de cadastro.

# Horários autorizados

- Em 04/11/2026, o usuário autorizou monitorar e seguir em qualquer horário, inclusive madrugada. A implementação é a preferência explícita `settings.allDay`; não simule 24h com uma janela 00h–23h59 ou horários iguais inválidos.
- Essa autorização muda os horários, não aumenta tetos diário/de sessão nem reduz intervalos por conta própria. Preservar proteções, avisos, histórico e verificação de identidade. Consultas periódicas não devem ser anunciadas como detecção instantânea de cada interação.

# Quantidade autorizada para a BFF

- Em 06/11/2026, o usuário pediu explicitamente a BFF sem teto de quantidade, mantendo 5 minutos entre ações. A opção por conta é `settings.unlimitedAttempts=true`, sujeita à confirmação da capability nativa. Ela desliga o teto diário e de lote, sem substituir por um número elevado nem serializar Infinity.
- Essa escolha não altera o padrão de outras contas, não apaga tentativas consumidas e não libera avisos, resultados incertos, identidades divergentes ou perfis protegidos. Alterar a preferência continua pausando e exigindo ativação revisada das fontes. Desligar a opção restaura os tetos numéricos guardados; o começo guiado deve desligá-la.
- As limitações de leitura do Instagram e os limites de tempo/passo das consultas continuam separados do teto de tentativas. Não removê-los por inferência desta autorização.
