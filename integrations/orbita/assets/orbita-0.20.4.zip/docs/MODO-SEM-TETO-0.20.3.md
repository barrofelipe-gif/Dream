# Quantidade sem teto — 0.20.3

Em 06/11/2026, o usuário pediu explicitamente a BFF sem teto de quantidade, mantendo 5 minutos entre ações. A preferência por conta `settings.unlimitedAttempts` desativa os tetos diário e por lote. Ausente equivale a falso; valores presentes que não sejam booleanos são rejeitados. Os limites numéricos continuam válidos e guardados para quando a opção for desligada. O padrão das outras contas não muda.

Não é um número elevado apresentado como ilimitado. O executor não serializa Infinity nem limpa o consumo diário para abrir novos lotes. O livro diário continua usando as chaves de cada dia, preservando histórico e última tentativa. O contador da sessão mantém as fronteiras legítimas do comportamento anterior: início manual e sessão comprovadamente anterior renovam contador e início juntos; um tick normal não os zera. O intervalo vale inclusive à meia-noite e depois de uma pausa.

## Execução e compatibilidade

`hasDailyBudget` e `hasSessionBudget` centralizam a decisão de quantidade em budgetStopReason, no início manual e na autorização final do clique. O scheduler não posterga a fila para amanhã por um teto desativado. Intervalo, janela, avisos, resultado incerto, identidade, fonte autorizada, exclusões, proteção e revisão de deixar de seguir mantêm suas verificações. Os limites de tempo/passo e transação das leituras parciais continuam separados.

Salvar preferências pausa e invalida a autorização anterior. Restore mantém a preferência válida, mas pausa e revoga a autorização. O começo guiado desliga a opção e restaura seus valores finitos. Contadores não são apagados ao escolher o modo.

O nativo novo informa `GET_STATE.capabilities.unlimitedAttempts=true`. A interface só permite ligar com suporte confirmado. Se o suporte desaparecer, a preferência verdadeira é apresentada como pendente e o início é impedido; desligar continua disponível. Não se finge que a preferência virou falsa.

No sentido inverso, uma interface antiga não pode liberar o modo apenas porque a conta já o usa. `START` e `START_CONTINUOUS` exigem `unlimitedAttemptsReviewed === true` quando a preferência está ativa, validado na transação de início. Comandos antigos continuam compatíveis com o modo limitado. A revisão inclui conta, fontes/fila, preferência e capability; mudanças invalidam a confirmação.

Preferências, fila, rotina e ritmo apresentam sem teto em vez dos números guardados ou barras de progresso finitas. Quantidades efetivamente realizadas continuam visíveis. A escolha não é uma frequência segura certificada pelo Instagram.

## Revisões e evidências

Uma revisão independente examinou core, nativo e interface. O Claude Code recebeu o contrato e o diff do core, sem credenciais nem dados de clientes. Seus riscos foram confrontados com código e regressões, sem serem chamados de bugs reproduzidos. A sugestão de fingir uma preferência falsa na perda de suporte não foi adotada: o estado permanece explícito e pendente, com início impedido.

As regressões incluem orçamento 501, preservação de consumo diário, uma tentativa só após 5 minutos, renovação coerente de sessão, cliente antigo, revisão literal, bloqueios, retorno ao modo limitado, capability perdida e recuperada durante CONFIG2, restauração e mudança durante gravação. A suíte final passou com 568 testes da Órbita e 23 da integração, e o build/TypeScript passou. A QA isolada no bundle final aprovou 82 verificações e 16 capturas em 1440/390px, com suporte moderno/legado, sem ações reais no Instagram. Resultados, hashes e dependências reais ficam em entrega/VALIDACAO-0.20.3.json.

A passagem real das três fontes e do primeiro follow foi confirmada na 0.20.2 em 06/11/2026. Isso não valida o modo sem teto novo. Sua aplicação real depende da recarga legítima do nativo 0.20.3, da escolha na BFF e da ativação revisada das fontes. Não há migração ou alteração de permissões/armazenamento do Chrome nesta atualização.
