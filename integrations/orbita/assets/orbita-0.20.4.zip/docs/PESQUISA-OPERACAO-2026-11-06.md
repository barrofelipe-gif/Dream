# Como as ferramentas operam — consulta de 06/11/2026

Esta comparação usa documentação pública dos fornecedores, sem assinatura, acesso a código privado ou teste das contas deles. Declarações comerciais não provam disponibilidade prolongada, segurança ou resultados. Não foi feita migração da Órbita.

| Ferramenta | Operação documentada | Relação com a Órbita |
| --- | --- | --- |
| [AutoInsta, autoinsta.online](https://www.autoinsta.online/) | Chrome visível, sessão local e dispositivo em execução. Define fontes, ritmo, janelas e limites por conta. Anuncia mais modalidades, como Stories e sequências de ações. | Confirma que usar navegador local não é uma particularidade da Órbita. Já temos fontes, fila, intervalos e histórico; Stories e sequências não integram o executor atual. |
| [PhantomBuster, Followers Auto Follow](https://phantombuster.com/automations/instagram/2439619339195827/instagram-followers-auto-follow) e [Auto Follow](https://phantombuster.com/automations/instagram/10274/instagram-auto-follow/tutorial) | Usa sessão autenticada, executa na nuvem, permite agendamentos e registra resultados. O produto para seguidores e o produto para listas próprias têm quantidades por execução diferentes. O fornecedor também declara limitações de exposição de seguidores em certos perfis. | A cadeia fonte → candidatos → executor → histórico já existe localmente. A execução sem computador é uma diferença real. Transferir sessão para nuvem não está autorizado e não foi feito. |
| [Nikau](https://nikau.com.br/) | A página atual prioriza visualização e interação em Stories, publicação e relatórios. | Não é evidência de um serviço atual equivalente de seguir/deixar de seguir. Anúncios de crescimento não foram tratados como resultado comprovado. |
| Perforgram / Scalehot | O domínio Perforgram retornou 502 nesta consulta; Scalehot não ficou acessível pela ferramenta. | Não foi possível confirmar a execução atual. Artigos antigos e páginas de terceiros não bastam para dizer como funcionam hoje. |

AutoInsta aqui identifica **autoinsta.online**. **autoinsta.com.br** é outro produto, voltado a respostas e mensagens; não foram misturados.

## O que pode ser reaproveitado

O padrão útil é configurar fontes por conta, coletar somente o que está disponível, deduplicar candidatos, manter fila persistente, executar com intervalo e registrar cada resultado. A Órbita validou essa cadeia em sessão real em 06/11/2026: 10 nomes nas curtidas, 5 nos comentários, 10 nos seguidores e um resultado automático Seguindo confirmado. As três leituras foram parciais.

As diferenças ainda relevantes são novas publicações descobertas automaticamente, mais modalidades de interação e execução na nuvem. Não foram declaradas implementadas por esta pesquisa. A publicação fixa da Dalu continua sendo a fonte de comentários/curtidas; as consultas a cada 15 minutos não são notificações instantâneas de cada interação.

## Aumento de quantidade pedido para a BFF

O teto de 5/dia era uma escolha do piloto da Órbita, não um limite publicado pelo Instagram. Em 06/11/2026, o usuário pediu explicitamente **sem teto de quantidade**, preservando **5 minutos entre ações**. A opção nova `unlimitedAttempts` retira teto diário e de lote de forma explícita, sem um número elevado disfarçado de ilimitado. O intervalo ainda permite no máximo cerca de 12 tentativas por hora; isso é aritmética da configuração, não garantia de uma frequência aceita pela plataforma.

As quantidades anunciadas por fornecedores variam por produto e não são limites oficiais nem prova de risco baixo. O modo sem teto conserva histórico, tentativas consumidas, identidade, proteções, revisão e interrupção por avisos ou resultado incerto. A opção requer suporte do executor nativo; uma interface antiga não pode autorizá-la silenciosamente.
