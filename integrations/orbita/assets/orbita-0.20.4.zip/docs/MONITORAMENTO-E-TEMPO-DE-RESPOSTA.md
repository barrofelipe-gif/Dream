# Monitoramento e tempo de resposta

Verificação em 03/11/2026, com documentação pública e leitura do executor nativo 0.19.0. Não foram contratados aplicativos, recebidas credenciais de concorrentes ou executadas ações no Instagram. A inspeção não mede o desempenho real de uma assinatura desses serviços.

## O que os fornecedores documentam

| Produto e fonte primária | Mecanismo documentado | O que essa evidência permite concluir |
| --- | --- | --- |
| [AutoInsta, autoinsta.online](https://www.autoinsta.online/) | Navegador Chrome, sessão conectada, dispositivo ligado, limites e janelas por conta. | A execução local de interface também existe nesse produto. O painel com ações em tempo real não comprova uma notificação instantânea de cada interação em um perfil terceiro. |
| [PhantomBuster, Watcher mode](https://phantombuster.com/automations/instagram/7175/instagram-follower-collector/tutorial) e [agendamentos](https://support.phantombuster.com/hc/en-us/articles/11392980593298-How-to-Schedule-Your-Phantoms-to-Run-Automatically) | O Watcher relê o perfil em cada execução e acrescenta nomes não encontrados anteriormente. Agendamentos repetem as execuções sem clicar em Launch. | É acompanhamento por consultas sucessivas. O mecanismo descrito não entrega um evento de Instagram para cada novo seguidor do perfil observado. O fornecedor reconhece listas parciais/limitadas. Não adotamos seus números anunciados como limites oficiais da Meta. |
| [Auto Insta, autoinsta.com.br](https://autoinsta.com.br/) | Produto diferente, que anuncia conexão oficial, respostas a comentários e Direct no perfil conectado. | A promessa de resposta em segundos refere-se às interações da própria conta conectada; não comprova acompanhamento equivalente dos seguidores, curtidas e comentários da Dalu. A latência anunciada não foi testada. |
| [Nikau](https://nikau.com.br/) | A página atual prioriza visualização e interação em Stories. | Não encontramos documentação técnica de um evento instantâneo de seguidores ou curtidas de concorrentes. Os materiais comerciais não bastam para confirmar a arquitetura. |
| Perforgram e Scalehot | As tentativas aos termos do Perforgram e ao domínio Scalehot retornaram 502 nesta consulta. | Não foi possível confirmar mecanismo, latência ou funcionamento atual. A indisponibilidade da consulta não demonstra encerramento dos serviços. |

## O que a Meta documenta

A [coleção oficial da Meta no GitHub](https://raw.githubusercontent.com/fbsamples/messenger-platform-samples/main/postman/instagram-platform-api.postman_collection.json) documenta `comments` e `live_comments` para mídia da conta profissional conectada ao app. O payload pode incluir autor, texto e mídia. Isso depende da conexão, permissões e assinatura do webhook; a Órbita não passa a receber esses eventos só por instalar sua extensão.

Na referência pública examinada não foi encontrado um webhook geral que notifique cada novo seguidor ou cada curtida, própria ou de um concorrente. Essa conclusão se limita à documentação examinada; a lista de exemplo de assinaturas não prova a inexistência de todo piloto ou produto privado. A consulta `is_user_follow_business` da User Profile API é um estado condicionado ao consentimento da pessoa via mensagens, não uma lista ou evento de novos seguidores da Dalu.

As páginas diretas de Webhooks em developers.facebook.com retornaram 429; a alternativa utilizada foi a coleção publicada pela própria Meta. Não se extrapolou o webhook de comentários próprios para mídia de terceiros.

## Situação comprovada no código da Órbita

- `src/extension/continuous-schedule.ts`, `continuousWakeAt()`: a janela das ações também limita o agendamento das leituras.
- `src/extension/background.ts`, `runContinuousTick()` e passos do scanner: fora da janela não há varredura. Na configuração BFF anteriormente conferida, ambos usam 09h–21h.
- `src/core/continuous.ts`, commit da leitura: cada fonte recebe o próximo prazo após o fim da leitura, com seu `pollMinutes`. Na configuração conferida são 15 minutos; atrasos, fila e disponibilidade podem ampliar esse tempo.
- O orçamento diário/de sessão esgotado bloqueia novas ações, mas não as leituras dentro da janela. Não se zera um contador nem se abre outro lote para contornar o orçamento.
- Seguidores, comentaristas e curtidores são três fontes processadas em sequência. Comentários e curtidas usam a publicação fixa configurada; novos posts não entram automaticamente.
- Pessoas já cadastradas são deduplicadas. Outra curtida ou comentário da mesma pessoa não cria um novo evento de reação. Descoberta no cadastro não prova que a interação ou o follow ocorreu naquele instante.
- As leituras são parciais, com limite de passos/tempo, e o executor requer computador, Chrome e sessão disponíveis. A conexão brasileira já conferida deve ser preservada; o painel publicado não cria um navegador de execução na nuvem.

## Separação necessária para o comportamento solicitado

1. **Eventos da própria conta:** conectar os webhooks oficiais para os eventos realmente disponíveis e encaminhá-los a uma fila idempotente, sem duplicar a automação de mensagens que o usuário já tem. Isso requer uma integração própria, ainda não validada aqui.
2. **Fontes de terceiros:** separar janela de coleta e janela de ações. Assim, uma coleta explicitamente configurada para 24h pode continuar durante a madrugada sem ampliar silenciosamente a janela de follows. A frequência continua sendo uma consulta configurável, não uma promessa de detecção instantânea.
3. **Execução das ações:** respeitar a janela escolhida, o intervalo, o orçamento, proteções, identidade e avisos existentes. Encontrar uma pessoa não obriga executar um follow imediatamente se essas condições não permitirem.
4. **Cobertura e evidência:** registrar separadamente horário da descoberta, horário da próxima consulta e espera na fila. Um horário de descoberta não deve ser exibido como horário real da interação. Descobrir publicações novas do perfil observado e guardar um histórico individual de eventos são incrementos separados.

Em 04/11/2026, o usuário definiu que monitoramento e follows podem funcionar em qualquer horário, inclusive madrugada. O nativo 0.19.1 acrescenta `settings.allDay` para ambos, preservando a janela anterior para quando desligado. A aplicação real depende da recarga do novo executor e da preferência salva; o campo ausente continua falso. A separação de janela exclusivamente de coleta não integra esse incremento, pois a escolha foi liberar ambos. Permanecem os limites das consultas periódicas e a ausência de detecção instantânea de cada interação de terceiros.
