# Recuperação de preparo pré-clique — 0.20.4

## Estado desta entrega

Contrato ORB-095 implementado no executor e no domínio. O responsável pelo executor conferiu 174 testes dirigidos com fixtures/doubles; os seis testes do arquivo de integração da UI e o TypeScript também passaram. O log integrado final do coordenador registra 588 testes aprovados e zero falhas; seu resultado foi lido nesta preparação. Build, pacotes, publicação, recarga do nativo e recuperação na sessão real ainda não foram conferidos nesta preparação. O histórico do defeito e sua validação ficam em REGISTRO-DE-PROBLEMAS.md. Relatórios reais, capturas da conta e dados de runtime ficam fora do ZIP de fonte.

## O que pode ser recuperado

O executor contínuo pode reagendar somente um PageDeadlineError ocorrido durante a preparação de um follow, antes de reservar a tentativa e antes de qualquer envio de FOLLOW. A espera não reserva nem consome uma tentativa de ação. Não se trata de repetir um pedido de ação cujo resultado não chegou.

O reagendamento exige que a conta, o candidato ainda queued e elegível, o username, a fonte e as autorizações global e da fonte continuem válidos. Esses vínculos, o número de falhas consecutivas, retryAt e a fase ficam persistidos em continuous.preparationRetry. Reabrir o serviço não deve perder a espera nem autorizar outra conta ou outro candidato.

## Espera e nova preparação

As falhas consecutivas usam esperas de 1 minuto, 3 minutos, 10 minutos e depois 15 minutos. A espera fica limitada a 15 minutos, sem um máximo de contagem de falhas e sem um laço imediato de consultas. O orçamento da consulta e o intervalo entre ações permanecem controles separados.

A próxima preparação usa uma aba nova; a aba anterior é preservada. Sessão, identidade da conta, rota do perfil, avisos, rascunhos, exclusões, proteções e demais controles são conferidos novamente. Acordar do alarme ou conseguir ler STATUS/fonte não comprova recuperação nem zera a sequência de falhas do preparo do follow; a limpeza depende de um resultado válido da ação conforme o executor. A recuperação das consultas de fontes tem seu próprio contador, descrito abaixo.

## Timeout durante a leitura de uma fonte

Esta mesma atualização acrescenta reagendamento de consultas de seguidores, comentários e curtidas quando a falha é um PageDeadlineError. Esse mecanismo não era um backoff já existente na versão anterior.

Ao agendar, o domínio exige conta vigente, rotina autorizada, fonte ativa e incluída nessa autorização, autorizações global e da fonte correspondentes e o mesmo runId ainda em checking. Um retorno de uma consulta anterior não pode reagendar uma ativação nova. A fonte mantém ready/enabled e guarda readRetry com authorizationId, sourceAuthorizationId, failures, retryAt e phase; nextCheckAt recebe retryAt.

As esperas também são de 1, 3, 10 e depois 15 minutos, sem limite de contagem e sem repetição imediata. A consulta que excedeu o prazo não importa seus resultados parciais nem revoga os candidatos já enfileirados. Os dados de leituras anteriores ficam preservados. A aba que falhou é desassociada antes de aguardar outras operações; a próxima leitura usa outra aba e outro identificador de consulta.

Um commit válido de leitura limpa o readRetry daquela fonte. Configuração, nova ativação, pausa, restauração e falha não transitória também o removem conforme o domínio. Erro explícito, identidade divergente, aviso do Instagram e fonte indisponível continuam seguindo os controles de parada/conferência; não são convertidos em timeout recuperável.

## Como a fila apresenta a espera

Quando a rotina contínua segue autorizada, o executor pode ficar entre ações sem uma pausa manual. A fila mostra Aguardando próxima ação durante essa espera e Reconectando automaticamente somente quando o helper do domínio confirma um preparationRetry ainda vinculado à conta, candidato, fonte e autorizações atuais. Um campo antigo, isoladamente, não autoriza esse título. O motivo e o próximo horário permanecem visíveis. Depois de uma pausa manual, o título continua Execução pausada.

## Quando cancelar ou parar

Pausa, alteração de preferências ou configuração da fonte, troca de conta, aviso pendente e restauração de backup revogam a recuperação. Uma resposta atrasada precisa continuar vinculada à mesma operação e às mesmas autorizações; não pode recriar a rotina depois de uma revogação.

Depois da reserva da tentativa, não há recuperação automática deste tipo, mesmo que a falha apareça antes de o painel receber uma resposta. Envio de FOLLOW, clique potencial, resultado desconhecido, erro explícito do Instagram, desafio, identidade divergente, rascunho, fonte indisponível ou estrutura não reconhecida não são licença para repetir uma ação. Resultados incertos continuam exigindo conferência.

## O que permanece igual

- A preferência sem teto continua explícita por conta e sujeita à capability e à revisão de início; dados antigos não a ativam.
- O pedido atual da BFF mantém 5 minutos entre ações. Esta correção não reduz esse intervalo, não apaga consumo, histórico ou última tentativa e não altera a agenda 24h escolhida.
- A recuperação dos timeouts de fontes é nova nesta versão, separada da recuperação pré-clique. A correção não torna a coleta completa, em tempo real ou independente de Chrome e sessão disponíveis.
- O painel e a bridge não retransmitem mutações expiradas. A recuperação acontece no executor nativo antes de existir uma ação reservada/enviada.
- Não há migração, proxy, troca automática de conta, alteração de permissões ou instalação/recarga automática.

## Segunda opinião e decisões da revisão

A primeira consulta ao Claude Code expirou após cinco minutos sem resposta; nenhum achado lhe foi atribuído. Uma nova consulta analisou o diff e devolveu um parecer condicionado negativo, com hipóteses e lacunas explícitas, sem executar testes. Esse parecer foi lido e conferido no código; não equivale a uma aprovação do Claude.

Dois ajustes pertinentes foram adotados: registrar o timeout descartado porque seu lease ficou obsoleto, preservando a ativação atual; e isolar o contador failures pelo mesmo vínculo completo de preparação (samePreparation), para não herdar falhas de outro candidato. As hipóteses de um retry continuar válido depois de sair de queued e de IDs de abas não tratados foram refutadas pelos controles e regressões conferidos. A sugestão de cair na pausa genérica quando o lease já mudou não foi adotada, pois poderia revogar uma ativação nova por causa de uma resposta antiga. A intervenção no fallback de injeção foi limitada ao leitor e conferida pelo responsável com a documentação do Chrome; não autoriza cliques.

Essa revisão e os testes fictícios não identificam a causa raiz da falha observada nem validam a recuperação na sessão real.

## Verificação necessária para fechar

As regressões do executor usam dados fictícios e APIs de Chrome/Instagram simuladas: esperas, persistência/reinício, vínculos de autorização, ausência de reserva/envio no timeout recuperável, cancelamentos e respostas atrasadas. A UI também cobre intervalo ativo, recuperação válida, lease obsoleta e pausa manual. Controles negativos preservam a parada depois de reserva, aviso, divergência ou resultado incerto. A suíte integrada, build e conferência de pacotes só serão registrados como aprovados após seus resultados serem lidos. O teste na sessão real é uma etapa separada; fixtures não o substituem. Recuperação simulada não prova que a rotina nunca vai parar nem identifica a causa raiz do timeout observado.

## Validação final do pacote

Após os dois ajustes da revisão Claude: 589/589 testes da Órbita, 23/23 da integração BFF e TypeScript/build aprovados. Os 175 testes focados do executor e 6 de UI estão incluídos na suíte correspondente, não são somados de novo. A revisão independente do snapshot final não encontrou achados materiais restantes. Não houve Instagram real nos fixtures; a primeira consulta Claude expirou e a segunda resposta foi lida e confrontada com o código completo, sem declarar aprovação pelo Claude.

