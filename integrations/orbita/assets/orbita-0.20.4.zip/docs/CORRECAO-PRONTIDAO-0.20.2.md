# Prontidão da rotina — 0.20.2

Em 04/11/2026, após o usuário confirmar a recarga legítima do nativo 0.20.1, o painel reconectou, confirmou suporte à agenda 24h e verificou a sessão da conta selecionada. O diagnóstico no próprio Chrome retornou país BR; não foi registrado IP. A preferência 24h foi salva explicitamente, preservando 5 tentativas/dia, 5/sessão, intervalo de ações de 5 minutos e consultas das três fontes a cada 15 minutos.

A ativação real autorizada consultou a publicação escolhida: comentários registrou 5 perfis, sem novos nem enfileiramentos. Curtidas registrou zero, mas a conferência visual posterior encontrou 11 linhas carregadas. Ao passar da publicação para o perfil, a rotina pausou afirmando troca de sessão, embora a navegação mostrasse a conta esperada. Não houve nova ação social nessa passagem. A rotina permaneceu pausada durante a correção; a autorização existente não foi reaplicada como tentativa de recuperação.

## Alterações delimitadas

- Identidade ausente aguarda dentro do mesmo prazo de preparo de 18 segundos. Conta identificada diferente e restrição continuam interrompendo imediatamente. STEP exige identidade esperada e as duas rotas da fonte reconhecidas. Prazo vencido informa ausência de identificação, sem afirmar troca de conta.
- Diálogo tipado ainda vazio, sem sinal explícito de ausência de dados, permanece carregando. O limite já existente de 16 passos/20 segundos continua valendo; a rotina não grava zero prematuramente. O reconhecimento de lista, autor e publicação continua obrigatório.
- A divergência real de identidade também gera registro na central de problemas, sem transformar pausas voluntárias ou identidade transitória em ocorrências.

## Segunda opinião

O Claude Code recebeu somente background.ts, dom.ts e testes fictícios do worker, com ferramentas desativadas. A resposta foi lida integralmente em output/claude-runtime-readiness-20261104.log. Ela confirmou a distinção entre identidade ausente e diferente e identificou a falta de diagnóstico no caminho de divergência real. As correções foram confrontadas com o código e testes, não aceitas por autoridade.

A hipótese de fonte ficar presa em checking foi refutada: pauseContinuous já chama invalidateCheck nas fontes em leitura e remove a referência de aba. O rascunho com identidade ausente passa a ser honrado pela correção principal. As sugestões adicionais de reler a aba após STATUS e alterar o método session() da fila não foram tratadas como bugs reproduzidos: a prontidão exige ambas as rotas, STEP volta a conferir a identidade/fonte, e a fila continua recusando identidade não confirmada antes de qualquer ação. Não foi ampliado o prazo, orçamento, quantidade de fontes, política de seguir ou permissões.

## Validação e limites

As regressões de hidratação e lista vazia falharam antes da correção. A suíte integrada passou com 539 testes, e TypeScript/build passaram. Entre eles, 23 testes do worker e 15 do leitor cobrem a rotina. Resultados finais de integração, publicação e hashes ficam na entrega VALIDACAO-0.20.2.json. A confirmação do usuário de 0.20.1 não equivale a carregar a correção 0.20.2. A validação real completa da rotina corrigida depende da recarga legítima e nova ativação explícita, sem repetição de ações de resultado incerto.

A coleta continua parcial e periódica, na sessão local do Chrome. Comentários e curtidas usam a publicação já configurada; não detectam todas as novas publicações nem eventos instantâneos. Nenhuma conta, sessão ou infraestrutura foi migrada.
