# Revisão integral da Órbita · 04/11/2026

## Escopo e evidências

Revisão da Órbita e da integração com o Growth do BFF: núcleo de contas, fila, coleta, rotina, armazenamento, métricas, importações, autorização, interface e distribuição. Não abrange os módulos independentes de Telegram, Gmail ou estoque do BFF.

O usuário proibiu migração. Nenhuma sessão, conta, execução ou infraestrutura será transferida como parte desta revisão. As verificações que simulam ações usam somente dados fictícios e não autorizam repetir operações no Instagram.

Antes das correções, `npm test` aprovou 458/458 testes, a integração BFF aprovou 16/16 testes de hosting/insights e `npx tsc --noEmit` do BFF terminou sem erros. Esses resultados não provam ausência de defeitos; reproduções independentes encontraram falhas adicionais.

O código pertinente foi separado em oito módulos, com caminhos e SHA256 no cabeçalho. As três consultas grandes iniciais excederam cinco minutos e **não contaram como revisão concluída**. Uma consulta curta confirmou disponibilidade do Claude Code; o contexto foi dividido em 33 partes menores. O índice local `output/revisao-20261104/cobertura.json` relaciona todos os 86 arquivos de `src`, além de scripts, manifest e integração. Não foram enviados `.env`, cookies, perfis autenticados, estados reais das contas ou listas de clientes. Cada achado precisa de conferência antes de virar alteração. Os resultados e a decisão sobre cada achado serão registrados abaixo após leitura.

A rotina real foi pausada durante a auditoria. A tela confirmou “Rotina pausada”, três fontes preservadas e 28 perfis existentes. Nenhuma ação real de seguir, deixar de seguir ou mensagem faz parte da QA.

## O que a documentação permite concluir sobre a Vercel

Os [Daemons](https://vercel.com/docs/daemons) oferecem processos contínuos em contêiner. A [configuração](https://vercel.com/docs/daemons/config-reference) permite escolher regiões. Isso é capacidade documentada da plataforma; não é validação do nosso aplicativo nesse ambiente.

Os [limites documentados](https://vercel.com/docs/daemons/limits) incluem execução somente em produção e ausência de armazenamento local persistente. O plano Hobby tem franquias mensais que podem interromper os processos. Portanto, não se deve prometer operação contínua gratuita ou persistência automática da sessão.

O [Playwright documenta extensões MV3 em Chromium com contexto persistente](https://playwright.dev/docs/chrome-extensions). Isso não comprova compatibilidade do pacote da Órbita com Daemons. Ainda seriam necessários ensaios próprios de contêiner, autenticação, armazenamento seguro, retomada sem duplicação e origem brasileira da conexão de saída. Escolher região brasileira, isoladamente, não prova a geolocalização do IP visto pelo Instagram.

Não há Docker disponível nesta estação para executar esse ensaio local. Não foi criado ou publicado um contêiner, nem transferida uma sessão. A viabilidade ponta a ponta na nuvem permanece **não testada**. A execução atual permanece no Chrome local.

## Revisões e correções

Fonte consolidado na versão 0.20.1. Os **530/530 testes integrados**, **23/23 testes da integração BFF** e TypeScript/build passaram. O BFF recebeu fast-forward dos dois commits externos já publicados, sem sobrescrever alterações de Telegram. A conferência final da publicação e da instalação nativa fica registrada ao final; aprovação em fixtures não equivale a execução real no Instagram.

### Triagem das respostas do Claude já lidas

| Parte / apontamento | Conferência e decisão |
| --- | --- |
| 3-1 · bootstrap concorrente | Os entry points reais aguardam `initialized`, que aguarda `storeReady`. O cenário sem essa espera não existe nos caminhos auditados. Não alterar serialização por uma hipótese de chamador ausente. |
| 3-1 · alarmes antigos | Handlers conferem conta ativa, modo e exclusão global. Alarmes antigos não bastam para executar uma segunda ação. Não foi reproduzido clique duplicado. |
| 3-1 · seguir após falha de setAccessLevel | Recomendação rejeitada: remover essa exigência enfraqueceria o isolamento do armazenamento. Bootstrap falha fechado; falha de leitura é comunicada pelo fluxo GET_STATE. |
| 8-1 · duplicata de métricas com períodos distintos | O coletor real solicita somente `period: day`. O adaptador descarta métricas ambíguas em vez de inventar totais. Não foi demonstrada perda com o contrato atual; eventual aceitação de períodos mistos exige um contrato próprio. |
| 8-1 · último dia/truncamento em 91 registros | Schema documenta data como chave diária 00:00 UTC e `@@unique([contaId,data])`; coletor faz upsert. A janela máxima é 90 dias. Hipótese descartada após leitura do produtor/schema. |
| 8-1 · candidato da loja 0.19.0 | Congelamento intencional do candidato técnico, não versão indicada para instalação atual. Script aceita pacote/SHA explícitos. Não atualizar artefato congelado nem anunciar aprovação da loja. |
| 8-2 · snapshot inicial vs watcher | Corrigido: watcher válido prevalece e limpa erro inicial; regressões antes/depois conferidas. |
| 8-2 · lockPanel sem desmontagem | Corrigido: desmontagem, fim de polling e recusa de mensagens novas, sem reduzir autenticação. |
| 8-2 · resposta de sessão não JSON | Corrigido com erro acionável e sessão inválida recusada. |
| 1-1 · QUEUE_UNFOLLOW com id obsoleto | Corrigido: seleção inteira validada antes de qualquer acesso/mutação. |
| 1-1 · ordenação de snapshots por texto | Corrigido em prontidão, ordem de relatórios e baseline de desempenho, com regressões. |
| 1-1 · mutate em migrateStore | Chamadores usam cópias e só persistem após retorno válido; mock de falha confirmou zero gravações e dados persistidos idênticos. |
| 1-2 · pausa deixa attempting | Worker conserva limite de resposta de 12 s e converte retorno inválido em uncertain; reinício recupera tentativa interrompida. Não marcar como travamento definitivo olhando apenas o módulo de rotina. |
| 1-2 · checking sem recuperação | Bootstrap invalida runId interrompido e agenda leitura nova; teste de reinício já cobre esse caminho. Não repetir ação social por conta dessa recuperação de leitura. |
| 1-2 · reiniciar antecipa consulta | Iniciar/reconfigurar são comandos explícitos; primeira consulta imediata é comportamento atual. Intervalos das ações e budgets continuam valendo. Não confundir reinício manual com aceleração automática. |
| 1-4 · lote pausado vs próximo lote | START explícito zera sessionAttempts antes da execução; quadro descreve o próximo lote. Não foi demonstrado bloqueio contraditório no fluxo completo. |
| 1-4 · fila de outras contas | AppState pertence a um workspace; executor exige dono da fila e conta ativa. Não adotar filtro permissivo `!queueAccount` sugerido sem validar contrato de propriedade. |
| 1-4 · formato de lastAttempts | Escritores usam chave `@` + usuário canonical, audit sem `@`; leitor usa os dois formatos nos lugares corretos. Caso hipotético de escritor externo não foi comprovado. |
| 1-3 · identidade e importação | Corrigidos conflito de rename após revisão e alias CSV genérico `id`. Retorno à revisão continua explícito; reprodução com botão Seguindo resultou em `already`, zero autorizações e zero cliques. |
| 2-1 · origens | Datas e nomes das listas são validados/normalizados pelo produtor; não reproduzido NaN em fluxo válido. JSON sem `account` é recusado. Operações usam clones e a escrita é serializada; a validação de preview não grava dados. Rótulo informado continua separado da evidência de associação. |
| 2-2 · benchmark e sementes | DTO exige nota como string, e a UI envia vazio quando não preenchida. UI arquiva referências, não as remove do livro; não reproduzida ressurreição por arquivamento. Rejeitado teto percentual de 100: interações/alcance pode exceder 100, e já existe teste disso. |
| 2-3 · Radar e variação | Corrigida colisão da query. Arquivamento é preservado deliberadamente ao importar. Variação passa a se chamar “entre medições”; datas reais continuam visíveis, sem atribuir um intervalo antigo a sete dias. |
| 2-4 · problemas e relações | UI envia `problem.scope`; recuperação de leitura é restrita e hooks não transformam sucesso em falha. Datas inválidas/futuras são recusadas; hipótese de ajuste do relógio não demonstra corrupção nem autoriza aceitar dados futuros indiscriminadamente. |
| 3-2 · avisos, conferência e rascunho | Corrigidos avisos auxiliares e rascunho manual. Validador da observação já confere eco, conta, usuário, estado e frescor; cinco respostas inválidas foram recusadas sem mudar candidato/budget. |
| 3-3 · leitor contínuo | Conferência usa documento novo, somente leitura; ação exige guards do worker. Loading é limitado a 16 passos/20 s. `end` com zero continua parcial e é consultado novamente; não significa fonte esgotada para sempre. Não adotado reclique automático por hipótese. |
| 3-4 · listas e leitura de página | Corrigido título da lista errada. Creator vazio no caminho clássico não alterava o vínculo pelo permalink e é preenchível na revisão; não tratado como atribuição comprovadamente errada. Identidade não detectada continua impedindo leitura. |
| 4-1 · disponibilidade | Título semântico e fallback “sua conta” corrigidos. `canCompareLosses` implica seguidores completos e, portanto, `canCheckAbsence`; a contradição sugerida não ocorre no core. |
| 4-2 · preferências e menu | Corrigidos desligamento de 24h sem capability e semântica/Escape do menu. Teto/intervalo zero são recusados pelo domínio; não houve intervalo zero executável. Não foi adotado clamp silencioso dos campos. |
| 4-3 · modais e fontes | ESC agora respeita salvamento; desligar fonte independe da sessão, conservando capability. Rejeitada ampliação automática de `activeIds`: o conjunto revisado é exato, conforme ORB-052. Texto informa que nova ativação substitui a anterior. |
| 5-1 · contas | Escrita de snapshots ordena por instante e histórico do gráfico exclui contadores ausentes. Troca de conta pausa execução; handlers revalidam dono após awaits. Não foi demonstrada gravação na conta errada. |
| 5-2 · origens na UI | `setFollowerOrigins` retorna clone para validar preview, sem escrita; seletor usa medição resolvida válida; nomes são normalizados no core. Os três riscos condicionais não se confirmaram no fluxo completo. |
| 5-3 · central | Envio duplicado e descarte indevido do relato corrigidos. Boundary usa estado inicial puro e diagnóstico tolerante a armazenamento. Fonte desconhecida foi reproduzida e corrigida na carga do cadastro; não escondida com ícone genérico. |
| 5-4 · ciclo | Uma linha por candidato, dedupe no comando, nomes canonical e prazo/política validados em par. Hipóteses de ciclos duplicados ou configuração parcial não confirmadas. |
| 5-5 · relações | Protegidos voltam às listas descritivas e Mútuos sem medição recebe início guiado. Importação já deduplica conteúdo no core; não foi atribuído histórico duplicado sem reprodução. |
| 5-6 · ritmo | Resumo agora mostra valores escolhidos; grupo recebe nome acessível. Avisos independentes continuam registráveis, preservando ORB-005. |
| 6-1 · apresentação e versões | Versão do bundle centralizada, com data das fontes separada no comparativo. URL de foto vazia vira undefined no validador. Autofoco em campo oculto não foi reproduzido nos modais existentes; nomes acessíveis foram corrigidos pelo componente genérico. |
| 6-2 · publicações | Corrigidas métricas ocultas exclusivas de Story. Revisões iguais são deduplicadas por conteúdo, não por timestamp. Hipóteses para janela all são suprimidas no core, sem texto “all horas” no caminho elegível. |
| 6-3 · melhoria | Partição de prioridades/forças garante o sinal correspondente. HTTPS é exigido pelo core. Teto artificial de 100% foi rejeitado. Não foi criada confirmação adicional por um clique intencional de remover referência, sem requisito novo. |
| 6-4 · Insights | Busca corrigida. Workspace remonta por `key=account.id` e importação reconfere o dono no domínio, impedindo importação cruzada. Alertas apresentam motivo quando a comparação está indisponível. |
| 6-5 · Radar na UI | Arquivo de outra conta é recusado, não deve receber `account` sobrescrito para parecer válido. Preenchimento da leitura é revisado antes de salvar e não grava sozinho. Incluído estado vazio de pesquisa para setor fora do catálogo. |
| 6-6 · métricas oficiais | Troca de workspace remonta o componente. BFF retorna 409 sem relatórios na desambiguação; id incompatível é recusado. `performanceReview` só retorna ready com baseline válido. Não houve importação cruzada ou crash reproduzido. |
| 7-1 · tema e contas | Foco dos campos reforçado com roxo do tema. Números e badges avaliados no CSS final, não somente nas cores antigas sobrescritas. Não se mudou tamanho de cartão por uma hipótese de estouro; QA inclui larguras intermediárias. |
| 7-2 · Insights e crescimento | Maioria das cores citadas era substituída por color-theme; mantida paleta. Eyebrow das hipóteses foi medido e corrigido. Upload recebeu foco visível. Abas compartilhadas com rolagem interna são intencionais e não causaram overflow de documento. |
| 7-3 · folhas de página | Tabelas já estão em contêiner de rolagem, sem overflow da página nas fixtures. Status também tem texto. Não alterado wizard sem reprodução de palavra quebrando layout. |
| 7-4 · estilos gerais | Foco dos uploads corrigido. Toast longo não reproduziu corte em 768 px, portanto regra não foi alterada. A QA encontrou, de fato, topbar com documento806 em viewport768; wrap entre701–1000 corrigiu para768, mantendo seletor/botão completos. |

### Segunda conferência das correções

Três novas consultas receberam somente os diffs, divididos em aproximadamente 28 mil caracteres, contra ZIP 0.19.2 com SHA verificado. As três respostas foram lidas.

- Coautoria com dois perfis no cabeçalho revelou regressão real: corrigida com vínculo positivo a shortcode, permalink datado e dono explícito coerente; artigos ambíguos e recomendações continuam recusados. Duas regressões novas e 530 testes integrados passaram.
- Comparativo agora distingue “fontes consultadas” da versão do painel gerador. A data das fontes não foi renovada sem pesquisa.
- Posse histórica do backup não autoriza ação: candidatos de fila viram uncertain, provas são demovidas, execução fica pausada e os handlers exigem conta viva/observação/revisão. A chave de `dailyAttempts` e a chave de `lastAttempts` pertencem a mapas diferentes e têm formatos distintos intencionais.
- Timeout do probe de rascunho pausa antes de reservar tentativa; não é motivo para presumir aba vazia. Evento de estado válido do watcher é leitura autenticada no painel web ou evento privado no nativo; comandos continuam revalidando autorização no worker.

## Limites que continuam explícitos

- O teste adicional de integração MV3 em um Chromium novo não foi executado: o único binário de teste instalado falhou antes de abrir páginas, `spawn UNKNOWN`, errno -4094. Não houve instalação, alteração de política ou uso da sessão real para contornar isso. Evidência em `output/playwright/native-mv3-20261104/result.json`.
- A QA visual usa Chrome em perfil temporário e relay fictício; não equivale ao teste nativo acima nem à sessão real do Instagram.
- A instalação real ainda precisa carregar a versão nativa nova. Não anunciar os patches do executor como ativos antes de conferir a versão carregada.
- Sincronização completa da Meta, atribuição causal individual, completude das listas e estabilidade prolongada continuam limitadas pelo que a ferramenta realmente mede. Não foi demonstrado risco baixo de bloqueio por uma faixa numérica.

## Revisão visual

O último ajuste de especificidade do título de disponibilidade foi separado na 0.20.1. O candidato local 0.20.0 já gerado foi preservado, sem publicação ou instalação. A alteração final é de CSS/versão; o smoke dirigido confere os três painéis de disponibilidade em duas larguras e os hashes dos assets finais. Continua sendo uma única atualização entregue ao usuário.

Conferência final com assets cujos hashes coincidem com a build: **655/655 verificações de interface/fluxo** em sete grupos. Cobertura de 15 telas, abas de Insights/relações/Radar, 18 famílias de modal, estados preenchidos/vazios, imagens válidas/ausentes/expiradas e duas contas fictícias. Larguras de 390, 768, 1024 e 1440 px; cabeçalho também amostrado nas faixas intermediárias.

Foram conferidos teclado, Escape durante salvamento, foco visível nos três uploads, seleção de conta, rascunhos, Stories→Reel, perfis protegidos e distinção de zero/ausente. O bundle hospedado real foi montado com autenticação fictícia e bloqueado ao expirar a sessão, preservando os dados e encerrando o React. Métricas oficiais usaram API 100% simulada: consulta sozinha não importa e a importação explícita ocorreu uma única vez.

Não houve exceção de JavaScript nem requisição externa inesperada nessas suítes. O cenário proposital de sessão expirada produziu um HTTP401 esperado no console; os demais cenários ficaram sem registros de console. Nenhuma ação real no Instagram foi executada. Isso não declara conformidade completa WCAG nem valida uma sessão nativa real.

Evidências locais: `output/playwright/system-audit/qa-summary.json`, os cinco `*-summary.json` em `output/playwright/system-audit` e screenshots antes/depois. A revisão do aplicativo real publicado fica separada no relatório de entrega, para não misturar fixtures e produção.

Fechamento visual: 649 verificações da base funcional 0.20.0 + 6 verificações dirigidas finais 0.20.1, com 172 capturas. Smoke final validou título 14px/700 e ausência de overflow em três telas/duas larguras. Hashes conferidos contra os três assets compilados; fonte congelado somente após QA_READY.
