import { normalizeUsername, sourceUrl } from "../core/domain.ts";
import type { Campaign, CandidateInput } from "../core/types.ts";
import { collectLoaded, detectAccount, pageRestriction, usernameFromHref } from "./dom.ts";

export interface ContinuousStepRequest { campaign: Campaign; expectedAccount: string; runId: string }
export type ContinuousStepResult = { ok: true; data: { account: string; sourceId: string; runId: string; url: string; candidates: CandidateInput[]; phase: "loading" | "ready" | "end"; at: string; complete: false } } | { ok: false; error: string; unavailable?: true; platformWarning?: true; accountMismatch?: true };
type PendingControl = { node: HTMLElement; signature: string };
const documents = new WeakMap<Document, { key: string; pending?: PendingControl }>();
const unavailable = /^(?:desculpe,?\s*)?(?:esta p[áa]gina n[ãa]o est[áa] dispon[íi]vel|esta conta [ée] privada|conte[uú]do indispon[íi]vel|publicaç[ãa]o indispon[íi]vel|esta publicaç[ãa]o n[ãa]o est[áa] dispon[íi]vel|p[áa]gina n[ãa]o encontrada)[.!]?$|^(?:sorry,?\s*)?(?:this page (?:isn['’]t|is not) available|this account is private|content unavailable|post unavailable|page not found)[.!]?$/i;
const socialIcon = /^(curtir|descurtir|like|unlike|comentar|comment|repostar|repost|compartilhar|share|enviar mensagem|send message)$/i;
const text = (node: Element) => {
  const copy = node.cloneNode(true) as Element;
  copy.querySelectorAll('svg,title,script,style,[hidden],[aria-hidden="true"]').forEach((child) => child.remove());
  return (copy.textContent || "").replace(/\s+/g, " ").trim();
};
const enabled = (node: HTMLElement) => !node.hasAttribute("disabled") && node.getAttribute("aria-disabled") !== "true" && !node.closest('[hidden],[aria-hidden="true"]');
const icons = (node: Element, label: RegExp) => [node, ...node.querySelectorAll("[aria-label]")].filter((child) => label.test((child.getAttribute("aria-label") || "").trim()));
const controls = (scope: Element) => [...scope.querySelectorAll<HTMLElement>('a[href],button,[role="button"]')].filter(enabled);
export function hasPageDraft(doc: Document): boolean {
  return [...doc.querySelectorAll<HTMLInputElement | HTMLTextAreaElement | HTMLElement>('textarea,input,[contenteditable]')].some((node) => {
    if (node.closest('[hidden],[aria-hidden="true"]')) return false;
    if (node.tagName === "INPUT" && /^(hidden|button|submit|reset|checkbox|radio|file|image|range|color)$/i.test((node as HTMLInputElement).type)) return false;
    if (node.hasAttribute("contenteditable") && node.getAttribute("contenteditable") === "false") return false;
    return !!((node.tagName === "INPUT" || node.tagName === "TEXTAREA") ? (node as HTMLInputElement).value.trim() : node.textContent?.trim());
  });
}
function urlOf(value: string, base = "https://www.instagram.com") { const url = new URL(value, base); if (url.origin !== "https://www.instagram.com" || url.username || url.password) throw new Error("A fonte aberta não corresponde ao Instagram esperado."); return url; }
function postLink(value: string) {
  try { const url = urlOf(value); const match = url.pathname.match(/^\/(?:(?<owner>[a-z0-9._]{1,30})\/)?(?<kind>p|reel)\/(?<code>[\w-]+)\/(?:liked_by\/)?$/i); return match?.groups; } catch { return; }
}
function typedDialog(doc: Document, kind: Campaign["kind"]): HTMLElement | undefined {
  const title = kind === "followers" ? /^(seguidores|followers)$/i : kind === "following" ? /^(seguindo|seguidos|following)$/i : /^(curtidas|likes)$/i;
  const dialogs = [...doc.querySelectorAll<HTMLElement>('[role="dialog"]')].filter(enabled);
  const matches = dialogs.filter((dialog) => [...dialog.querySelectorAll('h1,h2,h3,[role="heading"]')].some((heading) => heading.closest('[role="dialog"]') === dialog && title.test(text(heading))));
  if (matches.length > 1 || (matches.length === 1 && dialogs.some((dialog) => dialog !== matches[0] && !dialog.contains(matches[0])))) throw new Error("Há mais de um diálogo ou lista na tela. Confira a fonte antes de continuar.");
  if (matches.length === 1) return matches[0];
  if (dialogs.length) throw new Error("O diálogo aberto não é a lista solicitada. Feche-o e confira a fonte.");
}
function isolatedDocument(doc: Document, scope: Element): Document {
  const isolated = doc.implementation.createHTMLDocument("");
  const main = isolated.createElement("main");
  main.append(scope.cloneNode(true));
  main.querySelectorAll("nav,aside").forEach((node) => node.remove());
  isolated.body.append(main);
  return isolated;
}
function postScope(doc: Document, canonical: string, expectedProfile?: string) {
  const source = postLink(canonical)!;
  const anchors = [...doc.querySelectorAll<HTMLAnchorElement>('main a[href],[role="main"] a[href],article a[href],[role="dialog"] a[href]')];
  const dates = anchors.filter((anchor) => { const link = postLink(anchor.getAttribute("href") || ""); return link?.code === source.code && link.kind === source.kind && [...anchor.querySelectorAll("time[datetime]")].some((time) => Number.isFinite(Date.parse(time.getAttribute("datetime") || ""))); });
  if (dates.length !== 1) throw new Error("A publicação não foi reconhecida por um único link de data da fonte.");
  const date = dates[0], article = date.closest("article");
  const names = article ? [...article.querySelectorAll<HTMLAnchorElement>("header a[href]")].map((anchor) => usernameFromHref(anchor.getAttribute("href") || "")).filter(Boolean) : [];
  const owner = postLink(date.getAttribute("href") || "")?.owner?.toLowerCase() || (new Set(names).size === 1 ? names[0] : undefined);
  if (!owner || (expectedProfile && owner !== expectedProfile)) throw new Error("O autor da publicação não corresponde ao perfil da fonte.");
  for (let scope = date.parentElement; scope; scope = scope.parentElement) {
    if (scope.matches("body,html")) break;
    const datedSources = new Set([...scope.querySelectorAll<HTMLAnchorElement>("a[href]")].filter((anchor) => anchor.querySelector("time[datetime]")).flatMap((anchor) => { const link = postLink(anchor.getAttribute("href") || ""); return link ? [`${link.kind}/${link.code}`] : []; }));
    if (datedSources.size > 1) break;
    const hasOwner = [...scope.querySelectorAll<HTMLAnchorElement>("a[href]")].some((anchor) => usernameFromHref(anchor.getAttribute("href") || "") === owner);
    if (hasOwner && icons(scope, /^(curtir|descurtir|like|unlike)$/i).length && icons(scope, /^(comentar|comment)$/i).length) return { scope, owner, code: source.code };
  }
  throw new Error("O conteúdo e os controles da publicação não foram reconhecidos de forma única.");
}
function profileOpener(header: Element, profile: string, kind: "followers" | "following"): HTMLElement {
  const suffix = kind === "followers" ? "(?:seguidores|followers)" : "(?:seguindo|seguidos|following)";
  const counted = new RegExp(`^\\d[\\d.,\\s]*(?:mil|mi|[km])?\\s+${suffix}$`, "i");
  const candidates = controls(header).filter((control) => {
    const raw = control.getAttribute("href");
    if (raw && raw !== "#") { try { return (counted.test(text(control)) || new RegExp(`^${suffix}$`, "i").test(text(control))) && urlOf(raw).pathname.replace(/\/$/, "") === `/${profile}/${kind}`; } catch { return false; } }
    if (!counted.test(text(control))) return false;
    // The current profile layout uses href="#" in a compact three-counter group.
    for (let group = control.parentElement; group && group !== header; group = group.parentElement) {
      if (group.children.length !== 3) continue;
      const labels = [...group.children].map(text);
      if (labels.some((label) => /\s(?:posts|publicaç[õo]es)$/i.test(label)) && labels.some((label) => /\s(?:seguidores|followers)$/i.test(label)) && labels.some((label) => /\s(?:seguindo|seguidos|following)$/i.test(label))) return true;
    }
    return false;
  });
  if (candidates.length !== 1) throw new Error("O controle da lista do perfil não foi reconhecido de forma única.");
  return candidates[0];
}
function likesOpener(scope: Element): HTMLElement {
  const candidates = controls(scope).filter((control) => {
    if (control.closest("li")) return false;
    for (let row = control.parentElement; row && row !== scope; row = row.parentElement) if ([...row.querySelectorAll("a[href]")].some((anchor) => /\/(?:p|reel)\/[\w-]+\/c\/\d+\/?$/.test(anchor.getAttribute("href") || ""))) return false;
    if (!/^(?:\d[\d.,\s]*(?:mil|mi|[km])?)(?:\s+(?:curtidas|likes))?$/i.test(text(control)) || icons(control, socialIcon).length) return false;
    for (let branch: Element | null = control; branch && branch !== scope; branch = branch.parentElement) {
      const previous = branch.previousElementSibling;
      if (!previous) continue;
      const actions = icons(previous, socialIcon);
      if (actions.length === 1 && /^(curtir|descurtir|like|unlike)$/i.test(actions[0].getAttribute("aria-label") || "")) return true;
      if (actions.length) return false;
    }
    return false;
  });
  if (candidates.length !== 1) throw new Error("O controle que abre a lista Curtidas não foi reconhecido de forma única.");
  return candidates[0];
}
function commentExpander(scope: Element): HTMLElement | undefined {
  const label = /^(?:(?:carregar|ver|mostrar) (?:mais|todos os(?: \d+)?) coment[áa]rios|(?:load|view|show) (?:more|all(?: \d+)?) comments)$/i;
  const candidates = controls(scope).filter((control) => !icons(control, socialIcon).length && label.test(text(control) || control.getAttribute("aria-label") || ""));
  const leaves = candidates.filter((candidate) => !candidates.some((other) => other !== candidate && candidate.contains(other)));
  if (leaves.length > 1) throw new Error("Há mais de um controle para expandir comentários. Confira a publicação antes de continuar.");
  return leaves[0];
}
function scrollContainer(doc: Document, scope: Element, anchors: Element[]): HTMLElement | undefined {
  const candidates = new Set<HTMLElement>();
  for (const anchor of anchors) for (let node = anchor.parentElement; node && scope.contains(node); node = node.parentElement) {
    const overflow = doc.defaultView?.getComputedStyle(node).overflowY || node.style.overflowY;
    if (/^(auto|scroll)$/.test(overflow) && node.clientHeight > 0 && node.scrollHeight > node.clientHeight + 1) candidates.add(node);
    if (node === scope) break;
  }
  const common = [...candidates].filter((node) => anchors.every((anchor) => node.contains(anchor)));
  const deepest = common.filter((node) => !common.some((other) => other !== node && node.contains(other)));
  if (deepest.length > 1 || (candidates.size && !deepest.length)) throw new Error("O contêiner da lista é ambíguo. Nenhuma rolagem foi enviada.");
  return deepest[0];
}

/** One synchronous, read-only/socially non-mutating DOM step. No imports or network APIs. */
export function stepContinuousSource(doc: Document, initialUrl: string, request: ContinuousStepRequest): ContinuousStepResult {
  try {
    const { campaign, expectedAccount, runId } = request;
    if (!campaign || campaign.archived || !["followers", "following", "commenters", "likers"].includes(campaign.kind) || !campaign.id || typeof runId !== "string" || !runId || normalizeUsername(expectedAccount) !== expectedAccount) throw new Error("A configuração da etapa de coleta está inválida.");
    const canonical = sourceUrl(campaign.kind, campaign.target), target = urlOf(canonical);
    const profile = ["followers", "following"].includes(campaign.kind) ? target.pathname.split("/")[1] : undefined;
    const check = () => {
      const current = urlOf(doc.defaultView?.location.href || initialUrl);
      const restricted = pageRestriction(doc, current.pathname);
      if (restricted) throw Object.assign(new Error(restricted), { platformWarning: true });
      if (detectAccount(doc) !== expectedAccount) throw Object.assign(new Error("A conta da sessão mudou. A etapa foi interrompida sem trocar de conta."), { accountMismatch: true });
      if ([...doc.querySelectorAll('main h1,main h2,main span,main p,[role="main"] h1,[role="alert"]')].some((node) => unavailable.test(text(node)))) throw Object.assign(new Error("A fonte não está disponível para esta sessão. Confira diretamente no Instagram."), { unavailable: true });
      if (hasPageDraft(doc)) throw new Error("Há um rascunho nesta aba. A coleta foi interrompida; confira o Instagram antes de continuar.");
      if (profile) {
        const path = current.pathname.replace(/\/$/, "");
        if (path !== `/${profile}` && path !== `/${profile}/${campaign.kind}`) throw new Error("O perfil ou a lista aberta não corresponde à fonte.");
        const header = doc.querySelector("main header,article header");
        if (!header || [...header.querySelectorAll("h1,h2")].filter((heading) => text(heading).toLowerCase() === profile).length !== 1) throw new Error("O cabeçalho não confirma o perfil da fonte.");
      } else {
        const actual = postLink(current.href), expected = postLink(canonical);
        if (!actual || actual.code !== expected?.code || actual.kind !== expected.kind || (campaign.group?.profile && actual.owner && actual.owner.toLowerCase() !== campaign.group.profile)) throw new Error("A publicação aberta não corresponde à fonte.");
      }
    };
    check();
    const key = `${runId}:${campaign.id}`;
    if (documents.get(doc)?.key !== key) documents.set(doc, { key });
    const state = documents.get(doc)!;
    const result = (candidates: CandidateInput[], phase: "loading" | "ready" | "end"): ContinuousStepResult => { check(); return { ok: true, data: { account: expectedAccount, sourceId: campaign.id, runId, url: canonical, candidates, phase, at: new Date().toISOString(), complete: false } }; };
    const click = (control: HTMLElement, candidates: CandidateInput[], scope: Element): ContinuousStepResult => {
      const signature = `${text(control)}:${scope.querySelectorAll("a[href]").length}`;
      if (state.pending?.node === control && state.pending.signature === signature) return result(candidates, "loading");
      check();
      if (!enabled(control) || !scope.contains(control) || icons(control, socialIcon).length) throw new Error("O controle de navegação mudou. Nenhum clique social foi enviado.");
      state.pending = { node: control, signature };
      control.click();
      return result(candidates, candidates.length ? "ready" : "loading");
    };
    let scope: Element, owner = campaign.group?.profile, code: string | undefined;
    if (profile) {
      const dialog = typedDialog(doc, campaign.kind);
      if (!dialog) { const header = doc.querySelector("main header,article header")!; return click(profileOpener(header, profile, campaign.kind as "followers" | "following"), [], header); }
      scope = dialog; owner = profile;
    } else {
      const post = postScope(doc, canonical, owner); owner = post.owner; code = post.code;
      const actual = postLink((doc.defaultView?.location.href || initialUrl));
      if (actual?.owner && actual.owner.toLowerCase() !== owner) throw new Error("O autor da publicação aberta não corresponde ao conteúdo confirmado.");
      if (campaign.kind === "likers") { const dialog = typedDialog(doc, campaign.kind); if (!dialog) return click(likesOpener(post.scope), [], post.scope); scope = dialog; }
      else scope = post.scope;
    }
    check();
    let candidates: CandidateInput[] = [];
    const expander = campaign.kind === "commenters" ? commentExpander(scope) : undefined;
    try { candidates = collectLoaded(isolatedDocument(doc, scope), campaign.kind, campaign.target, expectedAccount, campaign.kind === "likers" ? undefined : profile || owner).candidates.filter((candidate) => candidate.username !== owner); }
    catch (error) {
      if (campaign.kind !== "commenters") throw error;
      if (!expander) {
        if (scope.querySelector('[role="progressbar"]')) return result([], "loading");
        if ([...scope.querySelectorAll("span,p,h1,h2,h3")].some((node) => /^(?:seja o primeiro a comentar|nenhum coment[áa]rio ainda|ainda n[ãa]o h[áa] coment[áa]rios|be the first to comment|no comments yet)[.!]?$/i.test(text(node)))) return result([], "end");
        if (error instanceof Error && error.message === "Nenhuma linha de comentário reconhecida. Abra os comentários da publicação e tente novamente.") return result([], "loading");
        throw error;
      }
    }
    if (expander) return click(expander, candidates, scope);
    // A title without rows or a spinner can be a newly hydrated dialog. Only
    // explicit empty-state evidence above establishes zero; the worker bounds loading.
    if (!candidates.length) return result([], "loading");
    const names = new Set(candidates.map((candidate) => candidate.username));
    const anchors = [...scope.querySelectorAll<HTMLAnchorElement>("a[href]")].filter((anchor) => { if (campaign.kind !== "commenters") return names.has(usernameFromHref(anchor.getAttribute("href") || "") || ""); try { return new RegExp(`^/(?:p|reel)/${code}/c/\\d+/?$`).test(urlOf(anchor.getAttribute("href") || "").pathname); } catch { return false; } });
    const scroller = scrollContainer(doc, scope, anchors);
    if (!scroller) return result(candidates, scope.querySelector('[role="progressbar"]') ? "loading" : "end");
    const maximum = Math.max(0, scroller.scrollHeight - scroller.clientHeight), next = Math.min(maximum, scroller.scrollTop + Math.max(200, Math.round(scroller.clientHeight * 0.8)));
    if (next <= scroller.scrollTop + 1) return result(candidates, scope.querySelector('[role="progressbar"]') ? "loading" : "end");
    check(); scroller.scrollTop = next;
    return result(candidates, "ready");
  } catch (error) {
    const flags = error as { unavailable?: boolean; platformWarning?: boolean; accountMismatch?: boolean };
    return { ok: false, error: error instanceof Error ? error.message : "Não foi possível conferir a etapa de coleta.", ...(flags?.unavailable ? { unavailable: true as const } : {}), ...(flags?.platformWarning ? { platformWarning: true as const } : {}), ...(flags?.accountMismatch ? { accountMismatch: true as const } : {}) };
  }
}
