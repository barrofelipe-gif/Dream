import { normalizeUsername, uid } from "./domain.ts";
import type {
  AccountWorkspace,
  MarketBook,
  MarketExperiment,
  MarketModel,
  MarketPattern,
  MarketProfile,
  MarketReference,
} from "./types.ts";

export const MARKET_MODELS = {
  wholesale: "Atacado · lojistas",
  retail: "Varejo · consumidor",
  both: "Atacado e varejo",
  unknown: "Modelo não informado",
} as const;
export const MARKET_PATTERNS = {
  demo: "Demonstração e caimento",
  mix: "Mix de peças e combinações",
  backstage: "Bastidores e produção",
  faq: "Dúvidas e como comprar",
  proof: "Depoimento e prova social",
  launch: "Lançamento e reposição",
  other: "Outro padrão",
} as const;
export const sectorLabel = (key: string) =>
  key === "fitness"
    ? "Moda fitness"
    : key === "beachwear"
      ? "Biquínis e moda praia"
      : key;
const plain = (s: string) =>
  s
    .normalize("NFD")
    .replace(/[\u0300-\u036f]/g, "")
    .toLowerCase();
function fail(s: string): never {
  throw new Error(s);
}
const obj = (v: unknown): Record<string, unknown> =>
  v && typeof v === "object" && !Array.isArray(v)
    ? (v as Record<string, unknown>)
    : fail("Use um objeto válido para o radar do setor.");
const str = (v: unknown, max: number, required = false): string => {
  if (v === undefined && !required) return "";
  if (typeof v !== "string" || v.length > max || (required && !v.trim()))
    fail(
      `Informe texto ${required ? "não vazio " : ""}de até ${max} caracteres.`,
    );
  return v.trim();
};
function choice<T extends string>(v: unknown, choices: readonly T[]): T {
  return choices.includes(v as T)
    ? (v as T)
    : fail("Opção inválida no radar do setor.");
}
function stamp(v: unknown) {
  if (
    typeof v !== "string" ||
    !/^\d{4}-\d{2}-\d{2}T\d{2}:\d{2}(?::\d{2}(?:\.\d{1,3})?)?(?:Z|[+-]\d{2}:\d{2})$/.test(
      v,
    ) ||
    !Number.isFinite(Date.parse(v)) ||
    Number(v.slice(11, 13)) > 23 ||
    Number(v.slice(14, 16)) > 59 ||
    new Date(v.slice(0, 10)).toISOString().slice(0, 10) !== v.slice(0, 10) ||
    Date.parse(v) > Date.now() + 60000 ||
    Date.parse(v) < Date.parse("2020-01-01")
  )
    fail("Use uma data real, sem datas futuras, para a observação.");
  return new Date(v).toISOString();
}
const sector = (v: unknown) => {
  const text = str(v, 80, true),
    key = plain(text);
  return ["fitness", "moda fitness"].includes(key)
    ? "fitness"
    : [
          "beachwear",
          "biquini",
          "biquinis",
          "moda praia",
          "biquinis e moda praia",
        ].includes(key)
      ? "beachwear"
      : text;
};
export function marketUrl(input: string, instagramOnly = false) {
  let u: URL;
  try {
    u = new URL(input);
  } catch {
    fail("Informe um link completo, começando por https://.");
  }
  if (
    u.protocol !== "https:" ||
    u.username ||
    u.password ||
    u.port ||
    !u.hostname.includes(".") ||
    /[\[\]:]/.test(u.hostname) ||
    /^\d{1,3}(?:\.\d{1,3}){3}$/.test(u.hostname) ||
    /(^|\.)(localhost|local|internal)$/.test(u.hostname)
  )
    fail("Use um link público HTTPS, sem credenciais ou porta personalizada.");
  if (["instagram.com", "www.instagram.com"].includes(u.hostname)) {
    const prefixed = u.pathname.match(
      /^\/([a-z0-9._]{1,30})\/(p|reel|reels)\/([\w-]+)\/?$/i,
    );
    const path = prefixed && normalizeUsername(prefixed[1])
      ? `/${prefixed[2].toLowerCase() === "reels" ? "reel" : prefixed[2].toLowerCase()}/${prefixed[3]}/`
      : u.pathname.replace(/^\/reels\//, "/reel/");
    if (
      !/^\/(p|reel)\/[\w-]+\/?$/.test(path) &&
      !(/^\/[\w.]+\/?$/.test(path) && normalizeUsername(path.split("/")[1]))
    )
      fail("Use um perfil, post ou Reel do Instagram.");
    if (/^\/(accounts|explore|direct|stories|reels|p|reel)\/?$/.test(path))
      fail("Use o link de um perfil ou publicação específica.");
    const username = /^\/[\w.]+\/?$/.test(path)
      ? normalizeUsername(path.split("/")[1])
      : undefined;
    return username
      ? `https://www.instagram.com/${username}/`
      : "https://www.instagram.com" + path.replace(/\/+$/, "") + "/";
  }
  if (instagramOnly)
    fail("A leitura de página aceita apenas links do Instagram.");
  if (
    ["facebook.com", "www.facebook.com"].includes(u.hostname) &&
    u.pathname === "/ads/library/"
  ) {
    const id = u.searchParams.get("id");
    if (!id || !/^\d+$/.test(id))
      fail("Informe o link de um anúncio específico da Biblioteca da Meta.");
    return `https://www.facebook.com/ads/library/?id=${id}`;
  }
  // Generic pages may identify different content through ?v=, ?id=, etc.
  // Strip tracking only; dropping the whole query can overwrite another source.
  for (const key of [...u.searchParams.keys()])
    if (/^utm_/i.test(key) || /^(fbclid|gclid|dclid|msclkid|igshid)$/i.test(key))
      u.searchParams.delete(key);
  u.searchParams.sort();
  return u.origin + u.pathname + u.search;
}
export const emptyMarket = (account: string): MarketBook => ({
  version: 1,
  account,
  references: [],
  experiments: [],
});
function owned(v: Record<string, unknown>, account: string) {
  if (!account || v.account !== account)
    fail(`O radar deve pertencer a @${account || "conta selecionada"}.`);
}
export function marketProfile(input: unknown, preserve = false): MarketProfile {
  const r = obj(input);
  return {
    sector: sector(r.sector),
    model: choice(r.model, Object.keys(MARKET_MODELS) as MarketModel[]),
    audience: str(r.audience, 300),
    bio: str(r.bio, 2200),
    updatedAt: preserve ? stamp(r.updatedAt) : new Date().toISOString(),
  };
}
export function suggestMarket(text: string) {
  const t = plain(text),
    candidates: string[] = [];
  if (/\b(fitness|legging|leggings|moda fit|roupa de academia)\b/.test(t))
    candidates.push("fitness");
  if (/\b(biquini|biquinis|moda praia|beachwear|maio|maios)\b/.test(t))
    candidates.push("beachwear");
  const wholesale =
      /\b(atacado|lojista|lojistas|revenda|revendedor|revendedores)\b/.test(t),
    retail = /\b(varejo|consumidor final)\b/.test(t);
  return {
    candidates,
    model:
      wholesale && retail
        ? "both"
        : wholesale
          ? "wholesale"
          : retail
            ? "retail"
            : "unknown",
  } as { candidates: string[]; model: MarketModel };
}
export function inferPattern(text: string): MarketPattern | undefined {
  const t = plain(text);
  const tests: [MarketPattern, RegExp][] = [
    ["demo", /provador|caimento|demonstracao|testando|tecido/],
    ["mix", /combinac|mix de|monte seu|looks/],
    ["backstage", /bastidor|producao|fabrica|embalando/],
    ["faq", /duvida|como comprar|pedido minimo|perguntas/],
    ["proof", /depoimento|cliente conta|prova social/],
    ["launch", /lancamento|reposicao|nova colecao/],
  ];
  return tests.find(([, re]) => re.test(t))?.[0];
}
function reference(
  input: unknown,
  source: MarketReference["source"],
  preserve = false,
): MarketReference {
  const r = obj(input),
    metrics = obj(r.metrics || {}),
    counts: MarketReference["metrics"] = {};
  for (const key of ["views", "likes", "comments"] as const)
    if (
      metrics[key] !== undefined &&
      metrics[key] !== null &&
      metrics[key] !== ""
    ) {
      if (
        typeof metrics[key] !== "number" ||
        !Number.isSafeInteger(metrics[key]) ||
        (metrics[key] as number) < 0
      )
        fail(
          "Métricas públicas precisam ser inteiros exatos não negativos; deixe dados abreviados em branco.",
        );
      counts[key] = metrics[key] as number;
    }
  const observedAt = stamp(r.observedAt),
    publishedAt = r.publishedAt ? stamp(r.publishedAt) : undefined;
  if (publishedAt && publishedAt > observedAt)
    fail("A publicação não pode ser posterior à observação.");
  const windowHours = r.windowHours;
  if (
    windowHours !== undefined &&
    (!Number.isInteger(windowHours) ||
      (windowHours as number) < 1 ||
      (windowHours as number) > 8760 ||
      !publishedAt ||
      Math.abs(
        Date.parse(observedAt) -
          Date.parse(publishedAt) -
          (windowHours as number) * 3600000,
      ) > 1800000)
  )
    fail(
      "Para comparar janelas, informe publicação e leitura com diferença de até 30 minutos da janela declarada (1 a 8.760 h).",
    );
  const kind = choice(r.kind, [
      "post",
      "carousel",
      "reel",
      "story",
      "live",
      "ad",
      "article",
    ] as const),
    distribution = choice(r.distribution, [
      "organic",
      "paid",
      "unknown",
    ] as const);
  if (kind === "ad" && distribution !== "paid")
    fail("Referência de anúncio precisa ser identificada como paga.");
  return {
    id: preserve ? str(r.id, 100, true) : uid(),
    url: marketUrl(str(r.url, 1000, true)),
    creator: str(r.creator, 100),
    sector: sector(r.sector),
    model: choice(r.model, Object.keys(MARKET_MODELS) as MarketModel[]),
    kind,
    pattern: choice(r.pattern, Object.keys(MARKET_PATTERNS) as MarketPattern[]),
    title: str(r.title, 200, true),
    hook: str(r.hook, 400),
    cta: str(r.cta, 400),
    note: str(r.note, 1600),
    distribution,
    publishedAt,
    observedAt,
    windowHours: windowHours as number | undefined,
    metrics: counts,
    source: preserve
      ? choice(r.source, ["manual", "file", "instagram"] as const)
      : source,
    archived: preserve ? r.archived === true : false,
    updatedAt: preserve ? stamp(r.updatedAt) : new Date().toISOString(),
  };
}
function experiment(
  input: unknown,
  book: MarketBook,
  preserve = false,
): MarketExperiment {
  const r = obj(input),
    referenceId = str(r.referenceId, 100, true);
  if (!book.references.some((x) => x.id === referenceId))
    fail("A referência do teste deve pertencer a esta conta.");
  const hours = r.windowHours;
  if (
    !Number.isInteger(hours) ||
    (hours as number) < 1 ||
    (hours as number) > 8760
  )
    fail("Informe a janela do teste, de 1 a 8.760 horas.");
  const ownUrl = r.ownUrl ? marketUrl(str(r.ownUrl, 1000), true) : "";
  if (ownUrl && !/^https:\/\/www.instagram.com\/(p|reel)\//.test(ownUrl))
    fail("Vincule uma publicação própria, não o perfil inteiro.");
  return {
    id: preserve ? str(r.id, 100, true) : uid(),
    referenceId,
    title: str(r.title, 200, true),
    hypothesis: str(r.hypothesis, 800, true),
    recipe: str(r.recipe, 1800, true),
    cta: str(r.cta, 400),
    goal: choice(r.goal, ["views", "total_interactions", "follows"] as const),
    windowHours: hours as number,
    status: choice(r.status, ["idea", "testing", "measured"] as const),
    ownUrl,
    note: str(r.note, 1200),
    updatedAt: preserve ? stamp(r.updatedAt) : new Date().toISOString(),
  };
}
export function validateMarket(input: unknown, account: string): MarketBook {
  const r = obj(input);
  owned(r, account);
  if (
    r.version !== 1 ||
    !Array.isArray(r.references) ||
    r.references.length > 500 ||
    !Array.isArray(r.experiments) ||
    r.experiments.length > 200
  )
    fail("Radar inválido: limite de 500 referências e 200 testes por conta.");
  const book = emptyMarket(account);
  book.profile =
    r.profile === undefined ? undefined : marketProfile(r.profile, true);
  book.references = r.references.map((v) => reference(v, "manual", true));
  book.experiments = r.experiments.map((v) => experiment(v, book, true));
  for (const list of [book.references, book.experiments])
    if (new Set(list.map((x) => x.id)).size !== list.length)
      fail("Identificadores repetidos no radar.");
  if (
    new Set(book.references.map((x) => x.url)).size !== book.references.length
  )
    fail("Links repetidos no radar; atualize a referência existente.");
  return book;
}
export function saveMarketReferences(
  book: MarketBook | undefined,
  input: unknown,
  account: string,
): MarketBook {
  const r = obj(input);
  owned(r, account);
  if (book) owned(obj(book), account);
  if (
    !Array.isArray(r.references) ||
    !r.references.length ||
    r.references.length > 500
  )
    fail("Informe de 1 a 500 referências.");
  const source = r.mode === "file" ? "file" : "manual",
    incoming = r.references.map((v) => reference(v, source));
  if (new Set(incoming.map((x) => x.url)).size !== incoming.length)
    fail("O lote tem links repetidos.");
  const result = structuredClone(book || emptyMarket(account));
  for (const next of incoming) {
    const index = result.references.findIndex((x) => x.url === next.url);
    if (index < 0) result.references.push(next);
    else
      result.references[index] = {
        ...next,
        id: result.references[index].id,
        archived: result.references[index].archived,
      };
  }
  if (result.references.length > 500)
    fail("Limite de 500 referências atingido; exporte e revise seu radar.");
  return validateMarket(result, account);
}
export function saveMarketExperiment(
  book: MarketBook | undefined,
  input: unknown,
  account: string,
): MarketBook {
  const r = obj(input);
  owned(r, account);
  if (book) owned(obj(book), account);
  const result = structuredClone(book || emptyMarket(account)),
    raw = obj(r.experiment),
    next = experiment(raw, result),
    index = raw.id ? result.experiments.findIndex((x) => x.id === raw.id) : -1;
  if (raw.id && index < 0) fail("Teste não encontrado nesta conta.");
  if (index < 0) result.experiments.push(next);
  else
    result.experiments[index] = { ...next, id: result.experiments[index].id };
  if (result.experiments.length > 200) fail("Limite de 200 testes por conta.");
  return validateMarket(result, account);
}
export function mergeMarket(
  current: MarketBook | undefined,
  input: unknown,
  account: string,
): MarketBook {
  if (current) owned(obj(current), account);
  const saved = validateMarket(input, account),
    result = structuredClone(current || emptyMarket(account));
  if (
    saved.profile &&
    (!result.profile || saved.profile.updatedAt > result.profile.updatedAt)
  )
    result.profile = saved.profile;
  const idMap = new Map<string, string>();
  for (const ref of saved.references) {
    const old = result.references.find((x) => x.url === ref.url);
    idMap.set(ref.id, old?.id || ref.id);
    if (!old) result.references.push(ref);
    else if (ref.updatedAt > old.updatedAt)
      Object.assign(old, { ...ref, id: old.id });
  }
  for (const exp of saved.experiments) {
    const next = { ...exp, referenceId: idMap.get(exp.referenceId)! },
      old = result.experiments.find((x) => x.id === exp.id);
    if (!old) result.experiments.push(next);
    else if (exp.updatedAt > old.updatedAt) Object.assign(old, next);
  }
  return validateMarket(result, account);
}
const median = (values: number[]) => {
  const s = [...values].sort((a, b) => a - b);
  return s.length % 2
    ? s[(s.length - 1) / 2]
    : (s[s.length / 2 - 1] + s[s.length / 2]) / 2;
};
export function marketAnalysis(book: MarketBook, days = 30, now = Date.now()) {
  const profile = book.profile,
    cutoff = now - days * 86400000;
  const references = book.references.filter(
    (r) =>
      !r.archived &&
      (!profile ||
        (plain(r.sector) === plain(profile.sector) &&
          (profile.model === "both" ||
            profile.model === "unknown" ||
            profile.model === r.model ||
            r.model === "both" ||
            r.model === "unknown"))) &&
      Date.parse(r.observedAt) >= cutoff &&
      Date.parse(r.observedAt) <= now + 60000,
  );
  const highlights = references
    .flatMap((r) => {
      if (
        profile?.model === "unknown" ||
        r.kind !== "reel" ||
        !normalizeUsername(r.creator.replace(/^@/, "")) ||
        !/^https:\/\/www.instagram.com\/(reel|p)\//.test(r.url) ||
        r.metrics.views === undefined ||
        !r.windowHours ||
        !r.publishedAt ||
        r.distribution === "unknown" ||
        r.model === "unknown" ||
        Date.parse(r.publishedAt) < cutoff
      )
        return [];
      const baseline = references.filter(
        (b) =>
          b.id !== r.id &&
          /^https:\/\/www.instagram.com\/(reel|p)\//.test(b.url) &&
          normalizeUsername(b.creator.replace(/^@/, "")) ===
            normalizeUsername(r.creator.replace(/^@/, "")) &&
          b.kind === r.kind &&
          b.windowHours === r.windowHours &&
          b.distribution === r.distribution &&
          b.model === r.model &&
          plain(b.sector) === plain(r.sector) &&
          b.publishedAt &&
          Date.parse(b.publishedAt) >= cutoff &&
          b.metrics.views !== undefined,
      );
      if (baseline.length < 5) return [];
      const base = median(baseline.map((b) => b.metrics.views!));
      return base > 0 && r.metrics.views >= 2 * base
        ? [
            {
              reference: r,
              ratio: r.metrics.views / base,
              median: base,
              n: baseline.length,
            },
          ]
        : [];
    })
    .sort((a, b) => b.ratio - a.ratio);
  return { references, highlights };
}
export function ownPatternMatches(
  account: AccountWorkspace,
  reportId: string,
  pattern: MarketPattern,
) {
  const report = account.insights?.find(
    (r) => r.id === reportId && r.account === account.username,
  );
  return (
    report?.content.filter(
      (c) =>
        inferPattern([c.title, c.theme, c.hook].filter(Boolean).join(" ")) ===
        pattern,
    ) || []
  );
}
export function adaptation(profile: MarketProfile, ref: MarketReference) {
  const product =
    profile.sector === "fitness"
      ? "um conjunto fitness seu"
      : profile.sector === "beachwear"
        ? "um biquíni ou saída da sua coleção"
        : "um produto seu";
  const buyer =
    profile.model === "wholesale"
      ? "lojistas e revendedores"
      : profile.model === "retail"
        ? "quem vai usar a peça"
        : profile.audience || "seu público";
  const recipes: Record<MarketPattern, string> = {
    demo: `Mostre ${product} em movimento, detalhe o acabamento e responda uma dúvida real sobre caimento.`,
    mix: `Monte três combinações com ${product}; mostre cores e tamanhos que você realmente oferece.`,
    backstage: `Mostre a separação ou produção de ${product}, do detalhe ao pedido pronto.`,
    faq: `Responda uma dúvida de ${buyer}: como escolher ${product}, comprar ou consultar a grade.`,
    proof: `Com autorização, apresente uma experiência real de cliente com ${product}; não invente depoimentos.`,
    launch: `Apresente ${product}, uma novidade ou reposição real, mostrando os detalhes e a disponibilidade atual.`,
    other: `Use a estrutura observada para apresentar ${product} de um jeito próprio, pensando em ${buyer}.`,
  };
  return {
    title: `Testar: ${MARKET_PATTERNS[ref.pattern]}`,
    hypothesis: `Testar se ${MARKET_PATTERNS[ref.pattern].toLowerCase()} melhora a resposta de ${buyer} ao nosso conteúdo.`,
    recipe: `1. Abra com uma dúvida de ${buyer}.\n2. ${recipes[ref.pattern]}\n3. Use sua gravação, identidade e informações comerciais.\n4. Mude um fator por vez e compare com conteúdos próprios do mesmo formato e janela.`,
    cta:
      profile.model === "wholesale"
        ? "Peça a grade e as condições de atacado pelo canal da bio."
        : "Veja cores e tamanhos no link da bio.",
    goal: "total_interactions" as const,
    windowHours: 24,
    status: "idea" as const,
    ownUrl: "",
    note: "Sugestão de teste; o desempenho da referência não garante o nosso resultado.",
  };
}
export function experimentMeasurement(
  account: AccountWorkspace,
  exp: MarketExperiment,
) {
  if (!exp.ownUrl) return undefined;
  const reports = [...(account.insights || [])]
    .filter((r) => r.account === account.username)
    .sort((a, b) => b.recordedAt.localeCompare(a.recordedAt));
  for (const report of reports) {
    const content = report.content.find((c) => {
      try {
        return c.url && marketUrl(c.url) === exp.ownUrl;
      } catch {
        return false;
      }
    });
    if (content)
      return {
        report,
        content,
        comparable:
          report.contentWindow === "period" &&
          report.coverage !== "unknown" &&
          content.observationHours === exp.windowHours,
        value: content.metrics[exp.goal],
      };
  }
  return undefined;
}
