import { insightSummary, localDay, metricSpec } from "./insights.ts";
import type { InsightMetric } from "./insights.ts";
import type { InsightReport } from "./types.ts";

// Only metrics with a useful, declared direction enter performance alerts.
// Publication volume and raw Story navigation have no universal good direction.
const DIRECTIONS: Record<string, 1 | -1> = {
  engagement_rate: 1,
  total_interactions: 1,
  reach: 1,
  accounts_engaged: 1,
  follows: 1,
  profile_visits: 1,
  profile_links_taps: 1,
  saves: 1,
  shares: 1,
  comments: 1,
  replies: 1,
  likes: 1,
  views: 1,
  reposts: 1,
  link_clicks: 1,
  sticker_taps: 1,
  question_answers: 1,
  avg_watch_time_seconds: 1,
  unfollows: -1,
  reels_skip_rate: -1,
};
export function performanceTone(key: string, delta: number) {
  const direction = Object.hasOwn(DIRECTIONS, key)
    ? DIRECTIONS[key]
    : undefined;
  return !direction || delta === 0
    ? "neutral"
    : delta * direction < 0
      ? "negative"
      : "positive";
}
export interface PerformanceComparison {
  key: string;
  label: string;
  unit: InsightMetric["unit"];
  before: number;
  current: number;
  difference: number;
  relative?: number;
  tone: ReturnType<typeof performanceTone>;
}
export interface PerformanceReview {
  status: "waiting" | "ready";
  reason?: string;
  previous?: InsightReport;
  comparisons: PerformanceComparison[];
  alerts: PerformanceComparison[];
  missing: string[];
  observations: string[];
}
const label = (key: string) =>
  key === "engagement_rate"
    ? "Engajamento · interações / alcance"
    : metricSpec(key)?.label || key;
const value = (r: InsightReport, key: string) =>
  key === "engagement_rate" ? insightSummary(r, []).rate : r.metrics[key];
const difference = (a: number, b: number) => {
  const delta = a - b;
  return Math.abs(delta) <= Number.EPSILON * Math.max(1, a, b) * 8 ? 0 : delta;
};

export function performanceReview(
  report: InsightReport,
  all: InsightReport[],
  today = localDay(),
): PerformanceReview {
  const waiting = (reason: string): PerformanceReview => ({
    status: "waiting",
    reason,
    comparisons: [],
    alerts: [],
    missing: [],
    observations: [],
  });
  if (report.end >= today)
    return waiting(
      "Este período ainda inclui o dia atual. Aguarde o encerramento e registre os dados completos para evitar um alerta de queda por período incompleto.",
    );
  if (report.coverage === "unknown")
    return waiting(
      "Informe a cobertura: orgânico, pago ou ambos. Cobertura desconhecida não permite comparar o desempenho.",
    );
  if (report.contentWindow !== "period")
    return waiting(
      "Este relatório usa dados de vida inteira. Para alertas de desempenho, registre valores do período, sem comparar acumulados como se fossem resultados de dois intervalos.",
    );
  // Use the latest revision of the eligible baseline, independent of input order.
  const previous = insightSummary(
    report,
    [...all].sort(
      (a, b) =>
        Date.parse(a.recordedAt) - Date.parse(b.recordedAt) || a.id.localeCompare(b.id),
    ),
  ).previous;
  if (!previous)
    return waiting(
      "Falta o período imediatamente anterior, sem lacunas ou sobreposição, com a mesma duração, conta, cobertura e valores do período. Importe ou registre esse relatório para ativar os alertas.",
    );
  const comparisons: PerformanceComparison[] = [],
    missing: string[] = [];
  for (const key of Object.keys(DIRECTIONS)) {
    const before = value(previous, key),
      current = value(report, key);
    if (before === undefined || current === undefined) {
      missing.push(label(key));
      continue;
    }
    const delta = difference(current, before);
    comparisons.push({
      key,
      label: label(key),
      before,
      current,
      difference: delta,
      relative: before > 0 ? (delta / before) * 100 : undefined,
      unit: key === "engagement_rate" ? "percent" : metricSpec(key)!.unit,
      tone: performanceTone(key, delta),
    });
  }
  const observations: string[] = [];
  const find = (key: string) => comparisons.find((c) => c.key === key);
  const interactions = find("total_interactions"),
    reach = find("reach"),
    rate = find("engagement_rate");
  if (interactions?.tone === "negative") {
    if (reach && rate) {
      observations.push(
        reach.difference < 0 && rate.difference < 0
          ? "O alcance e a razão de interações por alcance caíram juntos. Investigue distribuição e resposta ao conteúdo em testes separados."
          : reach.difference < 0
            ? "O alcance caiu, enquanto a razão de interações por alcance ficou estável ou subiu. O menor volume de exposição acompanha a queda de interações."
            : "O alcance ficou estável ou subiu, mas a razão de interações por alcance caiu. Examine o conteúdo e as chamadas para interação.",
      );
    } else
      observations.push(
        "As interações caíram, mas faltam dados de alcance nos dois períodos para separar exposição de resposta ao conteúdo.",
      );
  }
  if (
    report.metrics.content_published !== undefined &&
    previous.metrics.content_published !== undefined
  ) {
    observations.push(
      report.metrics.content_published < previous.metrics.content_published
        ? `Também houve menos conteúdos publicados: ${previous.metrics.content_published} → ${report.metrics.content_published}. Confira se a frequência ou a mistura de formatos mudou; isso não demonstra efeito no resultado.`
        : `Conteúdos publicados: ${previous.metrics.content_published} → ${report.metrics.content_published}. Compare também os formatos e temas; quantidade não mede a qualidade.`,
    );
  }
  return {
    status: "ready",
    previous,
    comparisons,
    alerts: comparisons.filter((c) => c.tone === "negative"),
    missing,
    observations,
  };
}

export function recoveryTest(key: string): {
  investigate: string;
  test: string;
} {
  if (key === "reach" || key === "views")
    return {
      investigate:
        "Confira a frequência publicada e os formatos usados nos dois períodos. Se a cobertura for paga, confira também investimento e entrega no relatório de anúncios.",
      test: "Escolha um formato já medido em Aprendizados e teste apenas um horário diferente. Mantenha tema e frequência comparáveis e registre o próximo ciclo.",
    };
  if (
    key === "follows" ||
    key === "profile_visits" ||
    key === "profile_links_taps" ||
    key === "link_clicks"
  )
    return {
      investigate:
        "Confira quais conteúdos geraram visitas, seguidores ou cliques, quando houver dados por publicação. Separe os resultados de anúncios.",
      test: "Teste uma única chamada para visitar, seguir ou acessar o link em um formato comparável. Meça a mesma ação na mesma janela, sem tratar clique como venda.",
    };
  if (key === "unfollows")
    return {
      investigate:
        "Confira se houve mudança de tema, frequência ou origem do público. O total de perdas não identifica o motivo nem quem deixou de seguir.",
      test: "Escolha um tema que já tenha boa resposta em Aprendizados e mantenha a frequência por um novo ciclo. Observe perdas e novos seguidores separadamente.",
    };
  if (key === "reels_skip_rate" || key === "avg_watch_time_seconds")
    return {
      investigate:
        "Compare vídeos de duração e janela semelhantes; confira abertura, tema e ponto de abandono quando essa informação estiver disponível.",
      test: "Teste uma abertura mais direta, mantendo tema e duração comparáveis. Registre tempo médio e taxa de pulos na mesma janela.",
    };
  if (key === "saves" || key === "shares")
    return {
      investigate:
        "Procure os temas e formatos com mais salvamentos ou compartilhamentos por alcance em Aprendizados, usando a mesma janela.",
      test: "Repita um desses temas e altere apenas a chamada para salvar ou compartilhar. Compare a ação por alcance no próximo ciclo.",
    };
  if (["replies", "question_answers", "sticker_taps"].includes(key))
    return {
      investigate:
        "Confira foto ou vídeo, tipo de figurinha e posição dos Stories. Resposta à caixinha, resposta ao Story e toque em figurinha são medidas diferentes.",
      test: "Teste uma pergunta mais simples, mantendo formato e janela. Registre a mesma métrica nos dois ciclos, sem somar caixinhas e respostas diferentes.",
    };
  return {
    investigate:
      "Compare os conteúdos dos dois períodos por formato, tema e chamada para ação. Use a mesma janela e observe interações por alcance, além dos totais.",
    test: "Escolha um padrão bem observado em Aprendizados e mude apenas a chamada para interação. Registre o próximo ciclo com a mesma duração e cobertura para reavaliar.",
  };
}
