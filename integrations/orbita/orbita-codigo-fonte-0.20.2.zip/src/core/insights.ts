import { normalizeUsername, uid } from "./domain.ts";
import { csvRows } from "./io.ts";
import { profilePhotoUrl } from "./photos.ts";
import type {
  AccountWorkspace,
  ContentKind,
  InsightAudience,
  InsightContent,
  InsightReport,
} from "./types.ts";

export type MetricGroup =
  | "visibility"
  | "engagement"
  | "growth"
  | "profile"
  | "video"
  | "stories"
  | "live";
export interface InsightMetric {
  key: string;
  label: string;
  group: MetricGroup;
  unit: "count" | "seconds" | "percent";
  help: string;
}
const metric = (
  key: string,
  label: string,
  group: MetricGroup,
  help: string,
  unit: InsightMetric["unit"] = "count",
): InsightMetric => ({ key, label, group, unit, help });
export const INSIGHT_METRICS: InsightMetric[] = [
  metric(
    "views",
    "Visualizações",
    "visibility",
    "Exibições ou reproduções informadas no relatório; podem incluir repetições.",
  ),
  metric(
    "reach",
    "Contas alcançadas",
    "visibility",
    "Contas únicas no período. Não some o alcance de posts para estimar o alcance da conta.",
  ),
  metric(
    "accounts_engaged",
    "Contas com engajamento",
    "engagement",
    "Contas únicas que interagiram no período.",
  ),
  metric(
    "total_interactions",
    "Interações",
    "engagement",
    "Total informado na origem; não é recalculado somando campos de coberturas diferentes.",
  ),
  metric(
    "likes",
    "Curtidas",
    "engagement",
    "Curtidas recebidas no recorte informado.",
  ),
  metric(
    "comments",
    "Comentários",
    "engagement",
    "Comentários recebidos no recorte informado.",
  ),
  metric(
    "saves",
    "Salvamentos",
    "engagement",
    "Vezes que seu conteúdo foi salvo.",
  ),
  metric(
    "shares",
    "Compartilhamentos",
    "engagement",
    "Compartilhamentos informados pelos Insights.",
  ),
  metric(
    "replies",
    "Respostas",
    "engagement",
    "Respostas informadas na origem; disponibilidade depende do formato.",
  ),
  metric(
    "reposts",
    "Republicações",
    "engagement",
    "Republicações, quando informadas pela conta ou conteúdo.",
  ),
  metric(
    "follows",
    "Novos seguidores",
    "growth",
    "Seguidores recebidos, conforme os Insights. Não são ações de seguir feitas pela Órbita.",
  ),
  metric(
    "unfollows",
    "Deixaram de seguir",
    "growth",
    "Perdas informadas na origem; não são inferidas apenas pela variação do total.",
  ),
  metric(
    "profile_visits",
    "Visitas ao perfil",
    "profile",
    "Visitas informadas pela origem, quando disponíveis.",
  ),
  metric(
    "profile_links_taps",
    "Toques nos links do perfil",
    "profile",
    "Toques nos links do perfil no período informado.",
  ),
  metric(
    "profile_activity",
    "Atividade no perfil",
    "profile",
    "Atividade atribuída ao conteúdo conforme a definição da origem.",
  ),
  metric(
    "link_clicks",
    "Cliques em links",
    "profile",
    "Cliques informados para o conteúdo ou conta; não são vendas.",
  ),
  metric(
    "content_published",
    "Conteúdos publicados",
    "visibility",
    "Quantidade publicada no período, sem confundir com o total atual de publicações do perfil.",
  ),
  metric(
    "watch_time_seconds",
    "Tempo total assistido",
    "video",
    "Tempo em segundos, conforme a origem. Converta milissegundos para segundos antes de importar.",
    "seconds",
  ),
  metric(
    "avg_watch_time_seconds",
    "Tempo médio assistido",
    "video",
    "Média fornecida na origem. Não calculamos a média das médias de vários vídeos.",
    "seconds",
  ),
  metric(
    "reels_skip_rate",
    "Taxa de pulos dos Reels",
    "video",
    "Percentual informado na origem, de 0 a 100; não convertida a partir de métricas incompatíveis.",
    "percent",
  ),
  metric(
    "facebook_views",
    "Visualizações no Facebook",
    "video",
    "Exibições no Facebook informadas separadamente, quando disponíveis.",
  ),
  metric(
    "crossposted_views",
    "Visualizações em publicação cruzada",
    "video",
    "Recorte de publicação cruzada, conforme a origem. Pode sobrepor outras visualizações.",
  ),
  metric(
    "navigation",
    "Navegação nos Stories",
    "stories",
    "Total de ações de navegação informado na origem.",
  ),
  metric(
    "story_forward",
    "Avanços nos Stories",
    "stories",
    "Toques para avançar dentro dos seus Stories.",
  ),
  metric(
    "story_back",
    "Retornos nos Stories",
    "stories",
    "Toques para voltar aos seus Stories.",
  ),
  metric(
    "story_next",
    "Próximo perfil nos Stories",
    "stories",
    "Passagens para Stories de outro perfil, se informadas.",
  ),
  metric(
    "story_exits",
    "Saídas dos Stories",
    "stories",
    "Saídas informadas pelos Insights.",
  ),
  metric(
    "sticker_taps",
    "Toques em figurinhas",
    "stories",
    "Toques em figurinhas informados na origem.",
  ),
  metric(
    "question_answers",
    "Respostas à caixinha · registro manual",
    "stories",
    "Contagem observada na caixinha desta publicação. Campo local manual; não equivale a replies, toques em figurinha ou pessoas únicas e não representa uma métrica garantida da API.",
  ),
  metric(
    "live_peak_viewers",
    "Pico de espectadores ao vivo",
    "live",
    "Pico informado para a transmissão; não soma picos de várias Lives.",
  ),
  metric(
    "impressions",
    "Impressões · histórico",
    "visibility",
    "Campo legado para relatórios antigos. Não é tratado como sinônimo de visualizações nem como métrica atual garantida.",
  ),
];
export const INSIGHT_GROUPS: Record<MetricGroup, string> = {
  visibility: "Alcance e visualizações",
  engagement: "Interações",
  growth: "Seguidores",
  profile: "Atividade do perfil",
  video: "Reels e vídeo",
  stories: "Stories",
  live: "Lives",
};
export const CONTENT_LABELS: Record<ContentKind, string> = {
  post: "Post",
  carousel: "Carrossel",
  reel: "Reel",
  story: "Story",
  live: "Live",
};
export const STORY_MEDIA_LABELS = { photo: "Foto", video: "Vídeo" } as const;
export const STORY_STICKER_LABELS = {
  none: "Sem figurinha interativa",
  question_box: "Caixinha de perguntas",
  poll: "Enquete",
  quiz: "Quiz",
  slider: "Controle deslizante",
  link: "Link",
  other: "Outra figurinha",
} as const;
export const COVERAGE_LABELS: Record<InsightReport["coverage"], string> = {
  organic: "Orgânico",
  paid: "Pago",
  combined: "Orgânico + pago",
  unknown: "Cobertura não informada",
};
export const metricSpec = (key: string) =>
  INSIGHT_METRICS.find((m) => m.key === key);
function fail(message: string): never {
  throw new Error(message);
}
function contentUrl(value: string): string {
  let parsed: URL;
  try {
    parsed = new URL(value);
  } catch {
    fail(
      "Use links completos de conteúdo do Instagram, começando por https://.",
    );
  }
  if (
    parsed.protocol !== "https:" ||
    !["instagram.com", "www.instagram.com"].includes(parsed.hostname) ||
    !/^\/(p|reel|reels|stories)\//.test(parsed.pathname)
  )
    fail("Use links de conteúdo do Instagram.");
  return (
    "https://www.instagram.com" +
    parsed.pathname.replace(/^\/reels\//, "/reel/").replace(/\/+$/, "") +
    "/"
  );
}
const object = (value: unknown): Record<string, unknown> =>
  value && typeof value === "object" && !Array.isArray(value)
    ? (value as Record<string, unknown>)
    : fail("O relatório deve conter objetos válidos.");
function day(value: unknown): string {
  if (
    typeof value !== "string" ||
    !/^\d{4}-\d{2}-\d{2}$/.test(value) ||
    !Number.isFinite(Date.parse(value)) ||
    new Date(value).toISOString().slice(0, 10) !== value
  )
    fail("Use datas válidas no formato AAAA-MM-DD.");
  return value as string;
}
export function localDay(now = new Date()): string {
  return `${now.getFullYear()}-${String(now.getMonth() + 1).padStart(2, "0")}-${String(now.getDate()).padStart(2, "0")}`;
}
function values(value: unknown): Record<string, number> {
  const result: Record<string, number> = {};
  const entries = Object.entries(object(value)).sort(([a], [b]) =>
    a.localeCompare(b),
  );
  if (entries.length > 120)
    fail("O relatório comporta até 120 métricas por recorte.");
  for (const [key, count] of entries) {
    if (
      !/^[a-z][a-z0-9_]{0,69}$/.test(key) ||
      ["constructor", "prototype"].includes(key)
    )
      fail("Identificador de métrica inválido.");
    if (count === null || count === undefined || count === "") continue;
    const spec = metricSpec(key);
    if (
      typeof count !== "number" ||
      !Number.isFinite(count) ||
      count < 0 ||
      count > Number.MAX_SAFE_INTEGER ||
      ((!spec || spec.unit === "count") && !Number.isSafeInteger(count)) ||
      (spec?.unit === "percent" && count > 100)
    )
      fail(
        `Valor inválido para ${spec?.label || key}. Use números sem abreviações; percentuais vão de 0 a 100.`,
      );
    result[key] = count;
  }
  return result;
}
export function validateInsightReport(
  input: unknown,
  expectedAccount: string,
  source: InsightReport["source"],
  preserveMetadata = false,
): InsightReport {
  const raw = object(input);
  if (!["manual", "file"].includes(source))
    fail("Origem de Insights inválida.");
  if (
    preserveMetadata &&
    (typeof raw.id !== "string" ||
      !raw.id.trim() ||
      raw.id.length > 150 ||
      typeof raw.recordedAt !== "string" ||
      !Number.isFinite(Date.parse(raw.recordedAt)) ||
      Date.parse(raw.recordedAt) > Date.now() + 60000)
  )
    fail("Identificador ou data de registro dos Insights inválidos.");
  const coverage = raw.coverage === undefined ? "unknown" : raw.coverage;
  if (!Object.hasOwn(COVERAGE_LABELS, String(coverage)))
    fail("Cobertura inválida: use organic, paid, combined ou unknown.");
  const contentWindow =
    raw.contentWindow === undefined ? "period" : raw.contentWindow;
  if (!["period", "lifetime"].includes(String(contentWindow)))
    fail("Recorte de conteúdo inválido: use period ou lifetime.");
  const account =
    typeof raw.account === "string" ? normalizeUsername(raw.account) : null;
  if (!account || account !== expectedAccount)
    fail(
      `O relatório deve pertencer a @${expectedAccount}. Nenhum dado de outra conta será importado.`,
    );
  const start = day(raw.start),
    end = day(raw.end);
  if (start > end || end > localDay())
    fail("Confira o período: início até fim, sem datas futuras.");
  const span = (Date.parse(end) - Date.parse(start)) / 86400000 + 1;
  if (span > 366) fail("Cada relatório deve cobrir até 366 dias.");
  const metrics = values(raw.metrics || {});
  if (
    (raw.content !== undefined && !Array.isArray(raw.content)) ||
    (raw.audience !== undefined && !Array.isArray(raw.audience))
  )
    fail("Conteúdo e público devem ser listas.");
  if (
    ((raw.content as unknown[] | undefined)?.length || 0) > 500 ||
    ((raw.audience as unknown[] | undefined)?.length || 0) > 30
  )
    fail("O relatório excede 500 conteúdos ou 30 recortes de público.");
  const seen = new Set<string>();
  const seenUrls = new Set<string>();
  const content: InsightContent[] = ((raw.content || []) as unknown[]).map(
    (value) => {
      const item = object(value);
      if (
        typeof item.id !== "string" ||
        !item.id.trim() ||
        item.id.length > 150 ||
        seen.has(item.id) ||
        !Object.hasOwn(CONTENT_LABELS, String(item.kind))
      )
        fail("Conteúdo sem identificador único ou formato válido.");
      seen.add(item.id as string);
      let url: string | undefined;
      if (item.url) {
        if (typeof item.url !== "string") fail("Link de conteúdo inválido.");
        url = contentUrl(item.url as string);
        if (seenUrls.has(url))
          fail(
            "O mesmo link de publicação aparece mais de uma vez no relatório.",
          );
        seenUrls.add(url);
      }
      const title =
        typeof item.title === "string"
          ? item.title.trim().slice(0, 180)
          : String(item.id);
      const metrics = values(item.metrics || {});
      if (!Object.keys(metrics).length)
        fail("Cada conteúdo precisa de pelo menos uma métrica.");
      const metadata: Partial<InsightContent> = {};
      const thumbnailUrl = profilePhotoUrl(item.thumbnailUrl);
      if (thumbnailUrl) metadata.thumbnailUrl = thumbnailUrl;
      for (const [key, labels] of [
        ["storyMedia", STORY_MEDIA_LABELS],
        ["storySticker", STORY_STICKER_LABELS],
      ] as const) {
        if (item[key] === undefined || item[key] === "") continue;
        if (item.kind !== "story" || !Object.hasOwn(labels, String(item[key])))
          fail(
            "Mídia e figurinha de Story devem ter valores válidos e pertencer a um conteúdo story.",
          );
        Object.assign(metadata, { [key]: item[key] });
      }
      for (const key of ["theme", "hook", "cta"] as const) {
        if (item[key] === undefined || item[key] === "") continue;
        if (typeof item[key] !== "string" || (item[key] as string).length > 100)
          fail(
            "Tema, tipo de abertura e chamada para ação devem ter até 100 caracteres.",
          );
        const cleaned = (item[key] as string).trim().replace(/\s+/g, " ");
        if (cleaned) metadata[key] = cleaned;
      }
      if (item.publishedAt !== undefined && item.publishedAt !== "") {
        if (
          typeof item.publishedAt !== "string" ||
          !/^\d{4}-\d{2}-\d{2}T\d{2}:\d{2}(?::\d{2}(?:\.\d{1,3})?)?(?:Z|[+-]\d{2}:\d{2})$/.test(
            item.publishedAt,
          ) ||
          !Number.isFinite(Date.parse(item.publishedAt)) ||
          Number(item.publishedAt.slice(11, 13)) > 23 ||
          Number(item.publishedAt.slice(14, 16)) > 59 ||
          Date.parse(item.publishedAt) > Date.now()
        )
          fail(
            "Informe a data de publicação válida com hora e fuso, sem datas futuras.",
          );
        day(item.publishedAt.slice(0, 10));
        metadata.publishedAt = item.publishedAt;
      }
      if (item.observationHours !== undefined && item.observationHours !== "") {
        if (contentWindow === "lifetime")
          fail(
            "Medições das primeiras horas exigem contentWindow=period. Vida inteira não é uma janela padronizada.",
          );
        if (
          !Number.isSafeInteger(item.observationHours) ||
          Number(item.observationHours) < 1 ||
          Number(item.observationHours) > 8760 ||
          !metadata.publishedAt
        )
          fail(
            "Informe a data de publicação e uma janela entre 1 e 8.760 horas.",
          );
        const offset = metadata.publishedAt.match(/(Z|[+-]\d{2}:\d{2})$/)![1];
        const windowEnds =
          Date.parse(metadata.publishedAt) +
          Number(item.observationHours) * 3600000;
        if (
          windowEnds > Date.parse(`${end}T23:59:59.999${offset}`) ||
          windowEnds > Date.now()
        )
          fail(
            "A janela de medição da publicação ainda não está completa ou ultrapassa a data final do relatório.",
          );
        metadata.observationHours = item.observationHours as number;
      }
      return {
        id: item.id as string,
        kind: item.kind as ContentKind,
        title,
        url,
        metrics,
        ...metadata,
      };
    },
  );
  const audiences = new Set<string>();
  const audience: InsightAudience[] = ((raw.audience || []) as unknown[]).map(
    (value) => {
      const row = object(value);
      if (
        !["followers", "reached", "engaged"].includes(String(row.audience)) ||
        ![
          "country",
          "city",
          "age",
          "gender",
          "hour",
          "day",
          "follower_status",
        ].includes(String(row.dimension)) ||
        !["count", "percent"].includes(String(row.unit)) ||
        !Array.isArray(row.values) ||
        row.values.length > 100
      )
        fail("Recorte de público inválido.");
      const id = `${row.audience}|${row.dimension}`;
      if (audiences.has(id))
        fail("Não repita o mesmo recorte de público no relatório.");
      audiences.add(id);
      const labels = new Set<string>();
      const entries = (row.values as unknown[]).map((value) => {
        const entry = object(value);
        if (
          typeof entry.label !== "string" ||
          !entry.label.trim() ||
          entry.label.length > 100 ||
          labels.has(entry.label.trim()) ||
          typeof entry.value !== "number" ||
          !Number.isFinite(entry.value) ||
          entry.value < 0 ||
          (row.unit === "percent" && entry.value > 100) ||
          (row.unit === "count" && !Number.isSafeInteger(entry.value))
        )
          fail("Valor de público inválido ou repetido.");
        labels.add((entry.label as string).trim());
        return {
          label: (entry.label as string).trim(),
          value: entry.value as number,
        };
      });
      if (
        row.unit === "percent" &&
        entries.reduce((sum, entry) => sum + entry.value, 0) > 100.5
      )
        fail("O recorte de público ultrapassa 100%.");
      return {
        audience: row.audience,
        dimension: row.dimension,
        unit: row.unit,
        values: entries,
      } as InsightAudience;
    },
  );
  if (
    !Object.keys(metrics).length &&
    !content.length &&
    !audience.some((a) => a.values.length)
  )
    fail("Informe pelo menos uma métrica, conteúdo ou recorte de público.");
  return {
    id: preserveMetadata ? (raw.id as string) : uid(),
    account: account!,
    start,
    end,
    recordedAt: preserveMetadata
      ? (raw.recordedAt as string)
      : new Date().toISOString(),
    source,
    coverage: coverage as InsightReport["coverage"],
    contentWindow: contentWindow as InsightReport["contentWindow"],
    note: typeof raw.note === "string" ? raw.note.trim().slice(0, 500) : "",
    metrics,
    content: content.sort((a, b) => a.id.localeCompare(b.id)),
    audience: audience
      .map((a) => ({
        ...a,
        values: a.values.sort((x, y) => x.label.localeCompare(y.label)),
      }))
      .sort((a, b) =>
        `${a.audience}|${a.dimension}`.localeCompare(
          `${b.audience}|${b.dimension}`,
        ),
      ),
  };
}
export function mergeInsightReports(
  account: AccountWorkspace,
  input: unknown,
  source: InsightReport["source"],
  preserveMetadata = false,
): void {
  if (!account.username)
    fail("Cadastre uma conta antes de registrar Insights.");
  const root = Array.isArray(input) ? input : [input];
  if (!root.length || root.length > 120)
    fail("Importe entre 1 e 120 relatórios por vez.");
  const reports = root.map((r) =>
    validateInsightReport(r, account.username!, source, preserveMetadata),
  );
  const combined = [...(account.insights || [])];
  for (const report of reports) {
    const fingerprint = (r: InsightReport) =>
      JSON.stringify([
        r.account,
        r.start,
        r.end,
        r.coverage,
        r.contentWindow,
        r.metrics,
        r.content.map(({ thumbnailUrl: _thumbnailUrl, ...content }) => content),
        r.audience,
        r.note,
      ]);
    const same = combined.findIndex(
      (r) => fingerprint(r) === fingerprint(report),
    );
    if (same >= 0) {
      // A renewed cover is metadata, not another measurement. Keep the existing
      // report identity, timestamp, metrics and any cover absent from the input.
      const incoming = new Map(
        report.content.map((content) => [content.id, content]),
      );
      combined[same] = {
        ...combined[same],
        content: combined[same].content.map((content) => {
          const thumbnailUrl = incoming.get(content.id)?.thumbnailUrl;
          return thumbnailUrl &&
            thumbnailUrl !== content.thumbnailUrl &&
            (!preserveMetadata || !content.thumbnailUrl)
            ? { ...content, thumbnailUrl }
            : content;
        }),
      };
    } else {
      if (combined.some((r) => r.id === report.id)) report.id = uid();
      combined.push(report);
    }
  }
  if (combined.length > 120)
    fail(
      "Este espaço já chegou a 120 relatórios. Exporte o histórico antes de organizar novos períodos.",
    );
  account.insights = combined.sort(
    (a, b) =>
      a.end.localeCompare(b.end) || Date.parse(a.recordedAt) - Date.parse(b.recordedAt),
  );
}
export function parseInsightFile(text: string): unknown {
  if (text.length > 5_000_000) fail("Use arquivos com até 5 MB.");
  if (text.trimStart().startsWith("{") || text.trimStart().startsWith("[")) {
    let parsed: unknown;
    try {
      parsed = JSON.parse(text.replace(/^\uFEFF/, ""));
    } catch {
      fail("JSON inválido. Confira o modelo Órbita.");
    }
    if (
      parsed &&
      !Array.isArray(parsed) &&
      typeof parsed === "object" &&
      "reports" in parsed
    )
      return (parsed as { reports: unknown }).reports;
    return parsed;
  }
  const rows = csvRows(text);
  if (rows.length > 30001) fail("Use até 30.000 linhas de dados por CSV.");
  const header = rows.shift()?.map((v) => v.trim().toLowerCase());
  const required = ["account", "start", "end", "scope", "metric", "value"];
  if (
    !header ||
    required.some((key) => !header.includes(key)) ||
    new Set(header).size !== header.length
  )
    fail(
      "Use o modelo CSV de Insights da Órbita. Relatórios da Meta precisam ser adaptados às colunas do modelo.",
    );
  const groups = new Map<
    string,
    {
      account: string;
      start: string;
      end: string;
      coverage: string;
      contentWindow: string;
      metrics: Record<string, number>;
      content: InsightContent[];
      audience: InsightAudience[];
    }
  >();
  for (const row of rows) {
    const get = (key: string) => row[header!.indexOf(key)]?.trim() || "";
    const owner = get("account"),
      start = get("start"),
      end = get("end"),
      scope = get("scope");
    if (!["account", ...Object.keys(CONTENT_LABELS)].includes(scope))
      fail("Coluna scope inválida no CSV.");
    const count = get("value");
    if (!count) continue;
    if (!/^\d+(?:\.\d+)?$/.test(count))
      fail(
        "No CSV, use números sem separadores de milhar, com ponto decimal quando necessário.",
      );
    const coverage = get("coverage") || "unknown",
      contentWindow = get("content_window") || "period";
    const key = `${owner}|${start}|${end}|${coverage}|${contentWindow}`;
    if (!groups.has(key))
      groups.set(key, {
        account: owner,
        start,
        end,
        coverage,
        contentWindow,
        metrics: {},
        content: [],
        audience: [],
      });
    const report = groups.get(key)!;
    let metrics = report.metrics;
    if (scope !== "account") {
      const id = get("content_id");
      if (!id) fail("Informe content_id nas linhas de cada publicação.");
      let item = report.content.find((c) => c.id === id);
      if (item && item.kind !== scope)
        fail("Um mesmo conteúdo tem formatos conflitantes no CSV.");
      if (!item) {
        item = {
          id,
          kind: scope as ContentKind,
          title: get("title") || id,
          url: undefined,
          metrics: {},
        };
        report.content.push(item);
      }
      const title = get("title"),
        url = get("url") ? contentUrl(get("url")) : undefined;
      if (title) {
        if (item.title !== id && item.title !== title)
          fail(`Títulos conflitantes para o conteúdo ${id}.`);
        item.title = title;
      }
      if (url) {
        if (item.url && item.url !== url)
          fail(`Links conflitantes para o conteúdo ${id}.`);
        item.url = url;
      }
      for (const [column, key] of [
        ["published_at", "publishedAt"],
        ["theme", "theme"],
        ["hook", "hook"],
        ["cta", "cta"],
        ["story_media", "storyMedia"],
        ["story_sticker", "storySticker"],
      ] as const) {
        const value = get(column);
        if (!value) continue;
        if (item[key] && item[key] !== value)
          fail(`Metadados conflitantes para o conteúdo ${id}: ${column}.`);
        Object.assign(item, { [key]: value });
      }
      const hours = get("observation_hours");
      if (hours) {
        if (
          !/^\d+$/.test(hours) ||
          (item.observationHours !== undefined &&
            item.observationHours !== Number(hours))
        )
          fail("Janela de medição inválida ou conflitante no CSV.");
        item.observationHours = Number(hours);
      }
      metrics = item.metrics;
    }
    const name = get("metric");
    if (
      !/^[a-z][a-z0-9_]{0,69}$/.test(name) ||
      ["constructor", "prototype"].includes(name)
    )
      fail("Identificador de métrica inválido no CSV.");
    if (Object.hasOwn(metrics, name))
      fail(
        `Métrica repetida no CSV: ${name}. Não somamos períodos sobrepostos.`,
      );
    metrics[name] = Number(count);
  }
  return [...groups.values()];
}
export function insightTemplate(
  account: string,
  start: string,
  end: string,
): string {
  return (
    "account,start,end,coverage,content_window,scope,content_id,title,url,metric,value,published_at,observation_hours,theme,hook,cta,story_media,story_sticker\r\n" +
    INSIGHT_METRICS.map(
      (m) =>
        `${account},${start},${end},unknown,period,account,,,,${m.key},,,,,,,,`,
    ).join("\r\n")
  );
}
export function insightSummary(report: InsightReport, all: InsightReport[]) {
  const span = Date.parse(report.end) - Date.parse(report.start);
  const previous = all
    .filter(
      (r) =>
        r.account === report.account &&
        report.coverage !== "unknown" &&
        r.coverage === report.coverage &&
        r.contentWindow === report.contentWindow &&
        r.end < report.start &&
        Date.parse(r.end) - Date.parse(r.start) === span &&
        Date.parse(report.start) - Date.parse(r.end) === 86400000,
    )
    .at(-1);
  const rate =
    report.metrics.reach > 0 && report.metrics.total_interactions !== undefined
      ? (report.metrics.total_interactions / report.metrics.reach) * 100
      : undefined;
  const net =
    report.metrics.follows !== undefined &&
    report.metrics.unfollows !== undefined
      ? report.metrics.follows - report.metrics.unfollows
      : undefined;
  const change = (key: string) => {
    const base = previous?.metrics[key],
      value = report.metrics[key];
    return base !== undefined && base > 0 && value !== undefined
      ? ((value - base) / base) * 100
      : undefined;
  };
  const difference = (key: string) => {
    const base = previous?.metrics[key],
      value = report.metrics[key];
    return base !== undefined && value !== undefined ? value - base : undefined;
  };
  return { previous, rate, net, change, difference };
}
export const reportFamily = (
  r: Pick<InsightReport, "start" | "end" | "coverage" | "contentWindow">,
) => JSON.stringify([r.start, r.end, r.coverage, r.contentWindow]);
// Replaces a complete content measurement in a new report version; this is not a partial patch.
export function contentRevision(
  base: InsightReport | undefined,
  account: string,
  period: Pick<InsightReport, "start" | "end" | "coverage" | "contentWindow">,
  input: unknown,
): InsightReport {
  if (base && base.account !== account)
    fail("A publicação pertence a outra conta.");
  const parent = base || {
    account,
    ...period,
    metrics: {},
    content: [],
    audience: [],
    note: "",
  };
  const single = validateInsightReport(
    { ...parent, content: [input] },
    account,
    "manual",
  ).content[0];
  const byId = parent.content.find((c) => c.id === single.id),
    byUrl = single.url && parent.content.find((c) => c.url === single.url);
  if (byId && byUrl && byId.id !== byUrl.id)
    fail("O identificador e o link apontam para publicações diferentes.");
  const existing = byId || byUrl;
  if (existing) single.id = existing.id;
  return validateInsightReport(
    {
      ...parent,
      content: [...parent.content.filter((c) => c.id !== single.id), single],
    },
    account,
    "manual",
  );
}
