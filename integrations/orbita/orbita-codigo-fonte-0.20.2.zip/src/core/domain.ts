import type {
  AppState,
  Audit,
  Candidate,
  CandidateInput,
  Command,
  Filters,
  Settings,
  SourceKind,
} from "./types.ts";
import { STARTER, sessionLimit } from "./safety.ts";
import { profilePhotoUrl } from "./photos.ts";
import { checkedCampaignGroup, profileCampaignPlan } from "./campaigns.ts";
import {
  validateProspectingCandidate,
  validateProspectingSettings,
} from "./prospecting.ts";
import {
  configureContinuousSource,
  pauseContinuous,
  setContinuousSourceUnavailable,
  validateContinuousState,
} from "./continuous.ts";

export const STORAGE_KEY = "orbita-state-v1";
export const sourceKinds: SourceKind[] = [
  "followers",
  "following",
  "commenters",
  "likers",
  "hashtag",
  "location",
  "import",
];
export const initialState = (): AppState => ({
  version: 1,
  campaigns: [],
  candidates: [],
  audit: [],
  dailyAttempts: {},
  lastAttempts: {},
  settings: {
    ...STARTER,
    hasPendingWarning: false,
    allDay: false,
    startHour: "09:00",
    endHour: "18:00",
    exclusions: [],
  },
  runtime: { mode: "paused", pauseReason: "A fila está sob seu controle." },
});
export const uid = () => crypto.randomUUID();
export const normalizeUsername = (value: string): string | null => {
  const clean = value.trim().replace(/^@/, "").toLowerCase();
  return /^[a-z0-9._]{1,30}$/.test(clean) &&
    ![
      "accounts",
      "explore",
      "direct",
      "reels",
      "stories",
      "p",
      "reel",
      "about",
      "legal",
    ].includes(clean)
    ? clean
    : null;
};
export function sourceUrl(kind: SourceKind, target: string): string {
  if (kind === "import") return "";
  if (kind === "followers" || kind === "following") {
    let input = target.trim();
    if (/^https:\/\//i.test(input)) {
      const url = new URL(input);
      if (
        url.hostname !== "www.instagram.com" &&
        url.hostname !== "instagram.com"
      )
        throw new Error("Use um perfil do Instagram.");
      input = url.pathname.split("/").filter(Boolean)[0] || "";
    }
    const username = normalizeUsername(input);
    if (!username) throw new Error("Informe um @perfil válido.");
    return `https://www.instagram.com/${username}/${kind}/`;
  }
  if (kind === "hashtag") {
    const hashtag = target.trim().replace(/^#/, "");
    if (!/^[\p{L}\p{N}_]{1,100}$/u.test(hashtag))
      throw new Error("Informe uma hashtag válida.");
    return `https://www.instagram.com/explore/tags/${encodeURIComponent(hashtag)}/`;
  }
  const url = new URL(target);
  if (
    url.protocol !== "https:" ||
    !["www.instagram.com", "instagram.com"].includes(url.hostname)
  )
    throw new Error("Cole um link https do Instagram.");
  if (kind === "location" && !/^\/explore\/locations\/\d+\//.test(url.pathname))
    throw new Error("Use o link da localização no Instagram.");
  if (
    (kind === "commenters" || kind === "likers") &&
    !/^\/(p|reel)\/[\w-]+\/?$/.test(url.pathname)
  )
    throw new Error("Use o link de uma publicação ou Reel.");
  return `https://www.instagram.com${url.pathname.replace(/\/?$/, "/")}`;
}
export function audit(
  state: AppState,
  kind: string,
  message: string,
  username?: string,
): void {
  const entry: Audit = {
    id: uid(),
    at: new Date().toISOString(),
    kind,
    message,
    username,
    account: state.runtime.account,
  };
  if (kind === "attempt" && state.runtime.account) {
    state.lastAttempts ||= {};
    state.lastAttempts[`@${state.runtime.account}`] = entry.at;
    state.runtime.sessionAttempts = (state.runtime.sessionAttempts || 0) + 1;
    state.dailyAttempts ||= {};
    const key = `${state.runtime.account}|${new Date().toDateString()}`;
    const legacyCount = state.audit.filter(
      (a) =>
        a.kind === "attempt" &&
        a.account === state.runtime.account &&
        new Date(a.at).toDateString() === new Date().toDateString(),
    ).length;
    state.dailyAttempts[key] =
      Math.max(state.dailyAttempts[key] || 0, legacyCount) + 1;
  }
  state.audit = [entry, ...state.audit].slice(0, 3000);
}
const finiteCount = (value: unknown): number | undefined =>
  typeof value === "number" && Number.isFinite(value) && value >= 0
    ? Math.floor(value)
    : undefined;
export function cleanInput(value: CandidateInput): CandidateInput | null {
  if (!value || typeof value.username !== "string") return null;
  const username = normalizeUsername(value.username);
  if (!username) return null;
  return {
    username,
    avatarUrl: profilePhotoUrl(value.avatarUrl),
    name: String(value.name || "").slice(0, 150),
    platformId:
      value.platformId && /^\d+$/.test(String(value.platformId))
        ? String(value.platformId)
        : undefined,
    bio: typeof value.bio === "string" ? value.bio.slice(0, 2000) : undefined,
    followers: finiteCount(value.followers),
    following: finiteCount(value.following),
    posts: finiteCount(value.posts),
    isPrivate:
      typeof value.isPrivate === "boolean" ? value.isPrivate : undefined,
  };
}
export function mergeCandidates(
  state: AppState,
  campaignId: string,
  inputs: CandidateInput[],
  url = "",
): { added: number; merged: number; invalid: number } {
  if (!state.campaigns.some((c) => c.id === campaignId && !c.archived))
    throw new Error("Selecione uma campanha ativa.");
  if (!Array.isArray(inputs) || inputs.length > 10000)
    throw new Error("Importe até 10.000 perfis por vez.");
  const byName = new Map(state.candidates.map((c) => [c.username, c]));
  const byId = new Map(
    state.candidates.filter((c) => c.platformId).map((c) => [c.platformId!, c]),
  );
  let added = 0,
    merged = 0,
    invalid = 0;
  const at = new Date().toISOString();
  for (const raw of inputs) {
    const input = cleanInput(raw);
    if (!input) {
      invalid++;
      continue;
    }
    const existing =
      (input.platformId && byId.get(input.platformId)) ||
      byName.get(input.username);
    if (existing) {
      const nameOwner = byName.get(input.username);
      if (nameOwner && nameOwner !== existing) {
        invalid++;
        continue;
      }
      if (
        input.platformId &&
        existing.platformId &&
        input.platformId !== existing.platformId
      ) {
        invalid++;
        continue;
      }
      const oldName = existing.username;
      if (oldName !== input.username && (
        existing.stage !== "new" || existing.queueAccount !== undefined || existing.queuedAction !== undefined ||
        existing.confirmedFollowAt !== undefined || existing.confirmedFollowAccount !== undefined || existing.confirmedFollowSource !== undefined ||
        existing.relationshipObserved !== undefined || state.runtime.activeCandidateId === existing.id
      )) {
        // Stable IDs can update an unreviewed discovery. A reviewed destination,
        // active lease or relationship evidence must never move to another @.
        invalid++;
        continue;
      }
      for (const [key, value] of Object.entries(input))
        if (value !== undefined && value !== "")
          Object.assign(existing, { [key]: value });
      if (oldName !== existing.username) {
        byName.delete(oldName);
        if (state.settings.exclusions.includes(oldName) || state.settings.exclusions.includes(existing.username))
          existing.stage = "excluded";
      }
      if (
        !existing.sources.some(
          (s) => s.campaignId === campaignId && s.url === url,
        )
      )
        existing.sources.push({ campaignId, url, at });
      existing.updatedAt = at;
      byName.set(input.username, existing);
      if (existing.platformId) byId.set(existing.platformId, existing);
      merged++;
    } else {
      if (state.candidates.length >= 30000)
        throw new Error(
          "O espaço comporta até 30.000 perfis. Exporte um backup e use outro espaço para continuar.",
        );
      const candidate: Candidate = {
        ...input,
        id: uid(),
        name: input.name || "",
        sources: [{ campaignId, url, at }],
        stage: state.settings.exclusions.includes(input.username)
          ? "excluded"
          : "new",
        createdAt: at,
        updatedAt: at,
        note: "",
      };
      state.candidates.push(candidate);
      byName.set(candidate.username, candidate);
      if (candidate.platformId) byId.set(candidate.platformId, candidate);
      added++;
    }
  }
  return { added, merged, invalid };
}
export function validateAllDaySchedule(value: unknown): boolean {
  if (value !== undefined && typeof value !== "boolean")
    throw new Error("Informe se a agenda de 24 horas está ativada.");
  return value ?? false;
}
export function validateSettings(value: Settings): Settings {
  if (!value || typeof value !== "object")
    throw new Error("Preferências ausentes ou inválidas no arquivo.");
  validateProspectingSettings(value);
  const allDay = validateAllDaySchedule(value.allDay);
  if (
    !Number.isInteger(value.dailyLimit) ||
    value.dailyLimit < 1 ||
    value.dailyLimit > 500
  )
    throw new Error(
      "O teto diário deve ser um inteiro entre 1 e 500. Isso não representa um limite seguro do Instagram.",
    );
  if (
    !Number.isFinite(value.intervalMinutes) ||
    value.intervalMinutes < 1 ||
    value.intervalMinutes > 1440
  )
    throw new Error("O intervalo deve estar entre 1 e 1.440 minutos.");
  const time = /^(?:[01]\d|2[0-3]):[0-5]\d$/;
  if (
    !time.test(value.startHour) ||
    !time.test(value.endHour) ||
    value.startHour === value.endHour
  )
    throw new Error(
      "Informe uma janela de horários com início e fim diferentes.",
    );
  if (!Array.isArray(value.exclusions) || value.exclusions.length > 10000)
    throw new Error("Lista de exclusão inválida.");
  if (
    !Number.isInteger(sessionLimit(value)) ||
    sessionLimit(value) < 1 ||
    sessionLimit(value) > 500
  )
    throw new Error("O tamanho do lote deve ser um inteiro entre 1 e 500.");
  if (
    value.hasPendingWarning !== undefined &&
    typeof value.hasPendingWarning !== "boolean"
  )
    throw new Error("Informe se há um aviso pendente na conta.");
  return {
    ...value,
    allDay,
    sessionLimit: sessionLimit(value),
    hasPendingWarning: value.hasPendingWarning ?? false,
    exclusions: [
      ...new Set(
        value.exclusions.map(normalizeUsername).filter((s): s is string => !!s),
      ),
    ],
  };
}
export function applyCommand(original: AppState, command: Command): AppState {
  const state = structuredClone(original);
  const ids = "ids" in command ? new Set(command.ids) : new Set<string>();
  switch (command.type) {
    case "CONFIGURE_CONTINUOUS_SOURCE":
      return configureContinuousSource(state, command);
    case "PAUSE_CONTINUOUS":
      return applyCommand(state, { type: "PAUSE" });
    case "SET_SOURCE_UNAVAILABLE":
      return setContinuousSourceUnavailable(state, command.id, command.reason);
    case "CREATE_PROFILE_CAMPAIGN": {
      const plan = profileCampaignPlan(
        command.name,
        command.profile,
        command.postUrl,
      );
      if (
        state.campaigns.some(
          (c) =>
            !c.archived &&
            c.group?.profile === plan.profile &&
            c.group.postUrl === plan.postUrl,
        )
      )
        throw new Error(
          "Esse perfil e essa publicação já têm uma campanha agrupada ativa. Continue a coleta no cartão existente.",
        );
      const existing = plan.sources.map((source) =>
        state.campaigns.find(
          (campaign) =>
            !campaign.archived &&
            campaign.kind === source.kind &&
            sourceUrl(campaign.kind, campaign.target) ===
              sourceUrl(source.kind, source.target),
        ),
      );
      if (existing.some((campaign) => campaign?.group))
        throw new Error(
          "Uma dessas fontes já pertence a outra campanha por perfil. Continue no cartão existente para preservar o histórico.",
        );
      const group = {
        id: uid(),
        name: plan.name,
        profile: plan.profile,
        postUrl: plan.postUrl,
      };
      const createdAt = new Date().toISOString();
      plan.sources.forEach((source, index) => {
        const campaign = existing[index];
        if (campaign) campaign.group = { ...group };
        else
          state.campaigns.push({
            id: uid(),
            name: plan.name,
            kind: source.kind,
            target: source.target,
            createdAt,
            archived: false,
            group: { ...group },
          });
      });
      audit(
        state,
        "campaign",
        `Campanha “${plan.name}” preparada para @${plan.profile}: seguidores, comentários e curtidas. Nenhuma captura foi iniciada.`,
      );
      break;
    }
    case "CREATE_CAMPAIGN": {
      if (
        !command.name.trim() ||
        command.name.length > 100 ||
        !sourceKinds.includes(command.kind)
      )
        throw new Error("Informe nome e fonte válidos.");
      sourceUrl(command.kind, command.target);
      state.campaigns.unshift({
        id: uid(),
        name: command.name.trim(),
        kind: command.kind,
        target: command.target.trim(),
        createdAt: new Date().toISOString(),
        archived: false,
      });
      audit(state, "campaign", `Campanha “${command.name.trim()}” criada.`);
      break;
    }
    case "ARCHIVE_CAMPAIGN": {
      const campaign = state.campaigns.find((c) => c.id === command.id);
      if (!campaign) throw new Error("Campanha não encontrada.");
      if (
        state.candidates.some(
          (c) =>
            ["queued", "attempting"].includes(c.stage) &&
            c.sources.some((s) => s.campaignId === campaign.id),
        )
      )
        throw new Error(
          "Retire os perfis da fila antes de arquivar esta campanha.",
        );
      campaign.archived = true;
      if (campaign.continuous) {
        campaign.continuous.enabled = false;
        delete campaign.continuous.authorizationId;
        delete campaign.continuous.runId;
        delete campaign.continuous.nextCheckAt;
      }
      if (state.continuous)
        state.continuous.sourceIds = state.continuous.sourceIds?.filter(
          (id) => id !== campaign.id,
        );
      audit(state, "campaign", `Campanha “${campaign.name}” arquivada.`);
      break;
    }
    case "IMPORT": {
      const result = mergeCandidates(
        state,
        command.campaignId,
        command.candidates,
        command.url,
      );
      audit(
        state,
        "import",
        `${result.added} novos · ${result.merged} já conhecidos · ${result.invalid} inválidos.`,
      );
      break;
    }
    case "APPROVE":
      for (const c of state.candidates)
        if (
          ids.has(c.id) &&
          c.stage === "new" &&
          !state.settings.exclusions.includes(c.username)
        )
          c.stage = "approved";
      audit(state, "review", "Seleção revisada e aprovada.");
      break;
    case "QUEUE": {
      if (state.continuous?.mode === "running")
        throw new Error(
          "Pause a rotina contínua antes de montar uma fila manual.",
        );
      if (!state.runtime.account)
        throw new Error(
          "Conecte e identifique a conta na extensão antes de montar a fila.",
        );
      let count = 0;
      for (const c of state.candidates)
        if (
          ids.has(c.id) &&
          c.stage === "approved" &&
          !c.sources.some((s) => s.url.startsWith("demo:")) &&
          !state.settings.exclusions.includes(c.username) &&
          c.username !== state.runtime.account
        ) {
          c.stage = "queued";
          c.queueAccount = state.runtime.account;
          c.queuedAction = "follow";
          delete c.continuousSourceId;
          delete c.continuousAuthorizationId;
          count++;
        }
      if (!count)
        throw new Error(
          "Selecione perfis aprovados que ainda não estejam na fila.",
        );
      audit(
        state,
        "queue",
        `${count} perfis adicionados à fila de @${state.runtime.account}.`,
      );
      break;
    }
    case "EXCLUDE":
      for (const c of state.candidates)
        if (ids.has(c.id)) {
          if (c.stage === "attempting")
            throw new Error(
              "Aguarde a ação em andamento antes de excluir este perfil.",
            );
          c.stage = "excluded";
          if (!state.settings.exclusions.includes(c.username))
            state.settings.exclusions.push(c.username);
        }
      audit(
        state,
        "review",
        "Perfis selecionados adicionados à lista de exclusão.",
      );
      break;
    case "REMOVE_FROM_QUEUE":
      for (const c of state.candidates)
        if (ids.has(c.id) && c.stage === "queued") {
          c.stage = c.queuedAction === "unfollow" ? "followed" : "approved";
          delete c.queueAccount;
          delete c.queuedAction;
        }
      audit(state, "queue", "Perfis retirados da fila.");
      break;
    case "RETURN_TO_REVIEW": {
      const c = state.candidates.find((c) => c.id === command.id);
      if (!c || !["uncertain", "failed", "excluded"].includes(c.stage))
        throw new Error("Este perfil não precisa de nova revisão.");
      if (c.queuedAction === "unfollow")
        throw new Error(
          "Confira o resultado de deixar de seguir no Instagram. Este resultado não pode voltar à fila de seguir por uma revisão genérica.",
        );
      validateProspectingCandidate(c, state.runtime.account);
      if (
        ["following", "requested"].includes(
          c.relationshipObserved?.status || "",
        )
      )
        throw new Error(
          "A conferência já observou Seguindo ou Solicitado; este perfil não pode voltar à fila de seguir.",
        );
      if (
        c.stage === "uncertain" &&
        (command.confirmed !== true ||
          state.runtime.mode !== "paused" ||
          state.candidates.some((row) => row.stage === "attempting") ||
          !state.runtime.account ||
          c.queueAccount !== state.runtime.account ||
          c.relationshipObserved?.account !== state.runtime.account ||
          c.relationshipObserved?.source !== "instagram" ||
          c.relationshipObserved?.status !== "not_following")
      )
        throw new Error(
          "Confira o resultado sem clique e confirme manualmente a observação Seguir desta conta antes de devolver à revisão.",
        );
      state.settings.exclusions = state.settings.exclusions.filter(
        (u) => u !== c.username,
      );
      c.stage = "new";
      delete c.continuousSourceId;
      delete c.continuousAuthorizationId;
      delete c.queueAccount;
      delete c.queuedAction;
      c.lastResult =
        "Devolvido à revisão pelo usuário após conferência manual.";
      audit(state, "review", c.lastResult, c.username);
      break;
    }
    case "NOTE": {
      const c = state.candidates.find((c) => c.id === command.id);
      if (c) c.note = command.note.slice(0, 2000);
      break;
    }
    case "SETTINGS":
      state.settings = validateSettings(command.settings);
      for (const c of state.candidates)
        if (
          state.settings.exclusions.includes(c.username) &&
          ["new", "approved", "queued"].includes(c.stage)
        )
          c.stage = "excluded";
      state.runtime.mode = "paused";
      state.runtime.pauseReason = state.settings.hasPendingWarning
        ? "Aviso pendente: confira o Instagram antes de retomar."
        : "Preferências atualizadas. Revise o ritmo antes de iniciar a fila.";
      delete state.runtime.nextRun;
      delete state.runtime.activeToken;
      delete state.runtime.activeAction;
      audit(
        state,
        "settings",
        "Preferências atualizadas; execução pausada. Uma ação já enviada pode terminar.",
      );
      return pauseContinuous(state, state.runtime.pauseReason);
    case "APPLY_STARTER":
      state.settings = { ...state.settings, ...STARTER };
      state.runtime.mode = "paused";
      state.runtime.pauseReason =
        "Começo guiado aplicado: até 5 tentativas por dia, lotes de 5 e intervalos de 15 minutos. Sem aumento automático.";
      delete state.runtime.nextRun;
      delete state.runtime.activeToken;
      delete state.runtime.activeAction;
      audit(state, "settings", state.runtime.pauseReason);
      return pauseContinuous(state, state.runtime.pauseReason);
    case "REPORT_WARNING":
      state.settings.hasPendingWarning = true;
      state.runtime.mode = "paused";
      state.runtime.pauseReason =
        "Você informou um aviso na conta. Confira a situação diretamente no Instagram antes de liberar a execução.";
      delete state.runtime.nextRun;
      delete state.runtime.activeToken;
      delete state.runtime.activeAction;
      audit(state, "warning", state.runtime.pauseReason);
      return pauseContinuous(state, state.runtime.pauseReason);
    case "PAUSE":
      state.runtime.mode = "paused";
      state.runtime.pauseReason =
        "Pausado por você. Uma ação já enviada pode terminar.";
      delete state.runtime.nextRun;
      delete state.runtime.activeToken;
      delete state.runtime.activeAction;
      audit(state, "pause", "Execução pausada pelo usuário.");
      return pauseContinuous(state, state.runtime.pauseReason);
    case "DEMO": {
      if (state.campaigns.length || state.candidates.length)
        throw new Error(
          "A demonstração só pode ser carregada em um espaço vazio.",
        );
      const id = uid();
      state.campaigns.push({
        id,
        name: "Demonstração · criadores locais",
        kind: "import",
        target: "Dados fictícios",
        archived: false,
        createdAt: new Date().toISOString(),
      });
      mergeCandidates(
        state,
        id,
        [
          {
            username: "exemplo.ana",
            name: "Ana · exemplo fictício",
            bio: "Cerâmica, café e projetos autorais. São Paulo.",
            followers: 1240,
            posts: 86,
            isPrivate: false,
          },
          {
            username: "exemplo.atelie",
            name: "Ateliê · exemplo fictício",
            bio: "Design independente e objetos feitos à mão.",
            followers: 3800,
            posts: 142,
            isPrivate: false,
          },
          {
            username: "exemplo.carlos",
            name: "Carlos · exemplo fictício",
            bio: "Fotografia de rua. Histórias da cidade.",
            followers: 680,
            posts: 43,
            isPrivate: false,
          },
          {
            username: "exemplo.bia",
            name: "Bia · exemplo fictício",
            bio: "Compartilhando o processo criativo.",
            isPrivate: true,
          },
          {
            username: "exemplo.estudio",
            name: "Estúdio · exemplo fictício",
            bio: "Arquitetura e interiores. Projetos em SP.",
            followers: 7250,
            posts: 210,
            isPrivate: false,
          },
        ],
        "demo://ficticio",
      );
      audit(
        state,
        "demo",
        "Dados fictícios carregados. Não podem entrar na fila real.",
      );
      break;
    }
    case "RESTORE": {
      const restored = restoreState(command.data);
      // An old backup must not erase a warning or replenish today's budget.
      restored.settings.hasPendingWarning = !!(
        state.settings.hasPendingWarning || restored.settings.hasPendingWarning
      );
      for (const [key, count] of Object.entries(state.dailyAttempts || {}))
        restored.dailyAttempts[key] = Math.max(
          restored.dailyAttempts[key] || 0,
          count,
        );
      const legacyCounts = new Map<string, number>();
      const latestAttempts = { ...state.lastAttempts };
      for (const entry of state.audit)
        if (entry.kind === "attempt" && entry.account) {
          const key = `${entry.account}|${new Date(entry.at).toDateString()}`;
          legacyCounts.set(key, (legacyCounts.get(key) || 0) + 1);
          const accountKey = `@${entry.account}`;
          if (
            (Date.parse(entry.at) || 0) >
            (Date.parse(latestAttempts[accountKey] || "") || 0)
          )
            latestAttempts[accountKey] = entry.at;
        }
      for (const [key, count] of legacyCounts)
        restored.dailyAttempts[key] = Math.max(
          restored.dailyAttempts[key] || 0,
          count,
        );
      restored.lastAttempts ||= {};
      for (const [key, at] of Object.entries(latestAttempts))
        if (
          (Date.parse(at) || 0) >
          (Date.parse(restored.lastAttempts[key] || "") || 0)
        )
          restored.lastAttempts[key] = at;
      return restored;
    }
  }
  return state;
}
export function matchesFilters(c: Candidate, f: Filters): boolean {
  const query = f.query.trim().toLocaleLowerCase();
  if (
    query &&
    !`${c.username} ${c.name} ${c.bio || ""}`
      .toLocaleLowerCase()
      .includes(query)
  )
    return false;
  if (f.campaignId && !c.sources.some((s) => s.campaignId === f.campaignId))
    return false;
  if (f.stage && c.stage !== f.stage) return false;
  if ((f.minFollowers || f.maxFollowers) && c.followers === undefined)
    return false;
  if (f.minFollowers && c.followers! < Number(f.minFollowers)) return false;
  if (f.maxFollowers && c.followers! > Number(f.maxFollowers)) return false;
  if (
    f.bio &&
    !(c.bio || "").toLocaleLowerCase().includes(f.bio.toLocaleLowerCase())
  )
    return false;
  if (f.publicOnly && c.isPrivate !== false) return false;
  if (f.requireKnown && c.followers === undefined) return false;
  return true;
}
export function insideWindow(date: Date, settings: Settings): boolean {
  if (settings.allDay === true) return true;
  const now = date.getHours() * 60 + date.getMinutes();
  const minutes = (t: string) =>
    Number(t.split(":")[0]) * 60 + Number(t.split(":")[1]);
  const start = minutes(settings.startHour),
    end = minutes(settings.endHour);
  return start < end ? now >= start && now < end : now >= start || now < end;
}
export function attemptsToday(state: AppState, now = new Date()): number {
  const legacyCount = state.audit.filter(
    (a) =>
      a.kind === "attempt" &&
      a.account === state.runtime.account &&
      new Date(a.at).toDateString() === now.toDateString(),
  ).length;
  return Math.max(
    legacyCount,
    state.dailyAttempts?.[`${state.runtime.account}|${now.toDateString()}`] ||
      0,
  );
}
export function recoverInterrupted(original: AppState): AppState {
  const state = structuredClone(original);
  for (const c of state.candidates)
    if (c.stage === "attempting") {
      c.stage = "uncertain";
      c.lastResult =
        "A sessão foi interrompida. Confira o perfil no Instagram; não haverá repetição automática.";
    }
  state.runtime.mode = "paused";
  state.runtime.pauseReason =
    "Sessão retomada. Revise a fila antes de iniciar novamente.";
  delete state.runtime.activeToken;
  delete state.runtime.activeCandidateId;
  delete state.runtime.activeAction;
  delete state.runtime.nextRun;
  return pauseContinuous(state, state.runtime.pauseReason);
}
export function restoreState(value: unknown): AppState {
  if (!value || typeof value !== "object") throw new Error("Backup inválido.");
  const input = value as AppState;
  if (
    input.version !== 1 ||
    !Array.isArray(input.campaigns) ||
    !Array.isArray(input.candidates) ||
    !Array.isArray(input.audit) ||
    input.candidates.length > 30000 ||
    input.campaigns.length > 1000
  )
    throw new Error("Formato de backup não reconhecido.");
  const state = initialState();
  state.settings = validateSettings(input.settings);
  if (input.lastAttempts && typeof input.lastAttempts === "object")
    for (const [key, at] of Object.entries(input.lastAttempts))
      if (
        /^@[a-z0-9._]{1,30}$/.test(key) &&
        typeof at === "string" &&
        Number.isFinite(Date.parse(at))
      )
        state.lastAttempts![key] = at;
  if (input.dailyAttempts && typeof input.dailyAttempts === "object")
    for (const [key, count] of Object.entries(input.dailyAttempts))
      if (
        key.length < 100 &&
        /^[a-z0-9._]+\|/.test(key) &&
        Number.isSafeInteger(count) &&
        count >= 0
      )
        state.dailyAttempts[key] = count;
  // Old backups may have recorded attempts only in the audit. Preserve their
  // conservative budget/interval evidence without restoring executable history.
  const legacyAttempts = new Map<string, number>();
  for (const entry of input.audit) {
    if (!entry || entry.kind !== "attempt" || typeof entry.account !== "string" ||
        normalizeUsername(entry.account) !== entry.account || typeof entry.at !== "string") continue;
    const at = Date.parse(entry.at);
    if (!Number.isFinite(at) || at > Date.now() + 60000) continue;
    const key = `${entry.account}|${new Date(at).toDateString()}`;
    legacyAttempts.set(key, (legacyAttempts.get(key) || 0) + 1);
    const accountKey = `@${entry.account}`;
    if (at > (Date.parse(state.lastAttempts![accountKey] || "") || 0))
      state.lastAttempts![accountKey] = new Date(at).toISOString();
  }
  for (const [key, count] of legacyAttempts)
    state.dailyAttempts[key] = Math.max(state.dailyAttempts[key] || 0, count);
  state.campaigns = input.campaigns.map((c) => {
    if (
      typeof c.id !== "string" ||
      typeof c.name !== "string" ||
      typeof c.target !== "string" ||
      !sourceKinds.includes(c.kind)
    )
      throw new Error("Campanha inválida no backup.");
    sourceUrl(c.kind, c.target);
    const group = checkedCampaignGroup(c.group, c);
    return {
      id: c.id,
      name: c.name.slice(0, 100),
      target: c.target,
      kind: c.kind,
      createdAt: c.createdAt,
      archived: !!c.archived,
      ...(c.continuous !== undefined
        ? { continuous: structuredClone(c.continuous) }
        : {}),
      ...(group ? { group } : {}),
    };
  });
  const knownStages = [
    "new",
    "approved",
    "queued",
    "attempting",
    "followed",
    "unfollowed",
    "requested",
    "already",
    "uncertain",
    "failed",
    "excluded",
  ];
  const ids = new Set<string>(),
    names = new Set<string>();
  state.candidates = input.candidates.map((c) => {
    const clean = cleanInput(c);
    if (
      !clean ||
      typeof c.id !== "string" ||
      ids.has(c.id) ||
      names.has(clean.username) ||
      !knownStages.includes(c.stage) ||
      !Array.isArray(c.sources)
    )
      throw new Error("Perfil inválido ou duplicado no backup.");
    ids.add(c.id);
    names.add(clean.username);
    const sources = c.sources
      .filter((s) =>
        state.campaigns.some((campaign) => campaign.id === s.campaignId),
      )
      .map((s) => ({
        campaignId: s.campaignId,
        url: String(s.url).slice(0, 2048),
        at: String(s.at),
      }));
    const restored: Candidate = {
      ...clean,
      id: c.id,
      name: clean.name || "",
      stage: ["queued", "attempting"].includes(c.stage) ? "uncertain" : c.stage,
      sources,
      createdAt: String(c.createdAt),
      updatedAt: String(c.updatedAt),
      note: String(c.note || "").slice(0, 2000),
      lastResult: "Restaurado de backup; confira o estado no Instagram.",
    };
    if (c.queueAccount !== undefined) {
      const backupOwner = normalizeUsername(input.runtime?.account || "");
      if (typeof c.queueAccount !== "string" || normalizeUsername(c.queueAccount) !== c.queueAccount || c.queueAccount !== backupOwner)
        throw new Error("O dono da fila do backup está inválido ou pertence a outra conta.");
      // This is historical ownership for read-only reconciliation, not a lease.
      // Restored queued/attempting candidates remain uncertain and paused.
      restored.queueAccount = c.queueAccount;
    }
    for (const key of [
      "confirmedFollowAt",
      "confirmedFollowAccount",
      "confirmedFollowSource",
      "relationshipObserved",
      "continuousSourceId",
      "continuousAuthorizationId",
      "queuedAction",
    ] as const)
      if (c[key] !== undefined) Object.assign(restored, { [key]: c[key] });
    if (
      ["queued", "attempting"].includes(c.stage) &&
      restored.queuedAction === undefined
    )
      restored.queuedAction = "follow";
    validateProspectingCandidate(
      restored,
      normalizeUsername(input.runtime?.account || "") || undefined,
      true,
    );
    return restored;
  });
  if (input.continuous !== undefined)
    state.continuous = structuredClone(input.continuous);
  validateContinuousState(
    state,
    normalizeUsername(input.runtime?.account || "") || undefined,
    true,
  );
  audit(
    state,
    "restore",
    "Backup restaurado. Conexão e execução não foram restauradas.",
  );
  return state;
}
