import type { Candidate, CandidateInput } from "./types.ts";
import { cleanInput } from "./domain.ts";

export function csvRows(text: string): string[][] {
  const rows: string[][] = [];
  let row: string[] = [],
    field = "",
    quoted = false;
  const firstLine = text.replace(/^\uFEFF/, "").split(/\r?\n/)[0];
  const separator =
    firstLine.includes(";") && !firstLine.includes(",") ? ";" : ",";
  text = text.replace(/^\uFEFF/, "");
  for (let i = 0; i < text.length; i++) {
    const ch = text[i];
    if (ch === '"') {
      if (quoted && text[i + 1] === '"') {
        field += '"';
        i++;
      } else quoted = !quoted;
    } else if (ch === separator && !quoted) {
      row.push(field);
      field = "";
    } else if ((ch === "\n" || ch === "\r") && !quoted) {
      if (ch === "\r" && text[i + 1] === "\n") i++;
      row.push(field);
      if (row.some(Boolean)) rows.push(row);
      row = [];
      field = "";
    } else field += ch;
  }
  if (quoted) throw new Error("O CSV tem aspas sem fechamento.");
  row.push(field);
  if (row.some(Boolean)) rows.push(row);
  return rows;
}
const count = (value: string | undefined): number | undefined =>
  value?.trim() && /^\d+$/.test(value.trim()) ? Number(value) : undefined;
export function parseCandidates(text: string): {
  candidates: CandidateInput[];
  invalid: number;
} {
  if (text.length > 5_000_000) throw new Error("O arquivo deve ter até 5 MB.");
  const rows = csvRows(text);
  if (!rows.length) return { candidates: [], invalid: 0 };
  const header = rows[0].map((c) => c.trim().toLowerCase());
  const aliases: Record<string, string[]> = {
    username: ["username", "usuario", "usuário", "perfil", "@perfil"],
    name: ["name", "nome"],
    bio: ["bio", "biografia"],
    followers: ["followers", "seguidores"],
    following: ["following", "seguindo", "seguidos"],
    posts: ["posts", "publicacoes", "publicações"],
    isPrivate: ["is_private", "private", "privado"],
    platformId: ["platform_id", "instagram_id"],
    avatarUrl: ["avatar_url", "profile_picture_url", "foto_url"],
  };
  const hasHeader = aliases.username.some((s) => header.includes(s));
  const index = (key: string) =>
    header.findIndex((s) => aliases[key].includes(s));
  const result: CandidateInput[] = [];
  let invalid = 0;
  for (const row of hasHeader ? rows.slice(1) : rows) {
    const get = (key: string) => row[index(key)];
    let rawUsername = hasHeader ? get("username") || "" : row[0];
    if (/^https:\/\/(?:www\.)?instagram\.com\//i.test(rawUsername)) {
      try {
        rawUsername =
          new URL(rawUsername).pathname.split("/").filter(Boolean)[0] || "";
      } catch {
        /* invalid below */
      }
    }
    const privateValue = hasHeader
      ? get("isPrivate")?.toLowerCase().trim()
      : undefined;
    const value = cleanInput({
      username: rawUsername,
      name: hasHeader ? get("name") : "",
      bio: hasHeader ? get("bio") : undefined,
      followers: hasHeader ? count(get("followers")) : undefined,
      following: hasHeader ? count(get("following")) : undefined,
      posts: hasHeader ? count(get("posts")) : undefined,
      platformId: hasHeader ? get("platformId") : undefined,
      avatarUrl: hasHeader ? get("avatarUrl") : undefined,
      isPrivate: ["true", "1", "sim"].includes(privateValue || "")
        ? true
        : ["false", "0", "nao", "não"].includes(privateValue || "")
          ? false
          : undefined,
    });
    if (value) result.push(value);
    else invalid++;
  }
  if (result.length > 10000)
    throw new Error("Importe até 10.000 perfis por vez.");
  return { candidates: result, invalid };
}
export function exportCsv(candidates: Candidate[]): string {
  const escape = (value: unknown) => {
    let s = String(value ?? "");
    if (/^[\s]*[=+\-@]/.test(s)) s = `'${s}`;
    return `"${s.replace(/"/g, '""')}"`;
  };
  return (
    "\uFEFF" +
    [
      [
        "username",
        "name",
        "bio",
        "followers",
        "following",
        "posts",
        "is_private",
        "stage",
        "note",
        "avatar_url",
      ],
      ...candidates.map((c) => [
        c.username,
        c.name,
        c.bio,
        c.followers,
        c.following,
        c.posts,
        c.isPrivate,
        c.stage,
        c.note,
        c.avatarUrl,
      ]),
    ]
      .map((row) => row.map(escape).join(","))
      .join("\r\n")
  );
}
export function download(name: string, content: string, type: string): void {
  const url = URL.createObjectURL(new Blob([content], { type }));
  const a = document.createElement("a");
  a.href = url;
  a.download = name;
  a.click();
  setTimeout(() => URL.revokeObjectURL(url), 1000);
}
