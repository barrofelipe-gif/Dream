import type { AccountWorkspace } from "./types.ts";
import { relationshipAnalysis } from "./relationships.ts";

/** Availability is derived only from this workspace. A missing measurement is never a zero. */
export function accountDataReadiness(account: AccountWorkspace) {
  const own = account.username;
  const history = relationshipAnalysis(account.relationships);
  const current =
    history.current?.account === own ? history.current : undefined;
  const profile = [...account.snapshots].sort((a, b) =>
    Date.parse(b.at) - Date.parse(a.at),
  )[0];
  const acquisition =
    own && account.acquisition?.account === own
      ? account.acquisition
      : undefined;
  const origins = acquisition?.assignments || [];
  const channelReports = acquisition?.reports || [];
  const market = account.market?.account === own ? account.market : undefined;
  const reports = (account.insights || []).filter((r) => r.account === own);
  const references = market?.references.filter((r) => !r.archived) || [];
  return {
    account: own,
    profile,
    network: {
      status: !current
        ? "missing"
        : current.followersComplete && current.followingComplete
          ? "complete"
          : "partial",
      snapshot: current,
      canCompareLosses: !!current && history.comparable,
      canCheckAbsence: !!current?.followersComplete,
    },
    acquisition: {
      measuredFollowers: current?.followers.length,
      origins,
      channelReports,
      status: !current
        ? "missing_membership"
        : origins.length
          ? "declared"
          : "unknown_origins",
      // Campaign sources are discovery history, never proof of incoming followers.
      discoveryProfiles: account.data.candidates.length,
      discoverySources: account.data.campaigns.filter((c) => !c.archived)
        .length,
    },
    market: {
      profile: market?.profile,
      references,
      status: !market?.profile
        ? "missing_context"
        : !references.length
          ? "missing_references"
          : "ready",
      measuredReferences: references.filter(
        (r) => Object.keys(r.metrics).length > 0,
      ).length,
    },
    insights: {
      reports: reports.length,
      latest: reports.toSorted((a, b) =>
        Date.parse(b.recordedAt) - Date.parse(a.recordedAt),
      )[0],
    },
  } as const;
}
