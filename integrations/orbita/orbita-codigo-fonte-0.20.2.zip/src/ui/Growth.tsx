import { useState } from "react";
import { Download, FlaskConical, Plus, Target, TrendingUp } from "lucide-react";
import type {
  AccountCommand,
  ContentKind,
  InsightContent,
  InsightReport,
} from "../core/types.ts";
import {
  CONTENT_LABELS,
  COVERAGE_LABELS,
  contentRevision,
  localDay,
  metricSpec,
  STORY_MEDIA_LABELS,
  STORY_STICKER_LABELS,
} from "../core/insights.ts";
import {
  GROWTH_DIMENSIONS,
  GROWTH_OBJECTIVES,
  contentPerformance,
  defaultGrowthWindow,
  growthAnalysis,
  growthWindows,
} from "../core/growth.ts";
import type { GrowthObjective } from "../core/growth.ts";
import { download } from "../core/io.ts";
import { uid } from "../core/domain.ts";
import { Empty, Field, Modal } from "./components.tsx";
import { GuidancePanel } from "./Guidance.tsx";
import { contentGuidance } from "../core/guidance.ts";
import { ContentCover } from "./ContentCover.tsx";

const decimal = (value: number | undefined) =>
  value === undefined
    ? "—"
    : new Intl.NumberFormat("pt-BR", { maximumFractionDigits: 2 }).format(
        value,
      );
const valueLabel = (value: number | undefined, objective: GrowthObjective) =>
  value === undefined
    ? "—"
    : `${decimal(value)}${objective === "engagementRate" ? "%" : ""}`;
type Run = (command: AccountCommand, success?: string) => Promise<boolean>;
export function GrowthPanel({
  report,
  onRecord,
  onOpen,
  canRecord,
}: {
  report?: InsightReport;
  onRecord: (c?: InsightContent) => void;
  onOpen: (c: InsightContent) => void;
  canRecord: boolean;
}) {
  const [objective, setObjective] =
      useState<GrowthObjective>("followersPer1000"),
    [window, setWindow] = useState("auto"),
    [format, setFormat] = useState<ContentKind | "all">("all"),
    [timeZone, setTimeZone] = useState(
      () => Intl.DateTimeFormat().resolvedOptions().timeZone,
    );
  if (!report)
    return (
      <section className="growth-empty">
        <Empty
          icon={<FlaskConical size={26} />}
          title="Descubra quais publicações valem um novo teste"
          text="Registre engajamento e seguidores atribuídos por publicação. O painel compara resultados e identifica hipóteses para repetir com novas medições."
          action={
            <button
              className="button primary"
              disabled={!canRecord}
              onClick={() => onRecord()}
            >
              <Plus size={16} />
              Registrar primeira publicação
            </button>
          }
        />
      </section>
    );
  const windowValue =
    window === "auto" ||
    window === "all" ||
    growthWindows(report, format).includes(Number(window))
      ? window
      : "auto";
  const selectedWindow =
    windowValue === "auto"
      ? defaultGrowthWindow(report, format)
      : windowValue === "all"
        ? "all"
        : Number(windowValue);
  const analysis = growthAnalysis(report, {
    objective,
    window: selectedWindow,
    format,
  });
  const bestFollows = [...analysis.cohort]
    .filter((r) => r.follows !== undefined)
    .sort((a, b) => b.follows! - a.follows!)[0];
  const bestEfficiency = [...analysis.cohort]
    .filter((r) => r.followersPer1000 !== undefined)
    .sort((a, b) => b.followersPer1000! - a.followersPer1000!)[0];
  const bestEngagement = [...analysis.cohort]
    .filter((r) => r.engagementRate !== undefined)
    .sort((a, b) => b.engagementRate! - a.engagementRate!)[0];
  return (
    <section className="growth-panel" aria-label="Aprendizados por publicação">
      <div className="growth-heading">
        <div>
          <h3>O que funcionou neste recorte</h3>
          <p>
            Resultados por publicação, eficiência e hipóteses para o próximo
            teste.
          </p>
        </div>
        <div className="metrics-actions">
          <button
            className="button secondary"
            onClick={() =>
              download(
                `orbita-${report.account}-aprendizados.json`,
                JSON.stringify(
                  {
                    account: report.account,
                    reportId: report.id,
                    start: report.start,
                    end: report.end,
                    coverage: report.coverage,
                    contentWindow: report.contentWindow,
                    objective,
                    format,
                    observationHours: selectedWindow,
                    timeZone,
                    guidance: contentGuidance(report, {
                      objective,
                      window: selectedWindow,
                      format,
                      timeZone,
                    }),
                    hypotheses: analysis.hypotheses,
                    groups: analysis.groups,
                    ranking: analysis.ranking,
                  },
                  null,
                  2,
                ),
                "application/json",
              )
            }
          >
            <Download size={15} />
            Exportar análise
          </button>
          <button className="button primary" onClick={() => onRecord()}>
            <Plus size={15} />
            Registrar publicação
          </button>
        </div>
      </div>
      <div className="growth-controls">
        <Field label="Objetivo da análise">
          <select
            value={objective}
            onChange={(e) => setObjective(e.target.value as GrowthObjective)}
          >
            {Object.entries(GROWTH_OBJECTIVES).map(([key, label]) => (
              <option key={key} value={key}>
                {label}
              </option>
            ))}
          </select>
        </Field>
        <Field label="Janela de medição">
          <select
            value={windowValue}
            onChange={(e) => setWindow(e.target.value)}
          >
            <option value="auto">
              Automático ·{" "}
              {defaultGrowthWindow(report, format) === "all"
                ? "sem janela comum"
                : `primeiras ${defaultGrowthWindow(report, format)}h`}
            </option>
            <option value="all">Explorar todas as janelas</option>
            {analysis.availableWindows.map((hours) => (
              <option value={hours} key={hours}>
                Primeiras {hours} horas
              </option>
            ))}
          </select>
        </Field>
        <Field label="Formato para análise">
          <select
            value={format}
            onChange={(e) => {
              setFormat(e.target.value as ContentKind | "all");
              if (e.target.value === "story") setObjective("engagementRate");
            }}
          >
            <option value="all">Todos os formatos</option>
            {Object.entries(CONTENT_LABELS).map(([key, label]) => (
              <option key={key} value={key}>
                {label}
              </option>
            ))}
          </select>
        </Field>
      </div>
      <div className="growth-data-coverage">
        <span>
          <b>
            {analysis.coverage.attributedFollowers}/
            {analysis.coverage.publications}
          </b>{" "}
          com seguidores atribuídos
        </span>
        <span>
          <b>
            {analysis.coverage.positiveReach}/{analysis.coverage.publications}
          </b>{" "}
          com alcance positivo
        </span>
        <span>
          <b>
            {analysis.coverage.standardWindow}/{analysis.coverage.publications}
          </b>{" "}
          com janela no período
        </span>
        <span>
          {COVERAGE_LABELS[report.coverage]} · {analysis.cohort.length}{" "}
          publicações no recorte
        </span>
      </div>
      {analysis.metadataGaps.some((g) => g.missing > 0) ? (
        <p className="insights-note">
          Neste recorte com taxa calculável:{" "}
          {analysis.metadataGaps
            .filter((g) => g.missing > 0)
            .map(
              (g) =>
                `${g.missing}/${g.total} sem ${GROWTH_DIMENSIONS[g.dimension].toLocaleLowerCase("pt-BR")}`,
            )
            .join(" · ")}
          . Valores não classificados ficam fora do contraste dessa dimensão.
        </p>
      ) : null}
      <p className="insights-note">
        Seguidores atribuídos vêm do dado informado para cada publicação. Não
        distribuímos o crescimento da conta entre posts e não usamos ações de
        seguir da Órbita. Interações/alcance = total_interactions ÷ reach × 100;
        seguidores por mil = follows ÷ reach × 1.000. Campos ausentes ficam sem
        cálculo.
      </p>
      <div className="growth-highlights">
        {[
          {
            label: "Mais seguidores atribuídos",
            row: bestFollows,
            value: bestFollows?.follows,
            unit: "",
          },
          {
            label: "Maior eficiência em seguidores",
            row: bestEfficiency,
            value: bestEfficiency?.followersPer1000,
            unit: " por mil alcançadas",
          },
          {
            label: "Maior taxa de interações",
            row: bestEngagement,
            value: bestEngagement?.engagementRate,
            unit: "%",
          },
        ].map((card) => (
          <div className="growth-highlight" key={card.label}>
            <span>{card.label}</span>
            <strong>
              {decimal(card.value)}
              {card.value !== undefined ? <small>{card.unit}</small> : null}
            </strong>
            {card.row ? (
              <button
                className="text-link"
                onClick={() => onOpen(card.row!.content)}
              >
                {card.row.content.title}
              </button>
            ) : (
              <p>Preencha os dados da publicação para comparar.</p>
            )}
          </div>
        ))}
      </div>
      <GuidancePanel
        report={report}
        objective={objective}
        window={selectedWindow}
        format={format}
        timeZone={timeZone}
        onTimeZone={setTimeZone}
        onRecord={() => onRecord()}
      />
      <section className="growth-lessons">
        <div className="growth-section-heading">
          <FlaskConical size={18} />
          <h3>Hipóteses para repetir e medir</h3>
        </div>
        {analysis.hypotheses.length ? (
          <div className="growth-hypotheses">
            {analysis.hypotheses.map((p) => (
              <article key={`${p.dimension}|${p.label}`}>
                <span className="eyebrow">
                  {GROWTH_DIMENSIONS[p.dimension]}
                </span>
                <h4>{p.label}</h4>
                <p>
                  <b>{p.n} publicações</b> tiveram mediana de{" "}
                  <b>{valueLabel(p.value, analysis.patternObjective)}</b>,
                  frente a {valueLabel(p.reference, analysis.patternObjective)}{" "}
                  em {p.otherN} publicações dos outros grupos informados.
                </p>
                <small>
                  {GROWTH_OBJECTIVES[analysis.patternObjective]} · primeiras{" "}
                  {selectedWindow} horas
                </small>
                <div className="growth-test-direction">
                  <Target size={17} />
                  <p>
                    Use esse padrão em outra publicação. Mantenha os demais
                    elementos estáveis e compare na mesma janela antes de
                    ampliar a repetição.
                  </p>
                </div>
                <button className="text-link" onClick={() => onOpen(p.best)}>
                  Ver exemplo do grupo ↗
                </button>
              </article>
            ))}
          </div>
        ) : (
          <div className="growth-insufficient">
            <strong>
              {analysis.reasons.length
                ? "Ainda faltam dados comparáveis"
                : "Nenhum grupo se destacou com contraste suficiente"}
            </strong>
            {analysis.reasons.length ? (
              analysis.reasons.map((reason) => <p key={reason}>{reason}</p>)
            ) : (
              <p>
                Não forçamos um vencedor. Complete tema, abertura e chamada para
                ação; cada hipótese exige pelo menos 3 publicações no grupo e 3
                com outro valor conhecido.
              </p>
            )}
            <button className="text-link" onClick={() => onRecord()}>
              Registrar ou completar uma publicação <Plus size={14} />
            </button>
          </div>
        )}
        <p className="insights-note">
          São sinais observados nesta amostra, sem prova de causa ou garantia de
          crescimento. O mínimo de 3 por grupo é um controle do produto, não
          comprovação estatística. Filtre um formato para comparar temas e
          chamadas com menos diferenças entre conteúdos. Seguidores totais são
          normalizados por alcance nas hipóteses. Os padrões podem se sobrepor.
          Confira também o alcance: taxas altas em poucas contas merecem novos
          testes.
        </p>
      </section>
      <div className="growth-section-heading">
        <TrendingUp size={18} />
        <h3>Ranking por publicação</h3>
      </div>
      {analysis.ranking.length ? (
        <div className="table-scroll growth-ranking">
          <table>
            <thead>
              <tr>
                <th>PUBLICAÇÃO</th>
                <th>FORMATO / TEMA</th>
                <th>SEGUIDORES ATRIBUÍDOS</th>
                <th>INTERAÇÕES</th>
                <th>ALCANCE</th>
                <th>INTERAÇÕES / ALCANCE</th>
                <th>SEGUIDORES / MIL</th>
                <th>JANELA INFORMADA</th>
                <th />
              </tr>
            </thead>
            <tbody>
              {analysis.ranking.map((row, index) => (
                <tr key={row.content.id}>
                  <td>
                    <button
                      className="text-link publication-link"
                      onClick={() => onOpen(row.content)}
                    >
                      <ContentCover content={row.content} />
                      <span>
                        <span className="publication-rank">#{index + 1}</span>
                        <span className="publication-title">
                          {row.content.title}
                        </span>
                      </span>
                    </button>
                  </td>
                  <td>
                    {CONTENT_LABELS[row.content.kind]}
                    <small>{row.content.theme || "Tema não informado"}</small>
                    {row.content.kind === "story" ? (
                      <small>
                        {[
                          row.content.storyMedia
                            ? STORY_MEDIA_LABELS[row.content.storyMedia]
                            : "Mídia não informada",
                          row.content.storySticker
                            ? STORY_STICKER_LABELS[row.content.storySticker]
                            : "Figurinha não informada",
                        ].join(" · ")}
                      </small>
                    ) : null}
                  </td>
                  <td>{decimal(row.follows)}</td>
                  <td>{decimal(row.interactions)}</td>
                  <td>{decimal(row.reach)}</td>
                  <td>
                    {row.engagementRate === undefined
                      ? "—"
                      : `${decimal(row.engagementRate)}%`}
                  </td>
                  <td>{decimal(row.followersPer1000)}</td>
                  <td>
                    {report.contentWindow === "lifetime"
                      ? "Vida inteira"
                      : row.content.observationHours
                        ? `Primeiras ${row.content.observationHours}h`
                        : "Sem padronização"}
                  </td>
                  <td>
                    <button
                      className="text-link"
                      onClick={() => onRecord(row.content)}
                      aria-label={`Editar medição de ${row.content.title}`}
                    >
                      Editar medição
                    </button>
                  </td>
                </tr>
              ))}
            </tbody>
          </table>
        </div>
      ) : (
        <Empty
          title="Sem valores para ordenar neste objetivo"
          text="Escolha outro objetivo, ajuste a janela ou informe seguidores atribuídos e alcance na medição da publicação."
        />
      )}
      <details className="growth-group-details">
        <summary>
          Ver medianas e amostras · até 50 grupos na tela, todos na exportação
        </summary>
        <div className="table-scroll">
          <table>
            <thead>
              <tr>
                <th>DIMENSÃO</th>
                <th>GRUPO</th>
                <th>PUBLICAÇÕES</th>
                <th>MEDIANA</th>
                <th>OUTROS GRUPOS</th>
                <th>LEITURA</th>
              </tr>
            </thead>
            <tbody>
              {analysis.groups.slice(0, 50).map((g) => (
                <tr key={`${g.dimension}|${g.label}`}>
                  <td>{GROWTH_DIMENSIONS[g.dimension]}</td>
                  <td>{g.label}</td>
                  <td>{g.n}</td>
                  <td>{valueLabel(g.value, analysis.patternObjective)}</td>
                  <td>
                    {valueLabel(g.reference, analysis.patternObjective)} · n=
                    {g.otherN}
                  </td>
                  <td>
                    {g.qualified
                      ? "Comparável neste recorte"
                      : "Amostra ou contexto insuficiente"}
                  </td>
                </tr>
              ))}
            </tbody>
          </table>
        </div>
      </details>
      <p className="insights-note">
        Na janela padronizada, entram publicações com data de publicação dentro
        de {report.start} a {report.end}. A opção “Explorar todas” permite
        inspeção dos valores, mas não produz hipóteses automáticas. Uma
        publicação antiga pode ter acumulado mais tempo de exposição.
      </p>
    </section>
  );
}
const ENTRY_METRICS = [
  "follows",
  "total_interactions",
  "reach",
  "views",
  "likes",
  "comments",
  "saves",
  "shares",
  "profile_visits",
  "avg_watch_time_seconds",
  "replies",
  "question_answers",
  "sticker_taps",
  "story_exits",
] as const;
function localInput(iso?: string) {
  if (!iso) return "";
  const d = new Date(iso);
  return `${localDay(d)}T${String(d.getHours()).padStart(2, "0")}:${String(d.getMinutes()).padStart(2, "0")}`;
}
function explicitTime(local: string) {
  const d = new Date(local),
    offset = -d.getTimezoneOffset(),
    sign = offset >= 0 ? "+" : "-",
    absolute = Math.abs(offset);
  return `${local}:00${sign}${String(Math.floor(absolute / 60)).padStart(2, "0")}:${String(absolute % 60).padStart(2, "0")}`;
}
export function ContentEntry({
  account,
  report: initialReport,
  content,
  run,
  onSaved,
  onClose,
  busy,
}: {
  account: string;
  report?: InsightReport;
  content?: InsightContent;
  run: Run;
  onSaved: (r: InsightReport) => void;
  onClose: () => void;
  busy: boolean;
}) {
  const [report] = useState(initialReport);
  const [id] = useState(() => content?.id || uid());
  const start = new Date();
  start.setDate(start.getDate() - 6);
  const [period, setPeriod] = useState({
    start: report?.start || localDay(start),
    end: report?.end || localDay(),
    coverage: report?.coverage || "unknown",
    contentWindow: report?.contentWindow || "period",
  });
  const [fields, setFields] = useState({
    title: content?.title || "",
    kind: content?.kind || "reel",
    url: content?.url || "",
    theme: content?.theme || "",
    hook: content?.hook || "",
    cta: content?.cta || "",
    published: localInput(content?.publishedAt),
    hours: content?.observationHours?.toString() || "",
    storyMedia: content?.storyMedia || "",
    storySticker: content?.storySticker || "",
  });
  const [metrics, setMetrics] = useState<Record<string, string>>(() =>
      Object.fromEntries(
        ENTRY_METRICS.map((key) => [
          key,
          content?.metrics[key]?.toString() || "",
        ]),
      ),
    ),
    [error, setError] = useState("");
  const applicableMetrics = ENTRY_METRICS.filter(
    (key) => fields.kind === "story" || !["question_answers", "sticker_taps", "story_exits"].includes(key),
  );
  return (
    <Modal
      title={
        content
          ? "Editar medição da publicação"
          : "Registrar publicação e resultado"
      }
      subtitle={`@${account} · dados manuais dos Insights desta publicação`}
      onClose={onClose}
      wide
    >
      <form
        onSubmit={async (e) => {
          e.preventDefault();
          setError("");
          try {
            const values = { ...(content?.metrics || {}) };
            for (const key of ENTRY_METRICS) {
              if (!applicableMetrics.includes(key) || metrics[key] === "") delete values[key];
              else values[key] = Number(metrics[key]);
            }
            const publishedAt = fields.published
              ? content?.publishedAt &&
                fields.published === localInput(content.publishedAt)
                ? content.publishedAt
                : explicitTime(fields.published)
              : undefined;
            const revision = contentRevision(report, account, period, {
              id,
              kind: fields.kind,
              title: fields.title,
              url: fields.url || undefined,
              thumbnailUrl:
                fields.url === (content?.url || "")
                  ? content?.thumbnailUrl
                  : undefined,
              theme: fields.theme,
              hook: fields.hook,
              cta: fields.cta,
              storyMedia:
                fields.kind === "story"
                  ? fields.storyMedia || undefined
                  : undefined,
              storySticker:
                fields.kind === "story"
                  ? fields.storySticker || undefined
                  : undefined,
              publishedAt,
              observationHours:
                period.contentWindow === "lifetime" || fields.hours === ""
                  ? undefined
                  : Number(fields.hours),
              metrics: values,
            });
            if (
              await run(
                { type: "RECORD_INSIGHTS", data: revision },
                "Medição registrada no relatório desta conta.",
              )
            ) {
              onSaved(revision);
              onClose();
            }
          } catch (err) {
            setError(
              err instanceof Error
                ? err.message
                : "Não foi possível salvar a publicação.",
            );
          }
        }}
      >
        {report ? (
          <p className="insights-note">
            Relatório: {report.start} a {report.end} ·{" "}
            {report.contentWindow === "lifetime"
              ? "vida inteira"
              : "recorte de período"}{" "}
            · {COVERAGE_LABELS[report.coverage]}. Salvar uma alteração cria uma
            versão manual; a original fica no histórico.
          </p>
        ) : (
          <div className="form-grid">
            <Field label="Início do relatório">
              <input
                required
                type="date"
                max={period.end}
                value={period.start}
                onChange={(e) =>
                  setPeriod({ ...period, start: e.target.value })
                }
              />
            </Field>
            <Field label="Fim do relatório">
              <input
                required
                type="date"
                min={period.start}
                max={localDay()}
                value={period.end}
                onChange={(e) => setPeriod({ ...period, end: e.target.value })}
              />
            </Field>
            <Field label="Cobertura dos dados da publicação">
              <select
                value={period.coverage}
                onChange={(e) =>
                  setPeriod({
                    ...period,
                    coverage: e.target.value as InsightReport["coverage"],
                  })
                }
              >
                {Object.entries(COVERAGE_LABELS).map(([key, label]) => (
                  <option key={key} value={key}>
                    {label}
                  </option>
                ))}
              </select>
            </Field>
          </div>
        )}
        <div className="form-grid">
          <Field label="Nome da publicação">
            <input
              required
              maxLength={180}
              value={fields.title}
              onChange={(e) => setFields({ ...fields, title: e.target.value })}
              placeholder="Ex.: 3 erros na escolha do produto"
            />
          </Field>
          <Field label="Formato da publicação">
            <select
              value={fields.kind}
              onChange={(e) =>
                setFields({ ...fields, kind: e.target.value as ContentKind })
              }
            >
              {Object.entries(CONTENT_LABELS).map(([key, label]) => (
                <option key={key} value={key}>
                  {label}
                </option>
              ))}
            </select>
          </Field>
          <Field
            label="Link da publicação"
            hint="Opcional. Ajuda a identificar a mesma publicação em outras medições."
          >
            <input
              type="url"
              value={fields.url}
              onChange={(e) => setFields({ ...fields, url: e.target.value })}
              placeholder="https://www.instagram.com/reel/…"
            />
          </Field>
          {fields.kind === "story" ? (
            <>
              <Field label="Mídia do Story">
                <select
                  value={fields.storyMedia}
                  onChange={(e) =>
                    setFields({ ...fields, storyMedia: e.target.value })
                  }
                >
                  <option value="">Não informado</option>
                  {Object.entries(STORY_MEDIA_LABELS).map(([key, label]) => (
                    <option key={key} value={key}>
                      {label}
                    </option>
                  ))}
                </select>
              </Field>
              <Field
                label="Figurinha do Story"
                hint="Informe sem figurinha quando não usou. Foto e caixinha podem estar no mesmo Story."
              >
                <select
                  value={fields.storySticker}
                  onChange={(e) =>
                    setFields({ ...fields, storySticker: e.target.value })
                  }
                >
                  <option value="">Não informado</option>
                  {Object.entries(STORY_STICKER_LABELS).map(([key, label]) => (
                    <option key={key} value={key}>
                      {label}
                    </option>
                  ))}
                </select>
              </Field>
            </>
          ) : null}
          <Field
            label="Data e hora da publicação"
            hint={`Fuso do navegador: ${Intl.DateTimeFormat().resolvedOptions().timeZone}.`}
          >
            <input
              type="datetime-local"
              value={fields.published}
              onChange={(e) =>
                setFields({ ...fields, published: e.target.value })
              }
            />
          </Field>
          <Field
            label="Primeiras quantas horas foram medidas?"
            hint={
              period.contentWindow === "lifetime"
                ? "Vida inteira é exploratória. Use um relatório de período para registrar resultados das primeiras horas."
                : "Ex.: 48 para os resultados das primeiras 48h. Informe o recorte realmente consultado, sem dividir o total por tempo."
            }
          >
            <input
              type="number"
              min="1"
              max="8760"
              disabled={period.contentWindow === "lifetime"}
              step="1"
              value={fields.hours}
              onChange={(e) => setFields({ ...fields, hours: e.target.value })}
              placeholder="Não padronizado"
            />
          </Field>
          <Field label="Tema da publicação">
            <input
              maxLength={100}
              value={fields.theme}
              onChange={(e) => setFields({ ...fields, theme: e.target.value })}
              placeholder="Dicas, bastidores, produto…"
            />
          </Field>
          <Field label="Tipo de abertura">
            <input
              maxLength={100}
              value={fields.hook}
              onChange={(e) => setFields({ ...fields, hook: e.target.value })}
              placeholder="Pergunta, lista, antes e depois…"
            />
          </Field>
          <Field label="Chamada para ação">
            <input
              maxLength={100}
              value={fields.cta}
              onChange={(e) => setFields({ ...fields, cta: e.target.value })}
              placeholder="Seguir, salvar, comentar…"
            />
          </Field>
        </div>
        <div className="growth-entry-metrics">
          <h3>Resultados informados na publicação</h3>
          <div className="form-grid">
            {applicableMetrics.map((key) => (
              <Field
                key={key}
                label={
                  key === "follows"
                    ? "Seguidores atribuídos a esta publicação"
                    : metricSpec(key)!.label +
                      (metricSpec(key)!.unit === "seconds" ? " · segundos" : "")
                }
                hint={
                  key === "follows"
                    ? "Copie apenas se esse dado estiver disponível nos Insights da publicação. Deixe vazio quando desconhecido."
                    : undefined
                }
              >
                <input
                  type="number"
                  min="0"
                  step={metricSpec(key)!.unit === "seconds" ? "any" : "1"}
                  value={metrics[key]}
                  placeholder="Não informado"
                  onChange={(e) =>
                    setMetrics({ ...metrics, [key]: e.target.value })
                  }
                />
              </Field>
            ))}
          </div>
        </div>
        <p className="insights-note">
          As taxas usam alcance e interações desta publicação. O crescimento
          total da conta não comprova que um post trouxe os seguidores. Nunca
          preencha valores desconhecidos com zero para completar a análise.
        </p>
        {error ? (
          <div className="notice error" role="alert">
            {error}
          </div>
        ) : null}
        <div className="modal-actions">
          <button className="button secondary" type="button" onClick={onClose}>
            Cancelar
          </button>
          <button className="button primary" disabled={busy}>
            Salvar medição da publicação
          </button>
        </div>
      </form>
    </Modal>
  );
}
