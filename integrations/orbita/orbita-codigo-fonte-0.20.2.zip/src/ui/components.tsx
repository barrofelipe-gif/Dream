import {
  createContext,
  useContext,
  useEffect,
  useId,
  useMemo,
  useRef,
  useState,
} from "react";
import { createPortal } from "react-dom";
import { reportProblem } from "../problems-client.ts";
import {
  X,
  ArrowUpRight,
  UsersRound,
  UserRoundPlus,
  Heart,
  MessageCircle,
  Hash,
  MapPin,
  FileText,
  Check,
  CircleHelp,
} from "lucide-react";
import type { ReactNode, FormEvent } from "react";
import type {
  AccountWorkspace,
  Campaign,
  SourceKind,
  Stage,
} from "../core/types.ts";
import { SOURCE_LABELS, STAGE_LABELS } from "../core/types.ts";
import { profilePhotoUrl } from "../core/photos.ts";

const ProfilePhotos = createContext<ReadonlyMap<string, string>>(new Map());
export function ProfilePhotosProvider({
  account,
  children,
}: {
  account: AccountWorkspace;
  children: ReactNode;
}) {
  const photos = useMemo(() => {
    const result = new Map<string, string>();
    for (const candidate of account.data.candidates) {
      const url = profilePhotoUrl(candidate.avatarUrl);
      if (url && candidate.username !== account.username)
        result.set(candidate.username, url);
    }
    const own = profilePhotoUrl(account.avatarUrl);
    if (own && account.username) result.set(account.username, own);
    return result;
  }, [account.data.candidates, account.username, account.avatarUrl]);
  return (
    <ProfilePhotos.Provider value={photos}>{children}</ProfilePhotos.Provider>
  );
}

export function Toast({
  message,
  error,
  onClose,
}: {
  message: string;
  error: boolean;
  onClose: () => void;
}) {
  const [target, setTarget] = useState<Element>(
    () => document.querySelector("dialog[open]") || document.body,
  );
  useEffect(() => {
    const update = () =>
      setTarget(document.querySelector("dialog[open]") || document.body);
    const observer = new MutationObserver(update);
    observer.observe(document.body, {
      childList: true,
      subtree: true,
      attributes: true,
      attributeFilter: ["open"],
    });
    update();
    return () => observer.disconnect();
  }, []);
  useEffect(() => {
    if (error) void reportProblem(message, { source: "visible" });
  }, [message, error]);
  return createPortal(
    <div
      className={`toast ${error ? "error" : ""}`}
      data-problem-capture="skip"
      role={error ? "alert" : "status"}
    >
      {error ? <CircleHelp size={19} /> : <Check size={19} />}
      <span>{message}</span>
      <button
        className="icon-button"
        aria-label="Dispensar mensagem"
        onClick={onClose}
      >
        <X size={16} />
      </button>
    </div>,
    target,
  );
}

export const number = (value: number | undefined) =>
  value === undefined
    ? "—"
    : new Intl.NumberFormat("pt-BR", {
        notation: value >= 10000 ? "compact" : "standard",
        maximumFractionDigits: 1,
      }).format(value);
export const date = (value: string) =>
  new Intl.DateTimeFormat("pt-BR", {
    day: "2-digit",
    month: "short",
    hour: "2-digit",
    minute: "2-digit",
  }).format(new Date(value));
export const SOURCE_ICONS = {
  followers: UsersRound,
  following: UserRoundPlus,
  commenters: MessageCircle,
  likers: Heart,
  hashtag: Hash,
  location: MapPin,
  import: FileText,
};
export function SourceIcon({
  kind,
  size = 19,
}: {
  kind: SourceKind;
  size?: number;
}) {
  const Icon = SOURCE_ICONS[kind];
  return <Icon size={size} />;
}
export function Badge({ stage }: { stage: Stage }) {
  return (
    <span className={`badge ${stage}`}>
      <i />
      {STAGE_LABELS[stage]}
    </span>
  );
}
export function SourceBadge({ campaign }: { campaign?: Campaign }) {
  return campaign ? (
    <span className={`source-badge ${campaign.kind}`}>
      <SourceIcon kind={campaign.kind} size={12} />
      {campaign.name}
    </span>
  ) : (
    <span className="muted">Fonte indisponível</span>
  );
}
export function Avatar({
  username,
  name,
  src,
  large = false,
}: {
  username: string;
  name?: string;
  src?: string;
  large?: boolean;
}) {
  const known = useContext(ProfilePhotos);
  const url = profilePhotoUrl(src === undefined ? known.get(username) : src);
  const [failed, setFailed] = useState<string>();
  const hash = [...username].reduce((n, char) => n + char.charCodeAt(0), 0);
  return (
    <span
      className={`avatar ${large ? "large" : ""} color-${hash % 5}`}
      aria-hidden="true"
    >
      {(name || username).slice(0, 2).toUpperCase()}
      {url && failed !== url ? (
        <img
          src={url}
          alt=""
          loading="lazy"
          decoding="async"
          referrerPolicy="no-referrer"
          onError={() => setFailed(url)}
        />
      ) : null}
    </span>
  );
}
export function Empty({
  icon,
  title,
  text,
  action,
}: {
  icon?: ReactNode;
  title: string;
  text: string;
  action?: ReactNode;
}) {
  return (
    <div className="empty">
      <div className="empty-icon">{icon || <UsersRound size={25} />}</div>
      <h3>{title}</h3>
      <p>{text}</p>
      {action}
    </div>
  );
}
export function Modal({
  title,
  subtitle,
  children,
  onClose,
  wide = false,
}: {
  title: string;
  subtitle?: string;
  children: ReactNode;
  onClose: () => void;
  wide?: boolean;
}) {
  const ref = useRef<HTMLDialogElement>(null);
  const titleId = useId();
  const subtitleId = useId();
  useEffect(() => {
    const dialog = ref.current!;
    dialog.showModal();
    dialog
      .querySelector<HTMLElement>("input:not([type=file]), select, textarea")
      ?.focus();
    return () => dialog.close();
  }, []);
  return (
    <dialog
      ref={ref}
      aria-labelledby={titleId}
      aria-describedby={subtitle ? subtitleId : undefined}
      className={`modal ${wide ? "wide" : ""}`}
      onCancel={(event) => {
        event.preventDefault();
        onClose();
      }}
      onClick={(event) => {
        if (event.target === ref.current) {
          const box = ref.current.getBoundingClientRect();
          if (
            event.clientX < box.left ||
            event.clientX > box.right ||
            event.clientY < box.top ||
            event.clientY > box.bottom
          )
            onClose();
        }
      }}
    >
      <div className="modal-heading">
        <div>
          <h2 id={titleId}>{title}</h2>
          {subtitle ? <p id={subtitleId}>{subtitle}</p> : null}
        </div>
        <button
          className="icon-button"
          aria-label="Fechar janela"
          onClick={onClose}
        >
          <X size={21} />
        </button>
      </div>
      {children}
    </dialog>
  );
}
export function Field({
  label,
  hint,
  children,
}: {
  label: string;
  hint?: string;
  children: ReactNode;
}) {
  return (
    <label className="field">
      <span>{label}</span>
      {children}
      {hint ? <small>{hint}</small> : null}
    </label>
  );
}
export function External({
  href,
  children,
}: {
  href: string;
  children: ReactNode;
}) {
  return (
    <a className="text-link" href={href} target="_blank" rel="noreferrer">
      {children}
      <ArrowUpRight size={14} />
    </a>
  );
}
export function Hint({ children }: { children: ReactNode }) {
  return (
    <div className="hint">
      <CircleHelp size={17} />
      <span>{children}</span>
    </div>
  );
}
export function FormButtons({
  onCancel,
  label,
  busy = false,
  disabled = false,
}: {
  onCancel: () => void;
  label: string;
  busy?: boolean;
  disabled?: boolean;
}) {
  return (
    <div className="modal-actions">
      <button type="button" className="button secondary" onClick={onCancel}>
        Cancelar
      </button>
      <button
        type="submit"
        className="button primary"
        disabled={busy || disabled}
      >
        {busy ? "Salvando…" : label}
        <Check size={16} />
      </button>
    </div>
  );
}
export function SourceSelector({
  kind,
  onChange,
}: {
  kind: SourceKind;
  onChange: (kind: SourceKind) => void;
}) {
  return (
    <div className="source-selector" role="group" aria-label="Fonte dos perfis">
      {(Object.keys(SOURCE_LABELS) as SourceKind[]).map((value) => (
        <button
          key={value}
          type="button"
          aria-pressed={kind === value}
          className={kind === value ? "selected" : ""}
          onClick={() => onChange(value)}
        >
          <SourceIcon kind={value} />
          <span>{SOURCE_LABELS[value]}</span>
          {kind === value ? <Check size={15} /> : null}
        </button>
      ))}
    </div>
  );
}
export function submit(
  event: FormEvent,
  action: () => Promise<void> | void,
): void {
  event.preventDefault();
  void action();
}
