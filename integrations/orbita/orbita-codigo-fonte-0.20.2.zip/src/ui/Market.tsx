import { useEffect, useRef, useState } from "react";
import {
  Archive,
  BookOpen,
  Download,
  Plus,
  Radar,
  Sparkles,
} from "lucide-react";
import { isExtension, readMarketPage } from "../bridge.ts";
import {
  adaptation,
  emptyMarket,
  experimentMeasurement,
  MARKET_MODELS,
  MARKET_PATTERNS,
  marketAnalysis,
  marketUrl,
  ownPatternMatches,
  saveMarketReferences,
  sectorLabel,
  suggestMarket,
} from "../core/market.ts";
import type {
  AccountCommand,
  AccountWorkspace,
  MarketExperiment,
  MarketModel,
  MarketPattern,
  MarketReference,
} from "../core/types.ts";
import { download } from "../core/io.ts";
import { MARKET_RESEARCH, researchReference } from "../core/market-seeds.ts";
import { AccountDataStatus } from "./AccountDataStatus.tsx";
import { CONTENT_LABELS } from "../core/insights.ts";
import { Empty, External, Field, Modal } from "./components.tsx";

type Run = (command: AccountCommand, success?: string) => Promise<boolean>;
const num = (n: number | undefined) =>
  n === undefined
    ? "—"
    : new Intl.NumberFormat("pt-BR", { maximumFractionDigits: 2 }).format(n);
const date = (s: string) => new Date(s).toLocaleString("pt-BR");
const localInput = (s: string) => {
  const d = new Date(s);
  return new Date(d.getTime() - d.getTimezoneOffset() * 60000)
    .toISOString()
    .slice(0, 16);
};
const nowInput = () => localInput(new Date().toISOString());
const KINDS = {
  ...CONTENT_LABELS,
  ad: "Anúncio",
  article: "Página / perfil de referência",
};
const SOURCES = {
  manual: "Registro revisado manualmente",
  file: "Arquivo importado",
  instagram: "Página carregada",
};

export function MarketPage({
  account,
  run,
  busy,
}: {
  account: AccountWorkspace;
  run: Run;
  busy: boolean;
}) {
  const book = account.market || emptyMarket(account.username || ""),
    profile = book.profile;
  const research = MARKET_RESEARCH.filter((row) => !profile || row.sector === profile.sector);
  const [tab, setTab] = useState<"radar" | "compare" | "tests" | "research">(
    "radar",
  );
  const [modal, setModal] = useState<"profile" | "reference" | "import" | null>(
    null,
  );
  const [edit, setEdit] = useState<MarketReference | null>(null),
    [test, setTest] = useState<Partial<MarketExperiment> | null>(null);
  const [days, setDays] = useState(30),
    [query, setQuery] = useState(""),
    [archived, setArchived] = useState(false);
  const [reportId, setReportId] = useState(account.insights?.at(-1)?.id || "");
  const analysis = marketAnalysis(book, days),
    ownReport =
      account.insights?.find((r) => r.id === reportId) ||
      account.insights?.at(-1);
  const refs = (
    archived ? book.references.filter((r) => r.archived) : analysis.references
  )
    .filter((r) =>
      `${r.title} ${r.creator} ${r.note}`
        .toLowerCase()
        .includes(query.toLowerCase()),
    )
    .sort((a, b) => (b.metrics.views ?? -1) - (a.metrics.views ?? -1));
  const searchText = `${profile ? sectorLabel(profile.sector) : "moda fitness"} ${profile?.model === "wholesale" ? "atacado lojistas" : "Instagram Reels"} ideias conteúdo`;
  const startTest = (ref: MarketReference) => {
    if (profile) setTest({ referenceId: ref.id, ...adaptation(profile, ref) });
    else setModal("profile");
  };
  return (
    <section className="market-page" aria-label="Radar do setor">
      <div className="market-heading">
        <div>
          <span className="eyebrow">OBSERVAR · ADAPTAR · MEDIR</span>
          <h2>Seu setor, novas ideias.</h2>
          <p>
            Veja referências, encontre uma oportunidade e teste com a sua marca.
          </p>
        </div>
        <button
          className="button secondary"
          disabled={!account.username || busy}
          onClick={() => setModal("profile")}
        >
          <Sparkles size={16} />
          {profile ? "Ajustar meu setor" : "Identificar meu setor"}
        </button>
      </div>
      <AccountDataStatus account={account} area="market" />
      <div className="market-profile">
        <Radar size={24} />
        <div>
          <strong>
            {profile
              ? `${sectorLabel(profile.sector)} · ${MARKET_MODELS[profile.model]}`
              : "Primeiro, conte qual é o seu negócio"}
          </strong>
          <p>
            {profile
              ? profile.audience ||
                "Defina seu público para orientar as adaptações."
              : "Leia o seu perfil na extensão ou informe a bio. A sugestão de setor precisa da sua confirmação e fica separada por conta."}
          </p>
          <small>
            @{account.username || "conta não cadastrada"}
            {profile ? ` · configuração de ${date(profile.updatedAt)}` : ""}
          </small>
        </div>
      </div>
      <div className="market-toolbar">
        <div className="insight-tabs" role="group" aria-label="Seções do radar">
          {(
            [
              ["radar", "Referências"],
              ["compare", "Comparar comigo"],
              ["tests", "Plano de testes"],
              ["research", "Pesquisa inicial"],
            ] as const
          ).map(([key, title]) => (
            <button
              key={key}
              aria-pressed={tab === key}
              className={tab === key ? "selected" : ""}
              onClick={() => setTab(key)}
            >
              {title}
            </button>
          ))}
        </div>
      </div>
      <div className="market-actions">
        <button
          className="button primary"
          disabled={!account.username || busy}
          onClick={() => {
            setEdit(null);
            setModal("reference");
          }}
        >
          <Plus size={15} />
          Adicionar referência
        </button>
        <button
          className="button secondary"
          disabled={!account.username || busy}
          onClick={() => setModal("import")}
        >
          Importar referências
        </button>
        <button
          className="icon-button"
          aria-label="Exportar referências do setor"
          onClick={() =>
            download(
              `orbita-${account.username}-referencias.json`,
              JSON.stringify(
                {
                  version: 1,
                  account: account.username,
                  references: book.references,
                },
                null,
                2,
              ),
              "application/json",
            )
          }
        >
          <Download size={16} />
        </button>
        <External
          href={`https://www.google.com/search?q=${encodeURIComponent(searchText)}`}
        >
          Pesquisar referências na web
        </External>
        <External
          href={`https://www.facebook.com/ads/library/?active_status=active&ad_type=all&country=BR&q=${encodeURIComponent(profile ? sectorLabel(profile.sector) : "moda fitness")}`}
        >
          Pesquisar anúncios na Meta
        </External>
      </div>
      <p className="market-limit">
        A leitura consulta uma página aberta por vez na extensão. Não há
        monitoramento automático de todo o Instagram. Visualizações ausentes ou
        abreviadas ficam sem número exato; resultado público não revela vendas,
        salvamentos ou alcance privado.
      </p>
      {tab === "radar" ? (
        <>
          <div className="market-stats">
            <div>
              <span>Referências no recorte</span>
              <strong>{analysis.references.length}</strong>
            </div>
            <div>
              <span>Destaques com base comparável</span>
              <strong>{analysis.highlights.length}</strong>
            </div>
            <div>
              <span>Testes da minha conta</span>
              <strong>{book.experiments.length}</strong>
            </div>
          </div>
          <div className="market-filters">
            <Field label="Observações recentes">
              <select
                value={days}
                onChange={(e) => setDays(Number(e.target.value))}
              >
                <option value={30}>Últimos 30 dias</option>
                <option value={90}>Últimos 90 dias</option>
                <option value={36500}>Todo o histórico</option>
              </select>
            </Field>
            <Field label="Buscar referência">
              <input
                value={query}
                onChange={(e) => setQuery(e.target.value)}
                placeholder="Perfil, ideia ou anotação"
              />
            </Field>
            <label className="market-check">
              <input
                type="checkbox"
                checked={archived}
                onChange={(e) => setArchived(e.target.checked)}
              />
              Ver arquivadas
            </label>
          </div>
          <div className="market-evidence">
            <strong>O que está se destacando?</strong>
            {profile?.model === "unknown" ? (
              <p>
                Informe se o seu negócio atende atacado, varejo ou ambos para
                habilitar destaques contextualizados.
              </p>
            ) : null}
            <p>
              {analysis.highlights.length
                ? "Os cartões marcados superam em pelo menos 2× a mediana da base salva do próprio perfil."
                : "Ainda não há uma base suficiente para apontar destaque com confiança. Muitas visualizações, sozinhas, não comprovam viralização."}
            </p>
            <details>
              <summary>Como o destaque é calculado</summary>
              <p>
                Exige um Reel e pelo menos 5 outros Reels do mesmo perfil,
                setor, modelo de venda, distribuição conhecida e janela
                declarada. Publicação e observação precisam estar no recorte. O
                limite de 2× é uma regra de triagem do produto, não prova
                estatística ou ranking do setor inteiro. Conteúdo pago e
                orgânico ficam separados; origem desconhecida não é orgânico.
                Contagens totais de idades diferentes não são comparadas como
                desempenho.
              </p>
            </details>
          </div>
          {refs.length ? (
            <div className="market-reference-grid">
              {refs.map((ref) => {
                const highlight = analysis.highlights.find(
                  (h) => h.reference.id === ref.id,
                );
                return (
                  <article
                    className="market-reference"
                    key={ref.id}
                    aria-label={`Referência: ${ref.title}`}
                  >
                    <div className="market-ref-top">
                      <span>{KINDS[ref.kind]}</span>
                      <span>
                        {ref.distribution === "paid"
                          ? "Pago"
                          : ref.distribution === "organic"
                            ? "Orgânico informado"
                            : "Distribuição desconhecida"}
                      </span>
                    </div>
                    <h3>{ref.title}</h3>
                    <p className="market-ref-author">
                      {ref.creator || "Autor não informado"} ·{" "}
                      {sectorLabel(ref.sector)} · {MARKET_MODELS[ref.model]}
                    </p>
                    {highlight ? (
                      <div className="market-highlight">
                        Destaque na amostra · {num(highlight.ratio)}×
                        <small>
                          Mediana: {num(highlight.median)} views · {highlight.n}{" "}
                          outros Reels · {ref.windowHours} h
                        </small>
                      </div>
                    ) : null}
                    <div className="market-public-metrics">
                      <span>
                        <strong>{num(ref.metrics.views)}</strong> visualizações
                      </span>
                      <span>
                        <strong>{num(ref.metrics.likes)}</strong> curtidas
                      </span>
                      <span>
                        <strong>{num(ref.metrics.comments)}</strong> comentários
                      </span>
                    </div>
                    <span className="market-pattern">
                      {MARKET_PATTERNS[ref.pattern]}
                    </span>
                    {ref.hook ? (
                      <p>
                        <b>Abertura:</b> {ref.hook}
                      </p>
                    ) : null}
                    {ref.note ? (
                      <p className="market-ref-note">{ref.note}</p>
                    ) : null}
                    <details>
                      <summary>Datas e fonte</summary>
                      <p>
                        Observado: {date(ref.observedAt)}
                        <br />
                        Publicado:{" "}
                        {ref.publishedAt
                          ? date(ref.publishedAt)
                          : "não informado"}
                        <br />
                        Janela:{" "}
                        {ref.windowHours
                          ? `${ref.windowHours} h declaradas`
                          : "não comparável"}
                        <br />
                        {SOURCES[ref.source]} · {MARKET_MODELS[ref.model]}
                      </p>
                    </details>
                    <div className="market-card-actions">
                      <External href={ref.url}>Ver fonte</External>
                      <button
                        className="text-link"
                        disabled={!profile || busy}
                        onClick={() => startTest(ref)}
                      >
                        Adaptar para mim →
                      </button>
                      <button
                        className="text-link"
                        onClick={() => {
                          setEdit(ref);
                          setModal("reference");
                        }}
                      >
                        Editar
                      </button>
                      <button
                        className="icon-button"
                        disabled={busy}
                        aria-label={`${ref.archived ? "Reativar" : "Arquivar"} referência ${ref.title}`}
                        onClick={() =>
                          void run({
                            type: "ARCHIVE_MARKET_REFERENCE",
                            id: ref.id,
                            archived: !ref.archived,
                          })
                        }
                      >
                        <Archive size={14} />
                      </button>
                    </div>
                  </article>
                );
              })}
            </div>
          ) : (
            <Empty
              icon={<BookOpen size={26} />}
              title={
                archived
                  ? "Nenhuma referência arquivada"
                  : "Seu radar começa com referências reais"
              }
              text="Adicione links de perfis e Reels, leia a página na extensão ou importe uma seleção. Pesquisa inicial traz fontes consultadas para começar, sem métricas inventadas."
              action={
                <button
                  className="text-link"
                  onClick={() => setTab("research")}
                >
                  Ver pesquisa inicial →
                </button>
              }
            />
          )}
        </>
      ) : null}
      {tab === "compare" ? (
        <div className="market-comparison">
          <h3>O setor observado e o meu conteúdo</h3>
          <p>
            Correspondência sugerida pelas palavras do título, tema e abertura.
            Ausência no recorte não significa que você nunca fez esse conteúdo.
          </p>
          <Field label="Meu relatório para comparação">
            <select
              value={ownReport?.id || ""}
              onChange={(e) => setReportId(e.target.value)}
            >
              <option value="" disabled>
                Sem relatório salvo
              </option>
              {[...(account.insights || [])].reverse().map((r) => (
                <option key={r.id} value={r.id}>
                  {r.start} a {r.end} · {r.coverage} · {r.content.length}{" "}
                  conteúdos
                </option>
              ))}
            </select>
          </Field>
          <div className="table-scroll">
            <table aria-label="Comparação de padrões do setor">
              <thead>
                <tr>
                  <th>Padrão observado</th>
                  <th>Referências do recorte</th>
                  <th>Meus conteúdos encontrados</th>
                  <th>Próximo passo</th>
                </tr>
              </thead>
              <tbody>
                {(Object.entries(MARKET_PATTERNS) as [MarketPattern, string][])
                  .filter(([key]) => key !== "other")
                  .map(([key, title]) => {
                    const external = analysis.references.filter(
                        (r) => r.pattern === key && r.model !== "unknown",
                      ),
                      own = ownReport
                        ? ownPatternMatches(account, ownReport.id, key)
                        : [];
                    return (
                      <tr key={key}>
                        <td>{title}</td>
                        <td>{external.length}</td>
                        <td>
                          {ownReport ? (
                            <>
                              {own.length}
                              <small>{own[0]?.title}</small>
                            </>
                          ) : (
                            "Sem relatório"
                          )}
                        </td>
                        <td>
                          {external.length ? (
                            <button
                              className="text-link"
                              disabled={!profile}
                              onClick={() => startTest(external[0])}
                            >
                              {own.length
                                ? "Testar uma variação"
                                : "Criar um primeiro teste"}{" "}
                              →
                            </button>
                          ) : (
                            "Adicionar referências"
                          )}
                        </td>
                      </tr>
                    );
                  })}
              </tbody>
            </table>
          </div>
          <p className="market-limit">
            Usamos somente o relatório selecionado, sem somar versões. Os
            números contam padrões encontrados nos textos, não desempenho
            comparável entre contas. As métricas da sua conta ficam no
            dashboard.
          </p>
        </div>
      ) : null}
      {tab === "tests" ? (
        <div className="market-tests">
          <h3>Da referência ao resultado próprio</h3>
          <p>
            Adapte a ideia com seu produto e sua linguagem. Depois vincule a
            publicação própria e registre seus Insights na mesma janela.
          </p>
          {book.experiments.length ? (
            book.experiments.map((exp) => {
              const measurement = experimentMeasurement(account, exp),
                ref = book.references.find((r) => r.id === exp.referenceId);
              return (
                <article key={exp.id} className="market-experiment">
                  <span className="market-pattern">
                    {
                      {
                        idea: "Ideia",
                        testing: "Em teste",
                        measured: "Medição registrada",
                      }[exp.status]
                    }
                  </span>
                  <h4>{exp.title}</h4>
                  <p>{exp.hypothesis}</p>
                  <pre>{exp.recipe}</pre>
                  <p>
                    <b>Chamada:</b> {exp.cta}
                  </p>
                  <p>
                    <b>Medir:</b>{" "}
                    {
                      {
                        views: "Visualizações",
                        total_interactions: "Interações",
                        follows: "Seguidores atribuídos à publicação",
                      }[exp.goal]
                    }{" "}
                    em {exp.windowHours} h.
                  </p>
                  <div className="market-measurement">
                    {measurement ? (
                      <>
                        <strong>
                          {measurement.comparable &&
                          measurement.value !== undefined
                            ? `${num(measurement.value)} · valor do meu conteúdo`
                            : "Publicação encontrada; medição ainda incompatível ou sem a métrica"}
                        </strong>
                        <p>
                          {measurement.report.start} a {measurement.report.end}{" "}
                          ·{" "}
                          {measurement.content.observationHours || "sem janela"}{" "}
                          h · {measurement.report.coverage}. O resultado não
                          prova a causa nem é comparado com o total da outra
                          conta.
                        </p>
                      </>
                    ) : (
                      <p>
                        {exp.ownUrl
                          ? "Link vinculado, ainda sem conteúdo correspondente nos Insights desta conta."
                          : "Publique o teste, vincule o link e registre os Insights para acompanhar."}
                      </p>
                    )}
                  </div>
                  <div className="market-card-actions">
                    {ref ? (
                      <External href={ref.url}>Referência original</External>
                    ) : null}
                    {exp.ownUrl ? (
                      <External href={exp.ownUrl}>Minha publicação</External>
                    ) : null}
                    <button
                      className="button secondary"
                      onClick={() => setTest(exp)}
                    >
                      Atualizar teste
                    </button>
                  </div>
                </article>
              );
            })
          ) : (
            <Empty
              title="Nenhum teste salvo"
              text="Abra uma referência e escolha Adaptar para mim. Você revisa o roteiro antes de salvá-lo."
            />
          )}
        </div>
      ) : null}
      {tab === "research" ? (
        <div className="market-research">
          <h3>Pesquisa inicial com fontes</h3>
          <p>
            Consulta em 03/11/2026. São exemplos de comunicação pública e
            hipóteses de adaptação; não um ranking de Reels virais. Instagram
            bloqueou a leitura pública direta de alguns perfis nesta consulta,
            por isso nenhuma visualização foi inventada.
          </p>
          <div className="market-reference-grid">
            {!research.length ? (
              <Empty
                icon={<BookOpen size={24} />}
                title="Ainda não há pesquisa inicial para este setor"
                text="Adicione referências públicas ao seu radar e registre suas métricas. As fontes já pesquisadas cobrem moda fitness e moda praia."
              />
            ) : null}
            {research.map((r) => (
              <article className="market-reference" key={r.url}>
                <span className="market-pattern">{sectorLabel(r.sector)}</span>
                <h3>{r.title}</h3>
                <p>
                  <b>{r.creator}</b>
                </p>
                <p>{r.note}</p>
                <External href={r.url}>Consultar fonte</External>
                <button
                  className="button secondary"
                  disabled={!profile || busy}
                  onClick={() =>
                    void run(
                      {
                        type: "SAVE_MARKET_REFERENCES",
                        data: {
                          account: account.username,
                          references: [
                            {
                              ...researchReference(r),
                            },
                          ],
                        },
                      },
                      "Fonte adicionada ao radar desta conta.",
                    )
                  }
                >
                  Guardar no meu radar
                </button>
              </article>
            ))}
          </div>
          <p className="market-limit">
            As condições comerciais das fontes podem mudar. A sugestão de
            conteúdo é uma inferência nossa, não uma afirmação de que a marca
            obteve crescimento com ela. A Biblioteca da Meta não está integrada
            automaticamente ao aplicativo.
          </p>
        </div>
      ) : null}
      {modal === "profile" ? (
        <ProfileModal
          account={account}
          run={run}
          busy={busy}
          onClose={() => setModal(null)}
        />
      ) : null}
      {modal === "reference" ? (
        <ReferenceModal
          account={account}
          reference={edit}
          run={run}
          busy={busy}
          onClose={() => setModal(null)}
        />
      ) : null}
      {modal === "import" ? (
        <ImportModal
          account={account}
          run={run}
          busy={busy}
          onClose={() => setModal(null)}
        />
      ) : null}
      {test ? (
        <ExperimentModal
          account={account}
          value={test}
          run={run}
          busy={busy}
          onClose={() => setTest(null)}
        />
      ) : null}
    </section>
  );
}
function ProfileModal({
  account,
  run,
  busy,
  onClose,
}: {
  account: AccountWorkspace;
  run: Run;
  busy: boolean;
  onClose: () => void;
}) {
  const old = account.market?.profile;
  const [sector, setSector] = useState(sectorLabel(old?.sector || "fitness")),
    [model, setModel] = useState<MarketModel>(old?.model || "unknown"),
    [bio, setBio] = useState(old?.bio || ""),
    [audience, setAudience] = useState(old?.audience || "");
  const [reading, setReading] = useState(false),
    [error, setError] = useState("");
  const suggested = suggestMarket(bio);
  return (
    <Modal
      title="Meu setor e público"
      subtitle={`Configuração de @${account.username}`}
      onClose={onClose}
    >
      <form
        onSubmit={async (e) => {
          e.preventDefault();
          if (
            await run(
              {
                type: "SET_MARKET_PROFILE",
                data: {
                  account: account.username,
                  sector,
                  model,
                  bio,
                  audience,
                },
              },
              "Setor salvo nesta conta.",
            )
          )
            onClose();
        }}
      >
        <button
          type="button"
          className="button secondary"
          disabled={!isExtension || reading}
          onClick={async () => {
            setReading(true);
            setError("");
            try {
              const read = await readMarketPage(account.id, true);
              setBio(read.text);
            } catch (e) {
              setError((e as Error).message);
            } finally {
              setReading(false);
            }
          }}
        >
          {reading ? "Lendo perfil…" : "Ler meu perfil no Instagram"}
        </button>
        <p className="market-limit">
          A extensão abre seu perfil e confere a sessão. Você revisa a sugestão
          antes de salvar. Na prévia, cole o texto da bio.
        </p>
        <Field label="Bio e descrição do meu negócio">
          <textarea
            value={bio}
            maxLength={2200}
            rows={4}
            onChange={(e) => setBio(e.target.value)}
          />
        </Field>
        {bio ? (
          <div className="market-evidence">
            <strong>Sugestão pelo texto informado</strong>
            <p>
              {suggested.candidates.length
                ? suggested.candidates.map(sectorLabel).join(" e ")
                : "Setor não identificado com clareza"}{" "}
              · {MARKET_MODELS[suggested.model]}. Confira a sugestão; palavras
              da bio não confirmam o posicionamento.
            </p>
            {suggested.candidates.length === 1 ? (
              <button
                type="button"
                className="text-link"
                onClick={() => {
                  setSector(sectorLabel(suggested.candidates[0]));
                  setModel(suggested.model);
                }}
              >
                Usar sugestão
              </button>
            ) : null}
          </div>
        ) : null}
        <Field
          label="Setor da conta"
          hint="Ex.: moda fitness, biquínis, cosméticos ou outro setor."
        >
          <input
            required
            maxLength={80}
            list="market-sector-options"
            value={sector}
            onChange={(e) => setSector(e.target.value)}
          />
          <datalist id="market-sector-options">
            <option value="Moda fitness" />
            <option value="Biquínis e moda praia" />
          </datalist>
        </Field>
        <Field label="Modelo de venda">
          <select
            value={model}
            onChange={(e) => setModel(e.target.value as MarketModel)}
          >
            {Object.entries(MARKET_MODELS).map(([k, v]) => (
              <option key={k} value={k}>
                {v}
              </option>
            ))}
          </select>
        </Field>
        <Field label="Quem queremos alcançar">
          <input
            value={audience}
            maxLength={300}
            onChange={(e) => setAudience(e.target.value)}
            placeholder="Ex.: lojistas de moda fitness no Brasil"
          />
        </Field>
        {error ? (
          <p role="alert" className="notice error">
            {error}
          </p>
        ) : null}
        <div className="modal-actions">
          <button type="button" className="button secondary" onClick={onClose}>
            Cancelar
          </button>
          <button className="button primary" disabled={busy || reading}>
            Confirmar setor
          </button>
        </div>
      </form>
    </Modal>
  );
}
function ReferenceModal({
  account,
  reference,
  run,
  busy,
  onClose,
}: {
  account: AccountWorkspace;
  reference: MarketReference | null;
  run: Run;
  busy: boolean;
  onClose: () => void;
}) {
  const profile = account.market?.profile;
  const [form, setForm] = useState({
    url: reference?.url || "",
    creator: reference?.creator || "",
    sector: sectorLabel(reference?.sector || profile?.sector || "fitness"),
    model: reference?.model || profile?.model || "unknown",
    kind: reference?.kind || "reel",
    pattern: reference?.pattern || "other",
    title: reference?.title || "",
    hook: reference?.hook || "",
    cta: reference?.cta || "",
    note: reference?.note || "",
    distribution: reference?.distribution || "unknown",
    observedAt: reference ? localInput(reference.observedAt) : nowInput(),
    publishedAt: reference?.publishedAt
      ? localInput(reference.publishedAt)
      : "",
    windowHours: reference?.windowHours?.toString() || "",
    views: reference?.metrics.views?.toString() || "",
    likes: reference?.metrics.likes?.toString() || "",
    comments: reference?.metrics.comments?.toString() || "",
  });
  const [reading, setReading] = useState(false),
    [error, setError] = useState("");
  const set = (key: keyof typeof form, value: string) =>
    setForm((f) => ({ ...f, [key]: value }));
  return (
    <Modal
      title={reference ? "Revisar referência" : "Adicionar referência do setor"}
      subtitle="Guarde a fonte e o que vale adaptar para a sua marca."
      onClose={onClose}
      wide
    >
      <form
        onSubmit={async (e) => {
          e.preventDefault();
          setError("");
          try {
            const metrics: Record<string, number> = {};
            for (const k of ["views", "likes", "comments"] as const)
              if (form[k] !== "") metrics[k] = Number(form[k]);
            const data = {
              account: account.username,
              references: [
                {
                  ...form,
                  observedAt: new Date(form.observedAt).toISOString(),
                  publishedAt: form.publishedAt
                    ? new Date(form.publishedAt).toISOString()
                    : undefined,
                  windowHours: form.windowHours
                    ? Number(form.windowHours)
                    : undefined,
                  metrics,
                },
              ],
            };
            saveMarketReferences(account.market, data, account.username || "");
            if (
              await run(
                { type: "SAVE_MARKET_REFERENCES", data },
                "Referência salva nesta conta.",
              )
            )
              onClose();
          } catch (e) {
            setError((e as Error).message);
          }
        }}
      >
        <Field label="Link da referência">
          <input
            required
            type="url"
            value={form.url}
            readOnly={!!reference}
            onChange={(e) => set("url", e.target.value)}
            placeholder="https://www.instagram.com/reel/…"
          />
        </Field>
        <button
          type="button"
          className="button secondary"
          disabled={!isExtension || reading || !form.url}
          onClick={async () => {
            setReading(true);
            setError("");
            try {
              const result = await readMarketPage(
                account.id,
                false,
                marketUrl(form.url, true),
              );
              setForm((f) => ({
                ...f,
                url: result.url,
                creator: result.creator || f.creator,
                kind: result.kind === "profile" ? "article" : result.kind,
                observedAt: localInput(result.observedAt),
                note: result.text.slice(0, 1600),
                views: result.metrics.views?.toString() || "",
                likes: result.metrics.likes?.toString() || "",
                comments: result.metrics.comments?.toString() || "",
              }));
            } catch (e) {
              setError((e as Error).message);
            } finally {
              setReading(false);
            }
          }}
        >
          {reading ? "Lendo página…" : "Ler página na extensão"}
        </button>
        <p className="market-limit">
          Lê somente texto e números exatos da página carregada. Confira o
          autor, classifique o padrão e revise antes de salvar. Não lê dados
          privados nem ignora telas de login.
        </p>
        <div className="market-form-grid">
          <Field label="Título da referência">
            <input
              required
              maxLength={200}
              value={form.title}
              onChange={(e) => set("title", e.target.value)}
            />
          </Field>
          <Field
            label="Perfil ou marca de origem"
            hint="Em Reels, informe o @perfil exato para habilitar comparações."
          >
            <input
              maxLength={100}
              value={form.creator}
              onChange={(e) => set("creator", e.target.value)}
              placeholder="@perfil ou nome da marca"
            />
          </Field>
          <Field label="Setor da referência">
            <input
              required
              maxLength={80}
              value={form.sector}
              onChange={(e) => set("sector", e.target.value)}
            />
          </Field>
          <Field label="Modelo de venda da referência">
            <select
              value={form.model}
              onChange={(e) => set("model", e.target.value)}
            >
              {Object.entries(MARKET_MODELS).map(([k, v]) => (
                <option key={k} value={k}>
                  {v}
                </option>
              ))}
            </select>
          </Field>
          <Field label="Formato da referência">
            <select
              value={form.kind}
              onChange={(e) => set("kind", e.target.value)}
            >
              {Object.entries(KINDS).map(([k, v]) => (
                <option key={k} value={k}>
                  {v}
                </option>
              ))}
            </select>
          </Field>
          <Field label="Padrão de conteúdo">
            <select
              value={form.pattern}
              onChange={(e) => set("pattern", e.target.value)}
            >
              {Object.entries(MARKET_PATTERNS).map(([k, v]) => (
                <option key={k} value={k}>
                  {v}
                </option>
              ))}
            </select>
          </Field>
          <Field label="Distribuição informada">
            <select
              value={form.distribution}
              onChange={(e) => set("distribution", e.target.value)}
            >
              <option value="unknown">Desconhecida</option>
              <option value="organic">Orgânica informada</option>
              <option value="paid">Paga / anúncio</option>
            </select>
          </Field>
          <Field label="Data e hora da observação">
            <input
              type="datetime-local"
              required
              value={form.observedAt}
              onChange={(e) => set("observedAt", e.target.value)}
            />
          </Field>
          <Field
            label="Data e hora da publicação"
            hint="Opcional. A ausência impede comparação de idade."
          >
            <input
              type="datetime-local"
              value={form.publishedAt}
              onChange={(e) => set("publishedAt", e.target.value)}
            />
          </Field>
          <Field
            label="Janela declarada em horas"
            hint="Opcional. Ex.: leitura feita 24 h após publicar; tolerância de 30 min."
          >
            <input
              type="number"
              min="1"
              max="8760"
              value={form.windowHours}
              onChange={(e) => set("windowHours", e.target.value)}
            />
          </Field>
        </div>
        <div className="market-form-grid">
          {(
            [
              ["views", "Visualizações públicas"],
              ["likes", "Curtidas públicas"],
              ["comments", "Comentários públicos"],
            ] as const
          ).map(([k, label]) => (
            <Field key={k} label={label}>
              <input
                type="number"
                min="0"
                step="1"
                value={form[k]}
                onChange={(e) => set(k, e.target.value)}
                placeholder="Sem dado exato"
              />
            </Field>
          ))}
        </div>
        <Field label="Abertura que chamou atenção">
          <input
            maxLength={400}
            value={form.hook}
            onChange={(e) => set("hook", e.target.value)}
          />
        </Field>
        <Field label="Chamada para ação observada">
          <input
            maxLength={400}
            value={form.cta}
            onChange={(e) => set("cta", e.target.value)}
          />
        </Field>
        <Field label="O que a referência faz e o que observar">
          <textarea
            rows={4}
            maxLength={1600}
            value={form.note}
            onChange={(e) => set("note", e.target.value)}
          />
        </Field>
        {error ? (
          <p role="alert" className="notice error">
            {error}
          </p>
        ) : null}
        <div className="modal-actions">
          <button type="button" className="button secondary" onClick={onClose}>
            Cancelar
          </button>
          <button className="button primary" disabled={busy || reading}>
            Salvar referência
          </button>
        </div>
      </form>
    </Modal>
  );
}
function ImportModal({
  account,
  run,
  busy,
  onClose,
}: {
  account: AccountWorkspace;
  run: Run;
  busy: boolean;
  onClose: () => void;
}) {
  const [data, setData] = useState<unknown>(null),
    [count, setCount] = useState(0),
    [error, setError] = useState("");
  const [reading, setReading] = useState(false);
  const fileRead = useRef(0);
  useEffect(
    () => () => {
      fileRead.current++;
    },
    [],
  );
  return (
    <Modal
      title="Importar referências"
      subtitle="JSON no modelo Órbita · máximo 2 MB e 500 referências."
      onClose={onClose}
    >
      <button
        className="button secondary"
        onClick={() =>
          download(
            "orbita-modelo-referencias.json",
            JSON.stringify(
              {
                account: account.username,
                references: [
                  {
                    url: "https://www.instagram.com/reel/SUBSTITUA/",
                    creator: "perfil.de.origem",
                    sector: account.market?.profile?.sector || "fitness",
                    model: account.market?.profile?.model || "unknown",
                    kind: "reel",
                    pattern: "demo",
                    title: "Substitua pela referência observada",
                    observedAt: new Date().toISOString(),
                    distribution: "unknown",
                    metrics: {},
                    note: "Use números observados; ausência não é zero.",
                  },
                ],
              },
              null,
              2,
            ),
            "application/json",
          )
        }
      >
        Baixar modelo JSON
      </button>
      <Field label="Arquivo de referências">
        <input
          type="file"
          disabled={busy}
          accept=".json,application/json"
          onChange={async (e) => {
            const readId = ++fileRead.current;
            const f = e.target.files?.[0];
            setData(null);
            setCount(0);
            setError("");
            setReading(!!f);
            try {
              if (!f) return;
              if (f.size > 2000000) throw Error("Use arquivo de até 2 MB.");
              const text = await f.text();
              if (readId !== fileRead.current) return;
              const parsed = JSON.parse(text);
              const input = { ...parsed, mode: "file" };
              saveMarketReferences(
                account.market,
                input,
                account.username || "",
              );
              setData(input);
              setCount(parsed.references.length);
            } catch (e) {
              if (readId !== fileRead.current) return;
              setError((e as Error).message);
            } finally {
              if (readId === fileRead.current) setReading(false);
            }
          }}
        />
      </Field>
      {reading ? <p role="status">Lendo arquivo selecionado…</p> : null}
      {count ? (
        <div className="market-evidence">
          <strong>
            {count} referências validadas para @{account.username}
          </strong>
          <p>
            Links já salvos serão atualizados, preservando o vínculo dos testes.
            Campos de fonte passam a arquivo importado. O lote não altera o
            setor configurado nem seus testes.
          </p>
        </div>
      ) : null}
      {error ? (
        <p role="alert" className="notice error">
          {error}
        </p>
      ) : null}
      <div className="modal-actions">
        <button className="button secondary" onClick={onClose}>
          Cancelar
        </button>
        <button
          className="button primary"
          disabled={!data || busy || reading}
          onClick={async () => {
            if (
              await run(
                { type: "SAVE_MARKET_REFERENCES", data },
                "Referências importadas nesta conta.",
              )
            )
              onClose();
          }}
        >
          Importar {count || ""} referências
        </button>
      </div>
    </Modal>
  );
}
function ExperimentModal({
  account,
  value,
  run,
  busy,
  onClose,
}: {
  account: AccountWorkspace;
  value: Partial<MarketExperiment>;
  run: Run;
  busy: boolean;
  onClose: () => void;
}) {
  const [form, setForm] = useState(value);
  const [windowHours, setWindowHours] = useState(
    String(value.windowHours ?? 24),
  );
  const set = (key: keyof MarketExperiment, v: string | number) =>
    setForm((f) => ({ ...f, [key]: v }));
  return (
    <Modal
      title={
        value.id
          ? "Atualizar meu teste"
          : "Adaptar a referência para minha conta"
      }
      subtitle="Revise o roteiro. Ele é uma hipótese para testar com conteúdo próprio."
      onClose={onClose}
      wide
    >
      <form
        onSubmit={async (e) => {
          e.preventDefault();
          if (
            await run(
              {
                type: "SAVE_MARKET_EXPERIMENT",
                data: {
                  account: account.username,
                  experiment: { ...form, windowHours: Number(windowHours) },
                },
              },
              "Teste salvo nesta conta.",
            )
          )
            onClose();
        }}
      >
        <Field label="Título do meu teste">
          <input
            required
            maxLength={200}
            value={form.title || ""}
            onChange={(e) => set("title", e.target.value)}
          />
        </Field>
        <Field label="O que queremos aprender">
          <textarea
            required
            maxLength={800}
            value={form.hypothesis || ""}
            onChange={(e) => set("hypothesis", e.target.value)}
          />
        </Field>
        <Field label="Roteiro para gravar">
          <textarea
            required
            rows={7}
            maxLength={1800}
            value={form.recipe || ""}
            onChange={(e) => set("recipe", e.target.value)}
          />
        </Field>
        <Field label="Minha chamada para ação">
          <input
            maxLength={400}
            value={form.cta || ""}
            onChange={(e) => set("cta", e.target.value)}
          />
        </Field>
        <div className="market-form-grid">
          <Field label="Métrica do teste">
            <select
              value={form.goal}
              onChange={(e) => set("goal", e.target.value)}
            >
              <option value="total_interactions">Interações</option>
              <option value="views">Visualizações</option>
              <option value="follows">
                Seguidores atribuídos à publicação
              </option>
            </select>
          </Field>
          <Field label="Janela de medição em horas">
            <input
              type="number"
              min="1"
              max="8760"
              required
              value={windowHours}
              onChange={(e) => setWindowHours(e.target.value)}
            />
          </Field>
          <Field label="Situação do teste">
            <select
              value={form.status}
              onChange={(e) => set("status", e.target.value)}
            >
              <option value="idea">Ideia</option>
              <option value="testing">Em teste</option>
              <option value="measured">Medição registrada</option>
            </select>
          </Field>
          <Field label="Link da minha publicação">
            <input
              type="url"
              value={form.ownUrl || ""}
              onChange={(e) => set("ownUrl", e.target.value)}
              placeholder="https://www.instagram.com/reel/…"
            />
          </Field>
        </div>
        <Field label="Anotações do teste">
          <textarea
            maxLength={1200}
            value={form.note || ""}
            onChange={(e) => set("note", e.target.value)}
          />
        </Field>
        <p className="market-limit">
          O link precisa estar nos Insights desta conta para mostrar a medição.
          Marcar como medido não cria números, não comprova autoria e não
          publica automaticamente.
        </p>
        <div className="modal-actions">
          <button type="button" className="button secondary" onClick={onClose}>
            Cancelar
          </button>
          <button className="button primary" disabled={busy}>
            Salvar teste
          </button>
        </div>
      </form>
    </Modal>
  );
}
