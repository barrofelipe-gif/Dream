import type { AccountWorkspace } from "../core/types.ts";
import { accountDataReadiness } from "../core/account-readiness.ts";
import { isExtension } from "../bridge.ts";
import "./account-data-status.css";

const num = (value: number | undefined) =>
  value === undefined ? "—" : value.toLocaleString("pt-BR");
const date = (value: string) => new Date(value).toLocaleString("pt-BR");

export function AccountDataStatus({
  account,
  area,
}: {
  account: AccountWorkspace;
  area: "network" | "acquisition" | "market";
}) {
  const state = accountDataReadiness(account);
  const network = state.network.snapshot;
  const items =
    area === "network"
      ? [
          {
            title: "Contadores do perfil",
            value: state.profile
              ? `${num(state.profile.followers)} seguidores · ${num(state.profile.following)} seguidos`
              : "Aguardando leitura do perfil",
            text: state.profile
              ? `Medição de ${date(state.profile.at)} · ${state.profile.source === "instagram" ? "Instagram" : "informada manualmente"}. Totais não identificam os @perfis.`
              : "Conecte a conta em Contas para ler os totais disponíveis. Isso não fornece uma lista de nomes.",
            ready: !!state.profile,
          },
          {
            title: "Pessoas na sua rede",
            value: network
              ? `${num(network.followers.length)} seguidores · ${num(network.following.length)} seguidos identificados`
              : "Listas ainda não coletadas",
            text: network
              ? `${network.followersComplete && network.followingComplete ? "Listas declaradas completas" : "Coleta parcial: mostra somente os nomes observados"} · ${date(network.at)}.`
              : "Leia as listas carregadas da sua conta na extensão ou importe o arquivo do Instagram.",
            ready: !!network,
          },
          {
            title: "Quem saiu / não segue de volta",
            value: state.network.canCompareLosses
              ? "Comparação de seguidores disponível"
              : state.network.canCheckAbsence
                ? "Reciprocidade disponível"
                : "Precisa de listas completas",
            text: "Uma lista parcial revela presenças. Ausência só é analisada com seguidores completos; saídas exigem duas medições completas.",
            ready: state.network.canCheckAbsence,
          },
        ]
      : area === "acquisition"
        ? [
            {
              title: "Seguidores identificados",
              value:
                state.acquisition.measuredFollowers === undefined
                  ? "Aguardando lista própria"
                  : `${num(state.acquisition.measuredFollowers)} @perfis na medição`,
              text: "Sem a lista própria, não tratamos os perfis encontrados em campanhas como seus seguidores.",
              ready: state.acquisition.measuredFollowers !== undefined,
            },
            {
              title: "Evidências já disponíveis",
              value: `Origens informadas: ${num(state.acquisition.origins.length)} · relatórios de canal: ${num(state.acquisition.channelReports.length)}`,
              text: "Os registros existentes desta conta são mostrados abaixo. Não há identificação automática da origem individual pela conexão oficial.",
              ready: !!(
                state.acquisition.origins.length ||
                state.acquisition.channelReports.length
              ),
            },
            {
              title: "Bases de prospecção",
              value: `${num(state.acquisition.discoveryProfiles)} perfis em ${num(state.acquisition.discoverySources)} fontes ativas`,
              text: "Ao ler sua rede, cruzamos os nomes com o histórico já capturado. Uma coincidência não comprova de onde veio o seguidor.",
              ready: state.acquisition.discoveryProfiles > 0,
            },
          ]
        : [
            {
              title: "Contexto da conta",
              value: state.market.profile
                ? "Setor identificado"
                : "Confirme seu setor",
              text: state.market.profile
                ? state.market.profile.audience ||
                  "Revise seu público e modelo de venda para adaptar as ideias."
                : "Informe setor, público e modelo de venda. Cada perfil tem seu próprio radar.",
              ready: !!state.market.profile,
            },
            {
              title: "Fontes para observar",
              value: state.market.references.length
                ? `${num(state.market.references.length)} referências disponíveis`
                : "Aguardando referências",
              text: "Fontes pesquisadas ficam prontas como ideias. Links e métricas lidos na extensão entram após sua revisão.",
              ready: state.market.references.length > 0,
            },
            {
              title: "Evidência de desempenho",
              value: `${num(state.market.measuredReferences)} referências com métricas · ${num(state.insights.reports)} relatórios próprios`,
              text: "Sem uma base comparável, nenhuma referência é anunciada como viral. Compare os resultados e salve um teste para sua marca.",
              ready:
                state.market.measuredReferences > 0 &&
                state.insights.reports > 0,
            },
          ];
  return (
    <section
      className="account-data-status"
      aria-label={
        account.username
          ? `Disponibilidade dos dados de @${account.username}`
          : "Disponibilidade dos dados da sua conta"
      }
    >
      <div className="account-data-heading">
        <h2>Seus dados, passo a passo</h2>
        <span>
          {isExtension
            ? "Leitura nativa disponível nesta extensão"
            : "Painel web · leitura do Instagram disponível na extensão"}
        </span>
      </div>
      <div className="account-data-grid">
        {items.map((item, i) => (
          <article
            key={item.title}
            className={item.ready ? "available" : "pending"}
          >
            <span className="account-data-step">
              {i + 1} · {item.ready ? "Disponível" : "Próximo passo"}
            </span>
            <h3>{item.title}</h3>
            <strong>{item.value}</strong>
            <p>{item.text}</p>
          </article>
        ))}
      </div>
    </section>
  );
}
