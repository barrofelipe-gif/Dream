import {
  useCallback,
  useEffect,
  useLayoutEffect,
  useRef,
  useState,
} from "react";
import {
  CalendarClock,
  Check,
  Pause,
  Play,
  RefreshCw,
  Settings2,
} from "lucide-react";
import type {
  AccountWorkspace,
  Command,
  Settings,
  SpecialCommand,
} from "../core/types.ts";
import { SOURCE_LABELS } from "../core/types.ts";
import {
  continuousReview,
  DEFAULT_CONTINUOUS_POLL_MINUTES,
} from "../core/continuous.ts";
import { attemptsToday } from "../core/domain.ts";
import { sessionLimit } from "../core/safety.ts";
import { sendExtension } from "../transport.ts";
import { withDeadline } from "../extension/page-channel.ts";
import { date, Field, Hint, Modal, number, SourceIcon } from "./components.tsx";
import "./continuous-sources.css";

type Run = (
  command: Command | SpecialCommand,
  success?: string,
) => Promise<boolean>;
type Source = ReturnType<typeof continuousReview>["sources"][number];
export type ContinuousCapability = {
  status: "checking" | "supported" | "unsupported" | "error";
  message?: string;
  allDaySchedule?: boolean;
};

export const executionWindowLabel = (
  settings: Settings,
  capability: ContinuousCapability,
) =>
  settings.allDay === true
    ? capability.allDaySchedule === true
      ? "24 horas"
      : "24 horas · pendente na extensão"
    : `${settings.startHour}–${settings.endHour}`;

/** One bounded, read-only capability request per mounted account/check. */
export function useContinuousCapability(accountId: string, available: boolean) {
  const [revision, setRevision] = useState(0);
  const [result, setResult] = useState<{
    scope: string;
    value: ContinuousCapability;
  }>();
  const pending = useRef<{ scope: string; promise: Promise<any> } | undefined>(
    undefined,
  );
  const scope = `${accountId}:${available}:${revision}`;
  useEffect(() => {
    let alive = true;
    if (!available) {
      setResult({ scope, value: { status: "unsupported" } });
      return;
    }
    setResult({ scope, value: { status: "checking" } });
    // StrictMode may mount an effect twice; both observe the same read.
    if (pending.current?.scope !== scope) {
      const read = {
        scope,
        promise: withDeadline(
          () => sendExtension({ type: "GET_STATE" }),
          Date.now() + 10000,
          "conferindo a rotina contínua",
        ),
      };
      pending.current = read;
      void read.promise
        .finally(() => {
          if (pending.current === read) pending.current = undefined;
        })
        .catch(() => {});
    }
    void pending.current.promise
      .then((response) => {
        if (!alive) return;
        if (!response?.ok)
          throw new Error(
            response?.error || "Não foi possível conferir a extensão.",
          );
        setResult({
          scope,
          value: {
            status:
              response.capabilities?.continuousSources === true
                ? "supported"
                : "unsupported",
            allDaySchedule: response.capabilities?.allDaySchedule === true,
          },
        });
      })
      .catch((error: unknown) => {
        if (alive)
          setResult({
            scope,
            value: {
              status: "error",
              message:
                error instanceof Error
                  ? error.message
                  : "Não foi possível conferir a extensão.",
            },
          });
      });
    return () => {
      alive = false;
    };
  }, [scope, available]);
  const refresh = useCallback(() => setRevision((value) => value + 1), []);
  return {
    capability:
      result?.scope === scope ? result.value : { status: "checking" as const },
    refresh,
  };
}

const when = (value?: string | number) =>
  value === undefined
    ? "—"
    : date(typeof value === "number" ? new Date(value).toISOString() : value);
const count = (value?: number) => (value === undefined ? "—" : number(value));
const sourceCheckFrom = (sourceAt?: string, nextRunAt?: string) => {
  if (nextRunAt === undefined) return undefined;
  const run = Date.parse(nextRunAt);
  const source = sourceAt === undefined ? run : Date.parse(sourceAt);
  return Number.isFinite(run) && Number.isFinite(source)
    ? Math.max(run, source)
    : undefined;
};
const status = (
  source: Source,
  mode: "running" | "paused",
  active: boolean,
) => {
  if (source.status === "unavailable")
    return "Indisponível · reative após conferir";
  if (source.status === "error")
    return "Precisa de atenção · reative após conferir";
  if (!source.enabled) return "Ainda não habilitada";
  if (source.status === "checking") return "Consultando a fonte";
  if (mode !== "running") return "Configurada · rotina pausada";
  return active ? "Na rotina ativada" : "Configurada · fora desta ativação";
};

function CapabilityNotice({
  capability,
  onRefresh,
}: {
  capability: ContinuousCapability;
  onRefresh: () => void;
}) {
  if (capability.status === "supported") return null;
  return (
    <div className="continuous-capability" role="status">
      <div>
        <strong>
          {capability.status === "checking"
            ? "Conferindo recurso na extensão…"
            : capability.status === "error"
              ? "Conferência da extensão indisponível"
              : "Rotina contínua requer extensão 0.19.0 ou posterior"}
        </strong>
        <p>
          {capability.status === "error"
            ? capability.message
            : "O restante do painel continua disponível. Conecte a versão com este recurso para configurar e ativar a rotina."}
        </p>
      </div>
      <button
        className="button secondary small"
        disabled={capability.status === "checking"}
        onClick={onRefresh}
      >
        <RefreshCw size={14} />
        Conferir extensão
      </button>
    </div>
  );
}

function Configuration({
  account,
  sources,
  disabled,
  busy,
  run,
  onClose,
  reviewContext,
}: {
  account: AccountWorkspace;
  sources: Source[];
  disabled: boolean;
  busy: boolean;
  run: Run;
  onClose: () => void;
  reviewContext: string;
}) {
  const existingPolicies = new Set(
    sources.map((source) =>
      source.enabled ? (source.autoFollow ? "follow" : "collect") : "",
    ),
  );
  const [policy, setPolicy] = useState(() =>
    existingPolicies.size === 1 ? [...existingPolicies][0] : "",
  );
  const [pollMinutes, setPollMinutes] = useState(() => {
    const polls = new Set(sources.map((source) => source.pollMinutes));
    return String(
      polls.size === 1 ? [...polls][0] : DEFAULT_CONTINUOUS_POLL_MINUTES,
    );
  });
  const [reviewToken, setReviewToken] = useState<string>();
  const signature = JSON.stringify([reviewContext, policy, pollMinutes]);
  const reviewed = reviewToken === signature;
  const currentSignature = useRef<string | undefined>(signature);
  useLayoutEffect(() => {
    currentSignature.current = signature;
    return () => {
      currentSignature.current = undefined;
    };
  }, [signature]);
  const [saving, setSaving] = useState(false);
  const [notice, setNotice] = useState("");
  const poll = Number(pollMinutes);
  const valid =
    sources.length > 0 &&
    sources.every((source) => source.configurable) &&
    ["collect", "follow"].includes(policy) &&
    Number.isInteger(poll) &&
    poll >= 5 &&
    poll <= 1440 &&
    reviewed;
  const blocked = disabled || busy || saving || !valid;
  const save = async (activate: boolean) => {
    if (blocked) return;
    const authorizedSignature = signature;
    const stillReviewed = () => {
      if (currentSignature.current === authorizedSignature) return true;
      setNotice(
        "As preferências, as fontes ou o suporte da extensão mudaram. A ativação foi interrompida; confira o estado da rotina e revise novamente antes de continuar.",
      );
      return false;
    };
    setSaving(true);
    setReviewToken(undefined);
    setNotice("");
    try {
      // A group is configured in steps. Pause first; failure never starts a
      // partially configured group or retries an earlier command.
      if (!(await run({ type: "PAUSE_CONTINUOUS" }))) return;
      if (!stillReviewed()) return;
      for (const source of sources) {
        if (
          !(await run({
            type: "CONFIGURE_CONTINUOUS_SOURCE",
            id: source.id,
            enabled: true,
            autoFollow: policy === "follow",
            pollMinutes: poll,
            reviewed: true,
          }))
        ) {
          setNotice(
            "A rotina ficou pausada. Algumas fontes podem ter sido salvas; confira os cartões antes de tentar novamente.",
          );
          return;
        }
        if (!stillReviewed()) return;
      }
      if (!stillReviewed()) return;
      if (
        activate &&
        !(await run({
          type: "START_CONTINUOUS",
          sourceIds: sources.map((source) => source.id),
          reviewed: true,
        }))
      ) {
        setNotice(
          "As configurações foram salvas. A ativação não foi confirmada; confira o estado da rotina antes de tentar novamente.",
        );
        return;
      }
      onClose();
    } finally {
      setSaving(false);
    }
  };
  return (
    <Modal
      title="Configurar rotina contínua"
      subtitle={`Somente @${account.username || account.label} · ${sources.length} ${sources.length === 1 ? "fonte" : "fontes"}`}
      onClose={() => {
        if (!saving) onClose();
      }}
      wide
    >
      <ul className="continuous-config-sources">
        {sources.map((source) => (
          <li key={source.id}>
            <SourceIcon kind={source.kind} size={16} />
            <span>
              <strong>{source.name}</strong>
              <small>
                {SOURCE_LABELS[source.kind]} · {source.target}
              </small>
            </span>
            {!source.configurable ? <small>Fonte não compatível</small> : null}
          </li>
        ))}
      </ul>
      <p className="continuous-detail">
        Salvar e ativar inicia uma nova ativação somente com as fontes listadas
        aqui e substitui o conjunto ativo anterior. Outras fontes configuradas
        continuam salvas, mas não entram nesta ativação.
      </p>
      <div className="continuous-config-fields">
        <Field
          label="O que a rotina pode fazer?"
          hint="Só vale para perfis descobertos nesta consulta e novos no seu espaço. Perfis antigos não são reaprovados automaticamente."
        >
          <select
            value={policy}
            disabled={saving}
            onChange={(event) => {
              setPolicy(event.target.value);
              setReviewToken(undefined);
            }}
          >
            <option value="">Escolha a política</option>
            <option value="collect">Somente coletar novos perfis</option>
            <option value="follow">
              Coletar e seguir novos perfis elegíveis
            </option>
          </select>
        </Field>
        <Field
          label="Consultar cada fonte a cada (minutos)"
          hint="Padrão: 15 minutos. O agendamento depende da sessão, dos horários e dos limites atuais; não é tempo real."
        >
          <input
            type="number"
            min={5}
            max={1440}
            step={1}
            value={pollMinutes}
            disabled={saving}
            onChange={(event) => {
              setPollMinutes(event.target.value);
              setReviewToken(undefined);
            }}
          />
        </Field>
      </div>
      <div className="continuous-policy-summary">
        <strong>
          {policy === "follow"
            ? "Seguir automaticamente está selecionado"
            : policy === "collect"
              ? "Somente coleta está selecionada"
              : "Escolha a política antes de autorizar"}
        </strong>
        <p>
          {policy === "follow"
            ? "Novos perfis elegíveis entram na fila de seguir, sem aprovação individual, respeitando exclusões, proteções, ritmo e orçamento. Não inclui deixar de seguir ou enviar mensagens."
            : "A coleta salva os perfis encontrados. Ela não segue as pessoas."}
        </p>
      </div>
      <label className="continuous-review-check">
        <input
          type="checkbox"
          checked={reviewed}
          disabled={saving || !policy}
          onChange={(event) =>
            setReviewToken(event.target.checked ? signature : undefined)
          }
        />
        <span>
          Conferi estas fontes, a política escolhida e autorizo o uso nesta
          conta. Entendi que a coleta pode ser parcial e que os limites não
          eliminam o risco de bloqueio.
        </span>
      </label>
      <p className="continuous-detail">
        Salvar deixa a rotina pausada. Salvar e ativar autoriza estas fontes de
        uma vez; as próximas consultas seguem a configuração até você pausar ou
        surgir um impedimento. Comentários e curtidas são somente da publicação
        informada.
      </p>
      {notice ? (
        <p className="continuous-operation-notice" role="status">
          {notice}
        </p>
      ) : null}
      <div className="modal-actions">
        <button
          className="button secondary"
          disabled={blocked}
          onClick={() => void save(false)}
        >
          <Check size={15} />
          {saving ? "Salvando…" : "Salvar configuração"}
        </button>
        <button
          className="button primary"
          disabled={blocked}
          onClick={() => void save(true)}
        >
          <Play size={15} />
          Salvar e ativar rotina
        </button>
      </div>
    </Modal>
  );
}

export function ContinuousSources({
  account,
  capability,
  sessionConnected,
  busy,
  run,
  configureIds,
  onConfigure,
  onCloseConfiguration,
  onRefreshCapability,
}: {
  account: AccountWorkspace;
  capability: ContinuousCapability;
  sessionConnected: boolean;
  busy: boolean;
  run: Run;
  configureIds: string[] | null;
  onConfigure: (ids: string[]) => void;
  onCloseConfiguration: () => void;
  onRefreshCapability: () => void;
}) {
  const [now, setNow] = useState(() => new Date());
  const [selection, setSelection] = useState<string[] | null>(null);
  const [acceptedKey, setAcceptedKey] = useState<string>();
  useEffect(() => {
    const tick = () => {
      if (document.visibilityState === "visible") setNow(new Date());
    };
    const timer = setInterval(tick, 60000);
    document.addEventListener("visibilitychange", tick);
    return () => {
      clearInterval(timer);
      document.removeEventListener("visibilitychange", tick);
    };
  }, []);
  const review = continuousReview(account, now);
  const { state, sources } = { state: account.data, sources: review.sources };
  const activeIds = new Set(state.continuous?.sourceIds || []);
  const startable = sources.filter((source) => source.startable);
  const activationSources =
    review.mode === "running"
      ? sources.filter((source) => activeIds.has(source.id))
      : startable;
  const selectedSources =
    review.mode === "running"
      ? activationSources
      : activationSources.filter(
          (source) => selection === null || selection.includes(source.id),
        );
  const sourceIds = selectedSources.map((source) => source.id);
  const snapshotKey = JSON.stringify([
    account.id,
    account.username,
    sourceIds,
    selectedSources.map((source) => [
      source.authorizationId,
      source.autoFollow,
      source.pollMinutes,
    ]),
    state.settings,
    sessionConnected,
    capability.status,
    capability.allDaySchedule,
  ]);
  const reviewed = acceptedKey === snapshotKey;
  const disabled =
    busy ||
    capability.status !== "supported" ||
    !sessionConnected ||
    (state.settings.allDay === true && capability.allDaySchedule !== true);
  const configured = configureIds
    ? sources.filter((source) => configureIds.includes(source.id))
    : [];
  const remaining = Math.max(
    0,
    state.settings.dailyLimit - attemptsToday(state, now),
  );
  const selectedAutoFollow = selectedSources.filter(
    (source) => source.autoFollow,
  ).length;
  return (
    <section
      className="panel continuous-sources"
      aria-labelledby="continuous-title"
    >
      <div className="continuous-heading">
        <div>
          <span className="tiny-label">
            ROTINA POR CONTA · @{account.username || account.label}
          </span>
          <h2 id="continuous-title">
            <CalendarClock size={23} />
            Rotina contínua
          </h2>
          <p>
            Configure as fontes uma vez. As próximas consultas coletam os perfis
            disponíveis e usam a política que você autorizou.
          </p>
        </div>
        <span className={`continuous-mode ${review.mode}`} role="status">
          {review.mode === "running" ? "Rotina ativada" : "Rotina pausada"}
        </span>
      </div>
      <CapabilityNotice
        capability={capability}
        onRefresh={onRefreshCapability}
      />
      {!sessionConnected ? (
        <p className="continuous-session" role="status">
          Conecte e confira a sessão de @{account.username || "sua conta"} para
          configurar ou ativar. O cadastro local não é uma sessão do Instagram.
        </p>
      ) : null}
      {state.settings.allDay === true && capability.allDaySchedule !== true ? (
        <p className="continuous-session" role="status">
          O modo 24h está pendente: a extensão desta conexão não confirmou o
          recurso de 24 horas, disponível na versão 0.19.1 ou posterior.
          Configure ou ative somente após conferir esse suporte. Nenhuma
          extensão será atualizada ou recarregada automaticamente.
        </p>
      ) : null}
      <div className="continuous-summary">
        <div>
          <span>Próxima execução programada</span>
          <strong>{when(review.nextRunAt)}</strong>
        </div>
        <div>
          <span>Janela atual</span>
          <strong>{executionWindowLabel(state.settings, capability)}</strong>
        </div>
        <div>
          <span>Tentativas restantes hoje</span>
          <strong>
            {remaining} de {state.settings.dailyLimit}
          </strong>
        </div>
        <div>
          <span>Ritmo atual de ações</span>
          <strong>
            {state.settings.intervalMinutes} min · até{" "}
            {sessionLimit(state.settings)} por sessão
          </strong>
        </div>
      </div>
      {review.reason ? (
        <p className="continuous-runtime-reason" role="status">
          {review.reason}
        </p>
      ) : null}
      {review.mode === "running" ? (
        <p className="continuous-detail">
          As fontes são consultadas em sequência, sem horário exato garantido
          por fonte. O início depende da sessão, dos horários e dos limites
          atuais.
          {review.nextRunAt === undefined
            ? " Aguardando o próximo agendamento do executor."
            : null}
        </p>
      ) : null}
      <div className="continuous-global-actions">
        <button
          className="button primary"
          disabled={disabled || !sources.some((source) => source.configurable)}
          onClick={() =>
            onConfigure(
              sources
                .filter((source) => source.configurable)
                .map((source) => source.id),
            )
          }
        >
          <Settings2 size={16} />
          Configurar fontes
        </button>
        <button
          className="button secondary"
          disabled={
            busy ||
            capability.status !== "supported" ||
            (review.mode !== "running" && state.runtime.mode !== "running")
          }
          onClick={() => {
            setAcceptedKey(undefined);
            void run(
              { type: "PAUSE_CONTINUOUS" },
              "Rotina pausada. Uma ação já enviada pode terminar; nenhuma nova será iniciada.",
            );
          }}
        >
          <Pause size={16} />
          Pausar rotina e ações
        </button>
      </div>
      {!sources.length ? (
        <p className="continuous-empty">
          Crie uma campanha por perfil ou uma fonte de seguidores, comentários
          ou curtidas para configurar a rotina.
        </p>
      ) : (
        <div className="continuous-source-list">
          {sources.map((source) => (
            <article
              className={`continuous-source ${source.status || "new"}`}
              key={source.id}
            >
              <div className="continuous-source-heading">
                <SourceIcon kind={source.kind} size={20} />
                <div>
                  <h3>{source.name}</h3>
                  <span>{SOURCE_LABELS[source.kind]}</span>
                </div>
                <span className="continuous-partial">Coleta parcial</span>
              </div>
              <p className="continuous-target">{source.target}</p>
              <p className="continuous-source-status">
                {status(source, review.mode, activeIds.has(source.id))}
              </p>
              <p className="continuous-detail">
                {source.configurationReason ||
                  source.reason ||
                  "Escolha a política desta fonte antes de ativar."}
              </p>
              <dl className="continuous-source-stats">
                <div>
                  <dt>Última verificação</dt>
                  <dd>{when(source.lastCheckAt)}</dd>
                </div>
                <div>
                  <dt>Próxima consulta a partir de</dt>
                  <dd>
                    {review.mode === "running" &&
                    activeIds.has(source.id) &&
                    source.enabled &&
                    source.status === "ready"
                      ? when(
                          sourceCheckFrom(source.nextCheckAt, review.nextRunAt),
                        )
                      : "—"}
                  </dd>
                </div>
                <div>
                  <dt>Lidos na última leitura salva</dt>
                  <dd>{count(source.lastLoaded)}</dd>
                </div>
                <div>
                  <dt>Descobertos nessa leitura</dt>
                  <dd>{count(source.lastAdded)}</dd>
                </div>
                <div>
                  <dt>Enfileirados nessa leitura</dt>
                  <dd>{count(source.lastQueued)}</dd>
                </div>
                <div>
                  <dt>Política · intervalo</dt>
                  <dd>
                    {source.enabled
                      ? `${source.autoFollow ? "Coletar e seguir" : "Somente coletar"} · ${source.pollMinutes} min`
                      : "Não autorizada"}
                  </dd>
                </div>
              </dl>
              {source.status === "unavailable" || source.status === "error" ? (
                <p className="continuous-detail">
                  Os contadores são da última leitura salva, quando disponível.
                  A verificação mais recente não concluiu uma nova leitura.
                </p>
              ) : null}
              <div className="continuous-source-actions">
                <button
                  className="button secondary small"
                  disabled={disabled || !source.configurable}
                  onClick={() => onConfigure([source.id])}
                >
                  <Settings2 size={14} />
                  {source.status === "unavailable" || source.status === "error"
                    ? "Conferir e reativar"
                    : "Configurar fonte"}
                </button>
                {source.enabled ? (
                  <button
                    className="text-link"
                    disabled={busy || capability.status !== "supported"}
                    onClick={() =>
                      void run(
                        {
                          type: "CONFIGURE_CONTINUOUS_SOURCE",
                          id: source.id,
                          enabled: false,
                          autoFollow: source.autoFollow === true,
                          pollMinutes: source.pollMinutes,
                        },
                        "Fonte desativada. Os demais dados foram preservados.",
                      )
                    }
                  >
                    Desativar fonte
                  </button>
                ) : null}
              </div>
              {source.status === "unavailable" ? (
                <p className="continuous-detail">
                  A rotina não insiste nesta fonte. Se o perfil bloqueou esta
                  conta, a limitação é a mesma da sua sessão. Reative somente
                  após conferir o acesso.
                </p>
              ) : null}
            </article>
          ))}
        </div>
      )}
      {activationSources.length ? (
        <div className="continuous-activation">
          <h3>
            {review.mode === "running"
              ? "Revisar fontes desta ativação"
              : "Ativar as fontes configuradas"}
          </h3>
          <div className="continuous-start-sources">
            {activationSources.map((source) => (
              <label key={source.id}>
                <input
                  type="checkbox"
                  checked={sourceIds.includes(source.id)}
                  disabled={disabled || review.mode === "running"}
                  onChange={(event) => {
                    const chosen = new Set(sourceIds);
                    if (event.target.checked) chosen.add(source.id);
                    else chosen.delete(source.id);
                    setSelection([...chosen]);
                  }}
                />
                <span>
                  {source.name}
                  <small>
                    {source.autoFollow
                      ? "Coletar e seguir novos elegíveis"
                      : "Somente coletar"}
                  </small>
                </span>
              </label>
            ))}
          </div>
          <label className="continuous-review-check">
            <input
              type="checkbox"
              checked={reviewed}
              disabled={
                disabled || !sourceIds.length || review.mode === "running"
              }
              onChange={(event) =>
                setAcceptedKey(event.target.checked ? snapshotKey : undefined)
              }
            />
            <span>
              Autorizo esta ativação para {sourceIds.length}{" "}
              {sourceIds.length === 1 ? "fonte" : "fontes"}:{" "}
              {selectedAutoFollow} com seguir automático. Horários, limites e
              proteções atuais continuam valendo.
            </span>
          </label>
          <button
            className="button primary"
            disabled={
              disabled ||
              review.mode === "running" ||
              !sourceIds.length ||
              !reviewed
            }
            onClick={() => {
              setAcceptedKey(undefined);
              void run(
                { type: "START_CONTINUOUS", sourceIds, reviewed: true },
                "Rotina ativada para as fontes selecionadas.",
              );
            }}
          >
            <Play size={16} />
            Ativar rotina
          </button>
        </div>
      ) : null}
      <Hint>
        Funciona neste computador, com Chrome e sessão disponíveis; uma conta
        executa por vez. As consultas não são em tempo real e podem trazer
        somente parte dos perfis. Comentários e curtidas usam a publicação
        informada, sem buscar todas as publicações. A rotina não roda na nuvem.
      </Hint>
      {configureIds && configured.length ? (
        <Configuration
          key={`${account.id}:${configureIds.join(":")}`}
          account={account}
          sources={configured}
          disabled={disabled || configured.length !== configureIds.length}
          busy={busy}
          run={run}
          onClose={onCloseConfiguration}
          reviewContext={JSON.stringify([
            account.id,
            account.username,
            state.settings,
            capability.status,
            capability.allDaySchedule,
            sessionConnected,
            configured.map((source) => [
              source.id,
              source.kind,
              source.target,
              source.configurable,
            ]),
          ])}
        />
      ) : null}
    </section>
  );
}
