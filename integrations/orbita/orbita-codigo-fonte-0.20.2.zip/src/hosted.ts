import { hostedRequest, storageKey } from "./transport.ts";
import { supportedHostedExtension } from "./core/hosted-session.ts";
import { createHostedSessionCheck } from "./hosted-access.ts";
const panelUserScope = document
  .querySelector('meta[name="orbita-user"]')
  ?.getAttribute("content");
const connect = document.getElementById(
  "connect-extension",
) as HTMLButtonElement;
const manual = document.getElementById("manual-mode") as HTMLButtonElement;
const status = document.getElementById("connection-status")!;
let mounted = false,
  locked = false;
const appSession = createHostedSessionCheck(panelUserScope);
let unmountApp: (() => void) | undefined;
function lockPanel() {
  if (locked) return;
  locked = true;
  window.orbitaHostedLocked = true;
  clearInterval(sessionPoll);
  document.removeEventListener("visibilitychange", visible);
  window.removeEventListener("orbita-transport-error", transportError);
  window.removeEventListener("orbita-transport-recovered", transportRecovered);
  window.dispatchEvent(new window.Event("orbita-locked"));
  unmountApp?.();
  unmountApp = undefined;
  const card = document.createElement("section");
  card.className = "hosted-setup";
  const title = document.createElement("h1");
  title.textContent = "Confira sua sessão do app";
  const text = document.createElement("p");
  text.textContent =
    "Não foi possível validar o acesso. Reabra o painel para continuar; os dados locais foram preservados. A fila continua sendo gerenciada pela extensão.";
  const link = document.createElement("a");
  link.href = "/api/growth/orbita/painel";
  link.textContent = "Reabrir e verificar acesso";
  card.append(title, text, link);
  document.body.replaceChildren(card);
}
async function mount(extension: boolean) {
  if (mounted || locked) return;
  await appSession();
  if (locked) return;
  if (!extension) storageKey("orbita-accounts-v2"); // Refuse a missing user scope.
  window.orbitaHostedConnected = extension;
  try {
    const app = await import("./main.tsx");
    if (locked) {
      app.unmountApp?.();
      return;
    }
    unmountApp = app.unmountApp;
    mounted = true;
    document.getElementById("setup")!.hidden = true;
    document.getElementById("connection-mode")!.textContent = extension
      ? "Extensão conectada · dados locais deste navegador · uma conta executa por vez"
      : "Modo manual · dados deste usuário neste navegador · sem coleta ou execução no Instagram";
  } catch (error) {
    window.orbitaHostedConnected = false;
    throw error;
  }
}
async function start(extension: boolean) {
  connect.disabled = manual.disabled = true;
  status.textContent = extension
    ? "Verificando a extensão instalada neste navegador…"
    : "Verificando seu acesso ao app…";
  try {
    if (extension) {
      const result = await hostedRequest({ type: "HOSTED_CONNECT" }, 6000);
      if (!result?.ok)
        throw new Error(result?.error || "A extensão não está pronta.");
      if (!supportedHostedExtension(result.version))
        throw new Error(
          "Atualize a extensão para a versão 0.18.0 ou posterior antes de conectar este painel.",
        );
    }
    await mount(extension);
  } catch (error) {
    status.textContent = `${error instanceof Error ? error.message : "Não foi possível abrir o painel."} ${extension ? "Instale ou recarregue a versão 0.18.0 e atualize esta página." : "Reabra o painel com seu login do app."}`;
    connect.disabled = manual.disabled = false;
  }
}
connect.addEventListener("click", () => void start(true));
manual.addEventListener("click", () => void start(false));
const check = async () => {
  if (!locked)
    try {
      await appSession();
    } catch {
      lockPanel();
    }
};
function visible() {
  if (document.visibilityState === "visible") void check();
}
const sessionPoll = setInterval(visible, 30000);
document.addEventListener("visibilitychange", visible);
function transportError() {
  if (mounted && !locked && window.orbitaHostedConnected) {
    document.getElementById("connection-mode")!.textContent =
      "Conexão com a extensão indisponível · confira a instalação e o resultado antes de repetir uma ação";
  }
  void check();
}
function transportRecovered() {
  if (mounted && !locked && window.orbitaHostedConnected)
    document.getElementById("connection-mode")!.textContent =
      "Extensão conectada · dados locais deste navegador · uma conta executa por vez";
}
window.addEventListener("orbita-transport-error", transportError);
window.addEventListener("orbita-transport-recovered", transportRecovered);
