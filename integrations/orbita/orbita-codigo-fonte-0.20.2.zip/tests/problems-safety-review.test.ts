import test from "node:test";
import assert from "node:assert/strict";
import { createRequire } from "node:module";
import { fileURLToPath } from "node:url";
import { runInNewContext } from "node:vm";
import { build } from "esbuild";
import { act, createElement } from "react";
import { createRoot } from "react-dom/client";
import { renderToStaticMarkup } from "react-dom/server";
import { JSDOM } from "jsdom";
import { initialStore, workspace } from "../src/core/accounts.ts";
import { initialState } from "../src/core/domain.ts";
import { emptyProblems } from "../src/core/problems.ts";

const compiled = (await build({
  stdin: {
    contents: "export { ProblemsPage } from './Problems.tsx'; export { DraftPaceNotice, SafetyNotices, SafetyPage } from './Safety.tsx';",
    resolveDir: fileURLToPath(new URL("../src/ui/", import.meta.url)),
    loader: "ts",
  },
  bundle: true, write: false, format: "cjs", platform: "node", packages: "external",
  plugins: [{ name: "isolated-problem-reporter", setup(builder) {
    builder.onResolve({ filter: /(^|\/)problems-client\.ts$/ }, () => ({ path: "reporter", namespace: "fixture" }));
    builder.onLoad({ filter: /.*/, namespace: "fixture" }, () => ({ loader: "js", contents: "export const reportProblem=(...args)=>globalThis.reportFixture(...args); export const changeProblem=async()=>{}; export const useProblems=()=>({});" }));
  } }],
})).outputFiles[0].text;
const mod = { exports: {} as any };
const sandbox: Record<string, any> = { module: mod, exports: mod.exports, require: createRequire(import.meta.url), structuredClone, crypto, console, Error, window: {}, setTimeout, clearTimeout, setInterval, clearInterval };
runInNewContext(compiled, sandbox);
const { ProblemsPage, DraftPaceNotice, SafetyNotices, SafetyPage } = mod.exports;

async function mount(t: any, component: any, props: any) {
  const dom = new JSDOM("<div id='root'></div>", { url: "https://qa.invalid/" });
  const originals = new Map<string, PropertyDescriptor | undefined>();
  for (const [key, value] of Object.entries({ window: dom.window, document: dom.window.document, HTMLElement: dom.window.HTMLElement, Event: dom.window.Event, IS_REACT_ACT_ENVIRONMENT: true })) {
    originals.set(key, Object.getOwnPropertyDescriptor(globalThis, key));
    Object.defineProperty(globalThis, key, { value, configurable: true, writable: true });
    sandbox[key] = value;
  }
  dom.window.HTMLDialogElement.prototype.showModal = function () { this.setAttribute("open", ""); };
  dom.window.HTMLDialogElement.prototype.close = function () { this.removeAttribute("open"); };
  Object.assign(dom.window.HTMLElement.prototype, { attachEvent() {}, detachEvent() {} });
  const root = createRoot(dom.window.document.getElementById("root")!);
  t.after(async () => {
    await act(async () => root.unmount());
    dom.window.close();
    for (const [key, descriptor] of originals) {
      descriptor ? Object.defineProperty(globalThis, key, descriptor) : Reflect.deleteProperty(globalThis, key);
      delete sandbox[key];
    }
    sandbox.window = {};
  });
  await act(async () => root.render(createElement(component, props)));
  const doc = dom.window.document;
  const button = (text: string) => {
    const found = [...doc.querySelectorAll<HTMLButtonElement>("button")].find((node) => node.textContent?.trim() === text);
    assert.ok(found, `Botão ausente: ${text}`);
    return found;
  };
  const click = async (element: HTMLElement) => { await act(async () => element.click()); };
  const fill = async (text: string) => {
    const field = doc.querySelector<HTMLTextAreaElement>("dialog textarea")!;
    await act(async () => {
      field.focus();
      Object.getOwnPropertyDescriptor(dom.window.HTMLTextAreaElement.prototype, "value")!.set!.call(field, text);
      field.dispatchEvent(new dom.window.Event("input", { bubbles: true }));
      field.dispatchEvent(new dom.window.Event("change", { bubbles: true }));
      field.dispatchEvent(new dom.window.KeyboardEvent("keyup", { bubbles: true, key: "a" }));
    });
  };
  const submit = () => doc.querySelector("dialog form")!.dispatchEvent(new dom.window.Event("submit", { bubbles: true, cancelable: true }));
  return { dom, doc, button, click, fill, submit };
}
const problemProps = () => ({ account: workspace(initialStore()), snapshot: { store: emptyProblems(), storageError: "", sessionIds: [], persistedReadable: true } });

test("dois submits do mesmo relato pendente geram somente uma ocorrência", async (t) => {
  const calls: any[] = [];
  const pending: Array<(id: string) => void> = [];
  sandbox.reportFixture = (...args: any[]) => { calls.push(args); return new Promise((resolve) => pending.push(resolve)); };
  const f = await mount(t, ProblemsPage, problemProps());
  await f.click(f.button("Registrar problema"));
  const text = "Relato fictício com contexto suficiente para revisão.";
  await f.fill(text);
  try {
    await act(async () => { f.submit(); f.submit(); });
    assert.equal(calls.length, 1);
    assert.equal(calls[0][0], text);
    assert.equal(calls[0][1].source, "manual");
    assert.equal(f.doc.querySelector<HTMLTextAreaElement>("dialog textarea")!.disabled, true);
    assert.equal(f.button("Cancelar").disabled, true);
    await act(async () => pending[0]("qa-problem"));
    assert.equal(f.doc.querySelector("dialog"), null);
    await f.click(f.button("Registrar problema"));
    assert.equal(f.doc.querySelector<HTMLTextAreaElement>("dialog textarea")!.value, "");
  } finally { await act(async () => pending.forEach((resolve) => resolve("qa-problem"))); }
});

test("falha sem id ou rejeição conserva relato e permite somente nova tentativa explícita", async (t) => {
  let mode: "missing" | "reject" | "success" = "missing";
  let calls = 0;
  sandbox.reportFixture = async () => {
    calls++;
    if (mode === "reject") throw Error("Falha fictícia ao registrar");
    return mode === "success" ? "qa-problem" : undefined;
  };
  const f = await mount(t, ProblemsPage, problemProps());
  await f.click(f.button("Registrar problema"));
  const text = "O texto fictício precisa permanecer após a falha.";
  await f.fill(text);
  await act(async () => { f.submit(); });
  assert.ok(f.doc.querySelector("dialog"));
  assert.equal(f.doc.querySelector<HTMLTextAreaElement>("dialog textarea")!.value, text);
  assert.match(f.doc.querySelector("dialog [role='alert']")!.textContent!, /não foi possível registrar/i);
  assert.equal(calls, 1);
  mode = "reject";
  await act(async () => { f.submit(); });
  assert.equal(f.doc.querySelector<HTMLTextAreaElement>("dialog textarea")!.value, text);
  assert.match(f.doc.querySelector("dialog [role='alert']")!.textContent!, /Falha fictícia/);
  assert.equal(calls, 2);
  mode = "success";
  await act(async () => { f.submit(); });
  assert.equal(f.doc.querySelector("dialog"), null);
  assert.equal(calls, 3);
});

test("ritmo mais conservador informa 3 por dia, lote de 2 e intervalo de 30 minutos", () => {
  const settings = { ...initialState().settings, dailyLimit: 3, sessionLimit: 2, intervalMinutes: 30 };
  const doc = new JSDOM(renderToStaticMarkup(createElement(DraftPaceNotice, { settings }))).window.document;
  const text = doc.body.textContent!;
  assert.match(text, /3 tentativas por dia/);
  assert.match(text, /lotes de 2/);
  assert.match(text, /30 minutos/);
  assert.equal(text.includes("15 minutos"), false);
  assert.match(text, /não.*limite|não.*aprovad|não.*garantia/i);
  assert.equal(doc.querySelector(".draft-pace.attention"), null);
});

test("alertas têm grupo nomeado e avisos pendentes continuam aceitando ocorrências independentes", async (t) => {
  const state = initialState();
  state.settings.hasPendingWarning = true;
  const commands: any[] = [];
  const f = await mount(t, SafetyPage, { state, run: async (command: any) => { commands.push(command); return true; }, busy: false, onSettings: () => {} });
  assert.ok(f.doc.querySelector('[role="group"][aria-label="Alertas de ritmo"]'));
  assert.ok(f.doc.querySelector('[role="group"] [role="alert"]'));
  const warning = f.button("Minha conta mostrou um aviso");
  assert.equal(warning.disabled, false);
  await f.click(warning);
  await f.click(warning);
  assert.deepEqual(JSON.parse(JSON.stringify(commands)), [{ type: "REPORT_WARNING" }, { type: "REPORT_WARNING" }]);
  assert.equal(state.settings.hasPendingWarning, true);
});
