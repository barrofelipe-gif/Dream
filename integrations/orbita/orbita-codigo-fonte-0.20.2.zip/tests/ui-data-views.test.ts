import test from "node:test";
import assert from "node:assert/strict";
import { createRequire } from "node:module";
import { runInNewContext } from "node:vm";
import { fileURLToPath } from "node:url";
import { buildSync } from "esbuild";
import { act, createElement } from "react";
import { createRoot } from "react-dom/client";
import { JSDOM } from "jsdom";
import { initialStore, workspace } from "../src/core/accounts.ts";
import { addRelationshipSnapshot } from "../src/core/relationships.ts";
import { validateInsightReport } from "../src/core/insights.ts";
import type { AccountCommand, InsightReport } from "../src/core/types.ts";

const compiled = buildSync({
  stdin: { contents: `export { RelationshipsPage } from './Relationships.tsx'; export { ContentEntry } from './Growth.tsx'; export { InsightsDashboard } from './Insights.tsx';`, resolveDir: fileURLToPath(new URL("../src/ui/", import.meta.url)), loader: "ts", sourcefile: "ui-data-views.ts" },
  bundle: true, platform: "node", format: "cjs", packages: "external", loader: { ".css": "empty" }, write: false,
}).outputFiles[0].text;
const mod = { exports: {} as any };
const sandbox: Record<string, any> = { module: mod, exports: mod.exports, require: createRequire(import.meta.url), console, window: {}, structuredClone, crypto, URL, setTimeout, clearTimeout, setInterval, clearInterval };
runInNewContext(compiled, sandbox);
const { RelationshipsPage, ContentEntry, InsightsDashboard } = mod.exports;
const fixture = () => { const account = workspace(initialStore()); account.username = "qa.views"; account.label = "Conta fictícia"; return account; };

async function mount(t: any, component: any, props: any) {
  const dom = new JSDOM("<div id='root'></div>", { url: "https://qa.invalid/" });
  const originals = new Map<string, PropertyDescriptor | undefined>();
  for (const [key, value] of Object.entries({ window: dom.window, document: dom.window.document, HTMLElement: dom.window.HTMLElement, Event: dom.window.Event, IS_REACT_ACT_ENVIRONMENT: true })) {
    originals.set(key, Object.getOwnPropertyDescriptor(globalThis, key));
    Object.defineProperty(globalThis, key, { configurable: true, writable: true, value }); sandbox[key] = value;
  }
  dom.window.HTMLDialogElement.prototype.showModal = function () { this.setAttribute("open", ""); };
  dom.window.HTMLDialogElement.prototype.close = function () { this.removeAttribute("open"); };
  Object.assign(dom.window.HTMLElement.prototype, { attachEvent() {}, detachEvent() {} });
  const root = createRoot(dom.window.document.getElementById("root")!);
  t.after(async () => {
    await act(async () => root.unmount()); dom.window.close();
    for (const [key, descriptor] of originals) { descriptor ? Object.defineProperty(globalThis, key, descriptor) : Reflect.deleteProperty(globalThis, key); delete sandbox[key]; }
    sandbox.window = {};
  });
  await act(async () => root.render(createElement(component, props)));
  const doc = dom.window.document;
  const button = (name: string) => {
    const result = [...doc.querySelectorAll<HTMLButtonElement>("button")].find((node) => node.textContent?.trim() === name || node.getAttribute("aria-label") === name);
    assert.ok(result, `Botão ausente: ${name}`); return result;
  };
  const change = async (element: Element, value: string | boolean) => {
    const key = Object.keys(element).find((name) => name.startsWith("__reactProps"))!;
    assert.ok(key);
    await act(async () => (element as any)[key].onChange({ target: typeof value === "boolean" ? { checked: value } : { value } }));
  };
  const field = (name: string) => {
    const label = [...doc.querySelectorAll("label")].find((node) => node.textContent?.includes(name));
    const input = label?.querySelector<HTMLInputElement | HTMLSelectElement>("input,select");
    assert.ok(input, `Campo ausente: ${name}`); return input;
  };
  return { dom, doc, button, change, field, click: async (element: HTMLElement) => { await act(async () => element.click()); } };
}

test("Rede mostra protegidos nas listas descritivas e preserva ocultação apenas em revisões", async (t) => {
  const account = fixture();
  for (const [at, followers] of [["2026-11-01T12:00:00Z", ["qa.kept", "qa.lost"]], ["2026-11-02T12:00:00Z", ["qa.kept"]]] as const) {
    account.relationships = addRelationshipSnapshot(account.relationships, { account: account.username, at, source: "manual", followers: [...followers], following: ["qa.kept", "qa.notback"], followersComplete: true, followingComplete: true }, account.username!);
  }
  account.relationships!.protections = ["qa.kept", "qa.notback", "qa.lost"].map((username) => ({ username, enabled: true, reason: "friend", note: "Proteção fictícia", updatedAt: "2026-11-02T12:00:00Z" }));
  const f = await mount(t, RelationshipsPage, { account, run: async () => true, busy: false });
  const listed = () => [...f.doc.querySelectorAll(".relationship-table tbody a")].map((node) => node.getAttribute("href"));
  assert.deepEqual(listed(), ["https://www.instagram.com/qa.kept/"]);
  assert.equal(f.doc.querySelector(".relationship-check"), null);
  await f.click(f.button("Você segue"));
  assert.deepEqual(listed(), ["https://www.instagram.com/qa.kept/", "https://www.instagram.com/qa.notback/"]);
  for (const [tab, username] of [["Não seguem de volta", "qa.notback"], ["Saíram da lista", "qa.lost"]]) {
    await f.click(f.button(tab));
    const checkbox = f.doc.querySelector<HTMLInputElement>('.relationship-check input[type="checkbox"]')!;
    assert.ok(checkbox); await f.change(checkbox, true); assert.deepEqual(listed(), []);
    await f.change(checkbox, false); assert.deepEqual(listed(), [`https://www.instagram.com/${username}/`]);
  }
});

test("Rede sem medição apresenta início guiado também na aba Mútuos", async (t) => {
  const f = await mount(t, RelationshipsPage, { account: fixture(), run: async () => true, busy: false });
  await f.click(f.button("Mútuos"));
  assert.match(f.doc.body.textContent!, /Comece com suas listas de seguidores e seguidos/);
  assert.doesNotMatch(f.doc.body.textContent!, /Nenhum perfil para revisar neste filtro/);
  assert.ok(f.button("Ler minha rede"));
});

for (const kind of ["reel", "story"] as const) test(`Publicação ${kind} salva só métricas aplicáveis, mantendo dados gerais e adicionais`, async (t) => {
  const report = validateInsightReport({ account: "qa.views", start: "2026-11-01", end: "2026-11-02", coverage: "organic", content: [{ id: "qa-story", kind: "story", title: "Story fictício", metrics: { question_answers: 0, sticker_taps: 4, story_exits: 2, views: 22, replies: 3, qa_imported_metric: 7 } }] }, "qa.views", "file");
  const commands: AccountCommand[] = [];
  const f = await mount(t, ContentEntry, { account: "qa.views", report, content: report.content[0], run: async (command: AccountCommand) => { commands.push(command); return true; }, onSaved() {}, onClose() {}, busy: false });
  await f.change(f.field("Formato da publicação"), kind);
  assert.equal([...f.doc.querySelectorAll("label")].some((node) => node.textContent?.includes("Toques em figurinhas")), kind === "story");
  await act(async () => { f.doc.querySelector("form")!.dispatchEvent(new f.dom.window.Event("submit", { bubbles: true, cancelable: true })); });
  assert.equal(commands.length, 1);
  const revision = (commands[0] as { data: InsightReport }).data, content = revision.content.find((row) => row.id === "qa-story")!;
  assert.equal(content.kind, kind);
  assert.equal(content.metrics.views, 22); assert.equal(content.metrics.replies, 3); assert.equal(content.metrics.qa_imported_metric, 7);
  for (const [key, value] of [["question_answers", 0], ["sticker_taps", 4], ["story_exits", 2]] as const) assert.equal(content.metrics[key], kind === "story" ? value : undefined);
});

test("Insights busca catálogo e extras com um filtro e apresenta vazio quando não encontra métricas", async (t) => {
  const account = fixture();
  account.insights = [validateInsightReport({ account: account.username, start: "2026-11-01", end: "2026-11-02", metrics: { views: 12, qa_custom_metric: 5 } }, account.username!, "file")];
  const f = await mount(t, InsightsDashboard, { account, run: async () => true, busy: false, onMarket() {} });
  await f.click(f.button("Todas as métricas"));
  const input = f.doc.querySelector<HTMLInputElement>('[aria-label="Buscar métrica de Insights"]')!;
  await f.change(input, "não existe qa resultado");
  assert.doesNotMatch(f.doc.body.textContent!, /Outras métricas do arquivo/);
  assert.match(f.doc.body.textContent!, /Nenhuma métrica encontrada/);
  await f.change(input, "QA_CUSTOM");
  assert.match(f.doc.body.textContent!, /Outras métricas do arquivo/);
  assert.match(f.doc.body.textContent!, /qa_custom_metric/);
  assert.doesNotMatch(f.doc.body.textContent!, /Nenhuma métrica encontrada/);
  await f.change(input, " REACH ");
  assert.doesNotMatch(f.doc.body.textContent!, /Outras métricas do arquivo/);
  assert.ok(f.doc.querySelector(".insight-metric-group .insight-kpis > *"));
});
