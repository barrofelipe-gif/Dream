import test from "node:test";
import assert from "node:assert/strict";
import { createRequire } from "node:module";
import { fileURLToPath } from "node:url";
import { runInNewContext } from "node:vm";
import { build } from "esbuild";
import { act, createElement } from "react";
import { createRoot } from "react-dom/client";
import { JSDOM } from "jsdom";
import { accountCommand, initialStore } from "../src/core/accounts.ts";
import { ACCOUNT_STORE_KEY } from "../src/core/accounts.ts";
import { hostedRequest, watchExtension } from "../src/transport.ts";
import { createHostedSessionCheck, verifyHostedActor } from "../src/hosted-access.ts";

const scope = "a".repeat(32);
const turn = () => new Promise<void>((resolve) => setImmediate(resolve));
const require = createRequire(import.meta.url);
function page() {
  const dom = new JSDOM(`<meta name="orbita-user" content="${scope}"><span id="connection-mode"></span><section id="setup"><button id="connect-extension">Conectar</button><button id="manual-mode">Manual</button><p id="connection-status"></p></section><div id="root"></div>`, {
    url: "https://app.bfffitnessatacado.com.br/api/growth/orbita/painel",
    pretendToBeVisual: true,
  });
  const originals = new Map<string, PropertyDescriptor | undefined>();
  for (const [key, value] of Object.entries({
    window: dom.window, document: dom.window.document, location: dom.window.location,
    localStorage: dom.window.localStorage, Event: dom.window.Event,
    CustomEvent: dom.window.CustomEvent, IS_REACT_ACT_ENVIRONMENT: true,
  })) {
    originals.set(key, Object.getOwnPropertyDescriptor(globalThis, key));
    Object.defineProperty(globalThis, key, { configurable: true, writable: true, value });
  }
  return { dom, close() {
    dom.window.close();
    for (const [key, descriptor] of originals)
      descriptor ? Object.defineProperty(globalThis, key, descriptor) : Reflect.deleteProperty(globalThis, key);
  } };
}

async function loadBridge(fixture: object, env: ReturnType<typeof page>) {
  const compiled = (await build({
    entryPoints: [fileURLToPath(new URL("../src/bridge.ts", import.meta.url))],
    bundle: true, write: false, format: "cjs", platform: "node", packages: "external",
    plugins: [{ name: "bridge-fixtures", setup(builder) {
      builder.onResolve({ filter: /(^|\/)transport\.ts$/ }, () => ({ path: "transport", namespace: "fixture" }));
      builder.onResolve({ filter: /(^|\/)problems-client\.ts$/ }, () => ({ path: "problems", namespace: "fixture" }));
      builder.onLoad({ filter: /.*/, namespace: "fixture" }, ({ path }) => ({ loader: "js", contents: path === "transport"
        ? "export const extensionAvailable=()=>true; export const storageKey=x=>x; export const sendExtension=()=>globalThis.fixture.read(); export const watchExtension=fn=>globalThis.fixture.watch(fn);"
        : "export const markReadRecovered=async()=>{}; export const reportProblem=async()=>undefined; export const responseError=x=>Error(x); export const tracked=(_s,_o,fn)=>fn();" }));
    } }],
  })).outputFiles[0].text;
  const mod = { exports: {} as any };
  runInNewContext(compiled, { module: mod, exports: mod.exports, require, fixture, structuredClone, crypto, console, window: env.dom.window, document: env.dom.window.document });
  return mod.exports.useAccountStore;
}

test("GET_STATE inicial atrasado não substitui a atualização mais recente recebida pelo watcher", async () => {
  const env = page();
  const previous = accountCommand(initialStore(), { type: "ADD_ACCOUNT", username: "qa.previous" });
  const fresh = accountCommand(previous, { type: "ADD_ACCOUNT", username: "qa.latest" });
  let release!: (response: unknown) => void;
  let notify!: (changes: unknown, area: string) => void;
  const useAccountStore = await loadBridge({
    read: () => new Promise((resolve) => { release = resolve; }),
    watch: (listener: typeof notify) => { notify = listener; return () => {}; },
  }, env);
  const root = createRoot(env.dom.window.document.getElementById("root")!);
  function Probe() {
    const [store, ready, error] = useAccountStore();
    return createElement("span", null, `${store.activeId}:${ready}:${error || ""}`);
  }
  try {
    await act(async () => root.render(createElement(Probe)));
    await act(async () => notify({ [ACCOUNT_STORE_KEY]: { newValue: fresh } }, "local"));
    await act(async () => release({ ok: true, store: previous }));
    assert.equal(env.dom.window.document.getElementById("root")!.textContent, `${fresh.activeId}:true:`);
  } finally {
    await act(async () => root.unmount());
    env.close();
  }
});

test("evento válido posterior à falha inicial remove o erro sem repetir comandos", async () => {
  const env = page();
  const fresh = accountCommand(initialStore(), { type: "ADD_ACCOUNT", username: "qa.recovered" });
  let notify!: (changes: unknown, area: string) => void;
  let reads = 0;
  const useAccountStore = await loadBridge({
    read: async () => { reads++; return { ok: false, error: "Falha fictícia inicial" }; },
    watch: (listener: typeof notify) => { notify = listener; return () => {}; },
  }, env);
  const root = createRoot(env.dom.window.document.getElementById("root")!);
  function Probe() {
    const [store, ready, error] = useAccountStore();
    return createElement("span", null, `${store.activeId}:${ready}:${error || ""}`);
  }
  try {
    await act(async () => root.render(createElement(Probe)));
    assert.match(env.dom.window.document.getElementById("root")!.textContent!, /Falha fictícia inicial/);
    assert.equal(reads, 1, "uma recusa de aplicação não deve provocar nova leitura automática");
    await act(async () => notify({ [ACCOUNT_STORE_KEY]: { newValue: fresh } }, "local"));
    assert.equal(env.dom.window.document.getElementById("root")!.textContent, `${fresh.activeId}:true:`);
    assert.equal(reads, 1, "a notificação não deve reenviar a leitura ou executar comandos");
  } finally {
    await act(async () => root.unmount());
    env.close();
  }
});

test("bloquear painel interrompe polling e não permite novas solicitações ao relay", async (t) => {
  const env = page();
  const win = env.dom.window as any;
  win.orbitaHostedConnected = true;
  const sent: any[] = [];
  win.postMessage = (request: any) => {
    sent.push(request);
    queueMicrotask(() => win.dispatchEvent(new env.dom.window.MessageEvent("message", {
      source: win, origin: win.location.origin,
      data: { channel: "orbita-extension-response", id: request.id, result: { ok: true, store: initialStore() } },
    })));
  };
  t.mock.timers.enable({ apis: ["Date", "setTimeout", "setInterval"], now: 1_800_000_000_000 });
  const stop = watchExtension(() => {}, ACCOUNT_STORE_KEY);
  try {
    t.mock.timers.tick(15000); await turn();
    assert.equal(sent.length, 1);
    win.orbitaHostedLocked = true;
    win.dispatchEvent(new env.dom.window.Event("orbita-locked"));
    t.mock.timers.tick(45000); await turn();
    win.document.dispatchEvent(new env.dom.window.Event("visibilitychange"));
    await turn();
    assert.equal(sent.length, 1, "painel bloqueado não deve continuar consultando a extensão");
    await assert.rejects(hostedRequest({ type: "GET_STATE" }), /bloqueado|sessão/i);
    assert.equal(sent.length, 1);
  } finally {
    stop(); t.mock.timers.reset(); env.close();
  }
});

test("bloqueio encerra espera pendente sem reenviar nem afirmar cancelamento da ação", async (t) => {
  const env = page();
  const win = env.dom.window as any;
  const sent: unknown[] = [];
  win.postMessage = (request: unknown) => sent.push(request);
  t.mock.timers.enable({ apis: ["Date", "setTimeout"], now: 1_800_000_000_000 });
  try {
    const request = hostedRequest({ type: "COMMAND", command: { type: "START" } }, 100);
    const rejected = assert.rejects(request, /bloqueado.*desconhecido/i);
    win.orbitaHostedLocked = true;
    win.dispatchEvent(new env.dom.window.Event("orbita-locked"));
    t.mock.timers.tick(101);
    await rejected;
    assert.equal(sent.length, 1);
  } finally { t.mock.timers.reset(); env.close(); }
});

test("perda da sessão desmonta o root e encerra os timers sem apagar dados locais", async (t) => {
  const env = page();
  const audit = { renders: 0, unmounts: 0, callbacks: 0, stop: () => {} };
  let valid = true;
  const compiled = (await build({
    entryPoints: [fileURLToPath(new URL("../src/hosted.ts", import.meta.url))],
    bundle: true, write: false, format: "cjs", platform: "node", packages: "external", loader: { ".css": "empty" },
    plugins: [{ name: "hosted-root-lifecycle", setup(builder) {
      builder.onResolve({ filter: /^react-dom\/client$/ }, () => ({ path: "root", namespace: "fixture" }));
      builder.onResolve({ filter: /(^|\/)ui\/App\.tsx$/ }, () => ({ path: "app", namespace: "fixture" }));
      builder.onResolve({ filter: /(^|\/)ui\/ProblemBoundary\.tsx$/ }, () => ({ path: "boundary", namespace: "fixture" }));
      builder.onResolve({ filter: /(^|\/)problems-client\.ts$/ }, () => ({ path: "problems", namespace: "fixture" }));
      builder.onLoad({ filter: /.*/, namespace: "fixture" }, ({ path }) => ({ loader: "js", contents: path === "root"
        ? "export function createRoot(node){return {render(){audit.renders++;node.textContent='QA montado';const timer=setInterval(()=>{},1000);audit.stop=()=>clearInterval(timer);},unmount(){audit.unmounts++;audit.stop();node.replaceChildren();}}}"
        : path === "boundary" ? "export function ProblemBoundary({children}){return children;}"
          : path === "app" ? "export default function App(){return null;}" : "export function installProblemListeners(){}" }));
    } }],
  })).outputFiles[0].text;
  t.mock.timers.enable({ apis: ["Date", "setTimeout", "setInterval"], now: 1_800_000_000_000 });
  env.dom.window.localStorage.setItem("qa-preserved", "fixture de dados mantida");
  const mod = { exports: {} };
  runInNewContext(compiled, {
    module: mod, exports: mod.exports, require, audit,
    window: env.dom.window, document: env.dom.window.document, location: env.dom.window.location,
    fetch: async () => ({ ok: valid, type: "basic", json: async () => ({ ready: true, userScope: scope }) }),
    setTimeout, clearTimeout, clearInterval,
    setInterval: (callback: () => void, delay: number) => setInterval(() => { audit.callbacks++; callback(); }, delay),
    AbortController, AbortSignal, Date, crypto, console,
  });
  try {
    env.dom.window.document.getElementById("manual-mode")!.click();
    await turn();
    assert.equal(audit.renders, 1);
    valid = false;
    env.dom.window.dispatchEvent(new env.dom.window.CustomEvent("orbita-transport-error"));
    await turn();
    assert.match(env.dom.window.document.body.textContent!, /Confira sua sessão/);
    assert.equal(audit.unmounts, 1);
    const before = audit.callbacks;
    t.mock.timers.tick(60000); await turn();
    assert.equal(audit.callbacks, before);
    assert.equal(env.dom.window.localStorage.getItem("qa-preserved"), "fixture de dados mantida");
  } finally { audit.stop(); t.mock.timers.reset(); env.close(); }
});

for (const operation of ["abertura", "gravação"] as const)
  test(`sessão HTTP 200 com HTML exibe erro de acesso na ${operation}, sem mensagem do parser`, async () => {
    const env = page();
    const original = globalThis.fetch;
    globalThis.fetch = async () => ({ ok: true, type: "basic", json: async () => { throw new SyntaxError("Unexpected token < in JSON"); } }) as unknown as Response;
    try {
      const check = operation === "abertura" ? createHostedSessionCheck(scope) : verifyHostedActor;
      await assert.rejects(check(), /sessão.*app|usuário.*sessão/i);
    } finally { globalThis.fetch = original; env.close(); }
  });
