import test from "node:test";
import assert from "node:assert/strict";
import { createRequire } from "node:module";
import { runInNewContext } from "node:vm";
import { fileURLToPath } from "node:url";
import { buildSync } from "esbuild";
import { act, createElement } from "react";
import { createRoot } from "react-dom/client";
import { JSDOM } from "jsdom";
import { initialStore, workspace } from "../src/core/accounts.ts";
import { validateInsightReport } from "../src/core/insights.ts";
import { addRelationshipSnapshot } from "../src/core/relationships.ts";
import { marketProfile, saveMarketReferences } from "../src/core/market.ts";
import type { AccountCommand } from "../src/core/types.ts";

const compiled = buildSync({
  stdin: {
    contents: `export { InsightsDashboard } from './Insights.tsx';
      export { RelationshipsPage } from './Relationships.tsx';
      export { MarketPage } from './Market.tsx';
      export { AccountDataStatus } from './AccountDataStatus.tsx';
      export { ImportModal as ProfileImportModal } from './App.tsx';
      export { Modal } from './components.tsx';`,
    resolveDir: fileURLToPath(new URL("../src/ui/", import.meta.url)),
    sourcefile: "ui-audit-entry.ts",
    loader: "ts",
  },
  bundle: true,
  platform: "node",
  format: "cjs",
  packages: "external",
  loader: { ".css": "empty" },
  write: false,
}).outputFiles[0].text;
const mod = { exports: {} as any };
const sandbox: Record<string, any> = {
  module: mod,
  exports: mod.exports,
  require: createRequire(import.meta.url),
  console,
  window: {},
  structuredClone,
  crypto,
  URL,
  setTimeout,
  clearTimeout,
  setInterval,
  clearInterval,
};
runInNewContext(compiled, sandbox);
const {
  InsightsDashboard,
  RelationshipsPage,
  MarketPage,
  Modal,
  AccountDataStatus,
  ProfileImportModal,
} = mod.exports;

const accountFixture = () => {
  const account = workspace(initialStore());
  account.username = "qa.audit";
  account.label = "Conta fictícia";
  return account;
};
const insight = (end = "2026-10-21") => ({
  account: "qa.audit",
  start: "2026-10-15",
  end,
  coverage: "organic",
  metrics: { views: end.endsWith("21") ? 10 : 20 },
});
const marketReference = (title = "Referência fictícia") => ({
  url: "https://www.instagram.com/reel/QaAudit/",
  creator: "qa.reference",
  sector: "fitness",
  model: "wholesale",
  kind: "reel",
  pattern: "demo",
  title,
  distribution: "organic",
  observedAt: new Date().toISOString(),
  metrics: {},
});

async function mount(t: any, component: any, initialProps: any) {
  const dom = new JSDOM("<div id='root'></div>", {
    url: "https://qa.invalid/",
  });
  const originals = new Map<string, PropertyDescriptor | undefined>();
  for (const [key, value] of Object.entries({
    window: dom.window,
    document: dom.window.document,
    HTMLElement: dom.window.HTMLElement,
    Event: dom.window.Event,
    IS_REACT_ACT_ENVIRONMENT: true,
  })) {
    originals.set(key, Object.getOwnPropertyDescriptor(globalThis, key));
    Object.defineProperty(globalThis, key, {
      configurable: true,
      writable: true,
      value,
    });
    sandbox[key] = value;
  }
  dom.window.HTMLDialogElement.prototype.showModal = function () {
    this.setAttribute("open", "");
  };
  dom.window.HTMLDialogElement.prototype.close = function () {
    this.removeAttribute("open");
  };
  // React loaded without a browser selects its old input polyfill in JSDOM.
  Object.assign(dom.window.HTMLElement.prototype, {
    attachEvent() {},
    detachEvent() {},
  });
  const root = createRoot(dom.window.document.getElementById("root")!);
  let props = initialProps;
  const render = async (next: any = props) => {
    props = next;
    await act(async () => root.render(createElement(component, props)));
  };
  t.after(async () => {
    await act(async () => root.unmount());
    dom.window.close();
    for (const [key, descriptor] of originals) {
      if (descriptor) Object.defineProperty(globalThis, key, descriptor);
      else Reflect.deleteProperty(globalThis, key);
      delete sandbox[key];
    }
    sandbox.window = {};
  });
  await render();
  const doc = dom.window.document;
  const button = (name: string) => {
    const result = [...doc.querySelectorAll<HTMLButtonElement>("button")].find(
      (b) =>
        b.getAttribute("aria-label") === name || b.textContent?.trim() === name,
    );
    assert.ok(result, `Botão ausente: ${name}`);
    return result;
  };
  const click = async (element: HTMLElement) => {
    await act(async () => element.click());
  };
  // File.text is controlled to reproduce completion in a different order from selection.
  const selectFile = async (file: {
    name: string;
    size: number;
    text: () => Promise<string>;
  }) => {
    const input = doc.querySelector<HTMLInputElement>(
      'dialog input[type="file"]',
    )!;
    Object.defineProperty(input, "files", {
      configurable: true,
      value: [file],
    });
    await act(async () => {
      input.dispatchEvent(new dom.window.Event("change", { bubbles: true }));
    });
  };
  return { doc, dom, render, button, click, selectFile };
}

for (const page of ["insights", "relationships"] as const) {
  test(`${page}: confirmação fixa o alvo original quando outra aba adiciona uma medição`, async (t) => {
    const account = accountFixture();
    const commands: AccountCommand[] = [];
    const run = async (command: AccountCommand) => {
      commands.push(command);
      return true;
    };
    let firstId: string;
    if (page === "insights") {
      account.insights = [
        validateInsightReport(insight(), account.username!, "file"),
      ];
      firstId = account.insights[0].id;
    } else {
      account.relationships = addRelationshipSnapshot(
        undefined,
        {
          account: account.username,
          at: "2026-10-20T12:00:00Z",
          source: "file",
          followers: ["qa.first"],
          following: [],
          followersComplete: true,
          followingComplete: true,
        },
        account.username!,
      );
      firstId = account.relationships.snapshots[0].id;
    }
    const component =
      page === "insights" ? InsightsDashboard : RelationshipsPage;
    const props = { account, run, busy: false, onMarket: () => {} };
    const f = await mount(t, component, props);
    await f.click(
      f.button(
        page === "insights"
          ? "Remover relatório de Insights selecionado"
          : "Remover medição de relações selecionada",
      ),
    );
    const next = structuredClone(account);
    if (page === "insights")
      next.insights!.push(
        validateInsightReport(insight("2026-10-22"), next.username!, "file"),
      );
    else
      next.relationships = addRelationshipSnapshot(
        next.relationships,
        {
          account: next.username,
          at: "2026-10-21T12:00:00Z",
          source: "file",
          followers: ["qa.second"],
          following: [],
          followersComplete: true,
          followingComplete: true,
        },
        next.username!,
      );
    await f.render({ ...props, account: next });
    await f.click(
      f.button(page === "insights" ? "Remover relatório" : "Remover medição"),
    );
    assert.equal(commands.length, 1);
    assert.equal((commands[0] as { id: string }).id, firstId);
  });

  test(`${page}: alvo removido em outra aba não autoriza excluir o próximo registro`, async (t) => {
    const account = accountFixture();
    const commands: AccountCommand[] = [];
    if (page === "insights")
      account.insights = [
        validateInsightReport(insight(), account.username!, "file"),
      ];
    else
      account.relationships = addRelationshipSnapshot(
        undefined,
        {
          account: account.username,
          at: "2026-10-20T12:00:00Z",
          source: "file",
          followers: [],
          following: [],
          followersComplete: true,
          followingComplete: true,
        },
        account.username!,
      );
    const props = {
      account,
      busy: false,
      onMarket: () => {},
      run: async (c: AccountCommand) => {
        commands.push(c);
        return true;
      },
    };
    const f = await mount(
      t,
      page === "insights" ? InsightsDashboard : RelationshipsPage,
      props,
    );
    await f.click(
      f.button(
        page === "insights"
          ? "Remover relatório de Insights selecionado"
          : "Remover medição de relações selecionada",
      ),
    );
    const next = structuredClone(account);
    if (page === "insights")
      next.insights = [
        validateInsightReport(insight("2026-10-22"), next.username!, "file"),
      ];
    else next.relationships!.snapshots = [];
    await f.render({ ...props, account: next });
    const confirm = [
      ...f.doc.querySelectorAll<HTMLButtonElement>("dialog button"),
    ].find(
      (b) =>
        b.textContent?.trim() ===
        (page === "insights" ? "Remover relatório" : "Remover medição"),
    );
    assert.ok(
      !confirm || confirm.disabled,
      "Confirmação deve ser fechada ou desabilitada",
    );
    if (confirm) await f.click(confirm);
    assert.deepEqual(commands, []);
  });
}

for (const page of ["insights", "market"] as const) {
  for (const staleOutcome of ["success", "error"] as const) {
    test(`${page}: leitura antiga ${staleOutcome} não substitui o último arquivo selecionado`, async (t) => {
      const account = accountFixture();
      const commands: AccountCommand[] = [];
      const f = await mount(
        t,
        page === "insights" ? InsightsDashboard : MarketPage,
        {
          account,
          busy: false,
          onMarket: () => {},
          run: async (c: AccountCommand) => {
            commands.push(c);
            return true;
          },
        },
      );
      await f.click(
        f.button(
          page === "insights" ? "Importar Insights" : "Importar referências",
        ),
      );
      let resolve!: (text: string) => void;
      let reject!: (error: Error) => void;
      const slow = new Promise<string>((yes, no) => {
        resolve = yes;
        reject = no;
      });
      await f.selectFile({ name: "antigo.json", size: 100, text: () => slow });
      const latest =
        page === "insights"
          ? { reports: [insight("2026-10-22")] }
          : {
              account: account.username,
              references: [marketReference("Arquivo mais recente")],
            };
      await f.selectFile({
        name: "ultimo.json",
        size: 100,
        text: async () => JSON.stringify(latest),
      });
      await act(async () => {
        if (staleOutcome === "error")
          reject(new Error("Falha antiga que deve ser descartada"));
        else
          resolve(
            JSON.stringify(
              page === "insights"
                ? { reports: [insight()] }
                : {
                    account: account.username,
                    references: [marketReference("Arquivo antigo")],
                  },
            ),
          );
        await slow.catch(() => {});
      });
      assert.equal(f.doc.querySelector('[role="alert"]'), null);
      if (page === "insights")
        assert.match(
          f.doc.querySelector(".insight-import-preview")!.textContent!,
          /ultimo\.json/,
        );
      await f.click(
        f.button(
          page === "insights"
            ? "Importar 1 relatório"
            : "Importar 1 referências",
        ),
      );
      assert.equal(commands.length, 1);
      const input = (commands[0] as { data: any }).data;
      if (page === "insights") assert.equal(input[0].end, "2026-10-22");
      else assert.equal(input.references[0].title, "Arquivo mais recente");
    });
  }
}

test("Radar: apagar janela mantém campo vazio e salvar uma nova janela envia o valor visível", async (t) => {
  const account = accountFixture();
  account.market = saveMarketReferences(
    undefined,
    { account: account.username, references: [marketReference()] },
    account.username!,
  );
  account.market.profile = marketProfile({
    sector: "fitness",
    model: "wholesale",
    audience: "lojistas",
    bio: "Moda fitness no atacado",
  });
  const commands: AccountCommand[] = [];
  const f = await mount(t, MarketPage, {
    account,
    busy: false,
    run: async (c: AccountCommand) => {
      commands.push(c);
      return true;
    },
  });
  await f.click(f.button("Adaptar para mim →"));
  const input = f.doc.querySelector<HTMLInputElement>(
    'dialog input[type="number"]',
  )!;
  const change = async (value: string) => {
    const propsKey = Object.keys(input).find((key) =>
      key.startsWith("__reactProps"),
    )!;
    await act(async () =>
      (input as any)[propsKey].onChange({ target: { value } }),
    );
  };
  await change("");
  assert.equal(input.value, "");
  assert.equal(input.validity.valueMissing, true);
  await f.click(f.button("Salvar teste"));
  assert.equal(commands.length, 0);
  await change("48");
  await f.click(f.button("Salvar teste"));
  assert.equal(commands.length, 1);
  assert.equal((commands[0] as { data: any }).data.experiment.windowHours, 48);
});

test("Modal: título e descrição fornecem nomes acessíveis únicos e estáveis", async (t) => {
  const f = await mount(t, Modal, {
    title: "Revisar operação",
    subtitle: "Conta fictícia",
    onClose: () => {},
    children: createElement("button", null, "Confirmar"),
  });
  const dialog = f.doc.querySelector("dialog")!;
  const titleId = dialog.getAttribute("aria-labelledby");
  const descriptionId = dialog.getAttribute("aria-describedby");
  assert.ok(titleId);
  assert.ok(descriptionId);
  assert.equal(f.doc.getElementById(titleId)!.textContent, "Revisar operação");
  assert.equal(
    f.doc.getElementById(descriptionId)!.textContent,
    "Conta fictícia",
  );
  await f.render({
    title: "Revisão atualizada",
    onClose: () => {},
    children: "Conteúdo",
  });
  assert.equal(dialog.getAttribute("aria-labelledby"), titleId);
  assert.equal(
    f.doc.getElementById(titleId)!.textContent,
    "Revisão atualizada",
  );
  assert.equal(dialog.hasAttribute("aria-describedby"), false);
});

test("disponibilidade dos dados tem título de seção e fallback sem arroba fictício", async (t) => {
  const account = workspace(initialStore());
  const f = await mount(t, AccountDataStatus, { account, area: "network" });
  const section = f.doc.querySelector("section")!;
  assert.equal(
    section.getAttribute("aria-label"),
    "Disponibilidade dos dados da sua conta",
  );
  assert.equal(
    section.querySelector(".account-data-heading h2")?.textContent,
    "Seus dados, passo a passo",
  );
  assert.equal(section.querySelectorAll(".account-data-grid h3").length, 3);
  await f.render({
    account: { ...account, username: "qa.audit" },
    area: "network",
  });
  assert.equal(
    section.getAttribute("aria-label"),
    "Disponibilidade dos dados de @qa.audit",
  );
});

test("Modal: cancelamento nativo respeita onClose que mantém operação pendente aberta", async (t) => {
  let calls = 0;
  const f = await mount(t, Modal, {
    title: "Salvando configuração",
    onClose: () => {
      calls++;
    },
    children: "Operação pendente",
  });
  const dialog = f.doc.querySelector("dialog")!;
  const cancel = new f.dom.window.Event("cancel", {
    bubbles: false,
    cancelable: true,
  });
  await act(async () => {
    dialog.dispatchEvent(cancel);
  });
  assert.equal(calls, 1);
  assert.equal(cancel.defaultPrevented, true);
  assert.equal(dialog.open, true);
});

async function profileImporter(t: any) {
  const commands: any[] = [];
  const f = await mount(t, ProfileImportModal, {
    campaigns: [
      {
        id: "qa-campaign",
        name: "QA fictícia",
        kind: "import",
        target: "Lista fictícia",
        createdAt: new Date().toISOString(),
        archived: false,
      },
    ],
    initialCampaign: "qa-campaign",
    busy: false,
    onClose: () => {},
    onImported: () => {},
    run: async (command: any) => {
      commands.push(command);
      return true;
    },
  });
  return { ...f, commands };
}

test("perfis: último arquivo vence e importação continua exigindo envio explícito", async (t) => {
  const f = await profileImporter(t);
  let resolve!: (text: string) => void;
  const slow = new Promise<string>((yes) => {
    resolve = yes;
  });
  await f.selectFile({ name: "antigo.txt", size: 100, text: () => slow });
  await f.selectFile({
    name: "ultimo.txt",
    size: 100,
    text: async () => "qa.latest",
  });
  await act(async () => {
    resolve("qa.old");
    await slow;
  });
  assert.equal(f.doc.querySelector("textarea")!.value, "qa.latest");
  assert.equal(f.commands.length, 0);
  await f.click(f.button("Importar perfis"));
  assert.equal(f.commands.length, 1);
  assert.equal(f.commands[0].candidates[0].username, "qa.latest");
});

test("perfis: digitação manual invalida leitura pendente e preserva a seleção digitada", async (t) => {
  const f = await profileImporter(t);
  let resolve!: (text: string) => void;
  const slow = new Promise<string>((yes) => {
    resolve = yes;
  });
  await f.selectFile({ name: "antigo.txt", size: 100, text: () => slow });
  const textarea = f.doc.querySelector("textarea")!;
  const propsKey = Object.keys(textarea).find((key) =>
    key.startsWith("__reactProps"),
  )!;
  await act(async () =>
    (textarea as any)[propsKey].onChange({ target: { value: "qa.manual" } }),
  );
  await act(async () => {
    resolve("qa.old");
    await slow;
  });
  assert.equal(textarea.value, "qa.manual");
  assert.deepEqual(f.commands, []);
});

test("perfis: falha atual de leitura tem aviso e não importa registros antigos", async (t) => {
  const f = await profileImporter(t);
  await f.selectFile({
    name: "valido.txt",
    size: 100,
    text: async () => "qa.previous",
  });
  await f.selectFile({
    name: "falha.txt",
    size: 100,
    text: async () => {
      throw Error("QA dispositivo indisponível");
    },
  });
  assert.match(
    f.doc.querySelector('[role="alert"]')!.textContent!,
    /ler o arquivo/,
  );
  assert.equal(f.doc.querySelector("textarea")!.value, "");
  assert.equal(f.button("Importar perfis").disabled, true);
  assert.deepEqual(f.commands, []);
});
