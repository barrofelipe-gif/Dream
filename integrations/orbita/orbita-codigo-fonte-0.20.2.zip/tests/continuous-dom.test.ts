import test from "node:test";
import assert from "node:assert/strict";
import { JSDOM } from "jsdom";
import type { Campaign } from "../src/core/types.ts";
import { hasPageDraft, stepContinuousSource } from "../src/extension/continuous-dom.ts";

const actor = "qa.actor", profile = "qa.source", postUrl = "https://www.instagram.com/p/QApost/";
const nav = `<nav><a href="/${actor}/">Perfil</a></nav>`;
const campaign = (kind: Campaign["kind"]): Campaign => ({ id: `source-${kind}`, kind, target: ["followers", "following"].includes(kind) ? `@${profile}` : postUrl, name: "Fonte fictícia", archived: false, createdAt: "2026-10-01T12:00:00Z" });
const env = (html: string, url = `https://www.instagram.com/${profile}/`) => new JSDOM(nav + html, { url });
const request = (kind: Campaign["kind"], runId = "qa-run") => ({ campaign: campaign(kind), expectedAccount: actor, runId });
const step = (dom: JSDOM, kind: Campaign["kind"], runId = "qa-run") => stepContinuousSource(dom.window.document, dom.window.location.href, request(kind, runId));
const rows = (start = 0, count = 25) => Array.from({ length: count }, (_, i) => `<div><a href="/qa.person${start + i}/">avatar</a><a href="/qa.person${start + i}/">qa.person${start + i}</a><button data-social>Seguir</button></div>`).join("");
const profileHeader = (english = false) => `<main><header><div><h2>${profile}</h2><button data-social>Seguir</button><button data-social>Enviar mensagem</button><div><div>17 posts</div><div><a id="followers" href="#">221 mil ${english ? "followers" : "seguidores"}</a></div><div><a id="following" href="#">33 ${english ? "following" : "seguindo"}</a></div></div></div></header><aside><a href="/qa.suggestion/">qa.suggestion</a><button data-social>Seguir</button></aside></main>`;
const dialog = (title: string, content = rows()) => `<div role="dialog"><div role="heading">${title}</div><div id="list" style="overflow-y:auto">${content}</div></div>`;
function scroller(dom: JSDOM, mutate?: (top: number) => void) {
  const list = dom.window.document.querySelector<HTMLElement>("#list")!;
  let top = 0;
  Object.defineProperties(list, { clientHeight: { configurable: true, value: 100 }, scrollHeight: { configurable: true, value: 500 }, scrollTop: { configurable: true, get: () => top, set(value) { top = value; mutate?.(value); } } });
  return list;
}
const commentRow = (name = "qa.customer", id = "123", owner = false) => `<div><div><a href="/${owner ? profile : name}/">${owner ? profile : name}</a><a href="/p/QApost/c/${id}/"><time datetime="2026-10-10T12:00:00Z">3 sem</time></a></div><p>Comentário fictício</p><button data-social>Responder</button><div role="button" data-social><svg aria-label="Curtir"></svg></div></div>`;
const post = (comments = commentRow(), extra = "") => `<main><div id="post"><div><a href="/${profile}/">${profile}</a><button><svg aria-label="Mais opções"></svg></button></div><p>Legenda fictícia</p><div id="comments" style="overflow-y:auto">${comments}</div><div id="footer"><div><span><div role="button" data-social><svg aria-label="Curtir"></svg></div></span><span id="likes" role="button">49</span><span><div role="button" data-social><svg aria-label="Comentar"></svg></div></span><span role="button">8</span><div role="button" data-social><svg aria-label="Repostar"></svg></div><span role="button">2</span></div><a href="/${profile}/p/QApost/"><time datetime="2026-10-01T12:00:00Z">data</time></a></div>${extra}</div><aside><ul><li><a href="/qa.suggestion/">qa.suggestion</a></li></ul></aside></main>`;

test("seguidores PT: abre só o contador, captura antes de rolar e agrega chunks virtualizados", () => {
  const dom = env(profileHeader());
  let opened = 0, social = 0, scrolls = 0;
  dom.window.document.querySelector("#followers")!.addEventListener("click", () => { opened++; dom.window.document.body.insertAdjacentHTML("beforeend", dialog("Seguidores")); });
  dom.window.document.querySelectorAll("[data-social]").forEach((button) => button.addEventListener("click", () => social++));
  const first = step(dom, "followers");
  assert.equal(first.ok, true); if (!first.ok) return;
  assert.equal(first.data.phase, "loading"); assert.equal(first.data.complete, false); assert.equal(first.data.url, `https://www.instagram.com/${profile}/followers/`); assert.deepEqual(first.data.candidates, []);
  scroller(dom, () => { scrolls++; dom.window.document.querySelector("#list")!.innerHTML = rows(20, 25); });
  const second = step(dom, "followers");
  assert.equal(second.ok, true); if (!second.ok) return;
  assert.equal(second.data.candidates.length, 25); assert.equal(second.data.candidates[0].username, "qa.person0"); assert.equal(second.data.phase, "ready");
  const third = step(dom, "followers"); assert.equal(third.ok, true); if (!third.ok) return;
  const accumulated = new Set([...second.data.candidates, ...third.data.candidates].map((candidate) => candidate.username));
  assert.equal(accumulated.size, 45); assert.equal(third.data.candidates[0].username, "qa.person20"); assert.equal(opened, 1); assert.equal(scrolls, 2); assert.equal(social, 0);
});

test("Following EN não clica no estado Following ou nos botões Follow de pessoas", () => {
  const dom = env(profileHeader(true)); let opened = 0;
  dom.window.document.querySelector("#following")!.addEventListener("click", () => { opened++; dom.window.document.body.insertAdjacentHTML("beforeend", dialog("Following", rows(0, 3))); });
  dom.window.document.querySelectorAll("[data-social]").forEach((button) => button.addEventListener("click", () => assert.fail("Não clicar em ação social")));
  assert.equal(step(dom, "following").ok, true);
  const result = step(dom, "following"); assert.equal(result.ok, true); if (!result.ok) return;
  assert.equal(result.data.candidates.length, 3); assert.equal(result.data.phase, "end"); assert.equal(result.data.complete, false); assert.equal(opened, 1);
});

test("Curtidas/Likes abre o contador adjacente, nunca o ícone Curtir, e isola o diálogo", () => {
  for (const title of ["Curtidas", "Likes"]) {
    const dom = env(post(), `https://www.instagram.com/${profile}/p/QApost/`); let opened = 0, social = 0;
    dom.window.document.querySelectorAll("[data-social]").forEach((button) => button.addEventListener("click", () => social++));
    dom.window.document.querySelector("#likes")!.addEventListener("click", () => { opened++; dom.window.document.body.insertAdjacentHTML("beforeend", dialog(title, rows(0, 19))); });
    const initial = step(dom, "likers"); assert.equal(initial.ok, true); if (!initial.ok) continue;
    assert.equal(initial.data.phase, "loading");
    const result = step(dom, "likers"); assert.equal(result.ok, true); if (!result.ok) continue;
    assert.equal(result.data.url, postUrl); assert.equal(result.data.candidates.length, 19); assert.equal(result.data.candidates.some((candidate) => candidate.username === "qa.suggestion"), false); assert.equal(opened, 1); assert.equal(social, 0);
  }
});

test("Curtidas recém-aberto sem spinner espera as linhas antes de concluir, sem gravar zero nem repetir o opener", () => {
  const dom = env(post(), `https://www.instagram.com/${profile}/p/QApost/`);
  let opened = 0, social = 0;
  dom.window.document.querySelectorAll("[data-social]").forEach((button) => button.addEventListener("click", () => social++));
  dom.window.document.querySelector("#likes")!.addEventListener("click", () => {
    opened++;
    dom.window.document.body.insertAdjacentHTML("beforeend", '<div role="dialog"><h2>Curtidas</h2><div id="hydrating-list"></div></div>');
  });
  const opening = step(dom, "likers"); assert.equal(opening.ok, true); if (!opening.ok) return;
  assert.equal(opening.data.phase, "loading");
  assert.equal(dom.window.document.querySelector('[role="progressbar"]'), null);
  const pending = step(dom, "likers"); assert.equal(pending.ok, true); if (!pending.ok) return;
  assert.equal(pending.data.phase, "loading", "título sem linhas ainda não é uma leitura zero observada");
  assert.deepEqual(pending.data.candidates, []); assert.equal(pending.data.complete, false);
  dom.window.document.querySelector("#hydrating-list")!.innerHTML = rows(0, 11);
  assert.equal(dom.window.document.querySelectorAll('#hydrating-list a[href]').length, 22);
  const populated = step(dom, "likers"); assert.equal(populated.ok, true); if (!populated.ok) return;
  assert.equal(populated.data.phase, "end"); assert.equal(populated.data.candidates.length, 11);
  assert.equal(populated.data.complete, false); assert.equal(opened, 1); assert.equal(social, 0);
});

test("diálogos vazios persistentes sem prova de zero nunca viram end por quantidade de etapas", () => {
  for (const [kind, title] of [["followers", "Seguidores"], ["following", "Following"], ["likers", "Likes"]] as const) {
    const dom = env((kind === "likers" ? post() : profileHeader()) + dialog(title, ""), kind === "likers" ? postUrl : `https://www.instagram.com/${profile}/`);
    let clicks = 0;
    dom.window.document.querySelectorAll('button,[role="button"],a[href]').forEach((control) => control.addEventListener("click", () => clicks++));
    for (let i = 0; i < 20; i++) {
      const result = step(dom, kind); assert.equal(result.ok, true); if (!result.ok) continue;
      assert.equal(result.data.phase, "loading"); assert.deepEqual(result.data.candidates, []); assert.equal(result.data.complete, false);
    }
    assert.equal(clicks, 0);
  }
});

test("nova consulta no mesmo documento não herda evidência de linhas de outra execução", () => {
  const dom = env(post() + dialog("Curtidas", rows(0, 2)), postUrl);
  const previous = step(dom, "likers", "qa-previous-run"); assert.equal(previous.ok, true); if (!previous.ok) return;
  assert.equal(previous.data.phase, "end"); assert.equal(previous.data.candidates.length, 2);
  dom.window.document.querySelector("#list")!.replaceChildren();
  const next = step(dom, "likers", "qa-next-run"); assert.equal(next.ok, true); if (!next.ok) return;
  assert.equal(next.data.phase, "loading"); assert.deepEqual(next.data.candidates, []); assert.equal(next.data.runId, "qa-next-run");
});

test("comentários ainda sem linha nem spinner esperam conteúdo; mensagem explícita de vazio continua distinta", () => {
  const dom = env(post(""), postUrl);
  const waiting = step(dom, "commenters"); assert.equal(waiting.ok, true); if (!waiting.ok) return;
  assert.equal(waiting.data.phase, "loading"); assert.deepEqual(waiting.data.candidates, []);
  dom.window.document.querySelector("#comments")!.innerHTML = commentRow();
  const populated = step(dom, "commenters"); assert.equal(populated.ok, true); if (!populated.ok) return;
  assert.equal(populated.data.phase, "end"); assert.equal(populated.data.candidates.length, 1);
  dom.window.document.querySelector("#comments")!.innerHTML = '<p>Nenhum comentário ainda.</p>';
  const empty = step(dom, "commenters"); assert.equal(empty.ok, true); if (!empty.ok) return;
  assert.equal(empty.data.phase, "end"); assert.deepEqual(empty.data.candidates, []); assert.equal(empty.data.complete, false);
});

test("comentários DIV capturam fonte antes de expandir PT/EN, excluindo autor e sugestões", () => {
  for (const label of ["Carregar mais comentários", "Load more comments", "Ver todos os 8 comentários", "View all 8 comments"]) {
    const dom = env(post(commentRow() + commentRow(profile, "124", true), `<button id="expand">${label}</button>`), postUrl); let expanded = 0;
    dom.window.document.querySelector("#expand")!.addEventListener("click", () => expanded++);
    dom.window.document.querySelectorAll("[data-social]").forEach((button) => button.addEventListener("click", () => assert.fail("Não clicar Curtir/Responder")));
    const first = step(dom, "commenters"); assert.equal(first.ok, true); if (!first.ok) continue;
    assert.deepEqual(first.data.candidates.map((candidate) => candidate.username), ["qa.customer"]); assert.equal(expanded, 1); assert.equal(first.data.complete, false);
    const second = step(dom, "commenters"); assert.equal(second.ok, true); if (!second.ok) continue;
    assert.equal(second.data.phase, "loading"); assert.equal(expanded, 1, "não repetir controle pendente sem mudança de DOM");
  }
});

test("fonte privada/404 vira indisponível genérico, sem inferir bloqueio ou trocar conta", () => {
  for (const label of ["Esta conta é privada", "Desculpe, esta página não está disponível.", "This account is private", "Sorry, this page isn't available."]) {
    const dom = env(`<main><h2>${label}</h2></main>`);
    const result = step(dom, "followers"); assert.equal(result.ok, false); if (result.ok) continue;
    assert.equal(result.unavailable, true); assert.doesNotMatch(result.error, /bloqueou|blocked by|bloqueado por/i); assert.equal(dom.window.document.querySelector("nav a")!.getAttribute("href"), `/${actor}/`);
  }
});

test("comentários contínuos não autorizam sugestões UL no mesmo escopo da publicação", () => {
  const dom = env(post(commentRow()), postUrl);
  const container = dom.window.document.querySelector("#post")!;
  // Some layouts place the owner and controls in sibling branches, so the
  // verified post scope reaches MAIN together with its suggestions section.
  container.replaceWith(...container.childNodes);
  const aside = dom.window.document.querySelector("aside")!;
  const suggestions = dom.window.document.createElement("section");
  suggestions.innerHTML = aside.innerHTML;
  aside.replaceWith(suggestions);
  dom.window.document.querySelectorAll("[data-social]").forEach((button) => button.addEventListener("click", () => assert.fail("Não clicar ação social")));
  const result = step(dom, "commenters");
  assert.equal(result.ok, true); if (!result.ok) return;
  assert.deepEqual(result.data.candidates.map((candidate) => candidate.username), ["qa.customer"]);
  assert.equal(result.data.complete, false);
});

test("restrição da plataforma e sessão trocada param antes de qualquer clique ou rolagem", () => {
  const blocked = env(profileHeader() + '<div role="alert">Try again later</div>');
  const warning = step(blocked, "followers"); assert.equal(warning.ok, false); if (!warning.ok) assert.equal(warning.platformWarning, true);
  const dom = env(profileHeader() + dialog("Seguidores")); let scrolls = 0;
  const list = scroller(dom, () => scrolls++);
  Object.defineProperty(list, "scrollHeight", { configurable: true, get() { dom.window.document.querySelector("nav a")!.setAttribute("href", "/qa.other/"); return 500; } });
  const changed = step(dom, "followers"); assert.equal(changed.ok, false); if (!changed.ok) { assert.equal(changed.accountMismatch, true); assert.equal(changed.unavailable, undefined); } assert.equal(scrolls, 0);
});

test("diálogo errado, controle duplicado e autor divergente param de forma explícita", () => {
  assert.equal(step(env(profileHeader() + dialog("Curtidas")), "followers").ok, false);
  assert.equal(step(env(post(commentRow(), '<button>Load more comments</button><button>Load more comments</button>'), postUrl), "commenters").ok, false);
  const wrong = request("likers"); wrong.campaign.group = { id: "group", name: "Fictício", profile: "qa.other", postUrl };
  const dom = env(post(), postUrl);
  assert.equal(stepContinuousSource(dom.window.document, dom.window.location.href, wrong).ok, false);
});

test("comentários explicitamente vazios continuam parciais; loading não vira ausência", () => {
  for (const label of ["Nenhum comentário ainda.", "No comments yet."]) {
    const dom = env(post(`<p>${label}</p>`), postUrl);
    const result = step(dom, "commenters"); assert.equal(result.ok, true); if (!result.ok) continue;
    assert.equal(result.data.phase, "end"); assert.deepEqual(result.data.candidates, []); assert.equal(result.data.complete, false);
  }
  const dom = env(post('<div role="progressbar"></div>'), postUrl);
  const result = step(dom, "commenters"); assert.equal(result.ok, true); if (result.ok) assert.equal(result.data.phase, "loading");
});

test("rascunhos impedem STEP sem alterar o texto; campos invisíveis e botões não são draft", () => {
  const dom = env(profileHeader() + '<textarea>texto privado fictício</textarea>'); let clicked = 0;
  dom.window.document.querySelector("#followers")!.addEventListener("click", () => clicked++);
  const result = step(dom, "followers"); assert.equal(result.ok, false); assert.equal(clicked, 0); assert.equal(dom.window.document.querySelector("textarea")!.value, "texto privado fictício"); assert.doesNotMatch(JSON.stringify(result), /texto privado fictício/);
  assert.equal(hasPageDraft(env('<input type="hidden" value="token"><input type="button" value="Enviar"><input hidden value="ignorado">').window.document), false);
  assert.equal(hasPageDraft(env('<div contenteditable="true">rascunho</div>').window.document), true);
});

test("STATUS expõe somente bool do rascunho e STEP pelo content não importa candidatos", async () => {
  const keys = ["document", "location", "chrome", "__orbita_content_v1__"], descriptors = new Map(keys.map((key) => [key, Object.getOwnPropertyDescriptor(globalThis, key)]));
  const dom = env(profileHeader() + '<textarea>segredo fictício do rascunho</textarea>'); let listener: Function | undefined; const messages: any[] = [];
  const put = (key: string, value: unknown) => Object.defineProperty(globalThis, key, { configurable: true, writable: true, value });
  try {
    put("document", dom.window.document); put("location", dom.window.location); put("__orbita_content_v1__", false);
    put("chrome", { runtime: { id: "qa-extension", onMessage: { addListener(fn: Function) { listener = fn; } }, async sendMessage(message: any) { messages.push(message); return { ok: false }; } } });
    const modulePath = "../src/extension/content.ts?qa-continuous-source"; await import(modulePath);
    let status: any; listener!({ type: "STATUS" }, { id: "qa-extension" }, (value: any) => { status = value; });
    assert.equal(status.hasDraft, true); assert.doesNotMatch(JSON.stringify(status), /segredo fictício/);
    let result: any; listener!({ type: "STEP_CONTINUOUS_SOURCE", ...request("followers") }, { id: "qa-extension" }, (value: any) => { result = value; });
    assert.equal(result.ok, false); assert.equal(messages.some((message) => ["CAPTURE", "IMPORT", "FOLLOW", "UNFOLLOW", "AUTHORIZE_CLICK"].includes(message.type)), false);
  } finally { dom.window.close(); for (const key of keys) { const descriptor = descriptors.get(key); if (descriptor) Object.defineProperty(globalThis, key, descriptor); else delete (globalThis as any)[key]; } }
});
