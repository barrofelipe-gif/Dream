import test from "node:test";
import assert from "node:assert/strict";
import { createRequire } from "node:module";
import { runInNewContext } from "node:vm";
import { fileURLToPath } from "node:url";
import { buildSync } from "esbuild";
import { act, createElement, StrictMode } from "react";
import { createRoot } from "react-dom/client";
import { renderToStaticMarkup } from "react-dom/server";
import { JSDOM } from "jsdom";
import { initialStore, workspace } from "../src/core/accounts.ts";
import { applyCommand } from "../src/core/domain.ts";
import {
  configureContinuousSource,
  pauseContinuous,
  startContinuous,
} from "../src/core/continuous.ts";
import type { Command, SpecialCommand } from "../src/core/types.ts";

const compiled = buildSync({
  entryPoints: [
    fileURLToPath(new URL("../src/ui/ContinuousSources.tsx", import.meta.url)),
  ],
  bundle: true,
  platform: "node",
  format: "cjs",
  packages: "external",
  loader: { ".css": "empty" },
  write: false,
}).outputFiles[0].text;
const mod = { exports: {} as any };
const sandbox: Record<string, any> = {
  module: mod,
  exports: mod.exports,
  require: createRequire(import.meta.url),
  console,
  structuredClone,
  crypto,
  URL,
  setTimeout,
  clearTimeout,
  setInterval,
  clearInterval,
};
runInNewContext(compiled, sandbox);
const { ContinuousSources, useContinuousCapability } = mod.exports;

function fixture() {
  const account = workspace(initialStore());
  account.username = "qa.continuous";
  account.label = "Conta fictícia";
  account.verifiedAt = new Date().toISOString();
  account.data.runtime.account = account.username;
  account.data.runtime.connectedAt = account.verifiedAt;
  account.data = applyCommand(account.data, {
    type: "CREATE_PROFILE_CAMPAIGN",
    name: "Grupo fictício",
    profile: "qa.reference",
    postUrl: "https://www.instagram.com/p/QaFixture/",
  });
  const commands: Array<Command | SpecialCommand> = [];
  return {
    account,
    commands,
    props: {
      account,
      capability: { status: "supported" },
      sessionConnected: true,
      busy: false,
      configureIds: null,
      onConfigure: () => {},
      onCloseConfiguration: () => {},
      onRefreshCapability: () => {},
      run: async (command: Command | SpecialCommand) => {
        commands.push(command);
        return true;
      },
    },
  };
}

async function mount(t: any, element: any) {
  const dom = new JSDOM("<div id='root'></div>", {
    url: "https://qa.invalid/",
  });
  const originals = new Map<string, PropertyDescriptor | undefined>();
  for (const [key, value] of Object.entries({
    window: dom.window,
    document: dom.window.document,
    HTMLElement: dom.window.HTMLElement,
    Event: dom.window.Event,
    IS_REACT_ACT_ENVIRONMENT: true,
  })) {
    originals.set(key, Object.getOwnPropertyDescriptor(globalThis, key));
    Object.defineProperty(globalThis, key, {
      configurable: true,
      writable: true,
      value,
    });
    sandbox[key] = value;
  }
  dom.window.HTMLDialogElement.prototype.showModal = function () {
    this.setAttribute("open", "");
  };
  dom.window.HTMLDialogElement.prototype.close = function () {
    this.removeAttribute("open");
  };
  const root = createRoot(dom.window.document.getElementById("root")!);
  t.after(async () => {
    await act(async () => root.unmount());
    dom.window.close();
    for (const [key, descriptor] of originals) {
      if (descriptor) Object.defineProperty(globalThis, key, descriptor);
      else Reflect.deleteProperty(globalThis, key);
      delete sandbox[key];
    }
  });
  await act(async () => root.render(element));
  const doc = dom.window.document;
  const button = (text: string) => {
    const found = [...doc.querySelectorAll<HTMLButtonElement>("button")].find(
      (item) => item.textContent?.trim() === text,
    );
    assert.ok(found, `Botão ausente: ${text}`);
    return found;
  };
  const click = async (element: HTMLElement) => {
    await act(async () => element.click());
  };
  const choosePolicy = async (value: string) => {
    const select = doc.querySelector<HTMLSelectElement>("dialog select")!;
    await act(async () => {
      select.value = value;
      select.dispatchEvent(new dom.window.Event("change", { bubbles: true }));
    });
  };
  return { root, doc, button, click, choosePolicy };
}

test("extensão sem capability mantém painel e desabilita comandos de rotina", async (t) => {
  const { props, commands } = fixture();
  const { doc, button, click } = await mount(
    t,
    createElement(ContinuousSources, {
      ...props,
      capability: { status: "unsupported" },
    }),
  );
  assert.match(doc.body.textContent!, /0\.19\.0/);
  assert.match(doc.body.textContent!, /restante do painel continua disponível/);
  assert.equal(button("Configurar fontes").disabled, true);
  assert.equal(button("Pausar rotina e ações").disabled, true);
  assert.ok(
    [...doc.querySelectorAll<HTMLButtonElement>("button")]
      .filter((item) => item.textContent?.includes("Configurar fonte"))
      .every((item) => item.disabled),
  );
  await click(button("Configurar fontes"));
  assert.deepEqual(commands, []);
});

test("grupo exige política e autorização; salva uma vez e ativa exatamente as fontes escolhidas", async (t) => {
  const { account, props, commands } = fixture();
  const ids = account.data.campaigns.map((source) => source.id);
  let closed = 0;
  const { doc, button, click, choosePolicy } = await mount(
    t,
    createElement(ContinuousSources, {
      ...props,
      configureIds: ids,
      onCloseConfiguration: () => closed++,
    }),
  );
  assert.equal(
    doc.querySelector<HTMLSelectElement>("dialog select")!.value,
    "",
  );
  assert.equal(
    doc.querySelector<HTMLInputElement>("dialog input[type=number]")!.value,
    "15",
  );
  assert.equal(button("Salvar e ativar rotina").disabled, true);
  await choosePolicy("follow");
  assert.equal(button("Salvar e ativar rotina").disabled, true);
  await click(
    doc.querySelector<HTMLInputElement>("dialog input[type=checkbox]")!,
  );
  await click(button("Salvar e ativar rotina"));
  const plain = JSON.parse(JSON.stringify(commands));
  assert.deepEqual(plain, [
    { type: "PAUSE_CONTINUOUS" },
    ...ids.map((id) => ({
      type: "CONFIGURE_CONTINUOUS_SOURCE",
      id,
      enabled: true,
      autoFollow: true,
      pollMinutes: 15,
      reviewed: true,
    })),
    { type: "START_CONTINUOUS", sourceIds: ids, reviewed: true },
  ]);
  assert.equal(closed, 1);
  assert.match(doc.body.textContent!, /sem aprovação individual/);
});

test("modal aberto invalida confirmação ao mudar preferências ou capability, preservando o formulário", async (t) => {
  const { account, props, commands } = fixture();
  const ids = account.data.campaigns.map((source) => source.id);
  const initial = {
    ...props,
    configureIds: ids,
    capability: { status: "supported", allDaySchedule: true },
  };
  const { root, doc, button, click, choosePolicy } = await mount(
    t,
    createElement(ContinuousSources, initial),
  );
  const form = doc.querySelector("dialog select");
  await choosePolicy("follow");
  await click(
    doc.querySelector<HTMLInputElement>("dialog input[type=checkbox]")!,
  );
  assert.equal(button("Salvar e ativar rotina").disabled, false);
  const changed = structuredClone(account);
  changed.data.settings.allDay = true;
  await act(async () =>
    root.render(
      createElement(ContinuousSources, { ...initial, account: changed }),
    ),
  );
  assert.equal(doc.querySelector("dialog select"), form);
  assert.equal(
    doc.querySelector<HTMLSelectElement>("dialog select")!.value,
    "follow",
  );
  assert.equal(
    doc.querySelector<HTMLInputElement>("dialog input[type=checkbox]")!.checked,
    false,
  );
  assert.equal(button("Salvar e ativar rotina").disabled, true);
  await click(
    doc.querySelector<HTMLInputElement>("dialog input[type=checkbox]")!,
  );
  assert.equal(button("Salvar e ativar rotina").disabled, false);
  await act(async () =>
    root.render(
      createElement(ContinuousSources, {
        ...initial,
        account: changed,
        capability: { status: "supported", allDaySchedule: false },
      }),
    ),
  );
  assert.equal(
    doc.querySelector<HTMLInputElement>("dialog input[type=checkbox]")!.checked,
    false,
  );
  assert.equal(button("Salvar e ativar rotina").disabled, true);
  assert.deepEqual(commands, []);
});

async function interleavedConfiguration(t: any, changeSettings: boolean) {
  const { account, props, commands } = fixture();
  const ids = account.data.campaigns.map((source) => source.id);
  let current = structuredClone(account);
  let configs = 0;
  let closed = 0;
  let release!: () => void;
  const gate = new Promise<void>((resolve) => {
    release = resolve;
  });
  let renderCurrent!: () => void;
  const run = async (command: Command | SpecialCommand) => {
    commands.push(command);
    if (command.type === "PAUSE_CONTINUOUS")
      current = { ...current, data: pauseContinuous(current.data) };
    if (command.type === "CONFIGURE_CONTINUOUS_SOURCE") {
      current = {
        ...current,
        data: configureContinuousSource(current.data, command),
      };
      configs++;
    }
    if (command.type === "START_CONTINUOUS")
      current = {
        ...current,
        data: startContinuous(current, command.sourceIds, command.reviewed),
      };
    renderCurrent();
    if (command.type === "CONFIGURE_CONTINUOUS_SOURCE" && configs === 2)
      await gate;
    return true;
  };
  const currentProps = () => ({
    ...props,
    account: current,
    configureIds: ids,
    capability: { status: "supported", allDaySchedule: true },
    run,
    onCloseConfiguration: () => {
      closed++;
    },
  });
  const mounted = await mount(
    t,
    createElement(ContinuousSources, currentProps()),
  );
  renderCurrent = () =>
    mounted.root.render(createElement(ContinuousSources, currentProps()));
  await mounted.choosePolicy("follow");
  const form = mounted.doc.querySelector("dialog select");
  await mounted.click(
    mounted.doc.querySelector<HTMLInputElement>("dialog input[type=checkbox]")!,
  );
  await mounted.click(mounted.button("Salvar e ativar rotina"));
  assert.equal(configs, 2);
  assert.equal(mounted.doc.querySelector("dialog select"), form);
  if (changeSettings) {
    current = {
      ...current,
      data: applyCommand(current.data, {
        type: "SETTINGS",
        settings: { ...current.data.settings, allDay: true },
      }),
    };
    await act(async () => renderCurrent());
  }
  await act(async () => release());
  return { ...mounted, commands, current, configs, closed };
}

test("preferências mudando durante CONFIG2 impedem START sem repetir comandos", async (t) => {
  const result = await interleavedConfiguration(t, true);
  assert.equal(
    result.commands.filter((command) => command.type === "START_CONTINUOUS")
      .length,
    0,
  );
  assert.equal(result.configs, 2);
  assert.equal(result.current.data.continuous?.mode, "paused");
  assert.equal(result.current.data.settings.allDay, true);
  assert.match(result.doc.body.textContent!, /mudou|mudaram/);
  assert.equal(result.closed, 0);
});

test("atualizações normais de CONFIG mantêm autorização da sequência com mesmas preferências", async (t) => {
  const result = await interleavedConfiguration(t, false);
  assert.equal(
    result.commands.filter(
      (command) => command.type === "CONFIGURE_CONTINUOUS_SOURCE",
    ).length,
    3,
  );
  assert.equal(
    result.commands.filter((command) => command.type === "START_CONTINUOUS")
      .length,
    1,
  );
  assert.equal(result.current.data.continuous?.mode, "running");
  assert.equal(result.current.data.continuous?.sourceIds?.length, 3);
  assert.equal(result.closed, 1);
});

test("falha numa configuração não repete comandos e não ativa grupo incompleto", async (t) => {
  const { account, props, commands } = fixture();
  const ids = account.data.campaigns.map((source) => source.id);
  const run = async (command: Command | SpecialCommand) => {
    commands.push(command);
    return !(
      command.type === "CONFIGURE_CONTINUOUS_SOURCE" && command.id === ids[1]
    );
  };
  const { doc, button, click, choosePolicy } = await mount(
    t,
    createElement(ContinuousSources, { ...props, configureIds: ids, run }),
  );
  await choosePolicy("collect");
  await click(
    doc.querySelector<HTMLInputElement>("dialog input[type=checkbox]")!,
  );
  await click(button("Salvar e ativar rotina"));
  assert.deepEqual(
    commands.map((command) => command.type),
    [
      "PAUSE_CONTINUOUS",
      "CONFIGURE_CONTINUOUS_SOURCE",
      "CONFIGURE_CONTINUOUS_SOURCE",
    ],
  );
  assert.match(doc.body.textContent!, /Algumas fontes podem ter sido salvas/);
  assert.ok(!commands.some((command) => command.type === "START_CONTINUOUS"));
});

test("salvar configuração somente não inicia coleta nem seguir", async (t) => {
  const { account, props, commands } = fixture();
  const { doc, button, click, choosePolicy } = await mount(
    t,
    createElement(ContinuousSources, {
      ...props,
      configureIds: [account.data.campaigns[0].id],
    }),
  );
  await choosePolicy("collect");
  await click(
    doc.querySelector<HTMLInputElement>("dialog input[type=checkbox]")!,
  );
  await click(button("Salvar configuração"));
  assert.deepEqual(
    commands.map((command) => command.type),
    ["PAUSE_CONTINUOUS", "CONFIGURE_CONTINUOUS_SOURCE"],
  );
  assert.equal(
    (commands[1] as Extract<Command, { type: "CONFIGURE_CONTINUOUS_SOURCE" }>)
      .autoFollow,
    false,
  );
});

test("desativar fonte sem sessão é redutor e exige capability; não libera configurar ou iniciar", async (t) => {
  const f = fixture();
  const id = f.account.data.campaigns[0].id;
  f.account.data = applyCommand(f.account.data, {
    type: "CONFIGURE_CONTINUOUS_SOURCE",
    id,
    enabled: true,
    autoFollow: true,
    pollMinutes: 15,
    reviewed: true,
  });
  const props = { ...f.props, sessionConnected: false };
  const view = await mount(t, createElement(ContinuousSources, props));
  assert.equal(view.button("Configurar fontes").disabled, true);
  assert.equal(view.button("Desativar fonte").disabled, false);
  await view.click(view.button("Desativar fonte"));
  assert.equal(f.commands.length, 1);
  const command = f.commands[0] as Extract<
    Command,
    { type: "CONFIGURE_CONTINUOUS_SOURCE" }
  >;
  assert.equal(command.enabled, false);
  const reduced = applyCommand(f.account.data, command);
  assert.equal(
    reduced.campaigns.find((c) => c.id === id)!.continuous!.enabled,
    false,
  );
  assert.equal(reduced.runtime.mode, "paused");
  await act(async () =>
    view.root.render(
      createElement(ContinuousSources, {
        ...props,
        capability: { status: "unsupported" },
      }),
    ),
  );
  assert.equal(view.button("Desativar fonte").disabled, true);
});

test("dados ausentes e zero permanecem distintos; indisponível exige reativação explícita", () => {
  const { account, props } = fixture();
  const now = new Date().toISOString();
  account.data.campaigns[0].continuous = {
    account: account.username!,
    enabled: true,
    autoFollow: true,
    pollMinutes: 15,
    authorizationId: "qa-authorization",
    authorizedAt: now,
    status: "unavailable",
    reason: "A fonte não está acessível nesta sessão.",
    lastCheckAt: now,
    lastLoaded: 12,
    lastAdded: 0,
    lastQueued: 0,
    partial: true,
  };
  const before = structuredClone(account);
  const doc = new JSDOM(
    renderToStaticMarkup(createElement(ContinuousSources, props)),
  ).window.document;
  const cards = [...doc.querySelectorAll(".continuous-source")];
  assert.match(cards[0].textContent!, /Indisponível/);
  assert.match(cards[0].textContent!, /Conferir e reativar/);
  assert.match(cards[0].textContent!, /A rotina não insiste/);
  assert.deepEqual(
    [...cards[0].querySelectorAll("dd")]
      .slice(2, 5)
      .map((node) => node.textContent),
    ["12", "0", "0"],
  );
  assert.deepEqual(
    [...cards[1].querySelectorAll("dd")]
      .slice(2, 5)
      .map((node) => node.textContent),
    ["—", "—", "—"],
  );
  assert.match(doc.body.textContent!, /não roda na nuvem/);
  assert.match(doc.body.textContent!, /sem buscar todas as publicações/);
  assert.deepEqual(account, before);
});

test("ativação usa somente fontes marcadas e nova autorização invalida a revisão anterior", async (t) => {
  const { account, props, commands } = fixture();
  const now = new Date().toISOString();
  for (const source of account.data.campaigns)
    source.continuous = {
      account: account.username!,
      enabled: true,
      autoFollow: source.kind === "followers",
      pollMinutes: 15,
      authorizationId: `qa-${source.id}`,
      authorizedAt: now,
      status: "ready",
      partial: true,
    };
  const { root, doc, button, click } = await mount(
    t,
    createElement(ContinuousSources, props),
  );
  const checks = [
    ...doc.querySelectorAll<HTMLInputElement>(
      ".continuous-start-sources input",
    ),
  ];
  await click(checks[1]);
  await click(
    doc.querySelector<HTMLInputElement>(
      ".continuous-activation .continuous-review-check input",
    )!,
  );
  assert.equal(button("Ativar rotina").disabled, false);
  await click(button("Ativar rotina"));
  assert.deepEqual(JSON.parse(JSON.stringify(commands)), [
    {
      type: "START_CONTINUOUS",
      sourceIds: [account.data.campaigns[0].id, account.data.campaigns[2].id],
      reviewed: true,
    },
  ]);
  const changed = structuredClone(account);
  changed.data.campaigns[0].continuous!.authorizationId =
    "qa-new-authorization";
  await act(async () =>
    root.render(
      createElement(ContinuousSources, { ...props, account: changed }),
    ),
  );
  assert.equal(button("Ativar rotina").disabled, true);
  assert.equal(
    doc.querySelector<HTMLInputElement>(
      ".continuous-activation .continuous-review-check input",
    )!.checked,
    false,
  );
  assert.equal(commands.length, 1);
});

test("rotina em execução mostra só o snapshot ativo, inclusive durante consulta", () => {
  for (const activeStatus of ["ready", "checking"] as const) {
    const { account, props } = fixture();
    const now = new Date().toISOString();
    for (const source of account.data.campaigns)
      source.continuous = {
        account: account.username!,
        enabled: true,
        autoFollow: true,
        pollMinutes: 15,
        authorizationId: `qa-${source.id}`,
        authorizedAt: now,
        status: "ready",
        partial: true,
      };
    account.data.campaigns[0].continuous!.status = activeStatus;
    account.data.continuous = {
      account: account.username!,
      mode: "running",
      sourceIds: [account.data.campaigns[0].id],
      authorizationId: "qa-activation",
    };
    const before = structuredClone(account);
    const doc = new JSDOM(
      renderToStaticMarkup(createElement(ContinuousSources, props)),
    ).window.document;
    const checks = [
      ...doc.querySelectorAll<HTMLInputElement>(
        ".continuous-start-sources input",
      ),
    ];
    assert.equal(checks.length, 1);
    assert.equal(checks.filter((check) => check.checked).length, 1);
    assert.ok(checks.every((check) => check.disabled));
    assert.match(
      doc.querySelector(".continuous-activation")!.textContent!,
      /Autorizo esta ativação para 1 fonte: 1 com seguir automático/,
    );
    assert.equal(
      [...doc.querySelectorAll(".continuous-source-status")].filter((node) =>
        node.textContent?.includes("fora desta ativação"),
      ).length,
      2,
    );
    assert.deepEqual(account, before);
  }
});

test("fora da janela mostra agendamento efetivo e não a consulta já vencida das fontes", () => {
  const { account, props } = fixture();
  const due = "2026-11-03T22:43:00-03:00";
  const nextRun = "2026-11-04T09:00:00-03:00";
  for (const source of account.data.campaigns)
    source.continuous = {
      account: account.username!,
      enabled: true,
      autoFollow: true,
      pollMinutes: 15,
      authorizationId: `qa-${source.id}`,
      authorizedAt: due,
      status: "ready",
      nextCheckAt: due,
      partial: true,
      lastLoaded: 0,
      lastAdded: 0,
      lastQueued: 0,
    };
  account.data.continuous = {
    account: account.username!,
    mode: "running",
    sourceIds: account.data.campaigns.map((source) => source.id),
    authorizationId: "qa-active",
    nextRunAt: nextRun,
  };
  const before = structuredClone(account);
  const doc = new JSDOM(
    renderToStaticMarkup(createElement(ContinuousSources, props)),
  ).window.document;
  const expected = new Intl.DateTimeFormat("pt-BR", {
    day: "2-digit",
    month: "short",
    hour: "2-digit",
    minute: "2-digit",
  }).format(new Date(nextRun));
  const summary = doc.querySelector(".continuous-summary > div")!;
  assert.match(summary.textContent!, /Próxima execução programada/);
  assert.equal(summary.querySelector("strong")!.textContent, expected);
  const cards = [...doc.querySelectorAll(".continuous-source")];
  for (const card of cards) {
    const schedule = card.querySelectorAll(".continuous-source-stats > div")[1];
    assert.equal(
      schedule.querySelector("dt")!.textContent,
      "Próxima consulta a partir de",
    );
    assert.equal(schedule.querySelector("dd")!.textContent, expected);
    assert.deepEqual(
      [...card.querySelectorAll("dd")]
        .slice(2, 5)
        .map((node) => node.textContent),
      ["0", "0", "0"],
    );
  }
  assert.match(doc.body.textContent!, /sem horário exato garantido por fonte/);
  assert.deepEqual(account, before);
  account.data.campaigns[2].continuous!.nextCheckAt =
    "2026-11-04T10:00:00-03:00";
  const later = new JSDOM(
    renderToStaticMarkup(createElement(ContinuousSources, props)),
  ).window.document;
  const laterExpected = new Intl.DateTimeFormat("pt-BR", {
    day: "2-digit",
    month: "short",
    hour: "2-digit",
    minute: "2-digit",
  }).format(new Date("2026-11-04T10:00:00-03:00"));
  assert.equal(
    later.querySelectorAll(".continuous-source")[2].querySelectorAll("dd")[1]
      .textContent,
    laterExpected,
  );
});

test("agenda ausente não vira previsão e timestamp zero permanece uma data", () => {
  const { account, props } = fixture();
  const epoch = "1970-01-01T00:00:00.000Z";
  account.data.campaigns[0].continuous = {
    account: account.username!,
    enabled: true,
    autoFollow: false,
    pollMinutes: 15,
    authorizationId: "qa-zero",
    authorizedAt: epoch,
    status: "ready",
    nextCheckAt: epoch,
    partial: true,
  };
  account.data.continuous = {
    account: account.username!,
    mode: "running",
    sourceIds: [account.data.campaigns[0].id],
    authorizationId: "qa-active",
  };
  let doc = new JSDOM(
    renderToStaticMarkup(createElement(ContinuousSources, props)),
  ).window.document;
  assert.equal(
    doc.querySelector(".continuous-summary strong")!.textContent,
    "—",
  );
  assert.equal(
    doc.querySelectorAll(".continuous-source-stats dd")[1].textContent,
    "—",
  );
  assert.deepEqual(
    [...doc.querySelectorAll(".continuous-source-stats dd")]
      .slice(2, 5)
      .map((node) => node.textContent),
    ["—", "—", "—"],
  );
  account.data.continuous.nextRunAt = epoch;
  doc = new JSDOM(renderToStaticMarkup(createElement(ContinuousSources, props)))
    .window.document;
  const expected = new Intl.DateTimeFormat("pt-BR", {
    day: "2-digit",
    month: "short",
    hour: "2-digit",
    minute: "2-digit",
  }).format(new Date(0));
  assert.equal(
    doc.querySelector(".continuous-summary strong")!.textContent,
    expected,
  );
  assert.equal(
    doc.querySelectorAll(".continuous-source-stats dd")[1].textContent,
    expected,
  );
});

test("janela mostra 24 horas só com capability confirmada, sem exibir 09–21 como janela ativa", () => {
  const { account, props } = fixture();
  account.data.settings.startHour = "09:00";
  account.data.settings.endHour = "21:00";
  account.data.settings.allDay = true;
  const before = structuredClone(account);
  for (const supported of [false, true]) {
    const doc = new JSDOM(
      renderToStaticMarkup(
        createElement(ContinuousSources, {
          ...props,
          capability: { status: "supported", allDaySchedule: supported },
        }),
      ),
    ).window.document;
    const windowValue = doc
      .querySelectorAll(".continuous-summary > div")[1]
      .querySelector("strong")!.textContent;
    assert.equal(
      windowValue,
      supported ? "24 horas" : "24 horas · pendente na extensão",
    );
    assert.ok(!windowValue!.includes("09:00"));
    if (!supported) {
      assert.match(doc.body.textContent!, /0\.19\.1 ou posterior/);
      const configure = [
        ...doc.querySelectorAll<HTMLButtonElement>("button"),
      ].find((button) => button.textContent?.includes("Configurar fontes"))!;
      assert.equal(configure.disabled, true);
    }
  }
  assert.deepEqual(account, before);
});

test("capability 24h é independente da rotina contínua e ausência não é suporte", async (t) => {
  let resolve!: (value: unknown) => void;
  sandbox.chrome = {
    runtime: {
      id: "qa-extension",
      sendMessage: () =>
        new Promise((done) => {
          resolve = done;
        }),
    },
  };
  sandbox.location = { protocol: "chrome-extension:" };
  t.after(() => {
    delete sandbox.chrome;
    delete sandbox.location;
  });
  function Probe() {
    const { capability, refresh } = useContinuousCapability("qa-all-day", true);
    return createElement(
      "div",
      null,
      createElement(
        "span",
        { id: "support" },
        `${capability.status}:${capability.allDaySchedule === true}`,
      ),
      createElement("button", { onClick: refresh }, "Conferir"),
    );
  }
  const { doc, button, click } = await mount(t, createElement(Probe));
  await act(async () =>
    resolve({ ok: true, capabilities: { continuousSources: true } }),
  );
  assert.equal(doc.getElementById("support")!.textContent, "supported:false");
  await click(button("Conferir"));
  await act(async () =>
    resolve({ ok: true, capabilities: { allDaySchedule: true } }),
  );
  assert.equal(doc.getElementById("support")!.textContent, "unsupported:true");
});

test("capability é leitura única em StrictMode e ausência do flag não libera ações", async (t) => {
  let resolve!: (value: unknown) => void;
  const requests: unknown[] = [];
  sandbox.chrome = {
    runtime: {
      id: "qa-extension",
      sendMessage: (message: unknown) => {
        requests.push(message);
        return new Promise((done) => {
          resolve = done;
        });
      },
    },
  };
  sandbox.location = { protocol: "chrome-extension:" };
  t.after(() => {
    delete sandbox.chrome;
    delete sandbox.location;
  });
  function Probe() {
    const { capability, refresh } = useContinuousCapability("qa-account", true);
    return createElement(
      "div",
      null,
      createElement("span", { id: "capability" }, capability.status),
      createElement("button", { onClick: refresh }, "Conferir"),
    );
  }
  const { doc, button, click } = await mount(
    t,
    createElement(StrictMode, null, createElement(Probe)),
  );
  assert.equal(requests.length, 1);
  assert.equal(doc.getElementById("capability")!.textContent, "checking");
  await act(async () => resolve({ ok: true }));
  assert.equal(doc.getElementById("capability")!.textContent, "unsupported");
  await click(button("Conferir"));
  assert.equal(requests.length, 2);
  await act(async () =>
    resolve({ ok: true, capabilities: { continuousSources: true } }),
  );
  assert.equal(doc.getElementById("capability")!.textContent, "supported");
  assert.deepEqual(JSON.parse(JSON.stringify(requests)), [
    { type: "GET_STATE" },
    { type: "GET_STATE" },
  ]);
});

test("capability atrasada de outra conta não libera o escopo atual", async (t) => {
  const deferred: Array<(value: unknown) => void> = [];
  sandbox.chrome = {
    runtime: {
      id: "qa-extension",
      sendMessage: () => new Promise((resolve) => deferred.push(resolve)),
    },
  };
  sandbox.location = { protocol: "chrome-extension:" };
  t.after(() => {
    delete sandbox.chrome;
    delete sandbox.location;
  });
  function Probe({ id }: { id: string }) {
    const { capability } = useContinuousCapability(id, true);
    return createElement("span", { id: "capability" }, capability.status);
  }
  const { root, doc } = await mount(t, createElement(Probe, { id: "qa-a" }));
  await act(async () => root.render(createElement(Probe, { id: "qa-b" })));
  assert.equal(deferred.length, 2);
  await act(async () =>
    deferred[0]({ ok: true, capabilities: { continuousSources: true } }),
  );
  assert.equal(doc.getElementById("capability")!.textContent, "checking");
  await act(async () => deferred[1]({ ok: true }));
  assert.equal(doc.getElementById("capability")!.textContent, "unsupported");
});
