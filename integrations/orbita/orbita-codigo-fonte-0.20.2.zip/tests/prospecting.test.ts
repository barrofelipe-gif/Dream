import test from "node:test";
import assert from "node:assert/strict";
import {
  initialState,
  applyCommand,
  mergeCandidates,
  restoreState,
  validateSettings,
} from "../src/core/domain.ts";
import {
  accountCommand,
  initialStore,
  workspace,
  applyScopedCommand,
  accountBackup,
  migrateStore,
} from "../src/core/accounts.ts";
import {
  prospectingReview,
  unfollowEligibility,
} from "../src/core/prospecting.ts";
import type {
  AccountWorkspace,
  Candidate,
  RelationshipSnapshot,
} from "../src/core/types.ts";

const DAY = 86400000,
  now = new Date(),
  followAt = new Date(now.getTime() - 40 * DAY).toISOString();
function fixture() {
  let store = accountCommand(initialStore(), {
    type: "ADD_ACCOUNT",
    username: "qa.alpha",
  });
  const account = workspace(store);
  account.data = applyCommand(account.data, {
    type: "CREATE_CAMPAIGN",
    name: "Referência QA",
    kind: "followers",
    target: "qa.source",
  });
  mergeCandidates(account.data, account.data.campaigns[0].id, [
    { username: "qa.person" },
    { username: "qa.other" },
  ]);
  account.data.settings.reviewAfterDays = 7;
  account.data.settings.reviewPolicy = "review_all";
  for (const c of account.data.candidates) {
    c.stage = "followed";
    c.confirmedFollowAt = followAt;
    c.confirmedFollowAccount = "qa.alpha";
    c.confirmedFollowSource = "orbita";
  }
  return {
    store,
    account,
    candidate: account.data.candidates[0],
    other: account.data.candidates[1],
  };
}
function snap(
  account: AccountWorkspace,
  at: string,
  followers: string[],
  complete: boolean,
): RelationshipSnapshot {
  return {
    id: crypto.randomUUID(),
    account: account.username!,
    at,
    recordedAt: at,
    source: "file",
    followers,
    following: [],
    followersComplete: complete,
    followingComplete: false,
    note: "QA fictícia",
  };
}
function relations(
  account: AccountWorkspace,
  snapshots: RelationshipSnapshot[] = [],
) {
  account.relationships = { version: 1, snapshots, protections: [] };
}

test("sem prazo ou política explícitos a fila de revisão fica desativada", () => {
  const { account, candidate } = fixture();
  delete account.data.settings.reviewAfterDays;
  delete account.data.settings.reviewPolicy;
  let row = prospectingReview(account, now).rows[0];
  assert.equal(row.ready, false);
  assert.equal(row.canQueue, false);
  assert.ok(row.codes.includes("review_disabled"));
  assert.ok(row.codes.includes("policy_missing"));
  account.data.settings.reviewAfterDays = 7;
  row = prospectingReview(account, now).rows[0];
  assert.equal(row.ready, true);
  assert.equal(row.canQueue, false);
  assert.equal(unfollowEligibility(account, candidate, now).eligible, false);
});
test("a idade vem da confirmação imutável, sem renovar por captura ou nota", () => {
  const { account, candidate } = fixture();
  candidate.updatedAt = now.toISOString();
  candidate.note = "Nova nota";
  mergeCandidates(account.data, account.data.campaigns[0].id, [
    { username: candidate.username, name: "Nome atualizado" },
  ]);
  const row = prospectingReview(account, now).rows[0];
  assert.equal(row.confirmedFollowAt, followAt);
  assert.equal(row.ageDays, 40);
  assert.equal(
    row.dueAt,
    new Date(Date.parse(followAt) + 7 * DAY).toISOString(),
  );
  assert.equal(row.canQueue, true);
  assert.equal(row.sources[0].target, "qa.source");
});
test("legado, solicitação, já-seguia e prova restaurada não autorizam unfollow", () => {
  for (const stage of ["followed", "requested", "already"] as const) {
    const { account, candidate } = fixture();
    candidate.stage = stage;
    delete candidate.confirmedFollowAt;
    delete candidate.confirmedFollowAccount;
    delete candidate.confirmedFollowSource;
    assert.equal(unfollowEligibility(account, candidate, now).eligible, false);
  }
  const { account, candidate } = fixture();
  candidate.confirmedFollowSource = "restored";
  assert.ok(
    unfollowEligibility(account, candidate, now).codes.includes(
      "restored_proof",
    ),
  );
});
test("importação de públicos não pode criar prova de follow mesmo com campos extras", () => {
  const { account } = fixture();
  mergeCandidates(account.data, account.data.campaigns[0].id, [
    {
      username: "qa.incoming",
      confirmedFollowAt: followAt,
      confirmedFollowAccount: "qa.alpha",
      confirmedFollowSource: "orbita",
    } as never,
  ]);
  const c = account.data.candidates.find((c) => c.username === "qa.incoming")!;
  assert.equal(c.confirmedFollowAt, undefined);
  assert.equal(c.confirmedFollowSource, undefined);
  assert.equal(
    prospectingReview(account, now).rows.some((r) => r.candidateId === c.id),
    false,
  );
});
test("prazo não vencido, prova futura e dono incorreto bloqueiam", () => {
  const { account, candidate } = fixture();
  candidate.confirmedFollowAt = new Date(now.getTime() - DAY).toISOString();
  assert.ok(
    unfollowEligibility(account, candidate, now).codes.includes("not_due"),
  );
  candidate.confirmedFollowAt = new Date(now.getTime() + DAY).toISOString();
  assert.ok(
    unfollowEligibility(account, candidate, now).codes.includes(
      "unconfirmed_follow",
    ),
  );
  candidate.confirmedFollowAt = followAt;
  candidate.confirmedFollowAccount = "qa.beta";
  assert.equal(unfollowEligibility(account, candidate, now).eligible, false);
});
test("proteções, clientes, exclusões, própria conta e demonstrações sempre bloqueiam", () => {
  for (const reason of ["friend", "client"] as const) {
    const { account, candidate } = fixture();
    relations(account);
    account.relationships!.protections.push({
      username: candidate.username,
      reason,
      enabled: true,
      note: "QA",
      updatedAt: now.toISOString(),
    });
    const row = prospectingReview(account, now).rows[0];
    assert.equal(row.ready, true);
    assert.equal(row.canQueue, false);
    assert.equal(row.protectionReason, reason);
  }
  const { account, candidate } = fixture();
  account.data.settings.exclusions.push(candidate.username);
  assert.ok(
    unfollowEligibility(account, candidate, now).codes.includes("excluded"),
  );
  account.data.settings.exclusions = [];
  candidate.sources[0].url = "demo://ficticio";
  assert.ok(
    unfollowEligibility(account, candidate, now).codes.includes("demo"),
  );
  candidate.sources[0].url = "https://www.instagram.com/qa.source/followers/";
  candidate.username = "qa.alpha";
  assert.ok(
    unfollowEligibility(account, candidate, now).codes.includes("own_account"),
  );
});
test("lista parcial comprova presença, nunca ausência; preservar exige ausência completa após prazo", () => {
  const { account, candidate } = fixture();
  account.data.settings.reviewPolicy = "preserve_followers";
  relations(account, [snap(account, now.toISOString(), [], false)]);
  let row = prospectingReview(account, now).rows[0];
  assert.equal(row.reciprocity.status, "unknown");
  assert.equal(row.canQueue, false);
  account.relationships!.snapshots = [
    snap(account, now.toISOString(), [candidate.username], false),
  ];
  row = prospectingReview(account, now).rows[0];
  assert.equal(row.reciprocity.status, "yes");
  assert.equal(row.canQueue, false);
  account.relationships!.snapshots = [
    snap(account, now.toISOString(), [], true),
  ];
  row = prospectingReview(account, now).rows[0];
  assert.equal(row.reciprocity.status, "no");
  assert.equal(row.canQueue, true);
  assert.equal(row.reciprocity.followersComplete, true);
});
test("snapshot antigo ou de outra conta não comprova ausência; parcial recente substitui completo antigo", () => {
  const { account } = fixture();
  account.data.settings.reviewPolicy = "preserve_followers";
  relations(account, [
    snap(account, new Date(Date.parse(followAt) + DAY).toISOString(), [], true),
  ]);
  assert.equal(
    prospectingReview(account, now).rows[0].reciprocity.status,
    "unknown",
  );
  const older = snap(
      account,
      new Date(now.getTime() - DAY).toISOString(),
      [],
      true,
    ),
    newer = snap(account, now.toISOString(), [], false);
  account.relationships!.snapshots = [older, newer];
  assert.equal(
    prospectingReview(account, now).rows[0].reciprocity.status,
    "unknown",
  );
  account.relationships!.snapshots = [{ ...older, account: "qa.beta" }];
  assert.equal(
    prospectingReview(account, now).rows[0].reciprocity.status,
    "unknown",
  );
});
test("review_all não converte reciprocidade desconhecida em ausência", () => {
  const { account } = fixture();
  relations(account, [snap(account, now.toISOString(), [], false)]);
  const row = prospectingReview(account, now).rows[0];
  assert.equal(row.reciprocity.status, "unknown");
  assert.equal(row.canQueue, true);
});
test("helper atende queued e attempting apenas quando ação e conta correspondem", () => {
  const { account, candidate } = fixture();
  for (const stage of ["queued", "attempting"] as const) {
    candidate.stage = stage;
    candidate.queuedAction = "unfollow";
    candidate.queueAccount = "qa.alpha";
    assert.equal(unfollowEligibility(account, candidate, now).eligible, true);
    candidate.queuedAction = "follow";
    assert.equal(unfollowEligibility(account, candidate, now).eligible, false);
    candidate.queuedAction = "unfollow";
    candidate.queueAccount = "qa.beta";
    assert.equal(unfollowEligibility(account, candidate, now).eligible, false);
  }
});
test("planejar não muda entrada e cycleId inclui a conta", () => {
  const { account } = fixture();
  const before = structuredClone(account);
  const review = prospectingReview(account, now);
  assert.deepEqual(account, before);
  assert.equal(review.counts.canQueue, 2);
  assert.ok(review.rows[0].cycleId.startsWith(account.id + ":"));
});
test("QUEUE_UNFOLLOW valida seleção inteira antes de mudar o cadastro e preserva controles", () => {
  const { store, account, candidate, other } = fixture();
  relations(account);
  account.relationships!.protections.push({
    username: other.username,
    reason: "client",
    enabled: true,
    note: "QA",
    updatedAt: now.toISOString(),
  });
  const before = structuredClone(store);
  assert.throws(
    () =>
      accountCommand(store, {
        type: "QUEUE_UNFOLLOW",
        account: "qa.alpha",
        ids: [candidate.id, other.id],
      }),
    /protegido/,
  );
  assert.deepEqual(store, before);
  assert.throws(
    () =>
      accountCommand(store, {
        type: "QUEUE_UNFOLLOW",
        account: "qa.beta",
        ids: [candidate.id],
      }),
    /conta selecionada/,
  );
  assert.throws(() =>
    accountCommand(store, {
      type: "QUEUE_UNFOLLOW",
      account: "qa.alpha",
      ids: [candidate.id, "missing"],
    }),
  );
  account.data.settings.hasPendingWarning = true;
  account.data.runtime.sessionAttempts = 3;
  account.data.dailyAttempts = { "qa.alpha|QA": 4 };
  account.data.lastAttempts = { "@qa.alpha": followAt };
  const queued = accountCommand(store, {
    type: "QUEUE_UNFOLLOW",
    account: "qa.alpha",
    ids: [candidate.id],
  });
  const a = workspace(queued),
    c = a.data.candidates[0];
  assert.equal(c.stage, "queued");
  assert.equal(c.queuedAction, "unfollow");
  assert.equal(c.queueAccount, "qa.alpha");
  assert.equal(c.confirmedFollowAt, followAt);
  assert.equal(a.data.runtime.mode, "paused");
  assert.equal(a.data.runtime.sessionAttempts, 3);
  assert.equal(a.data.settings.hasPendingWarning, true);
  assert.deepEqual(a.data.dailyAttempts, account.data.dailyAttempts);
  assert.deepEqual(a.data.lastAttempts, account.data.lastAttempts);
});
test("QUEUE_UNFOLLOW recusa seleção obsoleta com erro de domínio e só desvincula tags após validar todos", () => {
  const { store, account, candidate } = fixture();
  candidate.continuousSourceId = account.data.campaigns[0].id;
  candidate.continuousAuthorizationId = "qa-previous-authorization";
  const before = structuredClone(store);
  for (const ids of [["missing"], [candidate.id, "missing"]]) {
    assert.throws(
      () => accountCommand(store, { type: "QUEUE_UNFOLLOW", account: "qa.alpha", ids }),
      (error: unknown) => error instanceof Error && !(error instanceof TypeError) && /seleção mudou/i.test(error.message),
    );
    assert.deepEqual(store, before);
  }
  const result = accountCommand(store, { type: "QUEUE_UNFOLLOW", account: "qa.alpha", ids: [candidate.id] });
  const queued = workspace(result).data.candidates.find((row) => row.id === candidate.id)!;
  assert.equal(queued.stage, "queued"); assert.equal(queued.queuedAction, "unfollow");
  assert.equal(queued.continuousSourceId, undefined); assert.equal(queued.continuousAuthorizationId, undefined);
  assert.equal(queued.confirmedFollowAt, candidate.confirmedFollowAt);
  assert.deepEqual(store, before);
});

test("retirar unfollow da fila devolve followed; resultado incerto não vira novo follow", () => {
  const { store, candidate } = fixture();
  let queued = accountCommand(store, {
    type: "QUEUE_UNFOLLOW",
    account: "qa.alpha",
    ids: [candidate.id],
  });
  let removed = applyScopedCommand(queued, queued.activeId, {
    type: "REMOVE_FROM_QUEUE",
    ids: [candidate.id],
  });
  let c = workspace(removed).data.candidates[0];
  assert.equal(c.stage, "followed");
  assert.equal(c.queuedAction, undefined);
  assert.equal(c.confirmedFollowAt, followAt);
  c.stage = "uncertain";
  c.queuedAction = "unfollow";
  assert.throws(
    () =>
      applyScopedCommand(removed, removed.activeId, {
        type: "RETURN_TO_REVIEW",
        id: c.id,
      }),
    /revisão genérica/,
  );
});
test("backup guarda histórico, RESTORE marca restored e reload nativo preserva origem orbita", () => {
  const { store, account, candidate } = fixture();
  const backup = accountBackup(account);
  assert.equal(
    backup.account.data.candidates[0].confirmedFollowSource,
    "orbita",
  );
  const reload = migrateStore(JSON.parse(JSON.stringify(store)));
  assert.equal(
    workspace(reload).data.candidates[0].confirmedFollowSource,
    "orbita",
  );
  assert.equal(
    prospectingReview(workspace(reload), now).rows[0].canQueue,
    true,
  );
  const restored = applyScopedCommand(store, store.activeId, {
    type: "RESTORE",
    data: backup,
  });
  const c = workspace(restored).data.candidates[0];
  assert.equal(c.confirmedFollowAt, followAt);
  assert.equal(c.confirmedFollowAccount, "qa.alpha");
  assert.equal(c.confirmedFollowSource, "restored");
  assert.equal(
    prospectingReview(workspace(restored), now).rows[0].canQueue,
    false,
  );
  assert.equal(candidate.confirmedFollowSource, "orbita");
});
test("restaurar unfollow em execução mantém intenção incerta, sem restaurar autorização", () => {
  const { account, candidate } = fixture();
  candidate.stage = "attempting";
  candidate.queuedAction = "unfollow";
  candidate.queueAccount = "qa.alpha";
  account.data.runtime.activeAction = "unfollow";
  const restored = restoreState(account.data);
  assert.equal(restored.candidates[0].stage, "uncertain");
  assert.equal(restored.candidates[0].queuedAction, "unfollow");
  assert.equal(restored.candidates[0].confirmedFollowSource, "restored");
  assert.equal(restored.runtime.activeAction, undefined);
  assert.equal(restored.runtime.mode, "paused");
});
test("validação rejeita prazo/política/prova inválidos e não herda prova de outra conta", () => {
  const { store, account, candidate } = fixture();
  for (const days of [0, 366, 1.5, NaN])
    assert.throws(() =>
      validateSettings({ ...account.data.settings, reviewAfterDays: days }),
    );
  assert.throws(() =>
    validateSettings({
      ...account.data.settings,
      reviewPolicy: "automatic" as never,
    }),
  );
  candidate.confirmedFollowAccount = "qa.beta";
  assert.throws(() => migrateStore(structuredClone(store)), /outra conta/);
  candidate.confirmedFollowAccount = "qa.alpha";
  candidate.confirmedFollowAt = "2026-02-30T10:00:00Z";
  assert.throws(() => migrateStore(structuredClone(store)), /inválida/);
});

test("ciclo concluído não reaparece como pronto para revisão", () => {
  const { account, candidate } = fixture();
  candidate.stage = "unfollowed";
  const row = prospectingReview(account, now).rows[0];
  assert.equal(row.status, "unfollowed");
  assert.equal(row.codes.includes("not_due"), false);
  assert.equal(row.ready, false);
  assert.equal(row.canQueue, false);
});

test("perfil com identificador inválido não pode ser elegível mesmo com prova salva", () => {
  const { account, candidate } = fixture();
  candidate.username = "qa/invalid";
  assert.equal(unfollowEligibility(account, candidate, now).eligible, false);
});
