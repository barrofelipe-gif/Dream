import test from "node:test";
import assert from "node:assert/strict";

test("cadastro atual recusa tipo de fonte desconhecido sem alterar o conteúdo inválido", () => {
  const store = initialStore();
  store.accounts[0].data.campaigns.push({ id: "qa-invalid", name: "Fonte fictícia", target: "qa.source", kind: "unknown-source" as any, archived: false, createdAt: "2026-10-01T12:00:00Z" });
  const before = structuredClone(store);
  assert.throws(() => migrateStore(store), /fonte.*inválida/i);
  assert.deepEqual(store, before);
});
import { JSDOM } from "jsdom";
import {
  accountBackup,
  accountCommand,
  addSnapshot,
  applyScopedCommand,
  bindVerifiedAccount,
  initialStore,
  migrateStore,
  workspace,
} from "../src/core/accounts.ts";
import { audit, initialState, mergeCandidates } from "../src/core/domain.ts";
import { profileMetrics } from "../src/core/metrics.ts";
import { exactCount, readOwnProfileMetrics } from "../src/extension/dom.ts";
import { accountTypeGuide } from "../src/core/account-types.ts";

test("fila de deixar de seguir mantém IDs coincidentes isolados por conta", () => {
  let store = registered("qa.alpha");
  const alpha = store.activeId;
  store = accountCommand(store, { type: "ADD_ACCOUNT", username: "qa.beta" });
  const beta = store.activeId;
  const followAt = new Date(Date.now() - 40 * 86400000).toISOString();
  for (const id of [alpha, beta]) {
    const a = workspace(store, id);
    a.data.settings.reviewAfterDays = 7;
    a.data.settings.reviewPolicy = "review_all";
    a.data.candidates.push({
      id: "same-local-id",
      username: "qa.target",
      name: "QA fictícia",
      createdAt: followAt,
      updatedAt: followAt,
      sources: [],
      stage: "followed",
      note: "",
      confirmedFollowAt: followAt,
      confirmedFollowAccount: a.username,
      confirmedFollowSource: "orbita",
    });
  }
  const alphaBefore = structuredClone(workspace(store, alpha));
  assert.throws(
    () =>
      accountCommand(store, {
        type: "QUEUE_UNFOLLOW",
        account: "qa.alpha",
        ids: ["same-local-id"],
      }),
    /conta selecionada/,
  );
  const queued = accountCommand(store, {
    type: "QUEUE_UNFOLLOW",
    account: "qa.beta",
    ids: ["same-local-id"],
  });
  assert.deepEqual(workspace(queued, alpha), alphaBefore);
  assert.equal(
    workspace(queued, beta).data.candidates[0].queuedAction,
    "unfollow",
  );
  assert.equal(
    workspace(queued, beta).data.candidates[0].queueAccount,
    "qa.beta",
  );
});

test("backup com prova de seguir de outra conta é recusado sem alterar o espaço", () => {
  const store = registered("qa.alpha"),
    account = workspace(store);
  const at = new Date(Date.now() - 40 * 86400000).toISOString();
  const backup = accountBackup(account);
  backup.account.data.candidates.push({
    id: "forged-owner",
    username: "qa.target",
    name: "QA fictícia",
    createdAt: at,
    updatedAt: at,
    sources: [],
    stage: "followed",
    note: "",
    confirmedFollowAt: at,
    confirmedFollowAccount: "qa.beta",
    confirmedFollowSource: "orbita",
  });
  const before = structuredClone(store);
  assert.throws(
    () =>
      applyScopedCommand(store, store.activeId, {
        type: "RESTORE",
        data: backup,
      }),
    /outra conta/,
  );
  assert.deepEqual(store, before);
});

function registered(username = "qa.alpha") {
  return accountCommand(initialStore(), { type: "ADD_ACCOUNT", username });
}
test("contas pessoais, comerciais e de criador convivem com tipos separados", () => {
  let s = accountCommand(initialStore(), {
    type: "ADD_ACCOUNT",
    username: "qa.personal",
    accountType: "personal",
  });
  const personal = s.activeId;
  s = accountCommand(s, {
    type: "ADD_ACCOUNT",
    username: "qa.business",
    accountType: "business",
  });
  const business = s.activeId;
  s = accountCommand(s, {
    type: "ADD_ACCOUNT",
    username: "qa.creator",
    accountType: "creator",
  });
  assert.equal(workspace(s, personal).accountType, "personal");
  assert.equal(workspace(s, business).accountType, "business");
  assert.equal(workspace(s).accountType, "creator");
  assert.equal(accountTypeGuide("personal").professional, false);
  assert.equal(accountTypeGuide("business").professional, true);
  assert.equal(accountTypeGuide("creator").professional, true);
});
test("tipo antigo não informado não é inferido pelo nome da conta", () => {
  const s = initialStore();
  workspace(s).label = "Empresa comercial";
  const a = workspace(migrateStore(s));
  assert.equal(a.accountType, undefined);
  assert.equal(accountTypeGuide(a.accountType).type, "unknown");
});
test("alterar o tipo afeta apenas o cadastro escolhido e preserva sessão, métricas e limites", () => {
  let s = registered();
  const alpha = s.activeId;
  workspace(s).verifiedAt = new Date().toISOString();
  addSnapshot(workspace(s), { followers: 123, source: "manual" });
  s = accountCommand(s, {
    type: "ADD_ACCOUNT",
    username: "qa.beta",
    accountType: "personal",
  });
  const before = structuredClone(workspace(s, alpha));
  const beta = structuredClone(workspace(s));
  s = accountCommand(s, {
    type: "SET_ACCOUNT_TYPE",
    id: alpha,
    accountType: "creator",
  });
  assert.equal(workspace(s, alpha).accountType, "creator");
  assert.deepEqual(workspace(s, alpha).data, before.data);
  assert.equal(workspace(s, alpha).verifiedAt, before.verifiedAt);
  assert.deepEqual(workspace(s, alpha).snapshots, before.snapshots);
  assert.deepEqual(workspace(s), beta);
});
test("tipo inválido é rejeitado no cadastro, na alteração e no armazenamento", () => {
  const s = registered();
  assert.throws(
    () =>
      accountCommand(s, {
        type: "ADD_ACCOUNT",
        username: "qa.beta",
        accountType: "enterprise",
      } as never),
    /inválido/,
  );
  assert.throws(
    () =>
      accountCommand(s, {
        type: "SET_ACCOUNT_TYPE",
        id: s.activeId,
        accountType: null,
      } as never),
    /inválido/,
  );
  const invalid = structuredClone(s);
  (workspace(invalid) as unknown as { accountType: string }).accountType =
    "invalid";
  assert.throws(() => migrateStore(invalid), /inválido/);
});
test("backup recupera o tipo em espaço novo e preserva tipo atual conhecido", () => {
  const source = accountCommand(initialStore(), {
    type: "ADD_ACCOUNT",
    username: "qa.alpha",
    accountType: "business",
  });
  const backup = accountBackup(workspace(source));
  let target = initialStore();
  target = applyScopedCommand(target, target.activeId, {
    type: "RESTORE",
    data: backup,
  });
  assert.equal(workspace(target).accountType, "business");
  target = accountCommand(target, {
    type: "SET_ACCOUNT_TYPE",
    id: target.activeId,
    accountType: "personal",
  });
  target = applyScopedCommand(target, target.activeId, {
    type: "RESTORE",
    data: backup,
  });
  assert.equal(workspace(target).accountType, "personal");
});
test("conta pessoal aceita Insights locais sem tratar o tipo como autorização da Meta", () => {
  let s = accountCommand(initialStore(), {
    type: "ADD_ACCOUNT",
    username: "qa.personal",
    accountType: "personal",
  });
  s = accountCommand(s, {
    type: "RECORD_INSIGHTS",
    data: {
      account: "qa.personal",
      start: "2026-10-01",
      end: "2026-10-07",
      metrics: { views: 0 },
    },
  });
  assert.equal(workspace(s).insights?.[0].metrics.views, 0);
  assert.equal(workspace(s).verifiedAt, undefined);
  assert.deepEqual(workspace(s).data.dailyAttempts, {});
});
test("cadastro inválido ou duplicado não é aceito como armazenamento migrado", () => {
  const store = registered();
  const duplicate = structuredClone(workspace(store));
  duplicate.id = "outro-id";
  store.accounts.push(duplicate);
  assert.throws(() => migrateStore(store), /duplicados/);
  assert.throws(() => migrateStore({ version: 3 }), /não reconhecida/);
  assert.throws(() => migrateStore({ ...initialStore(), accounts: [null] }));
});
test("backup não exporta autorização nem identificação de abas ou conexão", () => {
  const store = registered();
  const a = workspace(store);
  a.verifiedAt = new Date().toISOString();
  a.data.runtime.activeToken = "nonce-privado";
  a.data.runtime.workerTabId = 123;
  a.data.runtime.mode = "running";
  const backup = accountBackup(a);
  assert.equal(backup.account.verifiedAt, undefined);
  assert.equal(backup.account.data.runtime.activeToken, undefined);
  assert.equal(backup.account.data.runtime.workerTabId, undefined);
  assert.equal(backup.account.data.runtime.mode, "paused");
  assert.equal(a.data.runtime.activeToken, "nonce-privado");
});
test("migração de contas valida 24 horas e conserva os horários e limites antigos", () => {
  const legacy = registered();
  const settings = workspace(legacy).data.settings;
  delete settings.allDay;
  Object.assign(settings, { startHour: "09:00", endHour: "21:00", intervalMinutes: 5, dailyLimit: 5, sessionLimit: 5 });
  const migrated = migrateStore(structuredClone(legacy));
  assert.deepEqual(workspace(migrated).data.settings, { ...settings, allDay: false });
  workspace(legacy).data.settings.allDay = true;
  assert.equal(workspace(migrateStore(structuredClone(legacy))).data.settings.allDay, true);
  const oldState = structuredClone(workspace(legacy).data);
  delete oldState.settings.allDay;
  assert.equal(workspace(migrateStore(undefined, oldState)).data.settings.allDay, false);
  for (const allDay of ["false", 1, null]) {
    const invalid = structuredClone(legacy);
    workspace(invalid).data.settings.allDay = allDay as unknown as boolean;
    assert.throws(() => migrateStore(invalid), /24 horas/);
  }
});
test("backup preserva a agenda 24 horas sem restaurar autorização e rejeita flag adulterada", () => {
  const source = registered();
  const account = workspace(source);
  account.data.settings = { ...account.data.settings, allDay: true, startHour: "09:00", endHour: "21:00", intervalMinutes: 5, dailyLimit: 5, sessionLimit: 5 };
  const backup = accountBackup(account);
  assert.equal(backup.account.data.settings.allDay, true);
  const target = initialStore();
  const restored = applyScopedCommand(target, target.activeId, { type: "RESTORE", data: backup });
  assert.deepEqual(workspace(restored).data.settings, account.data.settings);
  assert.equal(workspace(restored).verifiedAt, undefined);
  assert.equal(workspace(restored).data.runtime.mode, "paused");
  const invalidBackup = structuredClone(backup);
  invalidBackup.account.data.settings.allDay = "true" as unknown as boolean;
  const before = structuredClone(target);
  assert.throws(() => applyScopedCommand(target, target.activeId, { type: "RESTORE", data: invalidBackup }), /24 horas/);
  assert.deepEqual(target, before);
});
test("métricas não atribuem eventos sem conta e usam a maior contagem registrada", () => {
  const a = workspace(registered());
  const at = new Date().toISOString();
  const key = `qa.alpha|${new Date().toDateString()}`;
  a.data.dailyAttempts[key] = 1;
  a.data.audit.push(
    ...["a", "b"].map((id) => ({
      id,
      at,
      account: "qa.alpha",
      kind: "attempt" as const,
      message: "Tentativa",
    })),
    { id: "c", at, kind: "followed", message: "Sem conta identificada" },
  );
  const m = profileMetrics(a, 7);
  assert.equal(m.attempts, 2);
  assert.equal(m.confirmed, 0);
  assert.throws(() => profileMetrics(a, 90));
  assert.throws(() => profileMetrics(a, 0));
  assert.equal(profileMetrics(workspace(initialStore()), 7).attempts, 0);
});
function populated() {
  let store = registered();
  store = applyScopedCommand(store, store.activeId, {
    type: "CREATE_CAMPAIGN",
    name: "Fonte A",
    kind: "followers",
    target: "referencia",
  });
  const a = workspace(store);
  mergeCandidates(a.data, a.data.campaigns[0].id, [
    { username: "pessoa.alvo" },
  ]);
  a.data.candidates[0].note = "Somente A";
  return store;
}
test("migração preserva dados e proteções antigas sem assumir conexão válida", () => {
  const old = workspace(populated()).data;
  old.runtime.mode = "running";
  old.runtime.activeToken = "antigo";
  old.settings.hasPendingWarning = true;
  old.dailyAttempts["qa.alpha|dia"] = 4;
  old.lastAttempts = { "@qa.alpha": "2026-11-01T12:00:00Z" };
  const a = workspace(migrateStore(undefined, old));
  assert.equal(a.username, "qa.alpha");
  assert.equal(a.verifiedAt, undefined);
  assert.equal(a.data.runtime.mode, "paused");
  assert.equal(a.data.runtime.activeToken, undefined);
  assert.deepEqual(a.data.candidates, old.candidates);
  assert.deepEqual(a.data.dailyAttempts, old.dailyAttempts);
  assert.deepEqual(a.data.lastAttempts, old.lastAttempts);
  assert.equal(a.data.settings.hasPendingWarning, true);
  assert.equal(old.runtime.mode, "running");
});
test("primeiro cadastro aproveita o espaço inicial e duplicatas normalizadas não criam contas", () => {
  const store = registered();
  assert.equal(store.accounts.length, 1);
  const duplicate = accountCommand(store, {
    type: "ADD_ACCOUNT",
    username: "@QA.ALPHA",
  });
  assert.equal(duplicate.accounts.length, 1);
  assert.equal(duplicate.activeId, store.activeId);
  assert.equal(workspace(store).verifiedAt, undefined);
});
test("duas contas isolam campanha, candidato, nota, aviso, limites, contadores e medições", () => {
  let store = populated();
  const aId = store.activeId;
  const a = workspace(store);
  a.data.settings.dailyLimit = 3;
  a.data.settings.hasPendingWarning = true;
  audit(a.data, "attempt", "Tentativa A");
  addSnapshot(a, { followers: 120, source: "manual" });
  const before = structuredClone(a);
  store = accountCommand(store, { type: "ADD_ACCOUNT", username: "qa.beta" });
  const bId = store.activeId;
  assert.equal(workspace(store).data.campaigns.length, 0);
  assert.equal(workspace(store).snapshots.length, 0);
  assert.equal(workspace(store).data.settings.hasPendingWarning, false);
  assert.equal(workspace(store).data.settings.dailyLimit, 5);
  assert.deepEqual(workspace(store).data.dailyAttempts, {});
  store = applyScopedCommand(store, bId, {
    type: "CREATE_CAMPAIGN",
    name: "Fonte B",
    kind: "import",
    target: "Lista",
  });
  const b = workspace(store);
  mergeCandidates(b.data, b.data.campaigns[0].id, [
    { username: "pessoa.alvo" },
  ]);
  assert.equal(b.data.candidates.length, 1);
  assert.equal(b.data.candidates[0].note, "");
  assert.deepEqual(
    workspace(store, aId).data.candidates,
    before.data.candidates,
  );
  assert.deepEqual(
    workspace(store, aId).data.dailyAttempts,
    before.data.dailyAttempts,
  );
  store = accountCommand(store, { type: "SELECT_ACCOUNT", id: aId });
  assert.equal(workspace(store).data.settings.dailyLimit, 3);
  assert.equal(workspace(store).snapshots[0].followers, 120);
});
test("troca pausa a fila e remove autorizações da conta anterior", () => {
  let store = registered();
  const id = store.activeId;
  const runtime = workspace(store).data.runtime;
  runtime.mode = "running";
  runtime.activeToken = "token";
  runtime.nextRun = Date.now();
  store = accountCommand(store, { type: "ADD_ACCOUNT", username: "qa.beta" });
  assert.equal(workspace(store, id).data.runtime.mode, "paused");
  assert.equal(workspace(store, id).data.runtime.activeToken, undefined);
  assert.equal(workspace(store, id).data.runtime.nextRun, undefined);
});
test("troca e novo cadastro aguardam uma ação já em andamento", () => {
  const store = populated();
  workspace(store).data.candidates[0].stage = "attempting";
  assert.throws(
    () => accountCommand(store, { type: "ADD_ACCOUNT", username: "qa.beta" }),
    /Aguarde/,
  );
});
test("comando vindo de painel desatualizado não altera outra conta", () => {
  const first = registered();
  const id = first.activeId;
  const store = accountCommand(first, {
    type: "ADD_ACCOUNT",
    username: "qa.beta",
  });
  assert.throws(
    () => applyScopedCommand(store, id, { type: "REPORT_WARNING" }),
    /ativa mudou/,
  );
  assert.equal(workspace(store).data.settings.hasPendingWarning, false);
});
test("verificação não pode reatribuir um cadastro a outra sessão", () => {
  const store = registered();
  assert.throws(
    () => bindVerifiedAccount(store, store.activeId, "qa.beta"),
    /Troque/,
  );
  const connected = bindVerifiedAccount(store, store.activeId, "qa.alpha");
  assert.ok(workspace(connected).verifiedAt);
  assert.equal(connected.sessionUsername, "qa.alpha");
  assert.equal(workspace(connected).data.runtime.mode, "paused");
});
test("identificar sessão em espaço sem vínculo seleciona conta existente, sem duplicá-la", () => {
  let store = registered();
  const alpha = store.activeId;
  const draft = initialStore().accounts[0];
  store.accounts.push(draft);
  store.activeId = draft.id;
  store = bindVerifiedAccount(store, draft.id, "qa.alpha");
  assert.equal(store.activeId, alpha);
  assert.equal(store.accounts.length, 2);
  assert.equal(workspace(store).username, "qa.alpha");
});
test("backup de outra conta é rejeitado e backup próprio preserva consumo e aviso", () => {
  const original = populated();
  const id = original.activeId;
  const backup = accountBackup(structuredClone(workspace(original)));
  let store = accountCommand(original, {
    type: "ADD_ACCOUNT",
    username: "qa.beta",
  });
  assert.throws(
    () =>
      applyScopedCommand(store, store.activeId, {
        type: "RESTORE",
        data: backup,
      }),
    /pertence/,
  );
  const beta = structuredClone(workspace(store));
  store = accountCommand(store, { type: "SELECT_ACCOUNT", id });
  workspace(store).data.settings.hasPendingWarning = true;
  audit(workspace(store).data, "attempt", "Tentativa posterior");
  const consumed = structuredClone(workspace(store).data.dailyAttempts);
  store = applyScopedCommand(store, id, { type: "RESTORE", data: backup });
  assert.equal(workspace(store).data.settings.hasPendingWarning, true);
  assert.deepEqual(workspace(store).data.dailyAttempts, consumed);
  assert.equal(workspace(store).verifiedAt, undefined);
  assert.deepEqual(workspace(store, beta.id), beta);
});
test("restaurar backup no espaço vazio mantém a conta e medições sem duplicar na repetição", () => {
  const source = registered();
  addSnapshot(workspace(source), {
    followers: 0,
    source: "manual",
    at: "2026-10-01T12:00:00Z",
  });
  const backup = accountBackup(workspace(source));
  let target = initialStore();
  const id = target.activeId;
  target = applyScopedCommand(target, id, { type: "RESTORE", data: backup });
  target = applyScopedCommand(target, id, { type: "RESTORE", data: backup });
  assert.equal(workspace(target).username, "qa.alpha");
  assert.equal(workspace(target).data.runtime.account, "qa.alpha");
  assert.equal(workspace(target).snapshots.length, 1);
  assert.equal(workspace(target).snapshots[0].followers, 0);
});
test("backup não pode registrar dois espaços para o mesmo perfil nem misturar dono e runtime", () => {
  const source = registered();
  const backup = accountBackup(workspace(source));
  const target = registered();
  const draft = initialStore().accounts[0];
  target.accounts.push(draft);
  target.activeId = draft.id;
  assert.throws(
    () =>
      applyScopedCommand(target, draft.id, { type: "RESTORE", data: backup }),
    /já está cadastrada/,
  );
  backup.account.data.runtime.account = "qa.beta";
  assert.throws(
    () =>
      applyScopedCommand(source, source.activeId, {
        type: "RESTORE",
        data: backup,
      }),
    /diferentes/,
  );
});
test("medições validam inteiros, data, campos desconhecidos e preservam origem manual", () => {
  const a = workspace(registered());
  for (const count of [-1, 1.5, NaN, Infinity])
    assert.throws(() => addSnapshot(a, { followers: count, source: "manual" }));
  assert.throws(() => addSnapshot(a, { source: "manual" }));
  assert.throws(() =>
    addSnapshot(a, {
      followers: 5,
      at: new Date(Date.now() + 600000).toISOString(),
      source: "manual",
    }),
  );
  addSnapshot(a, { followers: 0, source: "manual" });
  assert.equal(a.snapshots[0].following, undefined);
  assert.equal(a.snapshots[0].source, "manual");
});
test("métricas usam só esta conta, distinguem ações e seguidores e respeitam período", (t) => {
  const a = workspace(registered());
  const now = new Date("2026-11-03T15:00:00Z");
  t.mock.timers.enable({ apis: ["Date"], now });
  addSnapshot(a, {
    followers: 100,
    at: "2026-10-20T12:00:00Z",
    source: "instagram",
  });
  addSnapshot(a, {
    followers: 110,
    at: "2026-11-02T12:00:00Z",
    source: "manual",
  });
  addSnapshot(a, {
    following: 30,
    posts: 0,
    at: "2026-11-03T12:00:00Z",
    source: "instagram",
  });
  a.data.audit.push(
    {
      id: "a",
      at: "2026-11-02T12:00:00Z",
      account: "qa.alpha",
      kind: "followed",
      message: "OK",
    },
    {
      id: "b",
      at: "2026-11-02T12:00:00Z",
      account: "qa.beta",
      kind: "followed",
      message: "Outra conta",
    },
  );
  a.data.dailyAttempts[
    `qa.alpha|${new Date("2026-11-02T12:00:00Z").toDateString()}`
  ] = 3;
  const m = profileMetrics(a, 7, now);
  assert.equal(m.followers.value, 110);
  assert.equal(m.followers.snapshot?.source, "manual");
  assert.equal(m.posts.value, 0);
  assert.equal(m.growth, 10);
  assert.equal(m.confirmed, 1);
  assert.equal(m.attempts, 3);
  assert.equal(m.history.length, 1);
});
test("medição única e dados antigos não inventam crescimento", () => {
  const a = workspace(registered());
  addSnapshot(a, {
    followers: 100,
    at: "2026-10-01T12:00:00Z",
    source: "manual",
  });
  assert.equal(profileMetrics(a, 7).growth, undefined);
  addSnapshot(a, {
    followers: 110,
    at: "2026-10-02T12:00:00Z",
    source: "manual",
  });
  assert.equal(profileMetrics(a, 7).growth, undefined);
});
function profile(
  session = "qa.alpha",
  heading = "qa.alpha",
  count = '<span title="1.234">1,2 mil</span> seguidores',
) {
  return new JSDOM(
    `<nav><a href="/${session}/">Perfil</a></nav><main><header><h2>${heading}</h2><ul><li>12 publicações</li><li><a href="/qa.alpha/followers/">${count}</a></li><li><a href="/qa.alpha/following/">0 seguindo</a></li></ul></header></main>`,
  ).window.document;
}
test("leitura de métricas exige sessão, rota e cabeçalho do próprio perfil", () => {
  assert.deepEqual(readOwnProfileMetrics(profile(), "/qa.alpha/", "qa.alpha"), {
    followers: 1234,
    following: 0,
    posts: 12,
  });
  assert.throws(() =>
    readOwnProfileMetrics(profile("qa.beta"), "/qa.alpha/", "qa.alpha"),
  );
  assert.throws(() =>
    readOwnProfileMetrics(profile(), "/qa.beta/", "qa.alpha"),
  );
  assert.throws(() =>
    readOwnProfileMetrics(
      profile("qa.alpha", "qa.beta"),
      "/qa.alpha/",
      "qa.alpha",
    ),
  );
});
test("contadores abreviados ficam desconhecidos e não viram números aproximados", () => {
  for (const v of ["1,2 mil", "1.2K", "1M", "-1", "12.34", "1e3"])
    assert.equal(exactCount(v), undefined);
  for (const v of ["1.234", "1,234", "1 234"])
    assert.equal(exactCount(v), 1234);
  assert.equal(
    readOwnProfileMetrics(
      profile("qa.alpha", "qa.alpha", "1,2 mil seguidores"),
      "/qa.alpha/",
      "qa.alpha",
    ).followers,
    undefined,
  );
});

function compactProfile(
  title = ' title="18.405"',
  extra = "",
  followingHref = "#",
) {
  return new JSDOM(`<nav><a aria-label="Perfil" href="/qa.alpha/"><img alt="Foto do perfil de qa.alpha"></a><a href="/qa.alpha/following/">999 seguindo</a></nav>
  <main role="main"><header><div><section><div data-profile-summary>
    <div><a href="#"><h2><span>qa.alpha</span></h2></a><button>Opções</button></div>
    <div>Nome de exibição fictício</div>
    <div data-stats><div><span><span><span>37</span></span> posts</span></div><div><a href="#" role="link"><span><span${title}><span>18&nbsp;mil</span></span> seguidores</span></a></div><div><a href="${followingHref}" role="link"><span><span><span>42</span></span> seguindo</span></a></div></div>
  </div><button>Bio fictícia com 888 posts e 777 seguindo</button>${extra}</section></div><a href="/accounts/edit/">Editar perfil</a><button>Ver Itens Arquivados</button></header>
  <article><h2>qa.alpha</h2><div><span>999 posts</span><a href="#">998 seguidores</a><a href="#">997 seguindo</a></div></article><a href="/reel/fake/">123 posts</a></main>`)
    .window.document;
}
test("contadores em DIV/SPAN com href # pertencem ao grupo local do cabeçalho", () => {
  assert.deepEqual(
    readOwnProfileMetrics(compactProfile(), "/qa.alpha/", "qa.alpha"),
    { followers: 18405, following: 42, posts: 37 },
  );
});
test("grupo compacto mantém abreviação desconhecida quando não há title exato", () => {
  assert.deepEqual(
    readOwnProfileMetrics(compactProfile(""), "/qa.alpha/", "qa.alpha"),
    { followers: undefined, following: 42, posts: 37 },
  );
});
test("grupo compacto não usa números da bio, da navegação ou de publicações", () => {
  const bio =
    '<button><div><span>666 posts</span><a href="#">665 seguidores</a><a href="#">664 seguindo</a></div></button>';
  assert.deepEqual(
    readOwnProfileMetrics(compactProfile("", bio), "/qa.alpha/", "qa.alpha"),
    { followers: undefined, following: 42, posts: 37 },
  );
});
test("leitura compacta continua exigindo a sessão e a rota da conta selecionada", () => {
  assert.throws(() =>
    readOwnProfileMetrics(compactProfile(), "/qa.beta/", "qa.alpha"),
  );
  assert.throws(() =>
    readOwnProfileMetrics(compactProfile(), "/qa.alpha/", "qa.beta"),
  );
});
test("grupo compacto com vínculo de outra conta não é usado como medição", () => {
  assert.deepEqual(
    readOwnProfileMetrics(
      compactProfile("", "", "/qa.beta/following/"),
      "/qa.alpha/",
      "qa.alpha",
    ),
    {},
  );
});
