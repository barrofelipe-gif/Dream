import test from "node:test";
import assert from "node:assert/strict";
import {
  accountCommand,
  addSnapshot,
  initialStore,
  migrateStore,
  workspace,
} from "../src/core/accounts.ts";
import { accountDataReadiness } from "../src/core/account-readiness.ts";
import { validateInsightReport } from "../src/core/insights.ts";
import {
  knownBusinessProfile,
  MARKET_RESEARCH_AT,
  prepareKnownMarket,
} from "../src/core/market-seeds.ts";
import {
  addRelationshipSnapshot,
  ownRelationshipMeasurement,
  relationshipAnalysis,
} from "../src/core/relationships.ts";
import type { OwnRelationshipReading } from "../src/core/types.ts";

const own = "qa.owner";
const reading = (
  kind: "followers" | "following",
  names: string[] = ["qa.fictitious"],
): OwnRelationshipReading => ({
  account: own,
  kind,
  usernames: names,
  complete: false,
  at: "2026-11-02T12:00:00.000Z",
});
const account = () =>
  workspace(
    accountCommand(initialStore(), { type: "ADD_ACCOUNT", username: own }),
  );

test("ausência de listas permanece ausente mesmo com contadores e histórico de prospecção", () => {
  const a = account();
  a.snapshots = [
    {
      id: "counter",
      at: "2026-11-02T12:00:00.000Z",
      followers: 220000,
      following: 30,
      source: "instagram",
    },
  ];
  const state = accountDataReadiness(a);
  assert.equal(state.profile?.followers, 220000);
  assert.equal(state.network.status, "missing");
  assert.equal(state.network.snapshot, undefined);
  assert.equal(state.acquisition.measuredFollowers, undefined);
  assert.equal(state.network.canCheckAbsence, false);
  assert.deepEqual(a.relationships, undefined);
});

test("uma medição explicitamente vazia é distinguida de uma lista não medida", () => {
  const a = account();
  a.relationships = addRelationshipSnapshot(
    undefined,
    {
      account: own,
      at: "2026-11-02T12:00:00.000Z",
      source: "manual",
      followers: [],
      following: [],
      followersComplete: true,
      followingComplete: true,
    },
    own,
  );
  const state = accountDataReadiness(a);
  assert.equal(state.network.status, "complete");
  assert.equal(state.acquisition.measuredFollowers, 0);
  assert.equal(state.network.canCheckAbsence, true);
});

test("perfil mais recente usa o instante absoluto quando snapshots têm offsets diferentes", () => {
  const a = account();
  addSnapshot(a, { at: "2026-11-02T12:00:00-03:00", followers: 9, source: "manual" });
  addSnapshot(a, { at: "2026-11-02T14:00:00Z", followers: 3, source: "manual" });
  const before = structuredClone(a.snapshots);
  assert.equal(accountDataReadiness(a).profile?.followers, 9);
  assert.equal(Date.parse(accountDataReadiness(a).profile!.at), Date.parse("2026-11-02T15:00:00Z"));
  assert.deepEqual(a.snapshots, before);
});

test("Insights mais recentes usam recordedAt absoluto preservado em relatórios válidos com offsets", () => {
  const a = account();
  a.insights = [
    validateInsightReport({ id: "latest", account: own, start: "2026-11-01", end: "2026-11-01", recordedAt: "2026-11-02T12:00:00-03:00", metrics: { views: 9 } }, own, "file", true),
    validateInsightReport({ id: "older", account: own, start: "2026-11-01", end: "2026-11-01", recordedAt: "2026-11-02T14:00:00Z", metrics: { views: 3 } }, own, "file", true),
  ];
  const before = structuredClone(a.insights);
  assert.equal(accountDataReadiness(a).insights.latest?.id, "latest");
  assert.deepEqual(a.insights, before);
});

test("origens registradas sem lista própria não se transformam em seguidores observados", () => {
  const a = account();
  a.acquisition = {
    version: 1,
    account: own,
    assignments: [
      {
        username: "qa.fictitious",
        channel: "paid",
        sourceLabel: "Fixture",
        evidence: "manual",
        note: "",
        updatedAt: "2026-11-02T12:00:00.000Z",
      },
    ],
    reports: [],
  };
  const state = accountDataReadiness(a);
  assert.equal(state.acquisition.origins.length, 1);
  assert.equal(state.acquisition.measuredFollowers, undefined);
  assert.equal(state.acquisition.status, "missing_membership");
  a.acquisition.account = "qa.other";
  assert.equal(accountDataReadiness(a).acquisition.origins.length, 0);
});

test("contexto informado prepara apenas as contas conhecidas, sem inventar métricas ou modelo da Moranga", () => {
  let store = accountCommand(initialStore(), {
    type: "ADD_ACCOUNT",
    username: "BFFfitness_atacado",
  });
  const bff = workspace(store);
  assert.equal(bff.market?.profile?.model, "wholesale");
  assert.equal(bff.market?.profile?.sector, "fitness");
  assert.equal(bff.market?.references.length, 2);
  assert.ok(
    bff.market?.references.every(
      (r) =>
        Object.keys(r.metrics).length === 0 &&
        r.observedAt === MARKET_RESEARCH_AT,
    ),
  );
  assert.equal(bff.market?.profile?.bio, "");
  store = accountCommand(store, {
    type: "ADD_ACCOUNT",
    username: "moranga_biquinis",
  });
  const moranga = workspace(store);
  assert.equal(moranga.market?.profile?.model, "unknown");
  assert.equal(moranga.market?.profile?.sector, "beachwear");
  assert.ok(moranga.market?.references.every((r) => r.sector === "beachwear"));
  assert.notEqual(bff.market, moranga.market);
  assert.equal(knownBusinessProfile("outro_perfil"), undefined);
  assert.equal(account().market, undefined);
});

test("ativação e migração preservam contexto editado, medições e referências arquivadas", () => {
  const store = accountCommand(initialStore(), {
    type: "ADD_ACCOUNT",
    username: "bfffitness_atacado",
  });
  const a = workspace(store);
  a.market!.profile!.audience = "Público revisado";
  a.market!.references[0].metrics = { likes: 49, comments: 8 };
  a.market!.references[0].note = "Observação real já salva; não sobrescrever.";
  a.market!.references.forEach((r) => (r.archived = true));
  const before = structuredClone(a.market);
  prepareKnownMarket(a);
  const migrated = migrateStore(structuredClone(store));
  const selected = accountCommand(migrated, {
    type: "SELECT_ACCOUNT",
    id: a.id,
  });
  // Validation may materialize optional undefined keys; the stored payload must stay identical.
  assert.deepEqual(
    JSON.parse(JSON.stringify(workspace(selected).market)),
    JSON.parse(JSON.stringify(before)),
  );
  assert.equal(
    accountDataReadiness(workspace(selected)).market.references.length,
    0,
  );
});

test("leitura nativa salva ambas as listas como parciais e preserva as duas datas", () => {
  const followers = reading("followers", ["qa.mutual", "qa.only_follower"]);
  const following = {
    ...reading("following", ["qa.mutual", "qa.only_following"]),
    at: "2026-11-02T12:05:00.000Z",
  };
  const original = structuredClone({ followers, following });
  const measurement = ownRelationshipMeasurement(own, followers, following);
  assert.equal(measurement.followersComplete, false);
  assert.equal(measurement.followingComplete, false);
  assert.equal(measurement.at, following.at);
  assert.ok(
    measurement.note.includes(followers.at) &&
      measurement.note.includes(following.at),
  );
  const book = addRelationshipSnapshot(undefined, measurement, own);
  const analysis = relationshipAnalysis(book);
  assert.deepEqual(analysis.mutual, ["qa.mutual"]);
  assert.equal(analysis.notFollowingBack, undefined);
  assert.equal(analysis.lost, undefined);
  assert.deepEqual({ followers, following }, original);
});

test("leitura parcial nova não usa medição antiga completa para inferir uma ausência", () => {
  let book = addRelationshipSnapshot(
    undefined,
    {
      account: own,
      at: "2026-11-01T12:00:00.000Z",
      source: "manual",
      followers: ["qa.mutual"],
      following: ["qa.mutual"],
      followersComplete: true,
      followingComplete: true,
    },
    own,
  );
  book = addRelationshipSnapshot(
    book,
    ownRelationshipMeasurement(
      own,
      reading("followers", ["qa.other"]),
      reading("following", ["qa.mutual"]),
    ),
    own,
  );
  const analysis = relationshipAnalysis(book);
  assert.equal(analysis.comparable, false);
  assert.equal(analysis.notFollowingBack, undefined);
  assert.equal(analysis.lost, undefined);
});

test("conta, tipo de lista, auto inclusão e completude forjada são rejeitados antes de salvar", () => {
  const followers = reading("followers"),
    following = reading("following");
  assert.throws(
    () => ownRelationshipMeasurement("qa.other", followers, following),
    /conta selecionada/,
  );
  assert.throws(
    () => ownRelationshipMeasurement(own, following, followers),
    /duas listas parciais/,
  );
  assert.throws(
    () =>
      ownRelationshipMeasurement(
        own,
        { ...followers, complete: true } as never,
        following,
      ),
    /duas listas parciais/,
  );
  assert.throws(
    () =>
      ownRelationshipMeasurement(own, reading("followers", [own]), following),
    /própria conta/,
  );
});
