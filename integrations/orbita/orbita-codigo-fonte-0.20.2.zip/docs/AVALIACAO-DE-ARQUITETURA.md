# Avaliação de arquitetura e mecanismos de automação

Data da consulta: **03/11/2026**. Escopo: documentação pública e trechos de código dos projetos originais, sem login, instalação, contratação ou execução de ações no Instagram. A leitura de um repositório comprova o mecanismo presente naquele código; não comprova que ele funciona hoje em todas as contas.

## Decisão para a Órbita

### Adequação à operação 24h — 04/11/2026

Para operar sem depender do computador de uso diário do usuário, a recomendação é manter o painel web e um executor em máquina dedicada no Brasil, com sessão persistente e separação por conta. A extensão pode continuar sendo o agente local dessa máquina; a escolha entre extensão e serviço deve considerar distribuição, recuperação e supervisão, e não ser confundida com a escolha entre o computador pessoal e uma máquina sempre disponível. Nenhuma máquina ou sessão foi migrada nesta avaliação.

O AutoInsta declara execução no dispositivo com Chrome e computador ligado. O PhantomBuster declara execução em nuvem com o navegador do usuário fechado, e seu Watcher relê fontes em execuções agendadas. Isso comprova diferenças de disponibilidade documentadas, sem comprovar superioridade de conversão, estabilidade ou risco de bloqueio. Um executor dedicado melhora a independência do computador pessoal, mas mantém dependências de sessão, interface e disponibilidade da plataforma; não cria notificações instantâneas de interações em terceiros.

A arquitetura recomendada combina esse executor com integrações oficiais para eventos efetivamente disponíveis da própria conta, como comentários, além de métricas e relatórios. O país de saída da conexão do executor deve ser verificado como Brasil; não se presumiu que uma nuvem comercial ofereça essa condição. A documentação pública foi conferida, mas não foi realizado um benchmark controlado entre fornecedores. A instalação atual ainda é o piloto local, e o modo24h publicado depende de recarga e aplicação explícita na BFF.

Fontes reconferidas: [AutoInsta](https://www.autoinsta.online/), [FAQ de execução em nuvem do PhantomBuster](https://phantombuster.com/pricing), [Watcher](https://phantombuster.com/automations/instagram/7175/instagram-follower-collector/tutorial), [agendamento](https://support.phantombuster.com/hc/en-us/articles/11392980593298-How-to-Schedule-Your-Phantoms-to-Run-Automatically) e [referência oficial da Meta](https://raw.githubusercontent.com/fbsamples/messenger-platform-samples/main/postman/instagram-platform-api.postman_collection.json).

A verificação específica de acompanhamento contínuo, eventos oficiais e latência está em [Monitoramento e tempo de resposta](MONITORAMENTO-E-TEMPO-DE-RESPOSTA.md). Ela diferencia os dois produtos chamados AutoInsta/Auto Insta, confirma o Watcher por execuções sucessivas do PhantomBuster e registra que o nativo 0.19.0 ainda usa a mesma janela para leituras e ações.

Atualização da implementação: a [rotina contínua 0.19.0](ROTINA-CONTINUA.md) acrescenta consultas periódicas às fontes configuradas, navegação/rolagem e política única para seguir novos elegíveis. As descrições de coleta acompanhada abaixo registram a situação avaliada na 0.18.2; a leitura manual continua disponível, e a validação nativa da nova rotina em conta real está pendente. A atualização não cria execução em nuvem nem muda as limitações de acesso impostas à sessão.

Manter o executor local na extensão para as ações consentidas e usar integrações oficiais para os dados e operações que a Meta oferece, à medida que forem implementadas. O painel web coordena contas, revisão e análise; a sessão do Instagram e o executor de interface permanecem no dispositivo. Esta é uma decisão de controle e observabilidade, **sem garantia de ausência de bloqueios**.

Não há evidência nesta auditoria que justifique substituir o executor por Android ou transferir a sessão para uma nuvem. Primeiro precisamos medir a confiabilidade do fluxo atual, inclusive mudanças de layout, resultados incertos e recuperação sem repetir cliques. Ter mais funções anunciadas não demonstra maior confiabilidade.

## O limite da API oficial

A [coleção oficial da Meta no Postman](https://www.postman.com/meta/instagram/documentation/6yqw8pt/instagram-api) documenta métricas, publicação, comentários próprios e consulta limitada de perfis profissionais. Facebook Login exige Página vinculada; contas pessoais ficam fora. Instagram Login usa permissões próprias e não acessa anúncios/marcações. Stories possuem restrição por tipo de conta.

| Necessidade | Caminho e limite comprovável |
| --- | --- |
| Métricas próprias | API oficial, conforme conta, permissões e disponibilidade; não significa todas as métricas. |
| Publicar | API oficial; criação e publicação são etapas distintas. |
| Outros perfis profissionais | Business Discovery: dados públicos limitados, sem Insights privados. |
| Seguir/deixar de seguir | Sem operação na API oficial pública. |
| Listar @seguidores/seguidos de terceiros | Sem uma lista geral na API oficial; contadores não identificam pessoas. |
| Atribuir origem individual | Cruzamento de nomes não comprova causalidade. |

Limite desta verificação: as páginas em `developers.facebook.com` e o Help Center responderam **429** ou ficaram inacessíveis. A coleção mantida pela Meta no Postman foi lida; não fizemos uma validação autenticada de permissões nem de todos os campos da versão vigente. [Referência oficial de IG User](https://developers.facebook.com/docs/instagram-platform/instagram-graph-api/reference/ig-user/) e [Business Discovery](https://developers.facebook.com/docs/instagram-platform/instagram-graph-api/reference/ig-user/business_discovery/) devem ser reconferidas ao implementar o conector.

No Send API descrito pela coleção, o destinatário precisa ter enviado mensagem. Followback não é autorização universal de DM; integrações externas exigem contrato próprio.

## Como os projetos executam o trabalho

| Projeto | Mecanismo documentado | Dependências e consequência operacional |
| --- | --- | --- |
| AutoInsta | O fornecedor declara Chrome visível, cliques na interface e uso da sessão conectada. | Exige computador ligado e execução no dispositivo. A abertura de páginas também ocorre nesse produto; isso não demonstra autonomia ou estabilidade equivalentes às nossas. |
| InstaPy | Python e Selenium controlam navegador; o código usa Firefox/WebDriver, leitura de botões e seletores. Há também leitura de relações por consultas internas do site. | Exige ambiente de execução, navegador/driver compatíveis e sessão. Pode ser hospedado por quem o opera, mas não é por isso um serviço gerenciado. Mudanças no DOM e nas interfaces internas afetam o funcionamento. |
| GramAddict | Python, ADB e UIAutomator2 controlam o aplicativo Instagram em Android físico ou emulador. | Exige dispositivo/emulador acessível, depuração configurada, sessão e compatibilidade com a versão do aplicativo. Android não elimina dependência de layout. |
| PhantomBuster | Serviço em nuvem; conecta uma sessão do Instagram por extensão ou cookie e executa automações agendadas. | Continua executando com o navegador local fechado. Depende da sessão aceita pelo Instagram, infraestrutura/plano do fornecedor e disponibilidade da plataforma. |
| Órbita, decisão desta avaliação | Painel com espaços separados por conta e executor local de interface para ações revisadas. Dados oficiais ficam em um caminho separado. | Ações locais exigem extensão, navegador e sessão disponíveis. A existência do site publicado não cria execução local quando o computador está desligado. |

**InstaPy.** O [README original](https://github.com/InstaPy/InstaPy) confirma Selenium e identifica licença GPL-3.0. A [documentação de ações](https://github.com/InstaPy/InstaPy/blob/master/docs/actions.md) descreve públicos como comentaristas e pessoas que curtiram, listas de proteção e unfollow após um prazo. O [leitor de vínculo](https://github.com/InstaPy/InstaPy/blob/master/instapy/follow_util.py) depende de seletores e do estado do botão. Já [relationship_tools.py](https://github.com/InstaPy/InstaPy/blob/master/instapy/relationship_tools.py) contém consultas GraphQL internas do site e estruturas privadas da página: seria incorreto classificá-lo como um cliente exclusivo da API pública oficial. Esses códigos não foram executados nesta consulta.

**GramAddict.** O [repositório original](https://github.com/GramAddict/bot) declara ADB/UIAutomator2, dispositivo físico/emulado, configuração por conta e licença MIT. A [configuração publicada](https://github.com/GramAddict/bot/blob/master/config-examples/config.yml) contém fontes, filtros, proteção contra versões não testadas e opções de unfollow. O [guia do próprio projeto](https://github.com/GramAddict/docs/blob/main/quickstart.md) exige idioma inglês e registra dependências antigas; não assumimos compatibilidade atual com base nesse guia. Existe [relato aberto de incompatibilidade com atualização obrigatória do Instagram](https://github.com/GramAddict/bot/issues/451), que é relato de um usuário no repositório, não ensaio independente nem conclusão sobre todos os dispositivos.

**PhantomBuster.** O [tutorial de Auto Follow](https://phantombuster.com/automations/instagram/10274/instagram-auto-follow/tutorial) documenta listas, follow/unfollow e configurações separadas para executar as duas ações em sequência. O [guia de conexão](https://support.phantombuster.com/hc/en-us/articles/360007071779-How-to-Connect-and-Manage-Non-LinkedIn-Social-Media-Accounts-Yours-or-Someone-Else-s) explica a sessão por cookie e sugere uma cópia do Phantom por conta. A [FAQ oficial](https://phantombuster.com/pricing) confirma a execução em nuvem com o navegador fechado. O [tutorial de coleta](https://phantombuster.com/automations/instagram/7175/instagram-follower-collector/tutorial) reconhece que a visibilidade oferecida pelo Instagram pode limitar listas. Números de ações recomendados pelo fornecedor não são limites oficiais nem garantia de segurança da Meta.

**AutoInsta.** A [página oficial](https://www.autoinsta.online/) informa navegador visível na tela, cliques, ausência de dependência da API e necessidade de manter o dispositivo ligado. Também anuncia segmentação por seguidores e comentaristas, sequências e limites por conta. Essas são declarações do fornecedor, não testes nossos de uma assinatura. O simples uso do navegador não é uma deficiência exclusiva da Órbita; a coleta acompanhada e a ausência de métricas de confiabilidade continuam sendo lacunas nossas.

## O que comprovamos e o que falta nos produtos comerciais

| Produto | Evidência primária encontrada | O que não foi comprovado |
| --- | --- | --- |
| Nikau | A [página principal](https://nikau.com.br/) prioriza visualização/interação em Stories e diz que seguir/deixar de seguir ficou no passado. A [landing page](https://lp.nikau.com.br/) anuncia seguir, deixar de seguir, curtidas e DM. Sua FAQ admite não garantir quantidade exata de seguidores ou ausência de bloqueios. | Não identificamos repositório, arquitetura de execução, uso efetivo de API oficial para cada função, desempenho ou método de confirmação dos resultados. As páginas divergem; não consolidar tudo como um recurso atual verificado. |
| Perforgram | Os [termos oficiais indexados](https://www.perforgram.com/terms) informam exigência de usuário/senha na vinculação, dependência do Instagram, ausência de afiliação e de garantia quantitativa de tráfego. | O site e a abertura direta dos termos retornaram 502 nesta consulta. A indexação é evidência documental, não confirmação de que o serviço está operacional. Não comprovamos cloud, navegador, Android ou mecanismo interno. |
| Scalehot | Tentativa direta ao [domínio consultado](https://scalehot.com/) retornou 502. | Não encontramos documentação técnica primária ou repositório atual que comprove mecanismo e funções. Não confundir com ScaleShot, outro produto. Indisponibilidade nesta consulta não prova encerramento da empresa. |

Na Nikau, a frase curta da FAQ é explícita: **“Não podemos prometer que não haverá bloqueios.”** Promessas de seguidores e afirmações de IA nas mesmas páginas são marketing do fornecedor; não são ensaio de eficácia, autorização da Meta nem especificação de arquitetura.

## Onde a Órbita pode melhorar de forma verificável

Os projetos abertos já mostram segmentação, filtros, listas de proteção, espera antes do unfollow e registros. Portanto, essas ideias não são exclusividades nossas. O PhantomBuster documenta execução agendada em nuvem e cadeias de automação: essa conveniência é uma vantagem comprovada do modelo dele sobre nosso executor local, mas não prova melhor segurança ou resultado.

O diferencial que devemos demonstrar é a qualidade da decisão e do registro: conta e alvo identificados, fontes preservadas, revisão explícita, resultado incerto tratado sem repetição e métricas sem preenchimento fictício. Ainda não temos uma medição comparativa que prove que a Órbita é mais estável ou gera mais clientes que os concorrentes.

Requisitos de arquitetura e medição:

1. **Separar contas e sessões.** Armazenamento, fila, tentativas, proteções e dados por conta; revalidar o ator e o alvo imediatamente antes de cada ação. Revisão antiga de outra aba não autoriza um lote novo.
2. **Distinguir intenção, clique e observação.** Registrar identificador da operação, autorização, envio quando comprovável e resultado. Ver Seguindo depois não prova quem enviou o clique. Resultado incerto exige conferência sem clique; nunca repetição automática.
3. **Manter contratos de leitura específicos.** Cabeçalho do perfil e diálogo da lista precisam pertencer ao alvo. Botões de sugestões e elementos externos não são evidência do vínculo. Guardar casos de layout em fixtures de regressão.
4. **Preservar a qualidade dos dados.** Lista parcial comprova presença, não ausência. Falta de métrica é ausência, não zero. Conservar horário da coleta e separar métricas do período de contagens acumuladas da mídia.
5. **Evoluir a coleta oficial com observabilidade.** O adaptador atual da Órbita lê coletas já existentes no app; isso não atualiza a Meta em tempo real. Uma coleta recorrente futura precisa de permissões verificadas, tratamento de expiração, versão da API e histórico por conta.
6. **Medir confiabilidade antes de ampliar recursos.** Contar operações autorizadas, cliques comprovados, confirmações, incertezas e falhas por versão/layout. Medir latência, recuperação sem duplicidade e interrupção por aviso. Ainda não há base para publicar taxa de sucesso ou probabilidade de bloqueio.
7. **Medir eficácia de negócio com evidência.** Acompanhar crescimento, conteúdo, visitas, conversas e clientes conforme dados disponíveis. Definir janela e denominador; não atribuir um seguidor à prospecção só porque apareceu na lista de uma campanha. Testes comparáveis devem considerar conteúdo, anúncios e variações de período.

Esses requisitos orientam a evolução; não significam que todos já foram implementados ou validados em produção. O documento não altera código, permissões, contas, limites nem a versão publicada.

## Correções desta auditoria

A entrega consolidada 0.18.2 trata ORB-042 a ORB-045: prazo efetivo nas leituras/navegação; liberação do executor e descarte do ponteiro defeituoso antes da reserva; cancelamento do coletor; captura sem repetição após retorno desconhecido; conferência de sessão sem acúmulo; liberação das vagas do relay e caixa do coletor que cabe em tela estreita.

Validação: 394 testes integrados aprovados, build aprovado, oito verificações funcionais do coletor em Chrome isolado e conferência visual em 390 px. O salvamento sem retorno encerrou a espera em 5.048 ms nesse fixture. São dados fictícios e falhas provocadas; nenhuma nova ação foi enviada ao Instagram real. O piloto real anterior continua sendo o da 0.18.0, sem conversões atribuídas.

A atualização não implementa coleta autônoma completa nem execução em nuvem. Não resolve a causa externa ainda não identificada do redirecionamento da aba para Home; evita que as esperas pendentes segurem o executor e permite a retomada explícita em documento novo. O código nativo precisa ser recarregado pelo usuário antes de validar essa correção no Chrome real; o painel continua aceitando 0.18.0.
