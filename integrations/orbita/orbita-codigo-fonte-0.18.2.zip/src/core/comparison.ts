export const COMPARISON_DATE = "2026-11-03";
export type ComparisonVerdict = "orbita" | "market" | "shared" | "unverified";
export const VERDICTS = {
  orbita: "Nossa vantagem neste uso",
  market: "Eles estão à frente",
  shared: "Recurso nos dois lados",
  unverified: "Sem conclusão comprovada",
} as const;
export const COMPARISON_SOURCES = {
  autoinsta: {
    label: "AutoInsta · recursos, execução local e planos",
    url: "https://www.autoinsta.online/",
  },
  phantomFollowers: {
    label:
      "PhantomBuster · execução em nuvem e limites da coleta de seguidores",
    url: "https://phantombuster.com/automations/instagram/2439619339195827/instagram-followers-auto-follow",
  },
  nikau: {
    label: "Nikau · Stories, publicação e planos",
    url: "https://nikau.com.br/",
  },
  metricoolMetrics: {
    label: "Metricool · métricas do Instagram",
    url: "https://help.metricool.com/instagram-metrics-ght51",
  },
  metricoolPublish: {
    label: "Metricool · agendamento e publicação",
    url: "https://help.metricool.com/schedule-and-post-on-instagram-6b6q5",
  },
  metricoolCompetitors: {
    label: "Metricool · análise de concorrentes",
    url: "https://help.metricool.com/competitor-analysis-ouhue",
  },
  metricoolStorage: {
    label: "Metricool · infraestrutura de armazenamento declarada",
    url: "https://metricool.com/legal-terms/",
  },
  laterAnalytics: {
    label: "Later · análises e tendências de hashtags por setor",
    url: "https://help.later.com/hc/en-us/articles/360043245753-Later-s-Instagram-Analytics",
  },
  laterPublish: {
    label: "Later · calendário e publicação",
    url: "https://later.com/social-media-scheduler/",
  },
  laterInbox: {
    label: "Later · mensagens e comentários",
    url: "https://later.com/social-media-inbox/",
  },
} as const;
type SourceId = keyof typeof COMPARISON_SOURCES;
export interface ComparisonCriterion {
  id: string;
  title: string;
  verdict: ComparisonVerdict;
  leader: string;
  scope: string;
  ours: string;
  reason: string;
  limit: string;
  evidence:
    | "Código e arquitetura"
    | "Avaliação do projeto"
    | "Documentação oficial"
    | "Evidência insuficiente";
  sources: SourceId[];
}
export const COMPARISON_CRITERIA: ComparisonCriterion[] = [
  {
    id: "custom",
    title: "Ajustar o produto ao seu jeito de trabalhar",
    verdict: "orbita",
    leader: "Órbita · personalização deste projeto",
    scope: "Entrega própria versus configurar uma plataforma contratada",
    ours: "Recebemos o código e conseguimos alterar roteiros, regras e telas para o seu negócio.",
    reason:
      "A mudança pode acontecer diretamente no projeto, em vez de depender somente das opções prontas da plataforma.",
    limit:
      "Vantagem do modelo de entrega. Não significa que os concorrentes não tenham APIs, integrações ou opções de personalização.",
    evidence: "Avaliação do projeto",
    sources: [],
  },
  {
    id: "local",
    title: "Manter a base da ferramenta no próprio computador",
    verdict: "orbita",
    leader: "Órbita · controle local da base",
    scope: "Comparação de arquitetura com Metricool",
    ours: "A base operacional da Órbita fica no navegador. O app BFF hospeda o painel, autentica o acesso e consulta as coletas oficiais já salvas no servidor. A extensão executa no computador.",
    reason:
      "É uma vantagem se a prioridade é manter essa base local. Metricool declara infraestrutura de servidores e armazenamento em nuvem.",
    limit:
      "Não prova segurança superior. AutoInsta também depende do computador; execução local não é uma exclusividade nossa.",
    evidence: "Código e arquitetura",
    sources: ["metricoolStorage", "autoinsta"],
  },
  {
    id: "runtime",
    title: "Executar com o computador desligado",
    verdict: "market",
    leader: "PhantomBuster · execução em nuvem declarada",
    scope: "Continuidade da execução, separada de armazenamento e hospedagem",
    ours: "A operação do Instagram depende da extensão, do navegador aberto e do computador ligado. Hospedar o painel no BFF não transfere essa execução para a nuvem.",
    reason:
      "PhantomBuster declara executar esse fluxo em nuvem sem navegador/computador ligado. AutoInsta declara Chrome visível e dispositivo em execução, assim como nossa dependência local.",
    limit:
      "É uma diferença de operação documentada. Não testamos a disponibilidade do serviço nem comprovamos maior eficácia ou menor risco de bloqueio.",
    evidence: "Documentação oficial",
    sources: ["phantomFollowers", "autoinsta"],
  },
  {
    id: "collection",
    title: "Conduzir a coleta de seguidores sem rolagem manual",
    verdict: "market",
    leader: "PhantomBuster · fluxo automático documentado",
    scope: "Seguidores de um perfil; sem promessa de lista completa",
    ours: "A coleta é acompanhada: abrir a fonte, expandir comentários/curtidas e rolar as listas. O coletor salva os nomes carregados; o grupo de três fontes organiza os passos, sem completar a lista automaticamente.",
    reason:
      "PhantomBuster documenta processar seguidores e repetir o fluxo em nuvem. Também alerta que alguns perfis expõem no máximo 50 seguidores para essa automação.",
    limit:
      "A coleta pode ser parcial nos dois modelos. O aviso do fornecedor não é uma regra universal nem um limite configurado pela Órbita; não há garantia de capturar toda a rede.",
    evidence: "Documentação oficial",
    sources: ["phantomFollowers"],
  },
  {
    id: "subscription",
    title: "Mensalidade para usar esta entrega local",
    verdict: "orbita",
    leader: "Órbita · sem mensalidade própria do app",
    scope: "Frente aos planos anunciados por AutoInsta e Nikau",
    ours: "Esta entrega local não cobra assinatura própria pelo uso.",
    reason:
      "Os dois concorrentes oferecem planos por assinatura. Nesse custo específico, temos vantagem.",
    limit:
      "Desenvolvimento, computador e manutenção têm custo. Metricool também tem plano Free; isso não é uma comparação de custo total.",
    evidence: "Avaliação do projeto",
    sources: ["autoinsta", "nikau", "metricoolCompetitors"],
  },
  {
    id: "sync",
    title: "Trazer métricas automaticamente",
    verdict: "market",
    leader: "Metricool e Later",
    scope: "Conexões de conta e métricas elegíveis",
    ours: "No app, importa parte da coleta oficial já salva, com prévia, datas e limites. A sessão local lê contadores; coleta Meta em tempo real e cobertura completa continuam pendentes.",
    reason:
      "As plataformas documentam análise conectada de conta e conteúdo. Nossa leitura usa a coleta já salva pelo app, com cobertura e janelas limitadas; isso não equivale à análise conectada completa.",
    limit:
      "Cobertura depende de conta, conexão, permissões e plano. Não significa acesso a todas as métricas do Instagram.",
    evidence: "Documentação oficial",
    sources: ["metricoolMetrics", "laterAnalytics"],
  },
  {
    id: "publish",
    title: "Agendar e publicar conteúdo",
    verdict: "market",
    leader: "Metricool, Later e Nikau",
    scope: "Disponibilidade conforme formato e plano",
    ours: "Temos roteiro e plano de teste; a publicação é manual.",
    reason:
      "Os fornecedores oferecem agendamento. Metricool e Later documentam publicação; Nikau anuncia agendamento de posts e Stories.",
    limit:
      "Há condições de conta e formato. Não verificamos o funcionamento em uma assinatura dos concorrentes.",
    evidence: "Documentação oficial",
    sources: ["metricoolPublish", "laterPublish", "nikau"],
  },
  {
    id: "competitors",
    title: "Coletar e comparar publicações de concorrentes",
    verdict: "market",
    leader: "Metricool",
    scope: "Dados públicos acessíveis pela API",
    ours: "O radar trabalha com referências salvas, importadas ou lidas uma página por vez.",
    reason:
      "Metricool documenta uma área de concorrentes com coleta de perfis e posts pela API. Já oferece parte do que precisamos automatizar no radar.",
    limit:
      "Alcance privado não fica público. Engajamento de concorrentes usa outra base; não pode ser comparado sem considerar a definição.",
    evidence: "Documentação oficial",
    sources: ["metricoolCompetitors"],
  },
  {
    id: "industry",
    title: "Acompanhar tendências do setor automaticamente",
    verdict: "market",
    leader: "Later · tendências de hashtags",
    scope: "Hashtags do setor em planos elegíveis",
    ours: "Setor sugerido por texto, referências revisadas e fontes iniciais com data; sem atualização automática do setor.",
    reason:
      "Later documenta tendências de hashtags por indústria atualizadas semanalmente, a partir de posts publicados por sua plataforma.",
    limit:
      "É um recorte da base do Later, não um radar universal de Reels virais nem prova de vendas.",
    evidence: "Documentação oficial",
    sources: ["laterAnalytics"],
  },
  {
    id: "automation",
    title: "Quantidade de tipos de interação automática",
    verdict: "market",
    leader: "AutoInsta e Nikau",
    scope: "Amplitude anunciada, não eficácia",
    ours: "Filas revisadas para seguir e deixar de seguir, com prazo, política de reciprocidade e proteções por conta. DMs e reações não foram implementadas.",
    reason:
      "AutoInsta anuncia mais modalidades de interação e sequências. Nikau anuncia visualização e interações em Stories.",
    limit:
      "Ter mais automações não prova melhor crescimento ou menos bloqueios. Este quadro não recomenda executar ações em excesso.",
    evidence: "Documentação oficial",
    sources: ["autoinsta", "nikau"],
  },
  {
    id: "inbox",
    title: "Atender mensagens e comentários no painel",
    verdict: "market",
    leader: "Later · Social Inbox",
    scope: "Planos Growth e Scale, conforme documentação",
    ours: "Não temos caixa de atendimento para responder DMs e comentários.",
    reason:
      "Later documenta uma caixa que reúne essas conversas e permite responder pelo produto.",
    limit:
      "Atendimento em uma inbox é diferente de envio automático de mensagens para prospecção.",
    evidence: "Documentação oficial",
    sources: ["laterInbox"],
  },
  {
    id: "pace",
    title: "Limites, horários e ritmo das ações",
    verdict: "shared",
    leader: "Órbita e AutoInsta têm controles",
    scope: "A presença do recurso é comparável; a eficácia não foi medida",
    ours: "Há teto, intervalo, revisão, lotes, confirmação da sessão e pausa por aviso.",
    reason:
      "AutoInsta também anuncia limites, horários e aquecimento. Não é correto apresentar controles de ritmo como algo que só nós fizemos.",
    limit:
      "Não temos teste comparativo que demonstre qual ferramenta gera menos bloqueios.",
    evidence: "Documentação oficial",
    sources: ["autoinsta"],
  },
  {
    id: "origin",
    title: "Saber de onde veio cada seguidor, automaticamente",
    verdict: "unverified",
    leader: "Sem vencedor verificado",
    scope: "Atribuição individual de causa",
    ours: "Origem informada por você, associações com bases e resultados agregados separados.",
    reason:
      "Cruzar uma pessoa com a base Dalu Fitness não prova o motivo do follow. Não comprovamos essa atribuição automática em nenhuma das ferramentas comparadas.",
    limit:
      "Nossa rastreabilidade é um diferencial implementado, não uma prova de superioridade ou exclusividade.",
    evidence: "Evidência insuficiente",
    sources: [],
  },
  {
    id: "results",
    title: "Gerar mais clientes, engajamento ou menos bloqueios",
    verdict: "unverified",
    leader: "Ainda não dá para afirmar",
    scope: "Resultado real em contas equivalentes",
    ours: "O piloto real concluiu cinco tentativas: dois estados Seguindo (um por observação posterior e um confirmado na execução) e três solicitações. Não medimos seguidores recebidos, clientes ou conversões causados pelo piloto.",
    reason:
      "Não fizemos um experimento equivalente entre produtos. Promessas comerciais não foram tratadas como resultado comprovado.",
    limit:
      "Quantidade de funções e aprovação nos testes de software não demonstram crescimento comercial.",
    evidence: "Evidência insuficiente",
    sources: [],
  },
  {
    id: "stability",
    title: "Estabilidade e retomada em uso prolongado",
    verdict: "unverified",
    leader: "Sem superioridade comprovada",
    scope: "Continuidade, falhas de leitura e retomada em sessões equivalentes",
    ours: "Houve piloto real e correções de leitura durante o uso. Ainda dependemos do DOM e de coleta acompanhada, sem uma medição de longa duração de disponibilidade ou completude.",
    reason:
      "Não medimos tempo de funcionamento, falhas e recuperação dos produtos nas mesmas condições. Aprovação nos testes de software e arquitetura em nuvem não substituem essa comparação.",
    limit:
      "Não afirmamos ser mais estáveis, mais seguros ou mais completos que os concorrentes. Ausência de medição não significa empate.",
    evidence: "Evidência insuficiente",
    sources: [],
  },
];
export const COMPARISON_PROVIDERS = [
  {
    name: "AutoInsta",
    group: "Automação de interações",
    ahead: "Leva vantagem na variedade de ações automáticas anunciadas.",
    ours: "Nosso diferencial é poder adaptar o projeto e ligar a revisão de públicos ao plano de conteúdo.",
    caution:
      "O fornecedor declara Chrome visível, sessão do navegador e computador ligado. Execução local e controles de ritmo não são exclusivos nossos.",
    sources: ["autoinsta"] as SourceId[],
  },
  {
    name: "PhantomBuster",
    group: "Automação em nuvem",
    ahead:
      "Documenta executar e repetir o fluxo de seguidores com o computador desligado.",
    ours: "Mantemos revisão por perfil e controle local da base e da execução.",
    caution:
      "O próprio fornecedor informa restrição de seguidores visíveis em certos perfis. Nuvem não comprova coleta completa, maior estabilidade ou resultado comercial.",
    sources: ["phantomFollowers"] as SourceId[],
  },
  {
    name: "Nikau",
    group: "Stories e agendamento",
    ahead: "Leva vantagem em interações de Stories e agendamento anunciados.",
    ours: "Já temos um fluxo próprio de referências, testes de conteúdo e diagnóstico local.",
    caution:
      "A promessa comercial de crescimento não comprova que terá resultado melhor em uma conta específica.",
    sources: ["nikau"] as SourceId[],
  },
  {
    name: "Metricool",
    group: "Métricas e concorrentes",
    ahead:
      "Está à frente na coleta conectada, publicação e análise de concorrentes.",
    ours: "Temos controle local da nossa base e acesso ao código para alterar o fluxo do projeto.",
    caution:
      "O módulo de concorrentes também existe no Free. Nosso radar não deve ser anunciado como exclusivo.",
    sources: [
      "metricoolMetrics",
      "metricoolCompetitors",
      "metricoolPublish",
    ] as SourceId[],
  },
  {
    name: "Later",
    group: "Conteúdo, setor e atendimento",
    ahead:
      "Está à frente em análise conectada, tendências de hashtags do setor, calendário e inbox.",
    ours: "Podemos ajustar nossos roteiros ao negócio e vincular testes aos dados locais.",
    caution:
      "As funções variam por plano. Nossa sugestão de setor por bio não equivale à coleta dessas tendências.",
    sources: ["laterAnalytics", "laterPublish", "laterInbox"] as SourceId[],
  },
];
export const COMPARISON_PRIORITIES = [
  {
    priority: "Primeiro",
    title: "Medir estabilidade e retomada além do piloto inicial",
    why: "O piloto real de cinco tentativas foi concluído. Falta medir continuidade, coleta parcial e recuperação em mais sessões; isso ainda não demonstra crescimento ou conversão.",
  },
  {
    priority: "Maior lacuna de dados",
    title: "Completar a atualização e a cobertura de Insights",
    why: "A leitura das coletas do app já reduz digitação. Falta completar atualização, métricas e cobertura para acompanhar a rotina de análise.",
  },
  {
    priority: "Rotina de conteúdo",
    title: "Integrar calendário e publicação",
    why: "Transformar o roteiro em execução acompanhada, respeitando o que cada formato e conta permitem.",
  },
  {
    priority: "Inteligência do setor",
    title: "Coletar referências e concorrentes com fonte atualizada",
    why: "Evoluir o radar atual, mantendo datas, limites da origem e comparações coerentes.",
  },
];
