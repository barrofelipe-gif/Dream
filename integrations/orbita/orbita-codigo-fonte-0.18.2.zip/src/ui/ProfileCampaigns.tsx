import { useState } from "react";
import { ArrowRight, Check, ExternalLink, Layers3, UsersRound } from "lucide-react";
import type { AppState, Command, SpecialCommand } from "../core/types.ts";
import { SOURCE_LABELS } from "../core/types.ts";
import { campaignMembers, groupedCampaigns } from "../core/campaigns.ts";
import { Hint, Modal, number, SourceIcon } from "./components.tsx";
import "./profile-campaigns.css";

type Group = ReturnType<typeof groupedCampaigns>[number];
type Run = (command: Command | SpecialCommand, success?: string) => Promise<boolean>;
const instruction = {
  followers: "Abra Seguidores no perfil. Role dentro da lista para carregar mais pessoas e use Capturar carregados, ou marque Capturar enquanto eu rolo.",
  commenters: "Abra os comentários da publicação. Expanda mais comentários ou respostas que quiser incluir e capture os perfis carregados.",
  likers: "Clique na quantidade de curtidas da publicação para abrir a lista Curtidas. Role dentro dela para carregar mais pessoas e capture os perfis.",
};
function CollectionSteps({ group, state, busy, run, onClose }: { group: Group; state: AppState; busy: boolean; run: Run; onClose: () => void }) {
  const [index, setIndex] = useState(0);
  const [openedId, setOpenedId] = useState<string>();
  const [finished, setFinished] = useState(false);
  const current = group.sources[index];
  const members = campaignMembers(state.candidates, [current]);
  const next = group.sources[index + 1];
  const open = async () => {
    if (await run({ type: "OPEN_SOURCE", id: current.id }, "Fonte aberta. Capture no Instagram e volte aqui para continuar.")) setOpenedId(current.id);
  };
  return <Modal title={`Coletar de @${group.profile}`} subtitle="Três fontes preparadas. Abra e confira uma etapa de cada vez." onClose={onClose} wide>
    <ol className="profile-source-steps" aria-label="Etapas de coleta">
      {group.sources.map((source, i) => <li key={source.id} aria-current={!finished && i === index ? "step" : undefined} className={finished || i < index ? "checked" : i === index ? "current" : ""}>
        <span>{finished || i < index ? <Check size={15} /> : i + 1}</span><strong>{SOURCE_LABELS[source.kind]}</strong>
        <small>{number(campaignMembers(state.candidates, [source]).length)} salvos</small>
      </li>)}
    </ol>
    {finished ? <div className="profile-source-instructions" role="status"><h3>Roteiro percorrido</h3><p>Você encerrou as etapas. O total reúne somente os perfis que foram capturados e salvos. É possível retomar qualquer fonte no cartão.</p><strong>{number(campaignMembers(state.candidates, group.sources).length)} perfis únicos no grupo</strong></div> : <>
      <div className="profile-source-instructions"><span className="tiny-label">ETAPA {index + 1} DE {group.sources.length}</span><h3>{SOURCE_LABELS[current.kind]}</h3><p>{instruction[current.kind as keyof typeof instruction]}</p><strong>{number(members.length)} perfis únicos salvos nesta fonte</strong><p className="body-copy">Não há limite de 11: esse número pode ser apenas o trecho carregado pelo Instagram. Ao rolar e capturar mais, os novos perfis são somados sem duplicar.</p></div>
      {openedId === current.id ? <div className="notice" role="status">Fonte aberta. Capture no Instagram antes de avançar. Abrir a fonte não significa que todos os perfis foram coletados.</div> : null}
      <div className="modal-actions">
        <button className="button secondary" disabled={busy} onClick={() => void open()}><ExternalLink size={15} />{openedId === current.id ? "Reabrir esta fonte" : "Abrir esta fonte"}</button>
        <button className="button primary" disabled={busy || openedId !== current.id} onClick={() => { if (next) { setIndex(index + 1); setOpenedId(undefined); } else setFinished(true); }}>
          {next ? "Encerrei esta etapa · continuar" : "Encerrei esta etapa · finalizar"}<ArrowRight size={15} />
        </button>
      </div>
    </>}
    <Hint>A captura é parcial e depende do conteúdo disponibilizado na tela. O grupo prepara seguidores e interações da publicação informada. Capturar não aprova nem segue pessoas.</Hint>
  </Modal>;
}
export function ProfileCampaignCards({ accountId, state, busy, run, onAudience }: { accountId: string; state: AppState; busy: boolean; run: Run; onAudience: (id: string) => void }) {
  const [collecting, setCollecting] = useState<string>();
  const groups = groupedCampaigns(state.campaigns).filter((group) => group.profile);
  const selected = groups.find((group) => group.id === collecting);
  return <>
    {groups.length ? <div className="profile-campaign-grid">{groups.map((group) => {
      const members = campaignMembers(state.candidates, group.sources);
      return <section className="panel profile-campaign-card" key={group.id}>
        <div className="profile-campaign-heading"><span className="source-symbol followers"><Layers3 size={23} /></span><span className="tiny-label">CAMPANHA POR PERFIL · {group.sources.length} FONTES</span></div>
        <h2>{group.name}</h2><a className="text-link" href={`https://www.instagram.com/${group.profile}/`} target="_blank" rel="noreferrer">@{group.profile}<ExternalLink size={13} /></a>
        <div className="profile-campaign-total"><UsersRound size={20} /><strong>{number(members.length)}</strong><span>perfis únicos salvos no grupo</span></div>
        <p>Seguidores do perfil + comentários e curtidas da publicação escolhida. As três fontes estão preparadas para coleta.</p>
        <div className="profile-campaign-sources">{group.sources.map((source) => <div key={source.id}><SourceIcon kind={source.kind} size={17} /><span>{SOURCE_LABELS[source.kind]}</span><strong>{number(campaignMembers(state.candidates, [source]).length)}</strong><button className="text-link" onClick={() => onAudience(source.id)}>Ver perfis</button></div>)}</div>
        <a className="text-link" href={group.postUrl} target="_blank" rel="noreferrer">Publicação de referência<ExternalLink size={13} /></a>
        <button className="button primary" disabled={busy || state.runtime.mode === "running"} onClick={() => setCollecting(group.id)}>Coletar as {group.sources.length} fontes<ArrowRight size={16} /></button>
        <small>Role a lista para ampliar a captura. Os totais são acumulados e podem ser parciais.</small>
      </section>;
    })}</div> : null}
    {selected ? <CollectionSteps key={`${accountId}:${selected.id}:${selected.sources.map((s) => s.id).join(":")}`} group={selected} state={state} busy={busy} run={run} onClose={() => setCollecting(undefined)} /> : null}
  </>;
}
