/** Version of this UI bundle, independent of the connected native executor. */
export const ORBITA_UI_VERSION = "0.20.3";
