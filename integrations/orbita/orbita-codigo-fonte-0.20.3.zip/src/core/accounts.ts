import {
  applyCommand,
  audit,
  initialState,
  normalizeUsername,
  sourceKinds,
  recoverInterrupted,
  uid,
  validateAllDaySchedule,
  validateUnlimitedAttempts,
} from "./domain.ts";
import type {
  AccountCommand,
  AccountStore,
  AccountWorkspace,
  AppState,
  Command,
  ProfileSnapshot,
} from "./types.ts";
import { mergeInsightReports, validateInsightReport } from "./insights.ts";
import { checkedAccountType } from "./account-types.ts";
import { profilePhotoUrl } from "./photos.ts";
import { prepareKnownMarket } from "./market-seeds.ts";
import { pauseContinuous, validateContinuousState } from "./continuous.ts";
import {
  unfollowEligibility,
  validateProspectingCandidate,
  validateProspectingSettings,
} from "./prospecting.ts";
import {
  savePerformanceBenchmark,
  validatePerformanceBenchmark,
} from "./improvement.ts";
import {
  emptyMarket,
  marketProfile,
  mergeMarket,
  saveMarketExperiment,
  saveMarketReferences,
  validateMarket,
} from "./market.ts";
import {
  addChannelResult,
  mergeAcquisition,
  setFollowerOrigins,
  validateAcquisition,
} from "./acquisition.ts";
import {
  addRelationshipSnapshot,
  validateRelationships,
  mergeRelationships,
  setRelationshipProtection,
} from "./relationships.ts";

export const ACCOUNT_STORE_KEY = "orbita-accounts-v2";
function sanitizePhotos(account: AccountWorkspace): void {
  for (const entity of [account, ...account.data.candidates]) {
    if (!entity || typeof entity !== "object" || entity.avatarUrl === undefined)
      continue;
    const photo = profilePhotoUrl(entity.avatarUrl);
    if (photo) entity.avatarUrl = photo;
    else delete entity.avatarUrl;
  }
}
export const workspace = (
  store: AccountStore,
  id = store.activeId,
): AccountWorkspace => {
  const account = store.accounts.find((a) => a.id === id);
  if (!account)
    throw new Error(
      "Conta não encontrada. Selecione uma conta disponível no painel.",
    );
  return account;
};
export function initialStore(data = initialState()): AccountStore {
  const id = uid();
  const paused = recoverInterrupted(data);
  const username =
    (data.runtime.account && normalizeUsername(data.runtime.account)) ||
    undefined;
  paused.runtime.account = username;
  validateProspectingSettings(paused.settings);
  paused.settings.allDay = validateAllDaySchedule(paused.settings.allDay);
  paused.settings.unlimitedAttempts = validateUnlimitedAttempts(paused.settings.unlimitedAttempts);
  for (const candidate of paused.candidates)
    validateProspectingCandidate(candidate, username);
  validateContinuousState(paused, username);
  const account: AccountWorkspace = {
    id,
    username,
    label: username || "Meu espaço",
    createdAt: new Date().toISOString(),
    verifiedAt: undefined,
    snapshots: [],
    data: paused,
  };
  prepareKnownMarket(account);
  return {
    version: 2,
    activeId: id,
    accounts: [account],
  };
}
export function migrateStore(root: unknown, legacy?: unknown): AccountStore {
  if (
    root &&
    typeof root === "object" &&
    (root as AccountStore).version === 2
  ) {
    const store = root as AccountStore;
    if (
      !Array.isArray(store.accounts) ||
      !store.accounts.length ||
      store.accounts.length > 100 ||
      !store.accounts.some((a) => a?.id === store.activeId)
    )
      throw new Error(
        "O cadastro de contas está inválido. Preserve o backup antes de restaurar.",
      );
    const ids = new Set<string>(),
      names = new Set<string>();
    for (const account of store.accounts) {
      if (
        !account ||
        typeof account.id !== "string" ||
        !account.id ||
        ids.has(account.id) ||
        typeof account.label !== "string" ||
        !Array.isArray(account.snapshots) ||
        account.snapshots.length > 730 ||
        (account.insights !== undefined &&
          (!Array.isArray(account.insights) ||
            account.insights.length > 120)) ||
        account.data?.version !== 1 ||
        !Array.isArray(account.data.campaigns) ||
        !Array.isArray(account.data.candidates) ||
        !Array.isArray(account.data.audit) ||
        !account.data.runtime ||
        !account.data.settings ||
        !account.data.dailyAttempts
      )
        throw new Error(
          "Um espaço de conta está inválido. Os dados existentes foram preservados.",
        );
      if (account.data.campaigns.some((campaign) => !campaign || !sourceKinds.includes(campaign.kind)))
        throw new Error("Há uma fonte de campanha inválida. Os dados existentes foram preservados.");
      ids.add(account.id);
      sanitizePhotos(account);
      validateProspectingSettings(account.data.settings);
      account.data.settings.allDay = validateAllDaySchedule(account.data.settings.allDay);
      account.data.settings.unlimitedAttempts = validateUnlimitedAttempts(account.data.settings.unlimitedAttempts);
      for (const candidate of account.data.candidates)
        validateProspectingCandidate(candidate, account.username);
      validateContinuousState(account.data, account.username);
      checkedAccountType(account.accountType);
      if (account.market !== undefined)
        account.market = validateMarket(account.market, account.username || "");
      if (account.performanceBenchmark !== undefined)
        account.performanceBenchmark = validatePerformanceBenchmark(
          account.performanceBenchmark,
          account.username || "",
        );
      if (account.acquisition !== undefined)
        account.acquisition = validateAcquisition(account.acquisition, account);
      if (account.relationships !== undefined)
        account.relationships = validateRelationships(
          account.relationships,
          account.username || "",
        );
      const reportIds = new Set<string>();
      if (account.insights)
        account.insights = account.insights.map((report) => {
          const checked = validateInsightReport(
            report,
            account.username || "",
            report?.source,
            true,
          );
          if (reportIds.has(report.id))
            throw new Error(
              "Há relatórios duplicados no cadastro. Os dados existentes foram preservados.",
            );
          reportIds.add(report.id);
          return checked;
        });
      if (account.username !== undefined) {
        if (
          typeof account.username !== "string" ||
          normalizeUsername(account.username) !== account.username ||
          names.has(account.username)
        )
          throw new Error(
            "O cadastro contém perfis inválidos ou duplicados. Os dados existentes foram preservados.",
          );
        names.add(account.username);
      }
      prepareKnownMarket(account);
    }
    return store;
  }
  if (root !== undefined && root !== null)
    throw new Error(
      "Versão de cadastro não reconhecida. Os dados existentes foram preservados.",
    );
  if (
    legacy &&
    typeof legacy === "object" &&
    (legacy as AppState).version === 1
  )
    return initialStore(legacy as AppState);
  return initialStore();
}
export function pauseWorkspace(
  account: AccountWorkspace,
  message = "Troca de conta: fila pausada. Confira a sessão antes de iniciar.",
): void {
  account.data = pauseContinuous(account.data, message);
  account.data.runtime.mode = "paused";
  account.data.runtime.pauseReason = message;
  delete account.data.runtime.activeToken;
  delete account.data.runtime.activeCandidateId;
  delete account.data.runtime.activeAction;
  delete account.data.runtime.activeExpiresAt;
  delete account.data.runtime.nextRun;
}
export function assertCanSwitch(store: AccountStore): void {
  if (
    store.accounts.some((a) =>
      a.data.candidates.some((c) => c.stage === "attempting"),
    )
  )
    throw new Error(
      "Aguarde o resultado da ação em andamento antes de trocar de conta.",
    );
}
function select(store: AccountStore, id: string): void {
  prepareKnownMarket(workspace(store, id));
  if (store.activeId === id) return;
  assertCanSwitch(store);
  pauseWorkspace(workspace(store));
  store.activeId = id;
  pauseWorkspace(workspace(store));
}
export function accountCommand(
  original: AccountStore,
  command: AccountCommand,
): AccountStore {
  const store = structuredClone(original);
  switch (command.type) {
    case "QUEUE_UNFOLLOW": {
      const account = workspace(store);
      if (account.data.continuous?.mode === "running")
        throw new Error(
          "Pause a rotina contínua antes de montar uma fila manual de deixar de seguir.",
        );
      if (!account.username || command.account !== account.username)
        throw new Error("A revisão precisa pertencer à conta selecionada.");
      assertCanSwitch(store);
      if (
        !Array.isArray(command.ids) ||
        !command.ids.length ||
        command.ids.length > 30000 ||
        command.ids.some((id) => typeof id !== "string" || !id) ||
        new Set(command.ids).size !== command.ids.length
      )
        throw new Error(
          "Selecione perfis válidos e sem duplicação para a revisão.",
        );
      const selected = command.ids.map((id) =>
        account.data.candidates.find((c) => c.id === id),
      );
      const now = new Date();
      // Validate the whole selection before touching a candidate or the queue.
      for (const candidate of selected) {
        if (!candidate || candidate.stage !== "followed")
          throw new Error(
            "A seleção mudou. Revise os perfis antes de montar a fila de deixar de seguir.",
          );
        const checked = unfollowEligibility(account, candidate, now);
        if (!checked.eligible)
          throw new Error(`@${candidate.username}: ${checked.reasons[0]}`);
      }
      for (const candidate of selected) {
        delete candidate!.continuousSourceId;
        delete candidate!.continuousAuthorizationId;
        candidate!.stage = "queued";
        candidate!.queuedAction = "unfollow";
        candidate!.queueAccount = account.username;
      }
      pauseWorkspace(
        account,
        "Fila de deixar de seguir preparada. Confira a seleção e inicie quando estiver pronto.",
      );
      audit(
        account.data,
        "queue_unfollow",
        `${selected.length} perfis adicionados à fila de deixar de seguir.`,
      );
      return store;
    }
    case "SAVE_PERFORMANCE_BENCHMARK":
      savePerformanceBenchmark(workspace(store), command.data);
      return store;
    case "REMOVE_PERFORMANCE_BENCHMARK":
      delete workspace(store).performanceBenchmark;
      return store;
    case "SET_MARKET_PROFILE": {
      const account = workspace(store);
      if (
        !account.username ||
        (command.data as { account?: string })?.account !== account.username
      )
        throw new Error("O setor precisa pertencer à conta selecionada.");
      account.market ||= emptyMarket(account.username);
      account.market.profile = marketProfile(command.data);
      return store;
    }
    case "SAVE_MARKET_REFERENCES": {
      const account = workspace(store);
      account.market = saveMarketReferences(
        account.market,
        command.data,
        account.username || "",
      );
      return store;
    }
    case "SAVE_MARKET_EXPERIMENT": {
      const account = workspace(store);
      account.market = saveMarketExperiment(
        account.market,
        command.data,
        account.username || "",
      );
      return store;
    }
    case "ARCHIVE_MARKET_REFERENCE": {
      const ref = workspace(store).market?.references.find(
        (r) => r.id === command.id,
      );
      if (!ref || typeof command.archived !== "boolean")
        throw new Error("Referência não encontrada nesta conta.");
      ref.archived = command.archived;
      ref.updatedAt = new Date().toISOString();
      return store;
    }
    case "ADD_ACCOUNT": {
      const accountType = checkedAccountType(command.accountType);
      const username = normalizeUsername(command.username);
      if (!username)
        throw new Error(
          "Informe um @perfil válido para a conta que você gerencia.",
        );
      const existing = store.accounts.find((a) => a.username === username);
      if (existing) {
        select(store, existing.id);
        return store;
      }
      const draft = workspace(store);
      if (!draft.username && store.accounts.length === 1) {
        assertCanSwitch(store);
        draft.username = username;
        draft.label = command.label?.trim().slice(0, 100) || username;
        draft.accountType = accountType;
        draft.data.runtime.account = username;
        prepareKnownMarket(draft);
        pauseWorkspace(
          draft,
          `@${username} cadastrada. Conecte a sessão correspondente do Instagram.`,
        );
        return store;
      }
      if (store.accounts.length >= 100)
        throw new Error("Este espaço comporta até 100 contas cadastradas.");
      assertCanSwitch(store);
      const data = initialState();
      data.runtime.account = username;
      data.runtime.pauseReason = `@${username} cadastrada. Conecte a sessão correspondente do Instagram.`;
      const account: AccountWorkspace = {
        id: uid(),
        username,
        label: command.label?.trim().slice(0, 100) || username,
        accountType,
        createdAt: new Date().toISOString(),
        snapshots: [],
        data,
      };
      prepareKnownMarket(account);
      store.accounts.push(account);
      select(store, account.id);
      return store;
    }
    case "SELECT_ACCOUNT":
      select(store, command.id);
      return store;
    case "RENAME_ACCOUNT": {
      const account = workspace(store, command.id);
      if (!command.label.trim())
        throw new Error("Informe um nome para identificar esta conta.");
      account.label = command.label.trim().slice(0, 100);
      return store;
    }
    case "SET_ACCOUNT_TYPE": {
      if (command.accountType === undefined)
        throw new Error("Informe o tipo de conta que deseja salvar.");
      workspace(store, command.id).accountType = checkedAccountType(
        command.accountType,
      );
      return store;
    }
    case "RECORD_SNAPSHOT": {
      const account = workspace(store);
      if (!account.username)
        throw new Error(
          "Cadastre ou identifique uma conta antes de registrar as métricas.",
        );
      addSnapshot(account, { ...command, source: "manual" });
      return store;
    }
    case "RECORD_RELATIONSHIPS": {
      const account = workspace(store);
      if (!account.username)
        throw new Error("Cadastre uma conta antes de registrar suas relações.");
      account.relationships = addRelationshipSnapshot(
        account.relationships,
        command.data,
        account.username,
      );
      return store;
    }
    case "SET_FOLLOWER_ORIGIN":
    case "IMPORT_FOLLOWER_ORIGINS": {
      const account = workspace(store);
      account.acquisition = setFollowerOrigins(account, command.data);
      return store;
    }
    case "RECORD_CHANNEL_RESULT": {
      const account = workspace(store);
      account.acquisition = addChannelResult(account, command.data);
      return store;
    }
    case "REMOVE_CHANNEL_RESULT": {
      const account = workspace(store);
      if (!account.acquisition?.reports.some((r) => r.id === command.id))
        throw new Error("Resultado de canal não encontrado nesta conta.");
      account.acquisition.reports = account.acquisition.reports.filter(
        (r) => r.id !== command.id,
      );
      return store;
    }
    case "REMOVE_RELATIONSHIP_SNAPSHOT": {
      const account = workspace(store);
      if (!account.relationships?.snapshots.some((s) => s.id === command.id))
        throw new Error("Medição de relações não encontrada nesta conta.");
      account.relationships.snapshots = account.relationships.snapshots.filter(
        (s) => s.id !== command.id,
      );
      return store;
    }
    case "PROTECT_RELATIONSHIP":
    case "UNPROTECT_RELATIONSHIP": {
      const account = workspace(store);
      if (!account.username)
        throw new Error("Cadastre uma conta antes de proteger perfis.");
      account.relationships = setRelationshipProtection(
        account.relationships,
        command.username,
        command.type === "PROTECT_RELATIONSHIP",
        command.type === "PROTECT_RELATIONSHIP" ? command.reason : "other",
        command.type === "PROTECT_RELATIONSHIP" ? command.note : "",
      );
      return store;
    }
    case "IMPORT_INSIGHTS":
    case "RECORD_INSIGHTS": {
      mergeInsightReports(
        workspace(store),
        command.data,
        command.type === "RECORD_INSIGHTS" ? "manual" : "file",
      );
      return store;
    }
    case "REMOVE_INSIGHT_REPORT": {
      const account = workspace(store);
      if (!account.insights?.some((r) => r.id === command.id))
        throw new Error("Relatório não encontrado nesta conta.");
      account.insights = account.insights.filter((r) => r.id !== command.id);
      return store;
    }
  }
}
export function bindVerifiedAccount(
  original: AccountStore,
  id: string,
  detected: string,
  avatarUrl?: unknown,
): AccountStore {
  const store = structuredClone(original);
  const account = workspace(store, id);
  const username = normalizeUsername(detected);
  if (!username)
    throw new Error("Não foi possível identificar a conta da sessão.");
  if (store.activeId !== id)
    throw new Error(
      "A conta selecionada mudou durante a conexão. Tente novamente.",
    );
  if (account.username && account.username !== username)
    throw new Error(
      `A sessão do Instagram mostra @${username}. Troque para @${account.username} no Instagram e conecte novamente.`,
    );
  const existing = store.accounts.find(
    (a) => a.username === username && a.id !== id,
  );
  if (existing) {
    select(store, existing.id);
    existing.verifiedAt = new Date().toISOString();
    existing.data.runtime.account = username;
    existing.data.runtime.connectedAt = existing.verifiedAt;
  } else {
    account.username = username;
    if (account.label === "Meu espaço") account.label = username;
    account.verifiedAt = new Date().toISOString();
    account.data.runtime.account = username;
    account.data.runtime.connectedAt = account.verifiedAt;
    pauseWorkspace(
      account,
      `Sessão local de @${username} identificada. Confira o dashboard desta conta.`,
    );
  }
  const photo = profilePhotoUrl(avatarUrl);
  if (photo) workspace(store).avatarUrl = photo;
  store.sessionUsername = username;
  store.sessionCheckedAt = new Date().toISOString();
  return store;
}
export function addSnapshot(
  account: AccountWorkspace,
  value: {
    followers?: number;
    following?: number;
    posts?: number;
    at?: string;
    source: "instagram" | "manual";
  },
): void {
  const snapshot: ProfileSnapshot = {
    id: uid(),
    at: value.at || new Date().toISOString(),
    source: value.source,
  };
  if (
    !Number.isFinite(Date.parse(snapshot.at)) ||
    Date.parse(snapshot.at) > Date.now() + 60000
  )
    throw new Error("Informe uma data válida, sem medições no futuro.");
  let known = 0;
  for (const key of ["followers", "following", "posts"] as const) {
    const count = value[key];
    if (count !== undefined) {
      if (!Number.isSafeInteger(count) || count < 0)
        throw new Error(
          "As métricas devem ser números inteiros a partir de zero.",
        );
      snapshot[key] = count;
      known++;
    }
  }
  if (!known)
    throw new Error(
      "Nenhum contador exato foi lido. Você pode registrar uma medição manual identificada como manual.",
    );
  account.snapshots = [...account.snapshots, snapshot]
    .sort((a, b) => Date.parse(a.at) - Date.parse(b.at))
    .slice(-730);
}
export function applyScopedCommand(
  store: AccountStore,
  id: string,
  command: Command,
): AccountStore {
  const result = structuredClone(store);
  const account = workspace(result, id);
  if (result.activeId !== id)
    throw new Error(
      "A conta ativa mudou. Aguarde a atualização do painel e tente novamente.",
    );
  if (command.type === "RESTORE") {
    if (
      account.data.runtime.mode === "running" ||
      account.data.candidates.some((c) => c.stage === "attempting")
    )
      throw new Error(
        "Pause a fila e aguarde o resultado da ação atual antes de restaurar.",
      );
    const raw = command.data as {
      type?: string;
      account?: AccountWorkspace;
      runtime?: AppState["runtime"];
    };
    const backupAccount =
      raw?.type === "orbita-account-backup" ? raw.account : undefined;
    if (raw?.type === "orbita-account-backup" && !backupAccount?.data)
      throw new Error(
        "Backup da conta inválido: os dados do espaço estão ausentes.",
      );
    const input = backupAccount?.data || raw;
    const rawOwner =
      backupAccount?.username || (input as AppState)?.runtime?.account;
    const owner =
      typeof rawOwner === "string" ? normalizeUsername(rawOwner) : undefined;
    if (rawOwner && !owner) throw new Error("A conta do backup é inválida.");
    if (
      backupAccount?.username &&
      (input as AppState)?.runtime?.account &&
      normalizeUsername((input as AppState).runtime.account!) !== owner
    )
      throw new Error(
        "O backup contém contas diferentes no cadastro e nos dados.",
      );
    if (owner && account.username && owner !== account.username)
      throw new Error(
        `Esse backup pertence a @${owner}. Selecione a conta correspondente antes de restaurar.`,
      );
    if (backupAccount) {
      const savedType = checkedAccountType(backupAccount.accountType);
      if (checkedAccountType(account.accountType) === "unknown")
        account.accountType = savedType;
    }
    if (owner && !account.username) {
      if (result.accounts.some((a) => a.id !== id && a.username === owner))
        throw new Error(
          `@${owner} já está cadastrada. Selecione essa conta para restaurar.`,
        );
      account.username = owner;
      if (account.label === "Meu espaço")
        account.label = backupAccount?.label?.trim().slice(0, 100) || owner;
    }
    account.data = applyCommand(account.data, { type: "RESTORE", data: input });
    for (const candidate of account.data.candidates)
      validateProspectingCandidate(candidate, account.username, true);
    validateContinuousState(account.data, account.username, true);
    if (backupAccount) {
      const photo = owner && profilePhotoUrl(backupAccount.avatarUrl);
      if (photo) account.avatarUrl = photo;
      if (backupAccount.performanceBenchmark !== undefined) {
        const benchmark = validatePerformanceBenchmark(
          backupAccount.performanceBenchmark,
          account.username || "",
        );
        if (
          !account.performanceBenchmark ||
          benchmark.updatedAt > account.performanceBenchmark.updatedAt
        )
          account.performanceBenchmark = benchmark;
      }
      if (backupAccount.market !== undefined)
        account.market = mergeMarket(
          account.market,
          backupAccount.market,
          account.username || "",
        );
      if (backupAccount.acquisition !== undefined) {
        if (!owner)
          throw new Error(
            "O backup de origens precisa identificar a conta proprietária.",
          );
        account.acquisition = mergeAcquisition(
          account,
          backupAccount.acquisition,
        );
      }
      if (backupAccount.relationships !== undefined) {
        if (!owner)
          throw new Error(
            "O backup de relações precisa identificar a conta proprietária.",
          );
        account.relationships = mergeRelationships(
          account.relationships,
          backupAccount.relationships,
          account.username || "",
        );
      }
      if (backupAccount.insights !== undefined) {
        if (
          !Array.isArray(backupAccount.insights) ||
          backupAccount.insights.length > 120
        )
          throw new Error("Insights inválidos no backup.");
        for (const report of backupAccount.insights) {
          if (!["manual", "file"].includes(report?.source))
            throw new Error("Origem de Insights inválida no backup.");
          mergeInsightReports(account, report, report.source, true);
        }
      }
      if (!Array.isArray(backupAccount.snapshots))
        throw new Error("Histórico de métricas inválido no backup.");
      const fingerprint = (s: ProfileSnapshot) =>
        JSON.stringify([s.at, s.followers, s.following, s.posts, s.source]);
      const existing = new Set(account.snapshots.map(fingerprint));
      if (backupAccount.snapshots.length > 730)
        throw new Error("Histórico de métricas excede o limite do backup.");
      for (const snapshot of backupAccount.snapshots) {
        if (!snapshot || !["instagram", "manual"].includes(snapshot.source))
          throw new Error("Origem de medição inválida no backup.");
        if (!existing.has(fingerprint(snapshot))) {
          addSnapshot(account, snapshot);
          existing.add(fingerprint(snapshot));
        }
      }
    }
    delete account.verifiedAt;
    delete account.data.runtime.connectedAt;
  } else account.data = applyCommand(account.data, command);
  account.data.runtime.account = account.username;
  return result;
}
export function accountBackup(account: AccountWorkspace) {
  const copy = structuredClone(account);
  sanitizePhotos(copy);
  validateContinuousState(copy.data, copy.username, true);
  copy.data.runtime = {
    mode: "paused",
    account: copy.username,
    pauseReason: "Backup restaurado. Verifique novamente a sessão desta conta.",
  };
  delete copy.verifiedAt;
  return { version: 2, type: "orbita-account-backup", account: copy };
}
