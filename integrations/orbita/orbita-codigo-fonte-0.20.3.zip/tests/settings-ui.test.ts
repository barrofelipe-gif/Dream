import test from "node:test";
import assert from "node:assert/strict";
import { createRequire } from "node:module";
import { runInNewContext } from "node:vm";
import { fileURLToPath } from "node:url";
import { buildSync } from "esbuild";
import { act, createElement } from "react";
import { createRoot } from "react-dom/client";
import { JSDOM } from "jsdom";
import {
  accountBackup,
  initialStore,
  workspace,
} from "../src/core/accounts.ts";
import type { Command, SpecialCommand } from "../src/core/types.ts";

const compiled = buildSync({
  entryPoints: [fileURLToPath(new URL("../src/ui/App.tsx", import.meta.url))],
  bundle: true,
  platform: "node",
  format: "cjs",
  packages: "external",
  loader: { ".css": "empty" },
  write: false,
}).outputFiles[0].text;
const mod = { exports: {} as any };
const sandbox: Record<string, any> = {
  module: mod,
  exports: mod.exports,
  require: createRequire(import.meta.url),
  console,
  window: {},
  structuredClone,
  crypto,
  URL,
  setTimeout,
  clearTimeout,
  setInterval,
  clearInterval,
};
runInNewContext(compiled, sandbox);
const { SettingsPage } = mod.exports;

async function fixture(
  t: any,
  allDaySupported: boolean,
  existingAllDay?: boolean,
  unlimited: { supported?: boolean; saved?: boolean } = {},
) {
  const account = workspace(initialStore());
  account.username = "qa.settings";
  account.data.runtime.account = account.username;
  Object.assign(account.data.settings, {
    dailyLimit: 5,
    sessionLimit: 5,
    intervalMinutes: 5,
    startHour: "09:00",
    endHour: "21:00",
  });
  if (existingAllDay === undefined) delete account.data.settings.allDay;
  else account.data.settings.allDay = existingAllDay;
  if (unlimited.saved !== undefined)
    account.data.settings.unlimitedAttempts = unlimited.saved;
  const before = structuredClone(account);
  const commands: Array<Command | SpecialCommand> = [];
  const flashes: Array<{ message: string; error?: boolean }> = [];
  let refreshes = 0;
  const props = {
    account,
    state: account.data,
    busy: false,
    flash: (message: string, error?: boolean) => {
      flashes.push({ message, error });
    },
    onCycle: () => {},
    capability: {
      status: "supported",
      allDaySchedule: allDaySupported,
      unlimitedAttempts: unlimited.supported === true,
    },
    onRefreshCapability: () => {
      refreshes++;
    },
    run: async (command: Command | SpecialCommand) => {
      commands.push(command);
      return true;
    },
  };
  const dom = new JSDOM("<div id='root'></div>", {
    url: "https://qa.invalid/",
  });
  const originals = new Map<string, PropertyDescriptor | undefined>();
  for (const [key, value] of Object.entries({
    window: dom.window,
    document: dom.window.document,
    HTMLElement: dom.window.HTMLElement,
    Event: dom.window.Event,
    IS_REACT_ACT_ENVIRONMENT: true,
  })) {
    originals.set(key, Object.getOwnPropertyDescriptor(globalThis, key));
    Object.defineProperty(globalThis, key, {
      configurable: true,
      writable: true,
      value,
    });
    sandbox[key] = value;
  }
  const root = createRoot(dom.window.document.getElementById("root")!);
  dom.window.HTMLDialogElement.prototype.showModal = function () {
    this.setAttribute("open", "");
  };
  dom.window.HTMLDialogElement.prototype.close = function () {
    this.removeAttribute("open");
  };
  Object.assign(dom.window.HTMLElement.prototype, {
    attachEvent() {},
    detachEvent() {},
  });
  t.after(async () => {
    await act(async () => root.unmount());
    dom.window.close();
    for (const [key, descriptor] of originals) {
      if (descriptor) Object.defineProperty(globalThis, key, descriptor);
      else Reflect.deleteProperty(globalThis, key);
      delete sandbox[key];
    }
    sandbox.window = {};
  });
  await act(async () => root.render(createElement(SettingsPage, props)));
  const doc = dom.window.document;
  const toggle = doc.querySelector<HTMLInputElement>(
    ".settings-all-day:not(.settings-unlimited) input",
  )!;
  const times = [
    ...doc.querySelectorAll<HTMLInputElement>('input[type="time"]'),
  ];
  const save = [...doc.querySelectorAll<HTMLButtonElement>("button")].find(
    (button) => button.textContent?.trim() === "Salvar preferências",
  )!;
  const click = async (element: HTMLElement) => {
    await act(async () => element.click());
  };
  return {
    root,
    props,
    account,
    before,
    commands,
    flashes,
    doc,
    toggle,
    times,
    save,
    click,
    refreshes: () => refreshes,
    dom,
  };
}

test("legado sem allDay fica desmarcado; extensão sem flag não habilita 24h nem recarrega", async (t) => {
  const f = await fixture(t, false);
  assert.equal(f.toggle.checked, false);
  assert.equal(f.toggle.disabled, true);
  assert.deepEqual(
    f.times.map((input) => [input.value, input.disabled]),
    [
      ["09:00", false],
      ["21:00", false],
    ],
  );
  assert.match(
    f.doc.querySelector(".settings-all-day")!.textContent!,
    /0\.19\.1 ou posterior/,
  );
  await f.click(f.toggle);
  assert.equal(f.toggle.checked, false);
  const refresh = [...f.doc.querySelectorAll<HTMLButtonElement>("button")].find(
    (button) => button.textContent?.includes("Conferir recurso de 24 horas"),
  )!;
  await f.click(refresh);
  assert.equal(f.refreshes(), 1);
  assert.deepEqual(f.commands, []);
  await f.click(f.save);
  assert.equal(f.commands.length, 1);
  const command = JSON.parse(JSON.stringify(f.commands[0])) as Extract<
    Command,
    { type: "SETTINGS" }
  >;
  assert.equal(command.type, "SETTINGS");
  assert.equal(command.settings.allDay, undefined);
  assert.deepEqual(f.account, f.before);
});

test("24h autorizado preserva 09–21 e limites 5/5/5 ao salvar", async (t) => {
  const f = await fixture(t, true);
  await f.click(f.toggle);
  assert.equal(f.toggle.checked, true);
  assert.deepEqual(
    f.times.map((input) => [input.value, input.disabled]),
    [
      ["09:00", true],
      ["21:00", true],
    ],
  );
  assert.equal(f.commands.length, 0);
  await f.click(f.save);
  assert.equal(f.commands.length, 1);
  const command = JSON.parse(JSON.stringify(f.commands[0])) as Extract<
    Command,
    { type: "SETTINGS" }
  >;
  assert.equal(command.type, "SETTINGS");
  assert.equal(command.settings.allDay, true);
  assert.deepEqual(
    [command.settings.startHour, command.settings.endHour],
    ["09:00", "21:00"],
  );
  assert.deepEqual(
    [
      command.settings.dailyLimit,
      command.settings.sessionLimit,
      command.settings.intervalMinutes,
    ],
    [5, 5, 5],
  );
  assert.match(
    f.doc.querySelector(".settings-all-day")!.textContent!,
    /ações e consultas de fontes também durante a madrugada/,
  );
  assert.deepEqual(f.account, f.before);
});

test("desligar 24h reabilita os mesmos horários, sem alterar teto ou intervalo", async (t) => {
  const f = await fixture(t, true, true);
  assert.ok(f.times.every((input) => input.disabled));
  await f.click(f.toggle);
  assert.equal(f.toggle.checked, false);
  assert.deepEqual(
    f.times.map((input) => [input.value, input.disabled]),
    [
      ["09:00", false],
      ["21:00", false],
    ],
  );
  await f.click(f.save);
  const command = JSON.parse(JSON.stringify(f.commands[0])) as Extract<
    Command,
    { type: "SETTINGS" }
  >;
  assert.equal(command.settings.allDay, false);
  assert.deepEqual(
    [
      command.settings.dailyLimit,
      command.settings.sessionLimit,
      command.settings.intervalMinutes,
    ],
    [5, 5, 5],
  );
  assert.deepEqual(f.account, f.before);
});

test("allDay salvo com capability ausente fica pendente e submit não envia 24h", async (t) => {
  const f = await fixture(t, false, true);
  assert.equal(f.toggle.checked, true);
  assert.equal(f.toggle.disabled, false);
  assert.equal(f.save.disabled, true);
  assert.match(
    f.doc.querySelector(".settings-all-day")!.textContent!,
    /permanece pendente/,
  );
  await act(async () =>
    f.doc
      .querySelector("form")!
      .dispatchEvent(
        new f.dom.window.Event("submit", { bubbles: true, cancelable: true }),
      ),
  );
  assert.deepEqual(f.commands, []);
  assert.deepEqual(f.account, f.before);
});

test("sem capability pode desligar 24h e salvar horários guardados, mas não religar", async (t) => {
  const f = await fixture(t, false, true);
  assert.equal(f.toggle.disabled, false);
  await f.click(f.toggle);
  assert.equal(f.toggle.checked, false);
  assert.equal(f.toggle.disabled, true);
  assert.equal(f.save.disabled, false);
  assert.deepEqual(
    f.times.map((input) => [input.value, input.disabled]),
    [
      ["09:00", false],
      ["21:00", false],
    ],
  );
  await f.click(f.save);
  assert.equal(f.commands.length, 1);
  const command = f.commands[0] as Extract<Command, { type: "SETTINGS" }>;
  assert.equal(command.settings.allDay, false);
  assert.deepEqual(
    [
      command.settings.dailyLimit,
      command.settings.sessionLimit,
      command.settings.intervalMinutes,
    ],
    [5, 5, 5],
  );
});

async function selectBackup(
  f: Awaited<ReturnType<typeof fixture>>,
  name: string,
  read: () => Promise<string>,
) {
  const input = f.doc.querySelector<HTMLInputElement>('input[type="file"]')!;
  Object.defineProperty(input, "files", {
    configurable: true,
    value: [{ name, size: 100, text: read }],
  });
  await act(async () => {
    input.dispatchEvent(new f.dom.window.Event("change", { bubbles: true }));
  });
}

test("backup mantém conteúdo e nome do último arquivo e só restaura após confirmação", async (t) => {
  const f = await fixture(t, true);
  let resolve!: (value: string) => void;
  const slow = new Promise<string>((yes) => {
    resolve = yes;
  });
  await selectBackup(f, "antigo.json", () => slow);
  const latest = accountBackup({ ...f.account, label: "Arquivo B fictício" });
  await selectBackup(f, "ultimo.json", async () => JSON.stringify(latest));
  await act(async () => {
    resolve(
      JSON.stringify(
        accountBackup({ ...f.account, label: "Arquivo A fictício" }),
      ),
    );
    await slow;
  });
  assert.match(
    f.doc.querySelector("dialog .modal-heading")!.textContent!,
    /ultimo\.json/,
  );
  assert.deepEqual(f.commands, []);
  const confirm = [
    ...f.doc.querySelectorAll<HTMLButtonElement>("dialog button"),
  ].find((b) => b.textContent?.trim() === "Substituir e restaurar")!;
  await f.click(confirm);
  assert.equal(f.commands.length, 1);
  const command = f.commands[0] as Extract<Command, { type: "RESTORE" }>;
  assert.equal(
    (command.data as ReturnType<typeof accountBackup>).account.label,
    "Arquivo B fictício",
  );
});

test("erro de leitura do backup atual informa falha e não libera restauração", async (t) => {
  const f = await fixture(t, true);
  await selectBackup(f, "falha.json", async () => {
    throw Error("Dispositivo indisponível");
  });
  assert.equal(f.doc.querySelector("dialog"), null);
  assert.ok(
    f.flashes.some((item) => item.error && /ler|leitura/i.test(item.message)),
  );
  assert.deepEqual(f.commands, []);
});

test("erro atrasado de backup antigo não altera a confirmação do arquivo atual", async (t) => {
  const f = await fixture(t, true);
  let reject!: (error: Error) => void;
  const slow = new Promise<string>((_yes, no) => {
    reject = no;
  });
  await selectBackup(f, "antigo.json", () => slow);
  await selectBackup(f, "ultimo.json", async () =>
    JSON.stringify(accountBackup(f.account)),
  );
  await act(async () => {
    reject(Error("Erro antigo"));
    await slow.catch(() => {});
  });
  assert.match(
    f.doc.querySelector("dialog .modal-heading")!.textContent!,
    /ultimo\.json/,
  );
  assert.deepEqual(f.flashes, []);
  assert.deepEqual(f.commands, []);
});

test("perder capability após o toggle bloqueia salvar a configuração 24h", async (t) => {
  const f = await fixture(t, true);
  await f.click(f.toggle);
  await act(async () =>
    f.root.render(
      createElement(SettingsPage, {
        ...f.props,
        capability: { status: "supported", allDaySchedule: false },
      }),
    ),
  );
  assert.equal(f.toggle.checked, true);
  assert.equal(f.save.disabled, true);
  await f.click(f.save);
  assert.deepEqual(f.commands, []);
});

test("sem teto exige capability explícita e não ativa nada ao habilitar; valores 5/5/5 ficam guardados", async (t) => {
  const f = await fixture(t, true, true, { supported: true });
  const toggle = f.doc.querySelector<HTMLInputElement>(
    ".settings-unlimited input",
  )!;
  const numbers = [
    ...f.doc.querySelectorAll<HTMLInputElement>('input[type="number"]'),
  ];
  assert.equal(toggle.checked, false);
  assert.equal(toggle.disabled, false);
  await f.click(toggle);
  assert.equal(toggle.checked, true);
  assert.deepEqual(
    numbers.map((i) => [i.value, i.disabled]),
    [
      ["5", true],
      ["5", false],
      ["5", true],
    ],
  );
  assert.deepEqual(f.commands, []);
  await f.click(f.save);
  const command = f.commands[0] as Extract<Command, { type: "SETTINGS" }>;
  assert.equal(command.type, "SETTINGS");
  assert.equal(command.settings.unlimitedAttempts, true);
  assert.equal(command.settings.allDay, true);
  assert.deepEqual(
    [
      command.settings.dailyLimit,
      command.settings.sessionLimit,
      command.settings.intervalMinutes,
    ],
    [5, 5, 5],
  );
  assert.deepEqual(
    [command.settings.startHour, command.settings.endHour],
    ["09:00", "21:00"],
  );
  assert.match(
    f.doc.querySelector(".draft-pace")!.textContent!,
    /sem teto diário ou por lote/,
  );
  assert.doesNotMatch(
    f.doc.querySelector(".draft-pace")!.textContent!,
    /até 5 tentativas|lotes de 5/,
  );
  assert.deepEqual(f.account, f.before);
});

test("sem suporte não liga sem teto; flag salva fica pendente mas pode desligar e restaurar tetos", async (t) => {
  const f = await fixture(t, true, false, { saved: true });
  const toggle = f.doc.querySelector<HTMLInputElement>(
    ".settings-unlimited input",
  )!;
  assert.equal(toggle.checked, true);
  assert.equal(toggle.disabled, false);
  assert.equal(f.save.disabled, true);
  assert.match(
    f.doc.querySelector(".settings-unlimited")!.textContent!,
    /pendente na extensão/,
  );
  await act(async () =>
    f.doc
      .querySelector("form")!
      .dispatchEvent(
        new f.dom.window.Event("submit", { bubbles: true, cancelable: true }),
      ),
  );
  assert.deepEqual(f.commands, []);
  await f.click(toggle);
  assert.equal(toggle.checked, false);
  assert.equal(toggle.disabled, true);
  assert.equal(f.save.disabled, false);
  assert.ok(
    [...f.doc.querySelectorAll<HTMLInputElement>('input[type="number"]')].every(
      (i) => !i.disabled,
    ),
  );
  await f.click(toggle);
  assert.equal(toggle.checked, false);
  await f.click(f.save);
  const command = f.commands[0] as Extract<Command, { type: "SETTINGS" }>;
  assert.equal(command.settings.unlimitedAttempts, false);
  assert.deepEqual(
    [
      command.settings.dailyLimit,
      command.settings.sessionLimit,
      command.settings.intervalMinutes,
    ],
    [5, 5, 5],
  );
});

test("perder capability com rascunho sem teto impede salvar até desligar", async (t) => {
  const f = await fixture(t, true, false, { supported: true });
  const toggle = f.doc.querySelector<HTMLInputElement>(
    ".settings-unlimited input",
  )!;
  await f.click(toggle);
  await act(async () =>
    f.root.render(
      createElement(SettingsPage, {
        ...f.props,
        capability: { ...f.props.capability, unlimitedAttempts: false },
      }),
    ),
  );
  assert.equal(toggle.checked, true);
  assert.equal(toggle.disabled, false);
  assert.equal(f.save.disabled, true);
  await f.click(f.save);
  assert.deepEqual(f.commands, []);
  await f.click(toggle);
  assert.equal(f.save.disabled, false);
});

test("começo guiado desliga sem teto no rascunho e não regrava flag antiga ao salvar", async (t) => {
  const f = await fixture(t, true, false, { supported: true, saved: true });
  const starter = [...f.doc.querySelectorAll<HTMLButtonElement>("button")].find(
    (b) => b.textContent?.includes("Usar começo guiado"),
  )!;
  await f.click(starter);
  assert.equal(f.commands[0].type, "APPLY_STARTER");
  assert.equal(
    f.doc.querySelector<HTMLInputElement>(".settings-unlimited input")!.checked,
    false,
  );
  await f.click(f.save);
  const command = f.commands[1] as Extract<Command, { type: "SETTINGS" }>;
  assert.equal(command.settings.unlimitedAttempts, false);
  assert.deepEqual(
    [
      command.settings.dailyLimit,
      command.settings.sessionLimit,
      command.settings.intervalMinutes,
    ],
    [5, 5, 15],
  );
});

test("backup com sem teto exige suporte antes da restauração confirmada", async (t) => {
  const f = await fixture(t, true);
  const backup = accountBackup(f.account);
  backup.account.data.settings.unlimitedAttempts = true;
  await selectBackup(f, "sem-teto.json", async () => JSON.stringify(backup));
  const confirm = [
    ...f.doc.querySelectorAll<HTMLButtonElement>("dialog button"),
  ].find((b) => b.textContent?.trim() === "Substituir e restaurar")!;
  assert.equal(confirm.disabled, true);
  assert.match(
    f.doc.querySelector("dialog")!.textContent!,
    /extensão não confirmou suporte/,
  );
  await f.click(confirm);
  assert.deepEqual(f.commands, []);
  await act(async () =>
    f.root.render(
      createElement(SettingsPage, {
        ...f.props,
        capability: { ...f.props.capability, unlimitedAttempts: true },
      }),
    ),
  );
  assert.equal(confirm.disabled, false);
  await f.click(confirm);
  assert.equal(f.commands.length, 1);
  assert.equal((f.commands[0] as Command).type, "RESTORE");
});
