import { attemptsToday, insideWindow } from "../core/domain.ts";
import { continuousCandidateEligibility, continuousDayKey, continuousPreparationRetry, nextContinuousCheck, nextContinuousUnfollow } from "../core/continuous.ts";
import { budgetStopReason, intervalReadyAt } from "../core/safety.ts";
import type { AccountWorkspace, Settings } from "../core/types.ts";

export const continuousAlarmName = (id: string) => `orbita-continuous:${id}`;

/** Uses the same local clock/window as the existing queue, including overnight windows. */
export function nextWindowAt(settings: Settings, at = Date.now()): number {
  const now = new Date(at);
  if (insideWindow(now, settings)) return at;
  const [hour, minute] = settings.startHour.split(":").map(Number);
  for (let offset = 0; offset < 3; offset++) {
    const start = new Date(at);
    start.setDate(start.getDate() + offset);
    start.setHours(hour, minute, 0, 0);
    if (start.getTime() > at) return start.getTime();
  }
  throw new Error("Não foi possível calcular a próxima janela da rotina.");
}

export function nextDayWindowAt(settings: Settings, at = Date.now()): number {
  const next = new Date(at);
  next.setDate(next.getDate() + 1);
  next.setHours(0, 0, 0, 0);
  return nextWindowAt(settings, next.getTime());
}

export function continuousWakeAt(account: AccountWorkspace, at = Date.now()): number | undefined {
  const state = account.data;
  if (state.continuous?.mode !== "running" || state.continuous.account !== account.username ||
      state.settings.hasPendingWarning || state.candidates.some((c) => c.stage === "uncertain" || c.stage === "attempting")) return;
  if (!insideWindow(new Date(at), state.settings)) return nextWindowAt(state.settings, at);
  // Wake the worker to renew yesterday's session before using that session's
  // budget to postpone a valid queue. Scheduling itself never resets counters.
  if (state.continuous.dayKey !== continuousDayKey(new Date(at))) return at + 1000;
  const now = new Date(at);
  const sourceAt = nextContinuousCheck(account, now);
  const queued = state.candidates.some((candidate) => continuousCandidateEligibility(account, candidate).eligible);
  const dueAt = queued ? at : nextContinuousUnfollow(account, now)?.dueAt;
  const actionAt = dueAt === undefined ? undefined : Math.max(
    dueAt,
    budgetStopReason(state, attemptsToday(state, now))
      ? nextDayWindowAt(state.settings, at)
      : Math.max(at, intervalReadyAt(state), state.runtime.nextRun || 0,
        Date.parse(continuousPreparationRetry(account)?.retryAt || "") || 0),
  );
  const next = Math.min(sourceAt ?? Infinity, actionAt ?? Infinity);
  return Number.isFinite(next) ? Math.max(at + 1000, nextWindowAt(state.settings, Math.max(at, next))) : undefined;
}
