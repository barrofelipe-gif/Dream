import { useEffect, useMemo, useState } from "react";
import {
  ArrowRight,
  CalendarClock,
  Check,
  ChevronDown,
  Clock3,
  ListOrdered,
  Settings2,
  ShieldCheck,
  UsersRound,
} from "lucide-react";
import type {
  AccountCommand,
  AccountWorkspace,
  Command,
  Settings,
  SpecialCommand,
} from "../core/types.ts";
import { prospectingReview } from "../core/prospecting.ts";
import type { ProspectingRow } from "../core/prospecting.ts";
import { PROTECTION_REASONS } from "../core/relationships.ts";
import { SOURCE_LABELS } from "../core/types.ts";
import { isExtension } from "../bridge.ts";
import { Avatar, date, Empty, Field } from "./components.tsx";
import "./prospecting.css";

type Run = (
  command: Command | SpecialCommand,
  success?: string,
) => Promise<boolean>;
type RunAccount = (
  command: AccountCommand,
  success?: string,
) => Promise<boolean>;
const STATUS: Record<ProspectingRow["status"], string> = {
  waiting: "Aguardando prazo",
  ready: "Elegível para revisão",
  queued: "Na fila para deixar de seguir",
  attempting: "Ação em andamento",
  unfollowed: "Deixamos de seguir",
  blocked: "Precisa de conferência",
};
const dateOrDash = (value?: string) => (value ? date(value) : "—");
const fingerprint = (row: ProspectingRow, policy?: Settings["reviewPolicy"]) =>
  JSON.stringify([
    policy,
    row.cycleId,
    row.status,
    row.canQueue,
    row.queuedAction,
    row.dueAt,
    row.reciprocity.status,
    row.reciprocity.snapshotId,
    row.reciprocity.measuredAt,
    row.reciprocity.followersComplete,
    row.protected,
    row.excluded,
  ]);
const protectionLabel = (row: ProspectingRow) =>
  row.protectionReason &&
  Object.hasOwn(PROTECTION_REASONS, row.protectionReason)
    ? PROTECTION_REASONS[
        row.protectionReason as keyof typeof PROTECTION_REASONS
      ]
    : "Proteção ativa";

function ReciprocityEvidence({ row }: { row: ProspectingRow }) {
  return (
    <div className="cycle-reciprocity">
      <span className={`cycle-reciprocity-label ${row.reciprocity.status}`}>
        {row.reciprocity.status === "yes"
          ? "Consta como seguidor"
          : row.reciprocity.status === "no"
            ? "Ausente da lista informada"
            : "Não comprovada"}
      </span>
      {row.reciprocity.measuredAt ? (
        <small>
          {dateOrDash(row.reciprocity.measuredAt)} ·{" "}
          {row.reciprocity.followersComplete === true
            ? "lista declarada completa"
            : row.reciprocity.followersComplete === false
              ? "lista parcial"
              : "completude não informada"}
        </small>
      ) : (
        <small>Sem medição disponível da sua conta.</small>
      )}
    </div>
  );
}

export function CycleEvidence({
  row,
  onReview,
}: {
  row: ProspectingRow;
  onReview: () => void;
}) {
  return (
    <section
      className="cycle-detail"
      aria-label="Ciclo de prospecção deste perfil"
    >
      <div className="cycle-section-heading">
        <h3>
          <CalendarClock size={17} aria-hidden="true" /> Ciclo de prospecção
        </h3>
        <span className={`cycle-status ${row.status}`}>
          {STATUS[row.status]}
        </span>
      </div>
      <dl className="cycle-evidence-grid">
        <div>
          <dt>Seguindo confirmado</dt>
          <dd>
            {dateOrDash(row.confirmedFollowAt)}
            <small>
              {row.confirmedFollowSource === "orbita"
                ? "Ação registrada pela Órbita"
                : row.confirmedFollowSource === "restored"
                  ? "Histórico restaurado; não habilita a ação"
                  : "Sem confirmação registrada"}
            </small>
          </dd>
        </div>
        <div>
          <dt>Revisão a partir de</dt>
          <dd>
            {dateOrDash(row.dueAt)}
            <small>
              {row.ageDays === undefined
                ? "Sem idade confiável do ciclo"
                : `${row.ageDays} ${row.ageDays === 1 ? "dia desde a confirmação" : "dias desde a confirmação"}`}
            </small>
          </dd>
        </div>
      </dl>
      <ReciprocityEvidence row={row} />
      {row.protected ? (
        <p className="cycle-protected">
          <ShieldCheck size={15} aria-hidden="true" /> Protegido ·{" "}
          {protectionLabel(row)}
        </p>
      ) : null}
      {row.status !== "unfollowed" && row.reasons.length ? (
        <ul className="cycle-reasons">
          {row.reasons.map((reason) => (
            <li key={reason}>{reason}</li>
          ))}
        </ul>
      ) : null}
      <button type="button" className="text-link" onClick={onReview}>
        Abrir revisão por prazo <ArrowRight size={15} aria-hidden="true" />
      </button>
    </section>
  );
}

function CyclePolicy({
  settings,
  accountName,
  automaticActive,
  automaticSupported,
  run,
  runAccount,
  busy,
}: {
  settings: Settings;
  accountName?: string;
  automaticActive: boolean;
  automaticSupported: boolean;
  run: Run;
  runAccount: RunAccount;
  busy: boolean;
}) {
  const configured =
    settings.reviewAfterDays !== undefined &&
    settings.reviewPolicy !== undefined;
  const [enabled, setEnabled] = useState(configured);
  const [automatic, setAutomatic] = useState(automaticActive);
  const [days, setDays] = useState(
    settings.reviewAfterDays === undefined
      ? ""
      : String(settings.reviewAfterDays),
  );
  const [policy, setPolicy] = useState<Settings["reviewPolicy"] | "">(
    settings.reviewPolicy || "",
  );
  return (
    <details className="panel cycle-policy" open={!configured}>
      <summary>
        <Settings2 size={18} aria-hidden="true" />
        <span>Configurar revisão por prazo</span>
        <small>
          {configured
            ? `${settings.reviewAfterDays} dias · ${automaticActive ? "deixar de seguir automático" : "revisão manual"}`
            : "Desativada · escolha prazo e política"}
        </small>
        <ChevronDown
          className="cycle-policy-chevron"
          size={17}
          aria-hidden="true"
        />
      </summary>
      <form
        onSubmit={(event) => {
          event.preventDefault();
          if (automatic || automaticActive) {
            if (!automaticSupported || !accountName) return;
            void runAccount(
              {
                type: "CONFIGURE_AUTO_UNFOLLOW",
                account: accountName,
                enabled: enabled && automatic,
                days: enabled ? Number(days) : undefined,
                policy: enabled ? (policy as Settings["reviewPolicy"]) : undefined,
              },
              enabled && automatic
                ? "Ciclo automático configurado nesta conta."
                : "Ciclo automático desativado nesta conta.",
            );
            return;
          }
          void run(
            {
              type: "SETTINGS",
              settings: {
                ...settings,
                reviewAfterDays: enabled ? Number(days) : undefined,
                reviewPolicy: enabled
                  ? (policy as Settings["reviewPolicy"])
                  : undefined,
              },
            },
            enabled
              ? "Revisão por prazo configurada nesta conta. Nenhuma ação foi iniciada."
              : "Revisão por prazo desativada nesta conta.",
          );
        }}
      >
        <label className="check-label">
          <input
            type="checkbox"
            checked={enabled}
            disabled={busy}
            onChange={(event) => setEnabled(event.target.checked)}
          />{" "}
          Ativar a revisão por prazo nesta conta
        </label>
        <div className="cycle-policy-fields">
          <Field
            label="Revisar após quantos dias?"
            hint="Contados a partir da confirmação de Seguindo pela Órbita. De 1 a 365 dias."
          >
            <input
              type="number"
              min="1"
              max="365"
              step="1"
              required={enabled}
              disabled={busy || !enabled}
              value={days}
              onChange={(event) => setDays(event.target.value)}
            />
          </Field>
          <Field label="Política de reciprocidade">
            <select
              value={policy}
              required={enabled}
              disabled={busy || !enabled}
              onChange={(event) =>
                setPolicy(event.target.value as Settings["reviewPolicy"] | "")
              }
            >
              <option value="">Escolha uma política</option>
              <option value="preserve_followers">
                Preservar quem segue de volta
              </option>
              <option value="review_all">Revisar todos</option>
            </select>
          </Field>
        </div>
        <div className="cycle-presets" aria-label="Atalhos de prazo">
          {[7, 14, 30].map((value) => (
            <button
              type="button"
              key={value}
              className={`button secondary small ${days === String(value) ? "selected" : ""}`}
              aria-pressed={days === String(value)}
              disabled={busy || !enabled}
              onClick={() => setDays(String(value))}
            >
              {value} dias
            </button>
          ))}
        </div>
        <p className="body-copy">
          {policy === "preserve_followers"
            ? "Quem consta como seguidor é preservado. Sem medição suficiente para comprovar ausência após o prazo, o perfil fica fora da fila."
            : policy === "review_all"
              ? "Revisar todos permite aprovar também perfis que seguem você de volta ou cuja reciprocidade é desconhecida. Proteções e exclusões continuam valendo."
              : "Escolha explicitamente o prazo e a política. Nenhuma opção é ativada por padrão."}
        </p>
        {isExtension && accountName ? (
          <label className="check-label">
            <input
              type="checkbox"
              checked={enabled && automatic}
              disabled={busy || !enabled || !automaticSupported}
              onChange={(event) => setAutomatic(event.target.checked)}
            />{" "}
            Deixar de seguir automaticamente após o prazo
          </label>
        ) : null}
        <p className="cycle-policy-hint">
          {enabled && automatic
            ? "A rotina deixa de seguir os perfis elegíveis após o prazo, usando o intervalo da conta. Perfis protegidos e excluídos ficam de fora."
            : "No ciclo manual, você escolhe os perfis e inicia o lote na Fila de ações."}
        </p>
        {isExtension && accountName && !automaticSupported ? (
          <p className="cycle-policy-hint">Para configurar o ciclo automático, conecte a extensão atualizada.</p>
        ) : null}
        <button type="submit" className="button primary" disabled={busy || ((automatic || automaticActive) && !automaticSupported)}>
          <Check size={16} aria-hidden="true" /> Salvar configuração do ciclo
        </button>
      </form>
    </details>
  );
}

export function CyclePage({
  account,
  run,
  runAccount,
  busy,
  automaticUnfollowSupported = false,
  onQueue,
  onRelationships,
  onDetail,
  onHelp,
}: {
  account: AccountWorkspace;
  run: Run;
  runAccount: RunAccount;
  busy: boolean;
  automaticUnfollowSupported?: boolean;
  onQueue: () => void;
  onRelationships: () => void;
  onDetail: (id: string) => void;
  onHelp: () => void;
}) {
  const [clock, setClock] = useState(() => Date.now());
  useEffect(() => {
    const update = () => {
      if (document.visibilityState === "visible") setClock(Date.now());
    };
    const timer = setInterval(update, 60000);
    document.addEventListener("visibilitychange", update);
    return () => {
      clearInterval(timer);
      document.removeEventListener("visibilitychange", update);
    };
  }, []);
  const review = useMemo(
    () => prospectingReview(account, new Date(clock)),
    [account, clock],
  );
  const [query, setQuery] = useState(""),
    [source, setSource] = useState(""),
    [status, setStatus] = useState("all"),
    [page, setPage] = useState(1);
  const [selected, setSelected] = useState<Map<string, string>>(
    () => new Map(),
  );
  const stamp = (row: ProspectingRow) => fingerprint(row, review.reviewPolicy);
  const eligibleSignature = JSON.stringify(
    review.rows
      .filter((row) => row.canQueue)
      .map((row) => [row.cycleId, stamp(row)]),
  );
  useEffect(() => {
    const eligible = new Map<string, string>(JSON.parse(eligibleSignature));
    setSelected((prior) => {
      const next = new Map(
        [...prior].filter(([id, stamp]) => eligible.get(id) === stamp),
      );
      return next.size === prior.size ? prior : next;
    });
  }, [eligibleSignature]);
  const sources = useMemo(() => {
    const unique = new Map<string, string>();
    for (const row of review.rows)
      for (const item of row.sources)
        if (!unique.has(item.campaignId))
          unique.set(
            item.campaignId,
            item.name ||
              item.target ||
              (item.kind ? SOURCE_LABELS[item.kind] : "Fonte sem nome"),
          );
    return [...unique].sort((a, b) => a[1].localeCompare(b[1], "pt-BR"));
  }, [review.rows]);
  const normalizedQuery = query.trim().replace(/^@/, "").toLowerCase();
  const filtered = review.rows.filter(
    (row) =>
      (!normalizedQuery || row.username.includes(normalizedQuery)) &&
      (!source || row.sources.some((item) => item.campaignId === source)) &&
      (status === "all" || row.status === status),
  );
  const pages = Math.max(1, Math.ceil(filtered.length / 25)),
    currentPage = Math.min(page, pages),
    visible = filtered.slice((currentPage - 1) * 25, currentPage * 25);
  const selectedRows = review.rows.filter(
    (row) => row.canQueue && selected.get(row.cycleId) === stamp(row),
  );
  const filteredIds = new Set(filtered.map((row) => row.cycleId));
  const selectedOutsideFilters = selectedRows.some(
    (row) => !filteredIds.has(row.cycleId),
  );
  const visibleEligible = visible.filter((row) => row.canQueue),
    allVisible =
      visibleEligible.length > 0 &&
      visibleEligible.every((row) => selected.get(row.cycleId) === stamp(row));
  const toggle = (row: ProspectingRow) =>
    setSelected((prior) => {
      const next = new Map(prior);
      if (next.get(row.cycleId) === stamp(row)) next.delete(row.cycleId);
      else if (row.canQueue) next.set(row.cycleId, stamp(row));
      return next;
    });
  const automaticActive = !!account.data.automaticUnfollowId;
  const automaticRunning = automaticActive && account.data.continuous?.mode === "running";
  const policyKey = `${account.id}:${account.data.settings.reviewAfterDays ?? ""}:${account.data.settings.reviewPolicy ?? ""}:${automaticActive}`;
  return (
    <section className="cycle-page" aria-label="Ciclo de prospecção da conta">
      <div className="cycle-heading">
        <div>
          <span className="eyebrow">
            CICLO DE @{account.username || "SUA CONTA"}
          </span>
          <h2>Revise cada conexão no tempo certo</h2>
          <p>
            {automaticActive
              ? account.data.continuous?.mode === "running"
                ? "Ciclo automático ativo. Os perfis elegíveis vencidos entram no ritmo da rotina contínua."
                : "Ciclo automático configurado. Ele funciona quando a rotina contínua está ativa."
              : "Confirmação de seguir, prazo e reciprocidade reunidos por perfil. Aprove os perfis para montar um lote manual."}
          </p>
        </div>
        <button type="button" className="button secondary" onClick={onQueue}>
          <ListOrdered size={16} aria-hidden="true" /> Ver fila de ações
        </button>
      </div>
      <div className="cycle-summary">
        <div>
          <span>Perfis no quadro</span>
          <strong>{review.counts.total}</strong>
        </div>
        <div>
          <span>Aguardando prazo</span>
          <strong>
            {review.rows.filter((row) => row.status === "waiting").length}
          </strong>
        </div>
        <div>
          <span>Elegíveis para revisão</span>
          <strong>{review.counts.canQueue}</strong>
        </div>
        <div>
          <span>Na fila para deixar de seguir</span>
          <strong>
            {
              review.rows.filter(
                (row) => row.status === "queued" || row.status === "attempting",
              ).length
            }
          </strong>
        </div>
        <div>
          <span>Reciprocidade não comprovada</span>
          <strong>{review.counts.unknown}</strong>
        </div>
        <div>
          <span>Perfis protegidos</span>
          <strong>{review.counts.protected}</strong>
        </div>
      </div>
      <CyclePolicy
        key={policyKey}
        settings={account.data.settings}
        accountName={account.username}
        automaticActive={automaticActive}
        automaticSupported={automaticUnfollowSupported}
        run={run}
        runAccount={runAccount}
        busy={busy}
      />
      {!isExtension ? (
        <div className="notice cycle-mode">
          <div>
            <strong>Revisão no modo manual</strong>
            <p>
              Você pode organizar a configuração e consultar os dados. Para
              montar e executar a fila real, conecte a extensão e confira a
              sessão do Instagram.
            </p>
          </div>
          <button
            type="button"
            className="button secondary small"
            onClick={onHelp}
          >
            Instalação e ajuda
          </button>
        </div>
      ) : null}
      <div className="cycle-evidence-note">
        <UsersRound size={20} aria-hidden="true" />
        <p>
          A reciprocidade usa as medições da sua conta em{" "}
          <strong>Seguidores e seguidos</strong>. A presença pode ser observada
          em uma lista parcial; a ausência exige lista completa medida após o
          prazo.
        </p>
        <button type="button" className="text-link" onClick={onRelationships}>
          Medições e protegidos <ArrowRight size={15} aria-hidden="true" />
        </button>
      </div>
      <section className="panel cycle-list" aria-labelledby="cycle-list-title">
        <div className="panel-heading">
          <div>
            <h3 id="cycle-list-title">Revisão por prazo</h3>
            <p>
              {automaticRunning
                ? "Acompanhe os prazos. A rotina cuida dos perfis elegíveis."
                : "Horários deste computador. Selecione somente os perfis que deseja revisar para deixar de seguir."}
            </p>
          </div>
          <span className="count-pill">{filtered.length}</span>
        </div>
        <div className="cycle-filters">
          <Field label="Buscar @perfil">
            <input
              type="search"
              value={query}
              onChange={(event) => {
                setQuery(event.target.value);
                setPage(1);
              }}
              placeholder="@perfil"
            />
          </Field>
          <Field label="Fonte da prospecção">
            <select
              value={source}
              onChange={(event) => {
                setSource(event.target.value);
                setPage(1);
              }}
            >
              <option value="">Todas as fontes</option>
              {sources.map(([id, name]) => (
                <option key={id} value={id}>
                  {name}
                </option>
              ))}
            </select>
          </Field>
          <Field label="Estado do ciclo">
            <select
              value={status}
              onChange={(event) => {
                setStatus(event.target.value);
                setPage(1);
              }}
            >
              <option value="all">Todos os estados</option>
              {Object.entries(STATUS).map(([value, label]) => (
                <option key={value} value={value}>
                  {label}
                </option>
              ))}
            </select>
          </Field>
        </div>
        <div className="cycle-selection">
          <span>
            {selectedRows.length}{" "}
            {selectedRows.length === 1
              ? "perfil selecionado"
              : "perfis selecionados"}
            {selectedOutsideFilters ? " · inclui perfis fora dos filtros" : ""}
          </span>
          <button
            type="button"
            className="text-link"
            disabled={!selected.size || busy}
            onClick={() => setSelected(new Map())}
          >
            Limpar seleção
          </button>
          <button
            type="button"
            className="button primary"
            disabled={
              busy || automaticRunning || !isExtension || !account.username || !selectedRows.length
            }
            onClick={async () => {
              if (
                await runAccount(
                  {
                    type: "QUEUE_UNFOLLOW",
                    account: account.username || "",
                    ids: selectedRows.map((row) => row.candidateId),
                  },
                  "Perfis adicionados à fila para deixar de seguir. Nenhuma ação foi iniciada.",
                )
              )
                setSelected(new Map());
            }}
          >
            Adicionar à fila de deixar de seguir{" "}
            <ArrowRight size={16} aria-hidden="true" />
          </button>
        </div>
        {visible.length ? (
          <>
            <div className="table-scroll">
              <table className="cycle-table">
                <thead>
                  <tr>
                    <th className="check-cell">
                      <input
                        type="checkbox"
                        aria-label="Selecionar elegíveis desta página"
                        checked={allVisible}
                        disabled={busy || automaticRunning || !visibleEligible.length}
                        onChange={(event) =>
                          setSelected((prior) => {
                            const next = new Map(prior);
                            for (const row of visibleEligible)
                              if (event.target.checked)
                                next.set(row.cycleId, stamp(row));
                              else next.delete(row.cycleId);
                            return next;
                          })
                        }
                      />
                    </th>
                    <th>PERFIL / FONTES</th>
                    <th>SEGUINDO CONFIRMADO</th>
                    <th>REVISÃO A PARTIR DE</th>
                    <th>RECIPROCIDADE OBSERVADA</th>
                    <th>ESTADO / CONFERÊNCIA</th>
                  </tr>
                </thead>
                <tbody>
                  {visible.map((row) => (
                    <tr
                      key={row.cycleId}
                      className={
                        selected.get(row.cycleId) === stamp(row) && row.canQueue
                          ? "selected-row"
                          : ""
                      }
                    >
                      <td>
                        <input
                          type="checkbox"
                          aria-label={`Selecionar ${row.username} para deixar de seguir`}
                          checked={
                            row.canQueue &&
                            selected.get(row.cycleId) === stamp(row)
                          }
                          disabled={busy || automaticRunning || !row.canQueue}
                          onChange={() => toggle(row)}
                        />
                      </td>
                      <td>
                        <button
                          type="button"
                          className="profile-cell"
                          onClick={() => onDetail(row.candidateId)}
                        >
                          <Avatar username={row.username} />
                          <strong>@{row.username}</strong>
                        </button>
                        <div className="cycle-sources">
                          {row.sources.length ? (
                            row.sources.slice(0, 2).map((item, index) => (
                              <span
                                key={`${item.campaignId}:${index}`}
                                title={`${item.name || "Fonte"}${item.target ? ` · ${item.target}` : ""}`}
                              >
                                {item.name ||
                                  (item.kind
                                    ? SOURCE_LABELS[item.kind]
                                    : "Origem informada")}
                                {item.archived ? " · arquivada" : ""}
                              </span>
                            ))
                          ) : (
                            <small>Origem não informada</small>
                          )}
                          {row.sources.length > 2 ? (
                            <small>
                              +{row.sources.length - 2} outras fontes no detalhe
                            </small>
                          ) : null}
                        </div>
                      </td>
                      <td>
                        <span>{dateOrDash(row.confirmedFollowAt)}</span>
                        <small className="cycle-cell-note">
                          {row.confirmedFollowSource === "orbita"
                            ? "Ação da Órbita"
                            : row.confirmedFollowSource === "restored"
                              ? "Histórico restaurado"
                              : "Sem confirmação registrada"}
                        </small>
                      </td>
                      <td>
                        <span>{dateOrDash(row.dueAt)}</span>
                        <small className="cycle-cell-note">
                          {row.ageDays === undefined
                            ? "Sem idade confiável"
                            : `${row.ageDays} ${row.ageDays === 1 ? "dia desde a confirmação" : "dias desde a confirmação"}`}
                        </small>
                      </td>
                      <td>
                        <ReciprocityEvidence row={row} />
                      </td>
                      <td>
                        <span className={`cycle-status ${row.status}`}>
                          {STATUS[row.status]}
                        </span>
                        {row.protected ? (
                          <p className="cycle-protected">
                            <ShieldCheck size={14} aria-hidden="true" />
                            {protectionLabel(row)}
                          </p>
                        ) : null}
                        {row.status !== "unfollowed" && row.reasons.length ? (
                          <ul className="cycle-reasons">
                            {row.reasons.map((reason) => (
                              <li key={reason}>{reason}</li>
                            ))}
                          </ul>
                        ) : null}
                      </td>
                    </tr>
                  ))}
                </tbody>
              </table>
            </div>
            <div className="pagination">
              <span>
                {(currentPage - 1) * 25 + 1}–
                {Math.min(currentPage * 25, filtered.length)} de{" "}
                {filtered.length} perfis
              </span>
              <div>
                <button
                  type="button"
                  className="button secondary small"
                  disabled={currentPage <= 1}
                  onClick={() => setPage(currentPage - 1)}
                >
                  Anterior
                </button>
                <button
                  type="button"
                  className="button secondary small"
                  disabled={currentPage >= pages}
                  onClick={() => setPage(currentPage + 1)}
                >
                  Próxima
                </button>
              </div>
            </div>
          </>
        ) : (
          <Empty
            icon={<CalendarClock size={28} />}
            title={
              review.rows.length
                ? "Nenhum ciclo corresponde aos filtros"
                : "O ciclo começa com um seguir confirmado"
            }
            text={
              review.rows.length
                ? "Ajuste a busca, a fonte ou o estado para consultar outros registros."
                : "Coletar um perfil, já segui-lo ou enviar uma solicitação não inicia este prazo. A contagem usa uma ação de seguir confirmada pela Órbita nesta conta."
            }
          />
        )}
      </section>
      <p className="cycle-footer">
        <Clock3 size={16} aria-hidden="true" /> O quadro acompanha ações e
        prazos. Não estima novos clientes ou vendas. Perfis protegidos e
        excluídos ficam fora da fila.
      </p>
    </section>
  );
}
