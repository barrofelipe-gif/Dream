import test from "node:test";
import assert from "node:assert/strict";
import { ACCOUNT_STORE_KEY, initialStore, workspace } from "../src/core/accounts.ts";
import { applyCommand, attemptsToday, sourceUrl } from "../src/core/domain.ts";
import { configureContinuousSource } from "../src/core/continuous.ts";
import { PROBLEMS_KEY } from "../src/core/problems.ts";
import { continuousWakeAt, nextDayWindowAt, nextWindowAt } from "../src/extension/continuous-schedule.ts";
import type { AccountStore } from "../src/core/types.ts";

test("janela contínua calcula espera diurna, noturna e virada diária sem mexer no ritmo", () => {
  const settings = workspace(initialStore()).data.settings;
  settings.startHour = "09:00"; settings.endHour = "21:00";
  const morning = new Date(2026, 10, 3, 9).getTime();
  assert.equal(nextWindowAt(settings, new Date(2026, 10, 3, 8).getTime()), morning);
  assert.equal(nextWindowAt(settings, morning), morning);
  assert.equal(nextDayWindowAt(settings, morning), new Date(2026, 10, 4, 9).getTime());
  settings.startHour = "21:00"; settings.endHour = "09:00";
  assert.equal(nextWindowAt(settings, new Date(2026, 10, 3, 10).getTime()), new Date(2026, 10, 3, 21).getTime());
  assert.equal(nextDayWindowAt(settings, new Date(2026, 10, 3, 23).getTime()), new Date(2026, 10, 4, 0).getTime());
});

test("horário de 24 horas ignora a janela guardada e renova o dia à meia-noite", () => {
  const settings = workspace(initialStore()).data.settings;
  Object.assign(settings, { allDay: true, startHour: "09:00", endHour: "21:00" });
  for (const hour of [0, 2, 8, 21, 23]) {
    const at = new Date(2026, 10, 3, hour, 59).getTime();
    assert.equal(nextWindowAt(settings, at), at);
  }
  assert.equal(nextDayWindowAt(settings, new Date(2026, 10, 3, 23, 59).getTime()), new Date(2026, 10, 4, 0).getTime());
  assert.equal(settings.startHour, "09:00"); assert.equal(settings.endHour, "21:00");
});

test("worker contínuo conecta leitura, fila, alarmes, pausa e recuperação sem ações reais", async (t) => {
  const originals = new Map(["chrome", "addEventListener"].map((key) => [key, Object.getOwnPropertyDescriptor(globalThis, key)]));
  const saved: Record<string, any> = {}, tabs = new Map<number, any>(), alarms = new Map<string, any>();
  let listener: Function | undefined, onAlarm: Function | undefined, onStartup: Function | undefined;
  let nextTab = 100, steps = 0, follows = 0, unfollows = 0, authorizedUnfollows = 0;
  let protectBeforeUnfollow = false;
  let stepMode: "normal" | "unavailable" | "hold" | "mismatch" = "normal";
  let releaseStep: ((value: any) => void) | undefined;
  let activateTabAfterStatus: number | undefined;
  let statusOverride: ((status: any, id: number) => any) | undefined;
  let preparationFailure: "status" | "inject" | "create" | "update" | undefined;
  let heldPreparation: ((value: any) => void) | undefined;
  let followTimeout = false;
  let sourceUpdateId: number | undefined;
  const injections: any[] = [];
  const updatedTabs: number[] = [];
  const sender = { id: "fixture-extension", url: "chrome-extension://fixture-extension/index.html" };
  const root = () => saved[ACCOUNT_STORE_KEY] as AccountStore;
  const account = () => workspace(root());
  const state = () => account().data;
  const problemCount = (operation: string) => (saved[PROBLEMS_KEY]?.entries || [])
    .filter((entry: any) => entry.scope === "qa-workspace" && entry.operation === operation)
    .reduce((sum: number, entry: any) => sum + entry.count, 0);
  const route = (message: any, actor = sender): Promise<any> => new Promise((resolve) => listener!(message, actor, resolve));
  const command = (cmd: object) => route({ type: "COMMAND", workspaceId: "qa-workspace", command: cmd });
  const accountAction = (cmd: object) => route({ type: "ACCOUNT_COMMAND", expectedActiveId: "qa-workspace", command: cmd });
  const flush = async () => { for (let i = 0; i < 120; i++) await Promise.resolve(); };
  const pumpUntil = async (check: () => boolean, limit = 12000) => {
    for (let elapsed = 0; elapsed <= limit; elapsed += 100) {
      await flush(); if (check()) { await flush(); return; }
      t.mock.timers.tick(100);
    }
    assert.fail("A jornada do worker não concluiu dentro do relógio simulado.");
  };
  const fire = () => { alarms.delete("orbita-continuous:qa-workspace"); onAlarm!({ name: "orbita-continuous:qa-workspace" }); };
  const resultFor = (message: any) => ({ ok: true, data: { account: "qa.owner", sourceId: message.campaign.id, runId: message.runId, url: sourceUrl(message.campaign.kind, message.campaign.target), at: new Date().toISOString(), complete: false, phase: "end", candidates: [{ username: message.campaign.id === "source-a" ? "qa.new" : "qa.second" }] } });
  const fixture = (two = false) => {
    const store = initialStore(), item = workspace(store);
    item.id = store.activeId = "qa-workspace"; item.username = "qa.owner"; item.verifiedAt = new Date().toISOString();
    store.sessionUsername = "qa.owner";
    item.data.runtime.account = "qa.owner"; item.data.runtime.connectedAt = item.verifiedAt;
    item.data.settings = { ...item.data.settings, dailyLimit: 5, sessionLimit: 5, intervalMinutes: 5, startHour: "00:00", endHour: "23:59" };
    item.data = applyCommand(item.data, { type: "CREATE_CAMPAIGN", name: "Fonte A fictícia", kind: "followers", target: "qa.reference" });
    item.data.campaigns[0].id = "source-a";
    item.data = configureContinuousSource(item.data, { type: "CONFIGURE_CONTINUOUS_SOURCE", id: "source-a", enabled: true, autoFollow: true, pollMinutes: 15, reviewed: true });
    if (two) {
      item.data = applyCommand(item.data, { type: "CREATE_CAMPAIGN", name: "Fonte B fictícia", kind: "commenters", target: "https://www.instagram.com/p/QApost/" });
      item.data.campaigns[0].id = "source-b";
      item.data = configureContinuousSource(item.data, { type: "CONFIGURE_CONTINUOUS_SOURCE", id: "source-b", enabled: true, autoFollow: true, pollMinutes: 15, reviewed: true });
    }
    saved[ACCOUNT_STORE_KEY] = structuredClone(store);
    tabs.clear(); alarms.clear(); steps = follows = unfollows = authorizedUnfollows = 0; stepMode = "normal"; releaseStep = undefined;
    protectBeforeUnfollow = false;
    activateTabAfterStatus = undefined; updatedTabs.length = 0;
    statusOverride = undefined;
    preparationFailure = undefined; heldPreparation = undefined; followTimeout = false; injections.length = 0; sourceUpdateId = undefined;
    return store;
  };
  const start = async (ids = ["source-a"]) => {
    const reply = await command({ type: "START_CONTINUOUS", sourceIds: ids, reviewed: true, unlimitedAttemptsReviewed: state().settings.unlimitedAttempts === true });
    assert.equal(reply.ok, true, reply.error);
    assert.ok(alarms.has("orbita-continuous:qa-workspace"));
  };
  try {
    t.mock.timers.enable({ apis: ["Date", "setTimeout"], now: new Date(2026, 10, 3, 12).getTime() });
    Object.defineProperty(globalThis, "chrome", { configurable: true, value: {
      runtime: { id: "fixture-extension", getURL: (path: string) => `chrome-extension://fixture-extension/${path}`, getManifest: () => ({ version: "0.19.0" }), onMessage: { addListener(fn: Function) { listener = fn; } }, onStartup: { addListener(fn: Function) { onStartup = fn; } } },
      storage: { local: { async get(keys: string | string[]) { return Object.fromEntries((Array.isArray(keys) ? keys : [keys]).map((key) => [key, structuredClone(saved[key])])); }, async set(values: any) { Object.assign(saved, structuredClone(values)); }, async setAccessLevel() {} } },
      action: { onClicked: { addListener() {} } },
      alarms: { async create(name: string, info: any) { alarms.set(name, info); }, async clear(name: string) { return alarms.delete(name); }, async get(name: string) { return alarms.get(name); }, onAlarm: { addListener(fn: Function) { onAlarm = fn; } } },
      scripting: { async executeScript(options: any) {
        injections.push(options);
        if (preparationFailure === "inject") return new Promise((resolve) => { heldPreparation = resolve; });
        assert.fail("O fixture já tem receptor; não reinjetar para repetir uma etapa.");
      } },
      tabs: {
        async get(id: number) { if (!tabs.has(id)) throw new Error("No tab with id"); return { ...tabs.get(id), status: "complete" }; },
        async create(options: any) { const tab = { id: ++nextTab, ...options }; tabs.set(tab.id, tab); if (preparationFailure === "create" && options.url.endsWith("/qa.new/")) return new Promise((resolve) => { heldPreparation = resolve; }); return tab; },
        async update(id: number, options: any) { updatedTabs.push(id); Object.assign(tabs.get(id), options); if (sourceUpdateId === id || (preparationFailure === "update" && options.url.endsWith("/qa.new/"))) return new Promise((resolve) => { heldPreparation = resolve; }); return tabs.get(id); },
        async sendMessage(id: number, message: any) {
          if (message.type === "STATUS") {
            if (tabs.get(id).url.endsWith("/qa.new/")) {
              if (preparationFailure === "inject") throw new Error("Could not establish connection. Receiving end does not exist.");
              if (preparationFailure === "status") return new Promise((resolve) => { heldPreparation = resolve; });
            }
            const status = { account: "qa.owner", restricted: null, url: tabs.get(id).url, hasDraft: tabs.get(id).hasDraft || false };
            if (activateTabAfterStatus === id) { Object.assign(tabs.get(id), { active: true, hasDraft: true }); activateTabAfterStatus = undefined; }
            return statusOverride ? statusOverride(status, id) : status;
          }
          if (message.type === "STEP_CONTINUOUS_SOURCE") {
            steps++;
            if (stepMode === "hold") return new Promise((resolve) => { releaseStep = resolve; });
            if (stepMode === "mismatch") return { ok: false, accountMismatch: true, error: "Conta trocada no fixture" };
            if (stepMode === "unavailable" && message.campaign.id === "source-a") return { ok: false, unavailable: true, error: "Fonte indisponível no fixture" };
            return resultFor(message);
          }
          if (message.type === "FOLLOW") {
            follows++;
            const authorized = await route({ type: "AUTHORIZE_CLICK", action: "follow", username: message.username, expectedAccount: message.expectedAccount, token: message.token }, { id: "fixture-extension", tab: { id }, url: tabs.get(id).url } as any);
            assert.equal(authorized.ok, true, "a autorização deve continuar vinculada à fonte, conta e candidato");
            if (followTimeout) return new Promise(() => {});
            return { action: "follow", stage: "followed", message: "Seguindo no fixture", clickSent: true };
          }
          if (message.type === "UNFOLLOW") {
            unfollows++;
            if (protectBeforeUnfollow)
              assert.equal((await accountAction({ type: "PROTECT_RELATIONSHIP", username: message.username, reason: "other", note: "Protegido durante o preparo" })).ok, true);
            const authorized = await route({
              type: "AUTHORIZE_CLICK", action: "unfollow", username: message.username,
              expectedAccount: message.expectedAccount, token: message.token,
            }, { id: "fixture-extension", tab: { id }, url: tabs.get(id).url } as any);
            if (!authorized.ok)
              return { action: "unfollow", stage: "failed", message: "Autorização negada no fixture", stop: true };
            authorizedUnfollows++;
            return { action: "unfollow", stage: "unfollowed", message: "Seguir no fixture", clickSent: true };
          }
          assert.fail(`Mensagem inesperada no fixture: ${message.type}`);
        },
      },
    } });
    Object.defineProperty(globalThis, "addEventListener", { configurable: true, value() {} });
    const modulePath = "../src/extension/background.ts?continuous-worker-fixture";
    await import(modulePath);
    const capabilities = (await route({ type: "GET_STATE" })).capabilities;
    assert.equal(capabilities.continuousSources, true);
    assert.equal(capabilities.allDaySchedule, true);
    assert.equal(capabilities.unlimitedAttempts, true);
    assert.equal(capabilities.autoRecovery, true);
    assert.equal(capabilities.automaticUnfollow, true);

    const week = 7 * 86400000;
    const autoConfig = { type: "CONFIGURE_AUTO_UNFOLLOW", account: "qa.owner", enabled: true, days: 7, policy: "review_all" };
    const confirmedCandidate = (username: string, at: number) => {
      const stamp = new Date(at).toISOString();
      return {
        id: username, username, name: "", note: "", sources: [],
        stage: "followed" as const, createdAt: stamp, updatedAt: stamp,
        confirmedFollowAt: stamp, confirmedFollowAccount: "qa.owner",
        confirmedFollowSource: "orbita" as const,
      };
    };
    const deferFixtureSource = () => {
      state().campaigns[0].continuous!.nextCheckAt = new Date(Date.now() + 900000).toISOString();
    };

    await t.test("ciclo automático acorda no sétimo dia, ignora protegidos e mantém a rotina", async () => {
      fixture();
      state().settings.allDay = true;
      const due = Date.now() + 60000;
      state().candidates.push(
        confirmedCandidate("qa.new", due - week),
        confirmedCandidate("qa.protected", Date.now() - week - 60000),
        { ...confirmedCandidate("qa.requested", Date.now() - week), stage: "requested", confirmedFollowAt: undefined, confirmedFollowAccount: undefined, confirmedFollowSource: undefined },
        { ...confirmedCandidate("qa.restored", Date.now() - week), confirmedFollowSource: "restored" },
      );
      assert.equal((await accountAction({ type: "PROTECT_RELATIONSHIP", username: "qa.protected", reason: "other", note: "Teste" })).ok, true);
      await start();
      deferFixtureSource();
      const lease = state().continuous!.authorizationId;
      assert.equal((await accountAction({ ...autoConfig, account: "qa.other" })).ok, false);
      assert.equal(state().automaticUnfollowId, undefined);
      assert.equal((await accountAction(autoConfig)).ok, true);
      assert.equal(state().continuous!.authorizationId, lease);
      assert.equal(continuousWakeAt(account(), Date.now()), due);
      t.mock.timers.tick(59000); fire(); await flush();
      assert.equal(unfollows, 0);
      t.mock.timers.tick(1000); fire();
      await pumpUntil(() => state().candidates[0].stage === "unfollowed");
      assert.equal(unfollows, 1); assert.equal(authorizedUnfollows, 1);
      assert.equal(state().candidates[1].stage, "followed");
      assert.equal(state().candidates[2].stage, "requested");
      assert.equal(state().candidates[3].stage, "followed");
      assert.equal(state().continuous?.mode, "running");
      assert.equal(attemptsToday(state()), 1);
      t.mock.timers.tick(300000); fire(); await flush();
      assert.equal(unfollows, 1);
    });

    await t.test("proteção adicionada antes da autorização impede o clique automático", async () => {
      fixture(); state().settings.allDay = true;
      state().candidates.push(confirmedCandidate("qa.new", Date.now() - week));
      await start(); deferFixtureSource();
      assert.equal((await accountAction(autoConfig)).ok, true);
      protectBeforeUnfollow = true;
      fire();
      await pumpUntil(() => state().continuous?.mode === "paused");
      assert.equal(unfollows, 1); assert.equal(authorizedUnfollows, 0);
      assert.equal(state().candidates[0].stage, "failed");
    });

    await t.test("timeout pré-clique preserva o ciclo de deixar de seguir e retoma uma única vez", async () => {
      fixture(); state().settings.allDay = true;
      state().candidates.push(confirmedCandidate("qa.new", Date.now() - week));
      await start(); deferFixtureSource();
      assert.equal((await accountAction(autoConfig)).ok, true);
      preparationFailure = "status";
      fire();
      await pumpUntil(() => state().continuous?.preparationRetry?.action === "unfollow", 6000);
      assert.equal(unfollows, 0); assert.equal(attemptsToday(state()), 0);
      const retryAt = Date.parse(state().continuous!.preparationRetry!.retryAt);
      preparationFailure = undefined;
      t.mock.timers.tick(retryAt - Date.now()); fire();
      await pumpUntil(() => state().candidates[0].stage === "unfollowed");
      assert.equal(unfollows, 1); assert.equal(authorizedUnfollows, 1);
      assert.equal(state().continuous?.preparationRetry, undefined);
      assert.equal(state().continuous?.mode, "running");
    });

    const prepareRecovery = async (failure: "status" | "inject" | "create" | "update") => {
      fixture(); state().settings.unlimitedAttempts = true;
      state().runtime.sessionAttempts = 7; state().runtime.sessionStartedAt = new Date().toISOString();
      state().dailyAttempts[`qa.owner|${new Date().toDateString()}`] = 7;
      state().lastAttempts = { "@qa.owner": new Date(Date.now() - 600000).toISOString() };
      await start(); fire();
      await pumpUntil(() => state().candidates.length === 1 && alarms.has("orbita-continuous:qa-workspace"));
      if (failure === "update") {
        const id = ++nextTab; tabs.set(id, { id, url: "https://www.instagram.com/qa.old/", active: false }); state().runtime.workerTabId = id;
      }
      preparationFailure = failure; t.mock.timers.tick(31000); fire();
      await pumpUntil(() => !!state().continuous?.preparationRetry, 22000);
    };

    for (const failure of ["inject", "status", "create", "update"] as const) {
      await t.test(`timeout pré-reserva ${failure} persiste espera e retoma em aba nova sem repetir ação atrasada`, async () => {
        await prepareRecovery(failure);
        const retry = structuredClone(state().continuous!.preparationRetry!), authorization = state().continuous!.authorizationId;
        const last = structuredClone(state().lastAttempts), oldTabs = [...tabs.keys()];
        assert.equal(state().continuous?.mode, "running"); assert.equal(state().runtime.mode, "paused");
        assert.equal(retry.failures, 1); assert.equal(Date.parse(retry.retryAt) - Date.now(), 60000);
        assert.equal(state().candidates[0].stage, "queued"); assert.equal(follows, 0);
        assert.equal(attemptsToday(state()), 7); assert.equal(state().runtime.sessionAttempts, 7);
        assert.equal(state().runtime.activeToken, undefined); assert.equal(state().runtime.workerTabId, undefined);
        if (failure === "inject") { assert.equal(injections.length, 1); assert.equal(injections[0].injectImmediately, true); }
        heldPreparation?.({ id: oldTabs.at(-1), account: "qa.owner", restricted: null, url: "https://www.instagram.com/qa.new/", status: "complete" });
        await flush(); assert.deepEqual(state().continuous?.preparationRetry, retry); assert.equal(follows, 0);
        const restartPath = new URL(`../src/extension/account-store.ts?retry-${failure}`, import.meta.url).href;
        await (await import(restartPath)).storeReady;
        assert.equal(alarms.get("orbita-continuous:qa-workspace").when, Date.parse(retry.retryAt));
        assert.deepEqual(state().continuous?.preparationRetry, retry);
        preparationFailure = undefined;
        t.mock.timers.tick(Date.parse(retry.retryAt) - Date.now() - 1000); fire(); await flush(); assert.equal(follows, 0);
        t.mock.timers.tick(1000); fire();
        await pumpUntil(() => state().candidates[0].stage === "followed" && alarms.has("orbita-continuous:qa-workspace"));
        assert.equal(follows, 1); assert.equal(attemptsToday(state()), 8); assert.equal(state().runtime.sessionAttempts, 8);
        assert.equal(state().continuous?.authorizationId, authorization); assert.equal(state().continuous?.preparationRetry, undefined);
        assert.ok(!oldTabs.includes(state().runtime.workerTabId!)); for (const id of oldTabs) assert.ok(tabs.has(id));
        assert.ok(Date.parse(state().lastAttempts!["@qa.owner"]) >= Date.parse(last!["@qa.owner"]));
        await command({ type: "PAUSE_CONTINUOUS" });
      });
    }

    await t.test("backoff cresce até quinze minutos e leitura de fonte não zera falhas de preparo", async () => {
      await prepareRecovery("status");
      for (let failures = 1; failures <= 5; failures++) {
        const retry = state().continuous!.preparationRetry!;
        assert.equal(retry.failures, failures);
        assert.equal(Date.parse(retry.retryAt) - Date.now(), [60000, 180000, 600000, 900000, 900000][failures - 1]);
        assert.equal(follows, 0); assert.equal(attemptsToday(state()), 7);
        if (failures === 4) {
          state().campaigns[0].continuous!.nextCheckAt = new Date(Date.now()).toISOString();
          const before = structuredClone(retry), beforeSteps = steps;
          fire(); await pumpUntil(() => steps > beforeSteps && alarms.has("orbita-continuous:qa-workspace"));
          assert.deepEqual(state().continuous!.preparationRetry, before);
        }
        if (failures < 5) {
          t.mock.timers.tick(Date.parse(state().continuous!.preparationRetry!.retryAt) - Date.now()); fire();
          await pumpUntil(() => state().continuous?.preparationRetry?.failures === failures + 1, 22000);
        }
      }
      await command({ type: "PAUSE_CONTINUOUS" });
      assert.equal(state().continuous?.preparationRetry, undefined); fire(); await flush(); assert.equal(follows, 0);
    });

    await t.test("timeout após reserva e entrega FOLLOW permanece incerto e nunca recupera automático", async () => {
      fixture(); await start(); fire(); await pumpUntil(() => state().candidates.length === 1 && alarms.has("orbita-continuous:qa-workspace"));
      followTimeout = true; t.mock.timers.tick(31000); fire();
      await pumpUntil(() => state().candidates[0].stage === "uncertain" && state().continuous?.mode === "paused", 15000);
      assert.equal(follows, 1); assert.equal(attemptsToday(state()), 1); assert.equal(state().continuous?.preparationRetry, undefined);
      fire(); await flush(); assert.equal(follows, 1); assert.equal(alarms.has("orbita-continuous:qa-workspace"), false);
    });

    await t.test("STEP vencido agenda leitura parcial nova sem revogar fonte ou importar retorno atrasado", async () => {
      fixture(); stepMode = "hold"; await start(); fire(); await pumpUntil(() => !!releaseStep);
      const runId = state().campaigns[0].continuous!.runId, auth = state().continuous!.authorizationId;
      await pumpUntil(() => !!state().campaigns[0].continuous?.readRetry, 5000);
      const cfg = state().campaigns[0].continuous!;
      assert.equal(cfg.status, "ready"); assert.equal(cfg.enabled, true); assert.equal(cfg.runId, undefined);
      assert.equal(cfg.readRetry?.failures, 1); assert.equal(state().continuous?.authorizationId, auth);
      assert.equal(state().candidates.length, 0); assert.equal(follows, 0);
      releaseStep!({ ok: true, data: { ...resultFor({ campaign: state().campaigns[0], runId }).data, candidates: [{ username: "qa.late" }] } });
      await flush(); assert.equal(state().candidates.length, 0);
      const retryAt = Date.parse(cfg.nextCheckAt!); stepMode = "normal";
      t.mock.timers.tick(retryAt - Date.now()); fire();
      await pumpUntil(() => state().candidates.length === 1 && alarms.has("orbita-continuous:qa-workspace"));
      assert.equal(state().candidates[0].username, "qa.new"); assert.equal(state().campaigns[0].continuous?.readRetry, undefined);
      assert.equal(follows, 0); await command({ type: "PAUSE_CONTINUOUS" });
    });

    for (const failure of ["status", "update"] as const) {
      await t.test(`fonte com ${failure} pendente desassocia a aba anterior e retoma em documento novo`, async () => {
        fixture(); const old = ++nextTab;
        tabs.set(old, { id: old, url: "https://www.instagram.com/qa.previous/", active: false });
        state().runtime.continuousTabId = old;
        if (failure === "status") statusOverride = (status, id) => id === old ? new Promise((resolve) => { heldPreparation = resolve; }) : status;
        else sourceUpdateId = old;
        await start(); fire();
        await pumpUntil(() => !!state().campaigns[0].continuous?.readRetry, 22000);
        assert.equal(state().runtime.continuousTabId, undefined);
        assert.equal(steps, 0); assert.equal(follows, 0); assert.ok(tabs.has(old));
        const retry = structuredClone(state().campaigns[0].continuous!.readRetry!);
        heldPreparation?.({ ...tabs.get(old), status: "complete", account: "qa.owner", restricted: null, hasDraft: false });
        await flush(); assert.equal(steps, 0); assert.equal(state().runtime.continuousTabId, undefined);
        assert.deepEqual(state().campaigns[0].continuous!.readRetry, retry);
        sourceUpdateId = undefined; statusOverride = undefined;
        t.mock.timers.tick(Date.parse(retry.retryAt) - Date.now()); fire();
        await pumpUntil(() => state().candidates.length === 1 && alarms.has("orbita-continuous:qa-workspace"));
        assert.notEqual(state().runtime.continuousTabId, old); assert.ok(tabs.has(old));
        assert.equal(steps, 1); assert.equal(follows, 0); assert.equal(state().campaigns[0].continuous!.readRetry, undefined);
        await command({ type: "PAUSE_CONTINUOUS" });
      });
    }

    for (const cancel of ["pause", "settings", "configure", "warning", "account"] as const) {
      await t.test(`timeout tardio após ${cancel} não revive autorização nem agenda follow`, async () => {
        fixture(); await start(); fire();
        const stale = problemCount("QUEUE_PREPARATION_STALE");
        await pumpUntil(() => state().candidates.length === 1 && alarms.has("orbita-continuous:qa-workspace"));
        preparationFailure = "status"; t.mock.timers.tick(31000); fire();
        await pumpUntil(() => !!heldPreparation);
        if (cancel === "pause") await command({ type: "PAUSE_CONTINUOUS" });
        if (cancel === "settings") await command({ type: "SETTINGS", settings: state().settings });
        if (cancel === "configure") await command({ type: "CONFIGURE_CONTINUOUS_SOURCE", id: "source-a", enabled: false, autoFollow: false });
        if (cancel === "warning") await command({ type: "REPORT_WARNING" });
        if (cancel === "account") assert.equal((await route({ type: "ACCOUNT_COMMAND", expectedActiveId: "qa-workspace", command: { type: "ADD_ACCOUNT", username: "qa.other" } })).ok, true);
        t.mock.timers.tick(20000); await flush();
        heldPreparation?.({ account: "qa.owner", restricted: null, url: "https://www.instagram.com/qa.new/", hasDraft: false });
        await flush();
        const original = workspace(root(), "qa-workspace").data;
        assert.equal(original.continuous?.mode, "paused"); assert.equal(original.continuous?.authorizationId, undefined);
        assert.equal(original.continuous?.preparationRetry, undefined); assert.equal(original.runtime.activeToken, undefined);
        assert.equal(attemptsToday(original), 0); assert.equal(follows, 0);
        assert.equal(alarms.has("orbita-continuous:qa-workspace"), false);
        assert.equal(problemCount("QUEUE_PREPARATION_STALE"), stale + 1);
      });
    }

    await t.test("modo sem teto exige revisão nova no início manual e contínuo sem repor consumo", async () => {
      fixture(); state().settings.unlimitedAttempts = true;
      state().runtime.sessionAttempts = 501;
      state().runtime.sessionStartedAt = new Date(Date.now() - 1800000).toISOString();
      const last = new Date().toISOString(); state().lastAttempts = { "@qa.owner": last };
      const key = `qa.owner|${new Date().toDateString()}`;
      state().dailyAttempts[key] = 501;
      const before = structuredClone(state());
      for (const unlimitedAttemptsReviewed of [undefined, false, "true"]) {
        const reply = await command({ type: "START_CONTINUOUS", sourceIds: ["source-a"], reviewed: true, unlimitedAttemptsReviewed });
        assert.equal(reply.ok, false); assert.match(reply.error, /sem teto/i);
        assert.deepEqual(state(), before);
        assert.equal(alarms.has("orbita-continuous:qa-workspace"), false);
      }
      await command({ type: "IMPORT", campaignId: "source-a", candidates: [{ username: "qa.manual" }], url: "https://www.instagram.com/qa.reference/followers/" });
      const ids = [state().candidates[0].id];
      await command({ type: "APPROVE", ids }); await command({ type: "QUEUE", ids });
      const queued = structuredClone(state());
      for (const unlimitedAttemptsReviewed of [undefined, false, "true"]) {
        const reply = await command({ type: "START", reviewed: true, unlimitedAttemptsReviewed });
        assert.equal(reply.ok, false); assert.match(reply.error, /sem teto/i);
        assert.deepEqual(state(), queued); assert.equal(tabs.size, 0);
      }
      const accepted = await command({ type: "START", reviewed: true, unlimitedAttemptsReviewed: true });
      assert.equal(accepted.ok, true, accepted.error);
      assert.equal(state().runtime.sessionAttempts, 0); assert.equal(attemptsToday(state()), 501);
      assert.equal(state().runtime.sessionStartedAt, new Date().toISOString());
      assert.equal(state().lastAttempts?.["@qa.owner"], last);
      assert.equal(state().runtime.nextRun, Date.parse(last) + 5 * 60000);
      const sessionStartedAt = state().runtime.sessionStartedAt;
      assert.equal(follows, 0); assert.equal(state().runtime.mode, "running");
      await command({ type: "PAUSE" });
      assert.equal((await command({ type: "SETTINGS", settings: { ...state().settings, unlimitedAttempts: false } })).ok, true);
      const limited = await command({ type: "START", reviewed: true });
      assert.equal(limited.ok, false); assert.match(limited.error, /teto diário/);
      assert.equal(state().runtime.sessionAttempts, 0); assert.equal(attemptsToday(state()), 501);
      assert.equal(state().runtime.sessionStartedAt, sessionStartedAt);
      assert.equal(state().lastAttempts?.["@qa.owner"], last);
    });

    await t.test("sem teto agenda após cinco minutos e confirma uma única ação acima de 500 sem reset", async () => {
      fixture(); state().settings.unlimitedAttempts = true;
      state().runtime.sessionAttempts = 501;
      state().runtime.sessionStartedAt = new Date().toISOString();
      const ledgerKey = `qa.owner|${new Date().toDateString()}`, last = new Date().toISOString();
      state().dailyAttempts[ledgerKey] = 501; state().lastAttempts = { "@qa.owner": last };
      const started = await command({ type: "START_CONTINUOUS", sourceIds: ["source-a"], reviewed: true, unlimitedAttemptsReviewed: true });
      assert.equal(started.ok, true, started.error); fire();
      await pumpUntil(() => state().candidates.length === 1 && alarms.has("orbita-continuous:qa-workspace"));
      const due = Date.parse(last) + 5 * 60000;
      assert.equal(alarms.get("orbita-continuous:qa-workspace").when, due);
      assert.equal(attemptsToday(state()), 501); assert.equal(state().runtime.sessionAttempts, 501);
      t.mock.timers.tick(due - Date.now() - 1000); fire(); await flush();
      assert.equal(follows, 0); assert.equal(attemptsToday(state()), 501);
      t.mock.timers.tick(1000); fire();
      await pumpUntil(() => state().candidates[0].stage === "followed" && alarms.has("orbita-continuous:qa-workspace"));
      assert.equal(follows, 1); assert.equal(attemptsToday(state()), 502); assert.equal(state().runtime.sessionAttempts, 502);
      assert.equal(state().settings.dailyLimit, 5); assert.equal(state().settings.sessionLimit, 5);
      fire(); await flush(); assert.equal(follows, 1); assert.equal(attemptsToday(state()), 502);
      await command({ type: "PAUSE_CONTINUOUS" });
    });

    await t.test("sem teto renova sessão comprovadamente anterior sem apagar ledger nem antecipar intervalo", async (subtest) => {
      const previousClock = Date.now(); subtest.after(() => t.mock.timers.setTime(previousClock));
      t.mock.timers.setTime(new Date(2026, 10, 8, 23, 59).getTime());
      fixture(); Object.assign(state().settings, { unlimitedAttempts: true, allDay: true });
      const last = new Date().toISOString(), key = `qa.owner|${new Date().toDateString()}`;
      state().runtime.sessionAttempts = 501; state().runtime.sessionStartedAt = last;
      state().dailyAttempts[key] = 501; state().lastAttempts = { "@qa.owner": last };
      assert.equal((await command({ type: "START_CONTINUOUS", sourceIds: ["source-a"], reviewed: true, unlimitedAttemptsReviewed: true })).ok, true);
      fire(); await pumpUntil(() => state().candidates.length === 1 && alarms.has("orbita-continuous:qa-workspace"));
      const due = Date.parse(last) + 5 * 60000;
      t.mock.timers.tick(60000); fire();
      await pumpUntil(() => alarms.has("orbita-continuous:qa-workspace"));
      assert.equal(state().runtime.sessionAttempts, 0); assert.equal(attemptsToday(state()), 0);
      assert.equal(state().runtime.sessionStartedAt, new Date().toISOString());
      assert.equal(state().lastAttempts?.["@qa.owner"], last);
      assert.equal(state().dailyAttempts[key], 501); assert.equal(follows, 0);
      assert.equal(alarms.get("orbita-continuous:qa-workspace").when, due);
      t.mock.timers.tick(due - Date.now()); fire();
      await pumpUntil(() => state().candidates[0].stage === "followed" && alarms.has("orbita-continuous:qa-workspace"));
      assert.equal(follows, 1); assert.equal(state().runtime.sessionAttempts, 1);
      assert.equal(attemptsToday(state()), 1); assert.equal(state().dailyAttempts[key], 501);
      assert.equal(state().settings.intervalMinutes, 5);
      await command({ type: "PAUSE_CONTINUOUS" });
    });

    for (const blocker of ["warning", "uncertain"] as const) {
      await t.test(`sem teto não libera ${blocker} nem cria autorização de rotina`, async () => {
        fixture(); state().settings.unlimitedAttempts = true;
        state().runtime.sessionAttempts = 501;
        state().dailyAttempts[`qa.owner|${new Date().toDateString()}`] = 501;
        if (blocker === "warning") state().settings.hasPendingWarning = true;
        else {
          await command({ type: "IMPORT", campaignId: "source-a", candidates: [{ username: "qa.uncertain" }], url: "https://www.instagram.com/qa.reference/followers/" });
          state().candidates[0].stage = "uncertain";
        }
        const response = await command({ type: "START_CONTINUOUS", sourceIds: ["source-a"], reviewed: true, unlimitedAttemptsReviewed: true });
        assert.equal(response.ok, false); assert.match(response.error, /avisos|incertos/);
        assert.equal(state().continuous?.mode, "paused"); assert.equal(state().continuous?.authorizationId, undefined);
        assert.equal(follows, 0); assert.equal(steps, 0); assert.equal(attemptsToday(state()), 501);
        assert.equal(state().runtime.sessionAttempts, 501); assert.equal(tabs.size, 0);
      });
    }

    await t.test("consulta enfileira uma vez, executa automático e mantém agenda para novas consultas", async () => {
      fixture(); await start(); fire();
      await pumpUntil(() => !!state().campaigns[0].continuous?.lastCheckAt && alarms.has("orbita-continuous:qa-workspace"));
      assert.equal(steps, 1); assert.equal(state().candidates[0].stage, "queued"); assert.equal(follows, 0);
      assert.equal(state().campaigns[0].continuous?.lastQueued, 1);
      t.mock.timers.tick(31000); fire();
      await pumpUntil(() => state().candidates[0].stage === "followed" && alarms.has("orbita-continuous:qa-workspace"));
      assert.equal(follows, 1); assert.equal(attemptsToday(state()), 1); assert.equal(state().continuous?.mode, "running");
      state().campaigns[0].continuous!.nextCheckAt = new Date(Date.now() - 1000).toISOString();
      fire(); await pumpUntil(() => steps === 2 && state().campaigns[0].continuous?.lastAdded === 0 && alarms.has("orbita-continuous:qa-workspace"));
      assert.equal(follows, 1); assert.equal(state().candidates.length, 1); assert.equal(attemptsToday(state()), 1);
      assert.equal((await command({ type: "PAUSE_CONTINUOUS" })).ok, true);
    });

    await t.test("fonte indisponível para; outra fonte continua sem insistir na anterior", async () => {
      fixture(true); stepMode = "unavailable"; await start(["source-a", "source-b"]);
      state().campaigns.find((c) => c.id === "source-b")!.continuous!.nextCheckAt = new Date(Date.now() + 1000).toISOString();
      fire();
      await pumpUntil(() => state().campaigns.find((c) => c.id === "source-a")?.continuous?.status === "unavailable" && alarms.has("orbita-continuous:qa-workspace"));
      assert.equal(state().continuous?.mode, "running"); assert.equal(steps, 1);
      t.mock.timers.tick(1000); fire(); await pumpUntil(() => !!state().campaigns.find((c) => c.id === "source-b")?.continuous?.lastCheckAt && alarms.has("orbita-continuous:qa-workspace"));
      assert.equal(steps, 2); assert.equal(state().candidates[0].username, "qa.second");
      assert.equal(state().candidates[0].stage, "queued");
      await command({ type: "PAUSE_CONTINUOUS" });
    });

    await t.test("alarmes simultâneos não sobrepõem scans e pausa invalida resposta tardia", async () => {
      fixture(); stepMode = "hold"; await start(); fire();
      await pumpUntil(() => !!releaseStep);
      fire(); await flush(); assert.equal(steps, 1);
      await command({ type: "PAUSE_CONTINUOUS" });
      releaseStep!({ ok: true, data: { account: "qa.owner", sourceId: "source-a", runId: state().campaigns[0].continuous?.runId, url: "https://www.instagram.com/qa.reference/followers/", at: new Date().toISOString(), phase: "end", complete: false, candidates: [{ username: "qa.late" }] } });
      await flush(); t.mock.timers.tick(1000); await flush();
      assert.equal(state().candidates.length, 0); assert.equal(follows, 0); assert.equal(state().continuous?.mode, "paused");
      fire(); await flush(); assert.equal(steps, 1);
    });

    await t.test("aba ativada durante a conferência de rascunho é preservada antes de navegar", async () => {
      fixture(); await start(); fire();
      await pumpUntil(() => !!state().campaigns[0].continuous?.lastCheckAt && alarms.has("orbita-continuous:qa-workspace"));
      const previous = state().runtime.continuousTabId!;
      activateTabAfterStatus = previous;
      state().campaigns[0].continuous!.nextCheckAt = new Date(Date.now() - 1000).toISOString();
      fire(); await pumpUntil(() => steps === 2 && alarms.has("orbita-continuous:qa-workspace"));
      assert.notEqual(state().runtime.continuousTabId, previous);
      assert.equal(updatedTabs.includes(previous), false);
      assert.equal(tabs.get(previous).hasDraft, true);
      assert.equal(follows, 0);
      await command({ type: "PAUSE_CONTINUOUS" });
    });

    await t.test("troca de ator pausa a rotina inteira, sem clique nem orçamento consumido", async () => {
      fixture(); stepMode = "mismatch";
      const recorded = problemCount("CONTINUOUS_SESSION"), sourceErrors = problemCount("CONTINUOUS_SOURCE");
      await start(); fire();
      await pumpUntil(() => state().continuous?.mode === "paused");
      assert.equal(follows, 0); assert.equal(attemptsToday(state()), 0); assert.equal(state().candidates.length, 0);
      assert.equal(alarms.has("orbita-continuous:qa-workspace"), false);
      assert.equal(problemCount("CONTINUOUS_SESSION"), recorded + 1);
      assert.equal(problemCount("CONTINUOUS_SOURCE"), sourceErrors);
      assert.equal(state().campaigns[0].continuous?.status, "ready");
      assert.equal(state().campaigns[0].continuous?.runId, undefined);
      fire(); await flush(); assert.equal(problemCount("CONTINUOUS_SESSION"), recorded + 1);
    });

    await t.test("pausa voluntária invalida mismatch tardio sem registrar nova falha de sessão", async () => {
      fixture(); stepMode = "hold";
      const recorded = problemCount("CONTINUOUS_SESSION"), sourceErrors = problemCount("CONTINUOUS_SOURCE");
      await start(); fire(); await pumpUntil(() => !!releaseStep);
      await command({ type: "PAUSE_CONTINUOUS" });
      releaseStep!({ ok: false, accountMismatch: true, error: "Resposta de uma consulta já pausada" });
      await flush(); t.mock.timers.tick(1000); await flush();
      assert.equal(problemCount("CONTINUOUS_SESSION"), recorded);
      assert.equal(problemCount("CONTINUOUS_SOURCE"), sourceErrors);
      assert.equal(state().campaigns[0].continuous?.status, "ready");
      assert.equal(state().campaigns[0].continuous?.runId, undefined);
      assert.equal(state().continuous?.mode, "paused"); assert.equal(follows, 0);
    });

    await t.test("sessão em hidratação após navegar do post aguarda identificação e rota exatas antes de STEP", async () => {
      fixture();
      const recorded = problemCount("CONTINUOUS_SESSION");
      const previous = ++nextTab;
      tabs.set(previous, { id: previous, url: "https://www.instagram.com/p/QApost/", active: false });
      state().runtime.continuousTabId = previous;
      let reads = 0;
      statusOverride = (status) => {
        if (status.url !== "https://www.instagram.com/qa.reference/") return status;
        reads++; assert.equal(steps, 0); assert.equal(follows, 0);
        if (reads === 1) return { ...status, account: null };
        if (reads === 2) return undefined;
        if (reads === 3) { const missing = { ...status }; delete missing.account; return missing; }
        if (reads === 4) return { ...status, url: "https://www.instagram.com/p/QApost/" };
        return status;
      };
      await start(); fire();
      await pumpUntil(() => !!state().campaigns[0].continuous?.lastCheckAt || state().continuous?.mode === "paused");
      assert.equal(state().continuous?.mode, "running"); assert.equal(reads, 5);
      assert.equal(steps, 1); assert.equal(follows, 0); assert.equal(attemptsToday(state()), 0);
      assert.equal(state().settings.hasPendingWarning, false);
      assert.equal(state().candidates[0].stage, "queued");
      assert.equal(state().runtime.continuousTabId, previous);
      await command({ type: "PAUSE_CONTINUOUS" });
      assert.equal(problemCount("CONTINUOUS_SESSION"), recorded);
    });

    await t.test("sessão sempre não identificada expira no prazo de preparo sem declarar troca nem enviar STEP", async () => {
      fixture(); let reads = 0;
      const recorded = problemCount("CONTINUOUS_SESSION"), sourceErrors = problemCount("CONTINUOUS_SOURCE");
      statusOverride = (status) => { reads++; return { ...status, account: null }; };
      await start(); const began = Date.now(); fire();
      const retries = problemCount("CONTINUOUS_SOURCE_RETRY");
      await pumpUntil(() => !!state().campaigns[0].continuous?.readRetry || state().continuous?.mode === "paused", 20000);
      const reason = state().campaigns[0].continuous?.reason || "";
      assert.equal(state().campaigns[0].continuous?.status, "ready");
      assert.match(state().campaigns[0].continuous!.readRetry!.phase, /identifica/i);
      assert.doesNotMatch(reason, /sessão.*mudou|Conecte a conta selecionada/i);
      assert.ok(Date.now() - began >= 18000 && Date.now() - began < 19000);
      assert.ok(reads > 1); assert.equal(steps, 0); assert.equal(follows, 0);
      assert.equal(state().candidates.length, 0); assert.equal(attemptsToday(state()), 0);
      assert.equal(state().settings.hasPendingWarning, false);
      assert.equal(problemCount("CONTINUOUS_SESSION"), recorded);
      assert.equal(problemCount("CONTINUOUS_SOURCE"), sourceErrors);
      assert.equal(problemCount("CONTINUOUS_SOURCE_RETRY"), retries + 1);
      await command({ type: "PAUSE_CONTINUOUS" });
    });

    for (const outcome of ["different", "warning"] as const) {
      await t.test(`STATUS ${outcome} pausa imediatamente sem aguardar hidratação nem enviar STEP`, async () => {
        fixture(); let reads = 0;
        const recorded = problemCount("CONTINUOUS_SESSION"), sourceErrors = problemCount("CONTINUOUS_SOURCE");
        statusOverride = (status) => { reads++; return outcome === "different" ? { ...status, account: "qa.other" } : { ...status, account: null, restricted: "Aviso fictício da plataforma" }; };
        await start(); const began = Date.now(); fire();
        await pumpUntil(() => state().continuous?.mode === "paused");
        assert.equal(reads, 1); assert.ok(Date.now() - began < 1000);
        assert.equal(state().settings.hasPendingWarning, outcome === "warning");
        assert.equal(steps, 0); assert.equal(follows, 0); assert.equal(attemptsToday(state()), 0);
        assert.equal(state().candidates.length, 0);
        assert.match(state().runtime.pauseReason, outcome === "different" ? /sessão.*mudou/i : /Aviso fictício/);
        assert.equal(problemCount("CONTINUOUS_SESSION"), recorded + (outcome === "different" ? 1 : 0));
        assert.equal(problemCount("CONTINUOUS_SOURCE"), sourceErrors);
        assert.equal(state().campaigns[0].continuous?.status, "ready");
        assert.equal(state().campaigns[0].continuous?.runId, undefined);
        if (outcome === "different") {
          assert.ok(saved[PROBLEMS_KEY]?.entries.some((entry: any) => entry.scope === "qa-workspace" && entry.operation === "CONTINUOUS_SESSION" && entry.category === "connection"));
          fire(); await flush(); assert.equal(problemCount("CONTINUOUS_SESSION"), recorded + 1);
        }
      });
    }

    for (const pointer of ["continuousTabId", "relationshipTabId"] as const) {
      await t.test(`aviso da plataforma pela ${pointer} pausa só a conta dona e conserva tentativas`, async () => {
        fixture(); await start();
        const foreign = workspace(initialStore());
        foreign.id = "qa-foreign"; foreign.username = "qa.other"; foreign.data.runtime.account = foreign.username;
        foreign.data.runtime.relationshipTabId = 888;
        root().accounts.push(foreign);
        const foreignBefore = structuredClone(foreign);
        state().runtime[pointer] = 777;
        state().runtime.sessionAttempts = 2;
        state().runtime.activeToken = "qa-revoked-token";
        state().dailyAttempts[`qa.owner|${new Date().toDateString()}`] = 2;
        const warning = `Aviso fictício de ${pointer}`;
        const reply = await route({ type: "PLATFORM_WARNING", message: warning }, { id: "fixture-extension", tab: { id: 777 }, url: "https://www.instagram.com/qa.reference/" } as any);
        assert.equal(reply.ok, true, reply.error);
        assert.equal(state().settings.hasPendingWarning, true); assert.equal(state().continuous?.mode, "paused");
        assert.equal(state().runtime.mode, "paused"); assert.equal(state().runtime.activeToken, undefined);
        assert.equal(state().runtime.sessionAttempts, 2); assert.equal(attemptsToday(state()), 2);
        assert.equal(alarms.has("orbita-continuous:qa-workspace"), false);
        assert.deepEqual(root().accounts.find((a) => a.id === foreign.id), foreignBefore);
        assert.ok(saved[PROBLEMS_KEY]?.entries.some((entry: any) => entry.scope === "qa-workspace" && entry.operation === "PLATFORM_WARNING" && entry.message === warning));
        const declined = await route({ type: "PLATFORM_WARNING", message: "Outra conta" }, { id: "fixture-extension", tab: { id: 888 }, url: "https://www.instagram.com/qa.other/" } as any);
        assert.equal(declined.ok, false);
        assert.deepEqual(root().accounts.find((a) => a.id === foreign.id), foreignBefore);
        fire(); await flush(); assert.equal(steps, 0); assert.equal(follows, 0);
      });
    }

    await t.test("fila automática preserva a aba ativada com rascunho após STATUS", async () => {
      fixture(); await start(); fire();
      await pumpUntil(() => state().candidates.length === 1 && alarms.has("orbita-continuous:qa-workspace"));
      const previous = ++nextTab, previousUrl = "https://www.instagram.com/qa.previous/";
      tabs.set(previous, { id: previous, url: previousUrl, active: false });
      state().runtime.workerTabId = previous;
      activateTabAfterStatus = previous;
      t.mock.timers.tick(31000); fire();
      await pumpUntil(() => state().candidates[0].stage === "followed" && alarms.has("orbita-continuous:qa-workspace"));
      assert.equal(updatedTabs.includes(previous), false);
      assert.equal(tabs.get(previous).url, previousUrl);
      assert.equal(tabs.get(previous).active, true); assert.equal(tabs.get(previous).hasDraft, true);
      assert.notEqual(state().runtime.workerTabId, previous);
      assert.equal(follows, 1); assert.equal(attemptsToday(state()), 1);
      await command({ type: "PAUSE_CONTINUOUS" });
    });

    for (const hasDraft of [true, false]) {
      await t.test(`lote manual ${hasDraft ? "preserva rascunho em aba ativa" : "reusa aba ativa sem rascunho"}`, async () => {
        fixture();
        assert.equal((await command({ type: "IMPORT", campaignId: "source-a", candidates: [{ username: "qa.manual" }], url: "https://www.instagram.com/qa.reference/followers/" })).ok, true);
        const ids = [state().candidates[0].id];
        assert.equal((await command({ type: "APPROVE", ids })).ok, true);
        assert.equal((await command({ type: "QUEUE", ids })).ok, true);
        const previous = ++nextTab, previousUrl = "https://www.instagram.com/qa.previous/";
        tabs.set(previous, { id: previous, url: previousUrl, active: true, hasDraft });
        state().runtime.workerTabId = previous;
        assert.equal((await command({ type: "START", reviewed: true })).ok, true);
        t.mock.timers.tick(31000); onAlarm!({ name: "orbita-queue:qa-workspace" });
        await pumpUntil(() => state().candidates[0].stage === "followed" && state().runtime.mode === "paused");
        assert.equal(updatedTabs.includes(previous), !hasDraft);
        assert.equal(tabs.get(previous).url, hasDraft ? previousUrl : "https://www.instagram.com/qa.manual/");
        assert.equal(tabs.get(previous).hasDraft, hasDraft); assert.equal(tabs.get(previous).active, true);
        assert.equal(state().runtime.workerTabId === previous, !hasDraft);
        assert.equal(follows, 1); assert.equal(attemptsToday(state()), 1); assert.equal(steps, 0);
      });
    }

    await t.test("novo dia renova só a sessão antiga; início no mesmo dia não repõe tentativas", async () => {
      fixture(); state().runtime.sessionAttempts = 5;
      state().runtime.sessionStartedAt = new Date().toISOString();
      state().lastAttempts = { "@qa.owner": new Date().toISOString() };
      state().dailyAttempts[`qa.owner|${new Date().toDateString()}`] = 5;
      await start(); fire();
      await pumpUntil(() => state().candidates.length === 1 && alarms.has("orbita-continuous:qa-workspace"));
      assert.equal(follows, 0); assert.equal(state().runtime.sessionAttempts, 5); assert.equal(attemptsToday(state()), 5);
      const previousLedger = structuredClone(state().dailyAttempts), previousInterval = state().settings.intervalMinutes;
      t.mock.timers.tick(86400000); fire();
      await pumpUntil(() => state().candidates[0].stage === "followed" && alarms.has("orbita-continuous:qa-workspace"));
      assert.equal(follows, 1); assert.equal(state().runtime.sessionAttempts, 1); assert.equal(attemptsToday(state()), 1);
      assert.equal(state().settings.intervalMinutes, previousInterval);
      for (const [key, value] of Object.entries(previousLedger)) assert.equal(state().dailyAttempts[key], value);
      await command({ type: "PAUSE_CONTINUOUS" });
    });

    await t.test("24 horas coleta na madrugada sem quota extra e segue fora da janela após virar o dia e cumprir o intervalo", async (subtest) => {
      const previousClock = Date.now();
      subtest.after(() => t.mock.timers.setTime(previousClock));
      t.mock.timers.setTime(new Date(2026, 10, 8, 23, 59).getTime());
      fixture();
      Object.assign(state().settings, { allDay: true, startHour: "09:00", endHour: "21:00" });
      const lastAttempt = new Date().toISOString(), previousDay = new Date().toDateString();
      state().runtime.sessionAttempts = 5;
      state().runtime.sessionStartedAt = lastAttempt;
      state().lastAttempts = { "@qa.owner": lastAttempt };
      state().dailyAttempts[`qa.owner|${previousDay}`] = 5;
      const midnight = new Date(2026, 10, 9, 0).getTime();
      const intervalDue = Date.now() + state().settings.intervalMinutes * 60000;
      await start(); fire();
      await pumpUntil(() => state().candidates.length === 1 && alarms.has("orbita-continuous:qa-workspace"));
      assert.equal(steps, 1, "a coleta fora de 09–21 continua, mesmo com o teto de seguir consumido");
      assert.equal(follows, 0); assert.equal(attemptsToday(state()), 5); assert.equal(state().runtime.sessionAttempts, 5);
      assert.equal(state().candidates[0].stage, "queued");
      assert.equal(alarms.get("orbita-continuous:qa-workspace").when, midnight);

      t.mock.timers.tick(midnight - Date.now()); fire();
      await pumpUntil(() => state().runtime.sessionAttempts === 0 && alarms.has("orbita-continuous:qa-workspace"));
      assert.equal(follows, 0, "meia-noite não encurta o intervalo da última tentativa");
      assert.equal(attemptsToday(state()), 0);
      assert.equal(state().dailyAttempts[`qa.owner|${previousDay}`], 5);
      assert.equal(state().lastAttempts?.["@qa.owner"], lastAttempt);
      assert.equal(alarms.get("orbita-continuous:qa-workspace").when, intervalDue);

      t.mock.timers.tick(intervalDue - Date.now()); fire();
      await pumpUntil(() => state().candidates[0].stage === "followed" && alarms.has("orbita-continuous:qa-workspace"));
      assert.equal(follows, 1); assert.equal(attemptsToday(state()), 1); assert.equal(state().runtime.sessionAttempts, 1);
      assert.equal(state().dailyAttempts[`qa.owner|${previousDay}`], 5);
      assert.equal(state().settings.intervalMinutes, 5); assert.equal(state().settings.dailyLimit, 5); assert.equal(state().settings.sessionLimit, 5);
      assert.equal(state().settings.startHour, "09:00"); assert.equal(state().settings.endHour, "21:00");

      const nextCheck = Date.parse(state().campaigns[0].continuous!.nextCheckAt!);
      t.mock.timers.tick(nextCheck - Date.now()); fire();
      await pumpUntil(() => steps === 2 && alarms.has("orbita-continuous:qa-workspace"));
      assert.equal(follows, 1, "reler a mesma fonte não repete o follow nem cria crédito de tentativas");
      assert.equal(attemptsToday(state()), 1); assert.equal(state().candidates.length, 1);
      await command({ type: "PAUSE_CONTINUOUS" });
    });

    await t.test("primeira ativação renova uma sessão comprovadamente anterior sem esperar outro dia", async () => {
      fixture();
      const yesterday = new Date(Date.now() - 86400000);
      state().runtime.sessionAttempts = 5;
      state().runtime.sessionStartedAt = yesterday.toISOString();
      state().lastAttempts = { "@qa.owner": yesterday.toISOString() };
      state().dailyAttempts[`qa.owner|${yesterday.toDateString()}`] = 5;
      await start(); fire();
      await pumpUntil(() => state().candidates.length === 1 && alarms.has("orbita-continuous:qa-workspace"));
      assert.equal(state().runtime.sessionAttempts, 0);
      assert.equal(attemptsToday(state()), 0);
      t.mock.timers.tick(31000); fire();
      await pumpUntil(() => state().candidates[0].stage === "followed" && alarms.has("orbita-continuous:qa-workspace"));
      assert.equal(follows, 1); assert.equal(state().runtime.sessionAttempts, 1);
      assert.equal(state().dailyAttempts[`qa.owner|${yesterday.toDateString()}`], 5);
      await command({ type: "PAUSE_CONTINUOUS" });
    });

    await t.test("reinício em outro dia agenda renovação agora, sem aguardar a fonte de 24 horas", async () => {
      fixture();
      state().campaigns[0].continuous!.pollMinutes = 1440;
      await start(); fire();
      await pumpUntil(() => state().candidates.length === 1 && alarms.has("orbita-continuous:qa-workspace"));
      const yesterday = new Date();
      state().runtime.sessionAttempts = 5;
      state().runtime.sessionStartedAt = yesterday.toISOString();
      state().lastAttempts = { "@qa.owner": yesterday.toISOString() };
      state().dailyAttempts[`qa.owner|${yesterday.toDateString()}`] = 5;
      t.mock.timers.tick(22 * 3600000);
      const recoveryPath = new URL("../src/extension/account-store.ts?continuous-next-day-alarm", import.meta.url).href;
      await (await import(recoveryPath)).storeReady;
      const alarm = alarms.get("orbita-continuous:qa-workspace");
      assert.ok(alarm.when <= Date.now() + 1000, "o tick precisa renovar o dia antes de aguardar uma fonte ainda futura");
      assert.equal(state().runtime.sessionAttempts, 5, "agendar não pode resetar contadores");
      assert.equal(attemptsToday(state()), 0);
      t.mock.timers.tick(1000); fire();
      await pumpUntil(() => state().candidates[0].stage === "followed" && alarms.has("orbita-continuous:qa-workspace"));
      assert.equal(follows, 1); assert.equal(state().runtime.sessionAttempts, 1);
      await command({ type: "PAUSE_CONTINUOUS" });
    });

    await t.test("reinício recupera leitura sem repetir ação; tentativa interrompida exige revisão", async () => {
      fixture(); await start();
      state().campaigns[0].continuous!.status = "checking"; state().campaigns[0].continuous!.runId = "old-read";
      delete state().campaigns[0].continuous!.nextCheckAt;
      const readRecovery = new URL("../src/extension/account-store.ts?continuous-read-recovery", import.meta.url).href;
      await (await import(readRecovery)).storeReady;
      assert.equal(state().campaigns[0].continuous?.status, "ready");
      assert.equal(state().campaigns[0].continuous?.runId, undefined); assert.ok(alarms.has("orbita-continuous:qa-workspace"));
      assert.equal(follows, 0);
      onStartup!(); await flush(); assert.equal(state().continuous?.mode, "running");
      fire(); await pumpUntil(() => state().candidates.length === 1 && alarms.has("orbita-continuous:qa-workspace"));
      state().candidates[0].stage = "attempting"; state().runtime.mode = "running";
      state().runtime.sessionAttempts = 3;
      state().dailyAttempts[`qa.owner|${new Date().toDateString()}`] = 3;
      const actionRecovery = new URL("../src/extension/account-store.ts?continuous-action-recovery", import.meta.url).href;
      await (await import(actionRecovery)).storeReady;
      assert.equal(state().candidates[0].stage, "uncertain"); assert.equal(state().continuous?.mode, "paused");
      assert.equal(attemptsToday(state()), 3); assert.equal(state().runtime.sessionAttempts, 3);
      assert.equal(continuousWakeAt(account()), undefined); assert.equal(follows, 0);
    });
  } finally {
    releaseStep?.({ ok: false, error: "Fixture encerrado" }); await flush();
    t.mock.timers.reset();
    for (const [key, descriptor] of originals) descriptor ? Object.defineProperty(globalThis, key, descriptor) : Reflect.deleteProperty(globalThis, key);
  }
});
