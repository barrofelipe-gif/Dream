# Rotina contínua — nativo 0.19.1 / painel 0.19.2

## Agenda 24h — 04/11/2026

O usuário autorizou monitorar e seguir também durante a madrugada. O campo opcional `settings.allDay` habilita todos os 1.440 minutos do dia, sem o intervalo que existiria numa janela 00h–23h59. Ausente equivale a falso. O controle requer `GET_STATE.capabilities.allDaySchedule === true`, exposto pelo nativo 0.19.1; a capability da coleta periódica continua separada.

Início e fim anteriores ficam guardados, mas não limitam a execução enquanto o modo está ativo. Salvar preferências pausa e invalida a execução anterior; é necessário revisar e ativar novamente as mesmas fontes. Tetos diário/de sessão, intervalo, proteções e avisos não são alterados. A renovação ocorre pelo dia local do computador, mantendo o livro diário e a última tentativa; não libera um follow antes do intervalo configurado.

A opção também é validada em migração e backup, sem tornar os demais campos legados mais estritos. Restauração continua pausando a execução e revogando autorizações; instalação não liga o modo 24h automaticamente. Clientes sem a capability não devem declarar o modo como aplicado nem iniciar uma rotina que dependa dele. A validação real depende da recarga legítima do nativo e da aplicação explícita da preferência.

Coletas seguem periódicas e parciais. O modo 24h não descobre novas publicações nem implementa notificações instantâneas das interações em concorrentes.

Na preparação desta versão, a suíte integrada passou com 458 testes e o build completo passou. Os novos testes de domínio verificam cada minuto do dia; a integração do worker atravessa 23h59/meia-noite, mantém o livro diário e o intervalo e confirma exatamente um follow fictício depois do prazo permitido. Os testes da interface cobrem habilitação, ausência/perda da capability, horários guardados e limites inalterados. Não houve ação real no Instagram nesses testes.

A rotina consulta periodicamente fontes já configuradas, preserva a origem de cada perfil e pode enfileirar novos elegíveis para seguir conforme a política explicitamente autorizada. A validação desta rotina em sessão real do Instagram está pendente; o piloto anterior de cinco ações não validou este fluxo periódico.

## Configuração e ativação

Em Campanhas, configure uma fonte ou o grupo de três fontes. Nesta versão são aceitos seguidores de um perfil, comentários de uma publicação e curtidas de uma publicação. A URL informada é a referência para comentários e curtidas; não há busca de todas as publicações. Seguidos, hashtags, locais e arquivos importados não participam da rotina.

A política exige escolha entre somente coletar e coletar/seguir novos elegíveis. Seguir não vem autorizado por padrão. O intervalo de consulta começa em 15 minutos, podendo ser configurado entre 5 e 1.440 minutos inteiros; não equivale ao intervalo de ações nem a uma frequência segura certificada pela plataforma.

Salvar uma configuração exige revisão explícita. A interface pausa a rotina antes de salvar um grupo em sequência; uma falha não inicia o conjunto incompleto nem repete comandos anteriores. Salvar configuração não inicia a rotina. Salvar e ativar ou Ativar rotina autoriza exatamente as fontes selecionadas e suas políticas atuais. Acrescentar uma fonte exige nova ativação do conjunto; fontes somente configuradas não começam a executar por conta própria.

Depois de ativada, a rotina consulta as fontes e pode seguir novos elegíveis. Cada leitura respeita exclusões e proteções. A autorização de deixar de seguir é separada da autorização das fontes e fica em **Ciclo de prospecção**.

Na 0.20.5, a opção automática permite agendar os perfis que a Órbita confirmou como seguidos nesta conta. Cada prazo começa nessa confirmação. A rotina prioriza o prazo vencido mais antigo e divide o intervalo e o orçamento com os follows. A verificação do perfil, da sessão e da proteção é repetida na autorização do clique. A recuperação de timeout fica restrita ao preparo anterior à reserva. Restaurar backup revoga a autorização do ciclo.

## Operação e interrupções

Chrome, computador e sessão corretos precisam permanecer disponíveis. Uma conta executa por vez, na sessão do Instagram do navegador. Hospedar o dashboard no app não transfere o executor para a nuvem.

A rotina respeita os horários, teto diário, intervalo de ações e tamanho de sessão configurados. Avisos da plataforma, resultado incerto ou identidade incompatível impedem novos trabalhos. A fila manual ou de deixar de seguir não é adotada silenciosamente pela rotina. A tela mostra o motivo e o agendamento que constam no estado do executor; não presume que uma espera já foi resolvida.

Ao atingir o orçamento do dia ou da sessão, não abre outro lote para contorná-lo. As leituras autorizadas podem continuar na janela; as ações aguardam o próximo dia permitido. A renovação de uma sessão comprovadamente anterior ocorre uma vez, preservando todo o livro diário e o último horário de tentativa. Não apaga avisos nem resultados incertos. O menor orçamento configurado continua limitando as ações; aumentar apenas o teto diário não aumenta o tamanho da sessão.

Reabrir o Chrome permite retomar uma rotina já autorizada, se a conta e as condições continuarem válidas. Leitura interrompida perde o runId e recebe uma nova consulta programada; isso não reaplica importações. Uma ação interrompida vira resultado incerto e exige conferência. Nenhuma rotina é criada ou autorizada por uma instalação, atualização ou restauração de backup.

Pausar rotina e ações impede novos trabalhos, preservando listas, proveniência e tentativas consumidas. Uma ação já enviada pode terminar. Resultados de uma consulta antiga perdem autorização quando seu conjunto é alterado ou pausado; não devem ser aplicados a outra conta ou ativação. Prazo vencido não provoca reenvio automático de uma mutação nem significa cancelamento de uma ação que já havia sido enviada.

Uma fonte indisponível ou com erro exige conferência e reativação explícita. Reconfigurar não a inclui silenciosamente no conjunto em execução: uma nova ativação é necessária. Se um perfil bloqueou a conta, a rotina tem a mesma limitação da sessão; não há insistência automática, bypass, troca de conta ou proxy para contornar o bloqueio.

## Informações na tela

- Última verificação inclui uma tentativa malsucedida, acompanhada de seu motivo.
- Lidos, descobertos e enfileirados são contadores da última leitura salva; podem continuar aparecendo após uma verificação que falhou. Ausência é exibida como traço, e zero permanece zero.
- Descoberto nesta consulta significa novo no cadastro desta conta durante a leitura, sem provar que o perfil é novo no Instagram, que começou a seguir a conta ou que virou cliente.
- Todas as leituras são parciais. O que a sessão, o DOM e a paginação disponibilizam pode ser menor que a lista completa. Não há garantia de tempo real, completude ou eliminação do risco de bloqueio.

## Compatibilidade e dados existentes

O painel mantém mínimo geral de extensão 0.18.0. Os controles de rotina só são habilitados quando GET_STATE informa `capabilities.continuousSources === true`, recurso da versão 0.19.0 ou posterior. A ausência desse campo mantém o restante do painel útil e não é interpretada como autorização.

Atualizar a instalação não habilita fontes nem ativa uma rotina nova. Restaurar backup preserva dados históricos, revoga autorizações contínuas e exige nova configuração/ativação. Nenhuma rotina real é ativada como parte da migração ou dos testes de software.

Os testes dirigidos usam dados fictícios em `continuous.test.ts`, `continuous-dom.test.ts`, `continuous-ui.test.ts` e `continuous-worker.test.ts`. Eles verificam contratos do domínio, leitor, interface e scheduler; aprovação nesses testes não comprova disponibilidade prolongada, crescimento comercial ou funcionamento da rotina em uma sessão real.

## Revisão independente

Três agentes revisaram domínio, leitor e interface. A revisão do scheduler encontrou uma corrida de alarmes e um atraso de renovação após reinício; os casos foram reproduzidos ou cobertos com regressões do worker e corrigidos antes da entrega. A tentativa de consultar também o Claude Code para esta versão excedeu cinco minutos sem retornar análise; nenhum achado foi atribuído a essa tentativa. A revisão recebida na 0.18.2 permanece documentada separadamente e não foi apresentada como revisão da rotina 0.19.0.

## Evidência da entrega

A suíte integrada passou com 437 testes, e o build passou. Vinte verificações em Chrome isolado conferiram configuração única, política, contadores, indisponibilidade, reativação, pausa e bloqueio da extensão antiga; o resumo de uma fonte ativa foi conferido em 1440 e 390 px, sem overflow. O STEP compilado leu dois perfis fictícios em cada modalidade (seguidores, curtidas e comentários), sempre parcial, com zero cliques sociais. O conteúdo testado corresponde ao bundle final. Nenhuma conta real foi acessada por essa QA, e ela não substitui a validação da sessão real após recarregar a extensão.

## QA da agenda24h

Vinte e quatro verificações em Chrome isolado, com dados fictícios e rede externa interceptada, passaram no bundle final: habilitar/salvar24h com09–21 e limites5/5/5 guardados; trêsCONFIG e umSTART explícito; pausa/retomada sem replay; intervalo de coleta15 preservado; cliente antigo semcapability bloqueado;24h salvo sem suporte apresentado como pendente. Telas1440 e390px sem corte horizontal; console comzeroerros eavisos. Capturas em output/playwright/all-day. Nenhuma ação real no Instagram.

## Recuperação do preparo — 0.20.4

Um timeout tipado antes da reserva da tentativa e de qualquer envio de FOLLOW pode reagendar a preparação, preservando os vínculos atuais de conta, candidato, fonte e autorizações. As esperas progridem de 1 para 3, 10 e depois 15 minutos; cada preparação refaz os controles em outra aba. Pausa, mudanças de configuração/preferências, troca, aviso ou restauração cancelam. Depois da reserva ou de um resultado incerto, não há repetição automática de ação. Timeouts PageDeadlineError na leitura de fontes também recebem o mesmo backoff, somente com conta, runId em checking e autorizações global/fonte vigentes. readRetry agenda a nova consulta sem importar resultados parciais; commit válido o limpa. Falhas de identidade, avisos e indisponibilidade continuam exigindo os controles de parada/conferência. Contrato, estado da implementação e limites em [RECUPERACAO-PRE-CLIQUE-0.20.4.md](RECUPERACAO-PRE-CLIQUE-0.20.4.md); não se trata de comprovação de operação ininterrupta.
